import {
  BrowserRouter,
  Route,
  Routes,
  Redirect,
  Navigate,
  ReactRoutes,
  useNavigate,
} from "react-router-dom";
import Login from "../component/Auth/Login/container";
import ForgotPassword from "../component/Auth/ForgotPassword/container";
import AuthenticatedRoute from "../component/AuthenticatRoute/index";
import ForgotOTP from "../component/Auth/ForgotOTP/container";
import { useEffect, useState } from "react";
import Home from "../component/Home/container";
import { createBrowserHistory } from "history";
import ReduxToastr from "react-redux-toastr";
import { Loginpopup } from "../component/Auth/LoginPopup/Loginpopup";
import ChangePassword from "../component/Auth/ChangePassword/container";
import "../../node_modules/react-redux-toastr/lib/css/react-redux-toastr.min.css";
import UserBasicContainer from "../component/Navigation/UsersRoleComp/UserDetails/container";
import CreateUser from "../component/UserCreate/container.js";
import CohortContainer from "../component/AddCohort/container.js";
import AddWarehouseContainer from "../component/AddWarehouseComp/container";
import { SuccessComp } from "../component/UserCreate/successComp";
import UpdateCohortContainer from "../component/Navigation/UsersRoleComp/UpdateUserDetails/UpdateCohort/container";
import UpdateWarehouseContainer from "../component/Navigation/UsersRoleComp/UpdateUserDetails/UpdateWareHouse/container";
import UpdateUserDetails from "../component/Navigation/UsersRoleComp/UpdateUserDetails/container";
import OrderListContainer from "../component/OrderComp/OrdersList/container";
import { LandingPage } from "../component/Auth/Grettingpage/component";
import OrdersViewContainer from "../component/OrderComp/OrdersDetails/container";
import UserPermissionContainer from "../component/UserPermission/container";
import Changepasswordsuccess from "../component/Auth/ChangepasswordSuccess/component";
import { OrderRefundComponent } from "../component/OrderComp/OrderRefund/component";
import OrdersRefundContainer from "../component/OrderComp/OrderRefund/container";
import CouponContainer from "../component/CouponComp/CouponCreate/container";
import CouponDesContainer from "../component/CouponComp/CouponDescription/container";
import CouponImageContainer from "../component/CouponComp/CouponImage/container";
import CouponDateContainer from "../component/CouponComp/CouponDate/container";
import CouponDeeplinkContainer from "../component/CouponComp/CouponDeepLink/container";
import CouponAmountContainer from "../component/CouponComp/CouponAmount/container";
import CouponTypeContainer from "../component/CouponComp/CouponType/container";
import { CouponCashbackComponent } from "../component/CouponComp/CouponCashback/component";
import CouponCashbackContainer from "../component/CouponComp/CouponCashback/container";
import { CouponCashbackDiscountComponent } from "../component/CouponComp/CouponDiscount/component";
import { CouponVMComponent } from "../component/CouponComp/CouponVM/component";
import CouponVMContainer from "../component/CouponComp/CouponVM/container";
import CouponAplicableItemContainer from "../component/CouponComp/CouponAplicableItem/container";
import CouponPGContainer from "../component/CouponComp/CouponPG/container";
import CouponUseDurationContainer from "../component/CouponComp/CouponUseDuration/container";
import CouponLimitContainer from "../component/CouponComp/CouponLimit/container";
import CouponDiscountCompContainer from "../component/CouponComp/CouponDiscountComp/container";
import CouponFreegiftContainer from "../component/CouponComp/CouponFreeGift/container";
import CouponSuccessContainer from "../component/CouponComp/CouponSuccess/container";
import BrandcategorizationContainer from "../component/walletsAndTags/BrandCategorization/container";
import VMRsuggestionContainer from "../component/VMComponent/VMRefillSuggestion/container";
import CouponTermandConditionContainer from "../component/CouponComp/CouponT&C/container";
import ConfigurepayoutContainer from "../component/Configuration/ConfigurePayout/container";
import CreateFranchiesComponent from "../component/Configuration/ConfigurePayout/CreateFranchies/component";
import ManagePartnersListContainer from "../component/Configuration/ManagePartner/ManagePartnerList/container";
import ManagePartnersDetailsContainer from "../component/Configuration/ManagePartner/ManagePartnerDetails/container";
import UpdateCohortDetailsContainer from "../component/Configuration/UpdateCohortDetails/container";
import UpdateFranchiseeDetailsContainer from "../component/Configuration/UpdateFranchiseeDetails/container";
import UpdateBankDetailsContainer from "../component/Configuration/UpdateBankDetails/container";
import UpdateMapChargesContainer from "../component/Configuration/UpdateMapCharges/container";
import TagpayListContainer from "../component/walletsAndTags/TagpayManagement/TagpayList/container";
import TagpayCreateContainer from "../component/walletsAndTags/TagpayManagement/CreateTagpay/container";
import TagpayDetailsContainer from "../component/walletsAndTags/TagpayManagement/TagpayListDetails/container";
import TagpayListComponent from "../component/walletsAndTags/TagpayManagement/TagpayList/component";
import BPListContainer from "../component/CustomerManager/BPManagement/BPList/container";
import BPCreateContainer from "../component/CustomerManager/BPManagement/CreateBP/container";
import VmCreateContainer from "../component/Configuration/VMCreation/NewVMCreation/container";
import VmListContainer from "../component/Configuration/VMCreation/VmList/container";
import VMDetailsContainer from "../component/Configuration/VMCreation/VMDetails/container";
import VMDecomissionContainer from "../component/Configuration/VMCreation/VMDecomission/container";
import VMCloneContainer from "../component/Configuration/VMCreation/VMClone/container";
import VmEditContainer from "../component/Configuration/VMCreation/VMEditDetails/container";
import ReportAndAnalysticsListContainer from "../component/OrderComp/ReportAndAnalystics/container";
import ScreensaversListContainer from "../component/ScreenSaversComp/container";
import DaalchiniPointsListContainer from "../component/walletsAndTags/DaalchiniPointComp/container";
import CohortListContainer from "../component/VMComponent/CohortsComp/container";
import WarehouseContainer from "../component/VMComponent/WarehouseComp/container"
import ProductListContainer from "../component/VMComponent/ProductComp/container"
import ProductVariantDetailsContainer from "../component/VMComponent/ProductComp/ProductVariantDetails/container.js"

import CreateMfidContainer from "../component/VMComponent/ProductComp/CreateMFIDComp/container"
import UpdateMfidContainer from "../component/VMComponent/ProductComp/EditMFIDComp/container";
import CreateVendorContainer from "../component/VMComponent/ProductComp/CreateVendorComp/container.js";

function App() {
  const [auth, setAuth] = useState(localStorage.getItem("data"));
  const [isAuthenticated, setIsAuthenticated] = useState(
    localStorage.getItem("data")
  );
  const navigate = useNavigate();
  useEffect(() => {
    const storedData = localStorage.getItem("data");
    setIsAuthenticated(storedData);

    if (!storedData && window.location.pathname.startsWith("/home")) {
      navigate("/");
    }
  }, [navigate]);

  //const shouldRenderChangePassword = !isAuthenticated;
  const history = createBrowserHistory();
  console.log("auth -----");

  return (
    <div>
      <Routes history={history}>
        {/* <Route path="/" element={<Login />} />
        <Route path="/home" element={<AuthenticatedRoute element={<LandingPage />} />} /> */}
        <Route path="/" element={<Login />} />
        <Route
          path="/home/*"
          element={
            isAuthenticated ? <LandingPage /> : <Navigate to="/" replace />
          }
        />

        <Route
          path="/forgetpassword"
          element={
            isAuthenticated ? <Navigate to="/" replace /> : <ForgotPassword />
          }
        />
        {/* <Route path="/changepassword" exact element={<ChangePassword />} /> */}

        <Route path="/forgototp" exact element={<ForgotOTP />} />
        <Route path="/changepassword" exact element={<ChangePassword />} />
        <Route path="/loginpopup" exact element={<Loginpopup />} />
        <Route
          path="/home/users/list"
          exact
          element={<UserPermissionContainer />}
        />

        <Route path="/createuser" exact element={<CreateUser />} />
        <Route path="/createcohort" exact element={<CohortContainer />} />
        <Route path="/addwarehouse" exact element={<AddWarehouseContainer />} />
        <Route path="/successpage" exact element={<SuccessComp />} />
        <Route
          path="/changepasswordsuccess"
          exact
          element={<Changepasswordsuccess />}
        />

        {/* Orders module start */}

        <Route exact path="/home/ordersview" element={<OrderListContainer />} />
        <Route
          exact
          path="/users/userlist/:userid"
          element={<UserBasicContainer />}
        />
        <Route
          path="/home/ordersview/:orderid"
          element={<OrdersViewContainer />}
        />

        <Route
          path="/home/orderview/manualrefund/:pg_name/:id"
          element={<OrdersRefundContainer />}
        />

        {/* Orders module end           */}

        <Route
          path="/updateuserdetails/:userid"
          element={<UpdateUserDetails />}
        />
        <Route
          path="/updatecohortdetails/:userid"
          element={<UpdateCohortContainer />}
        />
        <Route
          path="/updatewarehouse/:userid"
          element={<UpdateWarehouseContainer />}
        />

        {/* Coupon start */}

        <Route path="/home/couponcreate" element={<CouponContainer />} />

        <Route
          path="/home/coupondescription"
          element={<CouponDesContainer />}
        />
        <Route path="/home/couponimage" element={<CouponImageContainer />} />

        <Route path="/home/coupondate" element={<CouponDateContainer />} />
        <Route
          path="/home/coupondeeplink"
          element={<CouponDeeplinkContainer />}
        />
        <Route
          path="/home/coupondiscountamount"
          element={<CouponAmountContainer />}
        />
        <Route path="/home/coupontype" element={<CouponTypeContainer />} />
        <Route
          path="/home/couponcashback"
          element={<CouponCashbackContainer />}
        />
        <Route
          path="/home/couponcashbackdiscount"
          element={<CouponCashbackDiscountComponent />}
        />
        <Route path="/home/couponvmcreation" element={<CouponVMContainer />} />
        <Route
          path="/home/couponaplicableitem"
          element={<CouponAplicableItemContainer />}
        />
        <Route path="/home/couponpg" element={<CouponPGContainer />} />
        <Route
          path="/home/couponuseduration"
          element={<CouponUseDurationContainer />}
        />
        <Route path="/home/couponlimit" element={<CouponLimitContainer />} />
        <Route
          path="/home/coupondiscountcomp"
          element={<CouponDiscountCompContainer />}
        />
        <Route
          path="/home/couponfreegift"
          element={<CouponFreegiftContainer />}
        />
        <Route
          path="/home/couponsuccess"
          element={<CouponSuccessContainer />}
        />
        <Route
          path="/home/coupontnc"
          element={<CouponTermandConditionContainer />}
        />

        {/* Coupon end */}
        <Route
          path="/home/brandcategorization"
          element={<BrandcategorizationContainer />}
        />

        <Route
          path="/home/refillsuggestion"
          element={<VMRsuggestionContainer />}
        />

        <Route
          path="/home/configuration/managepartners"
          element={<ManagePartnersListContainer />}
        />
        <Route
          path="/home/configuration/managepartnersdetails/:id/:cohortId/:franchiseeId"
          element={<ManagePartnersDetailsContainer />}
        />

        <Route
          path="/home/createfranchies"
          element={<ConfigurepayoutContainer />}
        />

        <Route
          path="/home/updatecohortdetails/:cohortId"
          element={<UpdateCohortDetailsContainer />}
        />
        <Route
          path="/home/updatefranchiseedetails/:franchiseeId"
          element={<UpdateFranchiseeDetailsContainer />}
        />
        <Route
          path="/home/updatebankdetails/:franchiseeId"
          element={<UpdateBankDetailsContainer />}
        />
        <Route
          path="/home/updatemapcharges/:franchiseeId"
          element={<UpdateMapChargesContainer />}
        />

        <Route
          path="/home/walletandtag/tagpymanagement"
          element={<TagpayListContainer />}
        />
        <Route
          path="/home/walletandtag/tagpymanagementdetails/:seriesId"
          element={<TagpayDetailsContainer />}
        />

        <Route
          path="/home/walletandtag/tagpymanagement/createtagpay"
          element={<TagpayCreateContainer />}
        />

        <Route
          path="/home/customermanager/bpmanagementlist"
          element={<BPListContainer />}
        />
        <Route
          path="/home/customermanager/bpmanagement/createcorporate"
          element={<BPCreateContainer />}
        />

        <Route
          path="/home/configuration/vmcreation/newvmcreation"
          element={<VmCreateContainer />}
        />
        <Route
          path="/home/configuration/vmlist"
          element={<VmListContainer />}
        />
        <Route
          path="/home/configuration/vmdetails/:id"
          element={<VMDetailsContainer />}
        />
        <Route
          path="/home/configuration/vmdecomission/:id"
          element={<VMDecomissionContainer />}
        />
        <Route
          path="/home/configuration/vmclone/:id"
          element={<VMCloneContainer />}
        />
        <Route
          path="/home/configuration/vmeditdetails/:vmId"
          element={<VmEditContainer />}
        />
         <Route
          path="/home/reportsandanalytics"
          element={<ReportAndAnalysticsListContainer />}
        />
        <Route
          path="/home/addcenter/screensavers"
          element={<ScreensaversListContainer />}
        />
         <Route
          path="/home/walletsandtags/daalchinipoints"
          element={<DaalchiniPointsListContainer />}
        />
         <Route
          path="/home/configuration/cohorts"
          element={<CohortListContainer />}
        />
         <Route
          path="/home/configuration/warehouse"
          element={<WarehouseContainer />}
        />
         <Route
          path="/home/configuration/products"
          element={<ProductListContainer />}
        />
          <Route
          path="/home/configuration/productsvariantdetails/:variantId"
          element={<ProductVariantDetailsContainer />}
        />
          <Route
          path="/home/configuration/productsvariantdetails/createmfid/:variantId"
          element={<CreateMfidContainer />}
        />
         <Route
          path="/home/configuration/productsvariantdetails/updatemfid/:id/:variantId"
          element={<UpdateMfidContainer />}
        />
          <Route
          path="/home/configuration/productsvariantdetails/createnewvendor"
          element={<CreateVendorContainer />}
        />
        
      </Routes>
      <ReduxToastr
        newestOnTop={false}
        preventDuplicates
        position="top-right"
        transitionIn="fadeIn"
        transitionOut="fadeOut"
        progressBar
        closeOnToastrClick={false}
      />
    </div>
  );
}

export default App;
