/* eslint-disable */
// import { type } from '@testing-library/user-event/dist/type';
import { CLEAR_STATE, HANDLE_API_CALLS, HANDLE_API_CALLS_URL, LOGOUT_USER} from './constants';

export function getDataFromAPI(
  url,
  method,
  body,
  handleSuccess,
  handleError,
  showToast = false,
) 

{
  console.log("working getDataFromAPI")
  
  return {
    type: HANDLE_API_CALLS,
    url,
    method,
    body,
    handleSuccess,
    handleError,
    showToast,
  };
}
export function logoutuser (){
  return{
    type: LOGOUT_USER,
  }
  
}

export function clearState() {
  return {
    type: CLEAR_STATE,
  };
}








