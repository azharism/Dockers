import axios from 'axios';
import {call, put, select, takeEvery} from 'redux-saga/effects';
import {toastr} from 'react-redux-toastr';
import {push} from 'react-router-redux';
import {CLEAR_STATE, HANDLE_API_CALLS} from './constants';
import {setLoading} from '../component/Auth/Login/action'
import {BASE_URL} from '../config/API';

function callToAPI(method, url, data, { login }) {
  const ls = localStorage.getItem('data');
  const token = ls ? JSON.parse(ls).accessToken : '';
  // console.log(params);
 
  return axios({
    method,
    url: `${BASE_URL}${url}`,
    data,
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
}
 function logoutUser() {
 /*  localStorage.removeItem('data'); */
} 


// worker saga: makes the api call when watcher saga sees the action
function* handleAPICalls(action) {
  console.log('url--------hand------call saga api------>', action.url);
  const state = yield select(); // get teh current state
  try {
    const response = yield call(callToAPI, action.method, action.url, action.body, state);
    // console.log('response at saga ==> ', response);
    if (action.handleSuccess) {
      return yield call(action.handleSuccess, response.data.data);
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(err);
    if (err.response && err.response.status === 401) {
      toastr.error('Error', 'Please login to continue');
      yield call(logoutUser);
      yield put(setLoading(false));
      yield put({ type: CLEAR_STATE });
      yield put(push('/home'));
    } else if (err.response && err.response.status === 404) {
      if (!action.showToast) {
        toastr.error('ERROR', 'Not found Invalid request!');
      }
      if (action.handleError) {
        yield call(action.handleError, err.response);
      }
    } else if (action.response !== 402) {
      if (!action.showToast) {
        // toastr.error('ERROR', 'Failed to request');
      }
      if (action.handleError) {
        yield call(action.handleError, err.response.data);
      }
    }
  }
  return 0;
}


/* function callToAPIURL(method, url, data, { login }) {
  const ls = localStorage.getItem('data');
  const token = ls ? JSON.parse(ls).accessToken : '';
   
  
  
  return axios({
    method,
    url: `${url}`,
    data,
    headers: {
      'x-auth-token': (login && login.user && login.user.accessToken) || token
    }
  });
} */

function* handleAPICallsURL(action) {
  console.log('url--------hand------call saga api------>', action.url);
  const state = yield select(); // get teh current state
  try {
    const response = yield call(callToAPI, action.method, action.url, action.body, state);
    // console.log('response at saga ==> ', response);
    if (action.handleSuccess) {
      return yield call(action.handleSuccess, response.data);
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(err);
    if (err.response && err.response.status === 401) {
      toastr.error('Error', 'Please login to continue');
      yield call(logoutUser);
      yield put(setLoading(false));
      yield put({ type: CLEAR_STATE });
      yield put(push('/home'));
    } else if (err.response && err.response.status === 404) {
      if (!action.showToast) {
        toastr.error('ERROR', 'Not found Invalid request!');
      }
      if (action.handleError) {
        yield call(action.handleError, err.response);
      }
    } else if (action.response !== 402) {
      if (!action.showToast) {
        toastr.error('ERROR', 'Failed to request');
      }
      if (action.handleError) {
        yield call(action.handleError, err.response.data);
      }
    }
  }
  return 0;
}




// watcher saga: watches for actions dispatched to the store, starts worker saga
function* callToAPIWatcher() {
 yield takeEvery(HANDLE_API_CALLS, handleAPICalls);

}


/* eslint-disable */
export { callToAPIWatcher, };

/* eslint-enable */
