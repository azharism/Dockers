import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import { reducer as toastrReducer } from 'react-redux-toastr';
import loginReducer from '../component/Auth/Login/reducer';
import forgetpassword from '../component/Auth/ForgotPassword/reducer'
import forgetotp from '../component/Auth/ForgotOTP/reducer'
import changePassword from '../component/Auth/ChangePassword/reducer';
import createNewuser from '../component/CreateUserComp/reducer'
import CouponContainer from '../component/CouponComp/CouponCreate/reducer'
export default combineReducers({
    login: loginReducer,
    toastr: toastrReducer,
    forgetpassword:forgetpassword,
    forgetotp:forgetotp,
    changePassword:changePassword,
    createNewuser:createNewuser,
    coupon:CouponContainer
})