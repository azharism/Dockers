import React from 'react';
import ReactDOM from 'react-dom';
import { createStore, applyMiddleware, compose } from 'redux';
import { Provider } from 'react-redux';
import { ConnectedRouter, routerMiddleware } from 'react-router-redux';
import { createBrowserHistory } from 'history';
import createSagaMiddleware from 'redux-saga';
import rootReducer from './reducers/index';
import rootSaga from './sagas/index'; 
import Login from "../src/component/Auth/Login/container" 
import * as ReactDOMClient from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';

import App from '../src/Routes/App';
const initialState = {};
const history = createBrowserHistory();
const sagaMiddleware = createSagaMiddleware();
const middlewares = [sagaMiddleware, routerMiddleware(history)];
const enhancers = [applyMiddleware(...middlewares)];

const composeEnhancers =
  process.env.NODE_ENV !== 'production' &&
    typeof window === 'object' &&
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
    ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({
      shouldHotReload: false,
    })
    : compose;

const store = createStore(
  rootReducer,
  initialState,
  composeEnhancers(...enhancers),
);

store.runSaga = sagaMiddleware.run(rootSaga, store.dispatch);

const root = ReactDOMClient.createRoot(document.getElementById('root'));root.render(
  <React.StrictMode>
    <BrowserRouter>
     <Provider store={store}>
     {/*  <ConnectedRouter> */}
    
      < App />
      
      {/* </ConnectedRouter> */}
  </Provider>
  </BrowserRouter>
  </React.StrictMode>
);

