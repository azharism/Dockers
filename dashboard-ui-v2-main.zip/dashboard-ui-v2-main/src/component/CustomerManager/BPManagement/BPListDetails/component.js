import React from "react";
import "./style.css";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import search from "../../../../assests/search.svg";
import Button from "@mui/material/Button";
import refundpay from "../../../../assests/refundpay.svg";
import Switch from "@mui/material/Switch";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import recevied from "../../../../assests/recevied.svg";
import recharge from "../../../../assests/recharge.svg";
import rechargeIcon from "../../../../assests/rechargeIcon.svg";
import cross from "../../../../assests/cross.svg";
import { useNavigate, useParams } from "react-router-dom";
import LoadingSpinner from "../../../Loading/component";

const TagpayDetailsComponent = (props) => {
  const {
    loading,
    fetchRechargeDetails,
    searchValue,
    handleSearchInputChange,
    updateCardStatusApi,
    handleSubmit,
    setAmount,
    handleToggleAll,
    isAllActive,
    isRechargePopupOpen,
    handleOpenRechargePopup,
    handleRechargeAmountChange,
    handleRechargeSubmit,
    deactivateAllCards,
    handleCloseRechargePopup,
    rechargeAmount,
    uid,
    handleToggleCardStatus,
    selectedView,
    setSelectedView,
    handleActivateAll,
    deactivateAllCardStatus,
  } = props;
  const navigate = useNavigate();
  const goback = () => {
    navigate(-1);
  };

  const renderActivateDeactivateButtons = () => {
    if (selectedView === "active") {
      return (
        <Button
          variant="contained"
          color="primary"
          onClick={deactivateAllCards}
          style={{ width: "120px", color: "#fff" }}
        >
          Deactivate All
        </Button>
      );
    } else if (selectedView === "inactive") {
      return (
        <Button
          variant="contained"
          color="primary"
          onClick={handleActivateAll}
          style={{ width: "120px", color: "#fff" }}
        >
          Activate All
        </Button>
      );
    } else if (selectedView === "all") {
      return (
        <Button
          variant="contained"
          color="primary"
          onClick={handleActivateAll}
          style={{ width: "120px", color: "#fff", backgroundColor:"#3282FF" }}
          disabled 
        >
          Deactivate all
          {/* {selectedView === "inactive" ? "Deactivate All" : "Activate All"} */}
        </Button>
      );
    }
  
    return null;
  };
  
  
  
  
  
  
  
  

  return (
    <div className="main-div">
      <Sidebar />
      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
              onClick={goback}
            />{" "}
            All Tags
          </h2>
        </div>
        <div
          className="tagpaysearch"
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <div
            className="tagpaysearch"
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <div className="input-container">
              <input
                type="search"
                placeholder="Search by Tag ID"
                value={searchValue}
                onChange={handleSearchInputChange}
              />
              <button className="search-icon" onClick={handleSearchInputChange}>
                <img src={search} alt="" />
              </button>
            </div>
            <div className="select-container">
              <select
                className="selectTags"
                name=""
                id=""
                value={selectedView}
                onChange={(e) => setSelectedView(e.target.value)}
              >
                <option value="all">View All Tags</option>
                <option value="active">View Active Tags</option>
                <option value="inactive">View Inactive Tags</option>
              </select>
            </div>

            <div style={{ marginTop: "20px" }}>
              {/* <Button
  variant="contained"
  color="primary"
  onClick={handleToggleAll}
  style={{ width: "120px", color: "#fff" }}
>
  {isAllActive ? "Deactivate All" : "Activate All"}
</Button> */}
              {renderActivateDeactivateButtons()}
            </div>
          </div>
        </div>

        {loading ? (
          <LoadingSpinner />
        ) : (
          <div className="vmtablebrand">
            <div
              style={{
                padding: "20px",
                display: "flex",
                alignItems: "center",
                flexWrap: "wrap",
                overflow: "auto",
              }}
            >
              {fetchRechargeDetails.map((tagDetail) => (
                <div key={tagDetail.uid}>
                  <Card
                    sx={{ width: 437, height: 287, margin: 1 }}
                    className={
                      tagDetail.status === "active"
                        ? "card-active"
                        : "card-inactive"
                    }
                  >
                    <CardContent style={{ display: "flex" }}>
                      <div>
                        <img
                          style={{ marginRight: "8px" }}
                          src={
                            tagDetail.status === "inactive"
                              ? refundpay
                              : recevied
                          }
                          alt=""
                        />
                      </div>
                      <div style={{ position: "relative", left: "120px" }}>
                        <h3 className="logore-fund1">₹ 10</h3>
                        <Switch
                          defaultChecked={tagDetail.status === "active"}
                          color="success"
                          checked={tagDetail.status === "active"}
                          onChange={() =>
                            handleToggleCardStatus(
                              tagDetail.uid,
                              tagDetail.status
                            )
                          }
                        />
                      </div>
                      <div className="detailsText">
                        <p>tagId: {tagDetail.uid}</p>
                        <p>status: {tagDetail.status}</p>
                      </div>
                    </CardContent>
                    <CardActions>
                      {tagDetail.status === "inactive" ? (
                        <Button
                          variant="contained"
                          disabled={true}
                          className={`Button1 inactive-button`}
                          style={{
                            marginTop: "auto",
                            color: "white",
                            backgroundColor: "#808080",
                          }}
                        >
                          <img src={recharge} alt="" />
                          Recharge
                        </Button>
                      ) : (
                        <Button
                          variant="contained"
                          className={`Button1`}
                          style={{ marginTop: "auto" }}
                          onClick={() =>
                            handleOpenRechargePopup(
                              tagDetail.uid,
                              tagDetail.amount,
                              tagDetail.reason
                            )
                          }
                        >
                          <img src={recharge} alt="" />
                          Recharge
                        </Button>
                      )}
                    </CardActions>
                  </Card>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {isRechargePopupOpen && (
        <>
          <div className="overlay1"></div>
          <div className="recharge-popup">
            <div className="recharge-popup-content">
              <div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "start",
                    position: "relative",
                    right: "330px",
                  }}
                >
                  <img src={rechargeIcon} alt="" />
                  <h2
                    style={{
                      marginLeft: "10px",
                      marginTop: "2px",
                      fontSize: "20px",
                      color: "#3282FF",
                    }}
                  >
                    Recharge
                  </h2>
                </div>
                <div
                  style={{
                    display: "flex",
                    position: "relative",
                    left: "90px",
                    bottom: "40px",
                  }}
                >
                  <img onClick={handleCloseRechargePopup} src={cross} alt="" />
                </div>
              </div>

              <p
                style={{
                  fontSize: "18px",
                  fontWeight: "500",
                  color: "#3B3B3B",
                }}
              >
                Tag ID: {uid}
              </p>
              <input
                style={{ borderRadius: "16px" }}
                type="text"
                placeholder="Enter recharge amount"
                value={rechargeAmount}
                onChange={handleRechargeAmountChange}
              />
              <Button
                style={{
                  backgroundColor: "#14AE78",
                  width: "100%",
                  color: "#ffffff",
                  fontSize: "16px",
                  fontWeight: "600",
                  borderRadius: "16px",
                }}
                onClick={handleRechargeSubmit}
              >
                Recharge
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default TagpayDetailsComponent;
