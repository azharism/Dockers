import React from "react";
import "./component.css";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";

const CreateCorporateComponent = (props) => {
  return (
    <div className="cohortsec1">
      <div style={{ marginLeft: "40px" }}>
        <Box
          sx={{
            width: 500,
            maxWidth: "100%",
          }}
          style={{ marginTop: "90px", marginRight: "20px" }}
        >
          <TextField
            style={{ margin: "14px" }}
            fullWidth
            label="Corporate Name *"
            name="name"
            value={props.createCorporateData.name}
            onChange={props.handleChangeCorporate}
          />
          
          <TextField
            style={{ margin: "14px" }}
            fullWidth
            label="Domain *"
            name="domain"
            value={props.createCorporateData.domains[0].domain}
            onChange={props.handleChangeCorporate}
          />

          <TextField
            style={{ margin: "14px", color:"red" }}
            fullWidth
            label="Initial Balance *"
            name="initial_balance"
            value={props.createCorporateData.domains[0]?.initial_balance || ""}
            onChange={(e) => {
              const { name, value } = e.target;
              props.setCreateCorporateData((prevData) => ({
                ...prevData,
                domains: [
                  {
                    ...prevData.domains[0],
                    [name]: value,
                  },
                ],
              }));
            }}
          />
          <TextField
            style={{ margin: "14px" }}
            fullWidth
            label="Auto Expiry Month"
            name="expiry_date_month"
            value={props.createCorporateData.expiry_date_month}
            onChange={props.handleChangeCorporate}
          />
        
        </Box>
      </div>
    </div>
  );
};

export default CreateCorporateComponent;
