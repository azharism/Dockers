import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import TagpayCreateComponent from "./component";
import BPCreateComponent from "./component";

export const steps = [
  "Create Corporate",
  "Add User",
  "Recharge Rule",
  "Usage Limit",
];

const BPCreateContainer = (props) => {
  const [activeStep, setActiveStep] = useState(0);

  const [createCorporateData, setCreateCorporateData] = useState({
    name: "",
    expiry_date_month: "",
    domains: [{ domain: "", description: "", initial_balance: "" }],
  });
  const [createUser, setCreateUser] = useState({
    employeeId: "",
    employeeEmail: "",
    employeeName: "",
  });
  const [useageLimit, setUseageLimit] = useState([]);
  const [userLimit, setUserLimit] = useState({
    value: "",
    limit_type_id: "",
  });

  const [corporateId, setCorporateId] = useState(null);
  const [activeBtn, setActiveBtn] = useState("");
  const [activeBtn1, setActiveBtn1] = useState("");
  const [rechargeData, setRechargeData] = useState({
    monthly: {
      amount: "",
      reset_balance: true,
    },
    add_on: {
      amount: "",
      low_balance: "",
    },
  });

  const navigate = useNavigate();

  const handleNext = async () => {
    console.log("handleNext function called");

    if (activeStep === 0) {
      handleCreateCorporate();
      // if (validateStepOne()) {
      //   await handleCreateCorporate();

      // } else {
      //   toastr.error(
      //     "Validation Error",
      //     "Please complete all required fields For create the Corporate"
      //   );
      // }
    } else if (activeStep === 1) {
      handleAddUser();
      // if (validateStepTwo()) {
      //   await printTagId();
      //   setActiveStep((prevStep) => prevStep + 1);
      // } else {
      //   toastr.error(
      //     "Validation Error",
      //     "Please complete all required fields "
      //   );
      // }
    } else if (activeStep === 2) {
      handleRechargeApi();
      // if (validateStepThree()) {
      //   await handleActivateTagApi();
      //   setActiveStep((prevStep) => prevStep + 1);
      // } else {
      //   toastr.error(
      //     " Error",
      //     "Please select at least one checkbox For Activate Tag"
      //   );
      // }
    } else if (activeStep === 3) {
      handleUserLimit();
    }
  };

  const validateStepOne = () => {
    const { name, expiry_date_month } = handleChangeCorporate;

    if (!name || !expiry_date_month) {
      return false;
    }

    return true;
  };

  const validateStepTwo = () => {
    return true;
  };

  const validateStepThree = () => {
    return true;
  };

  const handleClose = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleAddRechargeBtnClick = (value) => {
    setActiveBtn(value);
  };
  const handleAddRechargeBtnClick1 = (value) => {
    setActiveBtn1(value);
  };

  const handleChangeCorporate = (e) => {
    const { name, value } = e.target;

    if (name === "domain") {
      const updatedDomains = [...createCorporateData.domains];
      updatedDomains[0] = {
        ...updatedDomains[0],
        domain: value,
      };

      setCreateCorporateData({
        ...createCorporateData,
        domains: updatedDomains,
      });
    } else {
      // For other fields, update directly
      setCreateCorporateData({
        ...createCorporateData,
        [name]: value,
      });
    }
  };

  const handleCreateCorporate = () => {
    const payload = {
      name: createCorporateData.name,
      expiry_date_month: createCorporateData.expiry_date_month,
      domains: createCorporateData.domains.map((domain) => ({
        domain: domain.domain,
        // description: domain.description || '', //
        initial_balance: domain.initial_balance || "",
      })),
    };

    props.getDataFromAPI(
      `/partner/api/v2/corporate`,
      "POST",
      payload,
      (response) => {
        console.log("API success response:", response);

        if (response && response) {
          const getId = response.id;
          setCorporateId(getId);
          console.log("get corp id", getId);
          // toastr.error("Failed", "Unable to create Corporate Series");
          setActiveStep((prevStep) => prevStep + 1);
          toastr.success("Success", "Corporate Series created successfully");
        }
      },
      (err) => {
        console.log("Error creating franchisee:", err);
        toastr.error(`${err.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
    );
  };

  const handleChangeUser = (e) => {
    const { name, value } = e.target;
    setCreateUser((prevUser) => ({
      ...prevUser,
      [name]: value,
    }));
  };

  const handleAddUser = () => {
    const userPayload = {
      userInfoList: [
        {
          index: 1,
          employeeId: createUser.employeeId,
          employeeName: createUser.employeeName,
          employeeEmail: createUser.employeeEmail,
          businessName: createCorporateData.name,
        },
      ],
    };
    props.getDataFromAPI(
      `/partner/api/v1/business-profile/${corporateId}`,
      "POST",
      userPayload,
      (response) => {
        console.log("API success response:", response);

        if (response && response) {
          setActiveStep((prevStep) => prevStep + 1);
          toastr.success("Success", "Corporate  user created successfully");
        }
      },
      (err) => {
        console.log("Error creating franchisee:", err);
        toastr.error(`${err.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
    );
  };

  const handleChangeRecharge = (event, field) => {
    const { name, value } = event.target;

    setRechargeData((prevData) => ({
      ...prevData,
      [field]: {
        ...prevData[field],
        [name]: value,
      },
    }));
  };

  const handleResetBalanceChange = (value) => {
    setRechargeData((prevData) => ({
      ...prevData,
      monthly: {
        ...prevData.monthly,
        reset_balance: value,
      },
    }));
  };

  const handleRechargeApi = () => {
    const payload = {
      monthly: {
        name: `bp_monthly_${corporateId} `,
        amount: parseInt(rechargeData.monthly.amount),
        reset_balance: rechargeData.monthly.reset_balance,
      },
    };

    if (activeBtn === "Yes") {
      payload.add_on = {
        name: `bp_monthly_addon_${corporateId} `,
        amount: parseInt(rechargeData.add_on.amount),
        low_balance: parseInt(rechargeData.add_on.low_balance),
      };
    }
    if (!rechargeData.monthly.reset_balance) {
      payload.monthly.name = `bp_monthly_reset_${corporateId}`;
    }
    props.getDataFromAPI(
      `/partner/api/v2/corporate/${corporateId}/plan?account_type=WALLET`,
      "PUT",
      payload,
      (response) => {
        console.log("API success response:", response);

        if (response && response) {
          toastr.success("Success", "Recharge data added successfully");
          setActiveStep((prevStep) => prevStep + 1);
        } else {
          console.log("Failed to add recharge data:", response);
          toastr.error("Failed", "Unable to add recharge data");
        }
      },
      (err) => {
        console.log("Error adding recharge data:", err.message);
        toastr.error(`${err.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
    );
  };

  const handleChangeUserLimit = (e) => {
    const { name, value } = e.target;
    console.log(`${name}:`, value);
    setUserLimit((prevUser) => ({
      ...prevUser,
      [name]: name === "limit_type_id" ? parseInt(value, 10) : value,
    }));
  };

  const handleSelectChange = (selectedValue) => {
    setUserLimit((prevUserLimit) => ({
      ...prevUserLimit,
      limit_type_id: selectedValue,
    }));
  };

  const handleUserLimit = () => {
    const userPayloadLimit =[{
      value: parseInt(userLimit.value),
      // limit_type_id: userLimit.limit_type_id !== null
      //   ? parseInt(userLimit.limit_type_id)
      //   : null,
      limit_type_id: parseInt(userLimit.limit_type_id),
    }
  ]
    props.getDataFromAPI(
      `/partner/api/v2/corporate/${corporateId}/limit?account_type=WALLET`,
      "PUT",
      userPayloadLimit,
      (response) => {
        console.log("API success response:", response);

        if (response && response) {
          setActiveStep((prevStep) => prevStep + 1);
          toastr.success("Success", "Corporate user created successfully");
          navigate("/home/customermanager/bpmanagementlist");
        }
      },
      (err) => {
        console.log("Error creating usage limit:", err);
        toast.error(`${err.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
    );
  };

  useEffect(() => {
    handleGetUseageList();
  }, []);

  const handleGetUseageList = () => {
    props.getDataFromAPI(
      `/partner/api/v2/corporate/limit-type`,
      "GET",
      undefined,
      (response) => {
        setUseageLimit(response);
        console.log("usage limit response:", response);
      },
      (err) => {
        toastr.error("Failed", "Unable to fetch tag series ");
      }
    );
  };

  return (
    <>
      <BPCreateComponent
        activeStep={activeStep}
        handleNext={handleNext}
        handleClose={handleClose}
        steps={steps}
        handleCreateCorporate={handleCreateCorporate}
        createCorporateData={createCorporateData}
        handleChangeCorporate={handleChangeCorporate}
        setCreateCorporateData={setCreateCorporateData}
        createUser={createUser}
        setCreateUser={setCreateUser}
        handleChangeUser={handleChangeUser}
        activeBtn={activeBtn}
        handleAddRechargeBtnClick={handleAddRechargeBtnClick}
        handleAddRechargeBtnClick1={handleAddRechargeBtnClick1}
        activeBtn1={activeBtn1}
        handleChangeRecharge={handleChangeRecharge}
        rechargeData={rechargeData}
        setActiveBtn={setActiveBtn}
        handleResetBalanceChange={handleResetBalanceChange}
        handleChangeUserLimit={handleChangeUserLimit}
        userLimit={userLimit}
        setUserLimit={setUserLimit}
        useageLimit={useageLimit}
        handleSelectChange={handleSelectChange}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}

export default connect(mapStateToProps, {
  getDataFromAPI,
})(BPCreateContainer);
