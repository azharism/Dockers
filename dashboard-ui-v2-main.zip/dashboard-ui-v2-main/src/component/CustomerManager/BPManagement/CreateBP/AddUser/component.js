
import React from "react";
import "./component.css";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";

const AddCorporateUserComponent = (props) => {
  return (
    <div className="cohortsec1" style={{ overflow: "scroll", height: "700px" }}>
      <div>
        <div
          style={{
            display: "flex",
            marginLeft: "20px",
            justifyContent: "space-evenly",
            flexWrap: "wrap",
          }}
        >
          
            <Box
             
              sx={{
                width: 380,
                maxWidth: "100%",
              }}
              style={{ marginTop: "90px", marginRight: "20px" }}
            >
              <TextField
  fullWidth
  label="Name"
  name="employeeName"
  value={props.createUser.employeeName}
  onChange={(e) => props.handleChangeUser(e)}
  style={{ margin: "14px" }}
/>
<TextField
  fullWidth
  label="Email"
  name="employeeEmail"
  value={props.createUser.employeeEmail}
  onChange={(e) => props.handleChangeUser(e)}
  style={{ margin: "14px" }}
/>
<TextField
  fullWidth
  label="EMP ID"
  name="employeeId"
  value={props.createUser.employeeId}
  onChange={(e) => props.handleChangeUser(e)}
  style={{ margin: "14px" }}
/>

              
            </Box>
         
        </div>
      </div>
    </div>
  );
};

export default AddCorporateUserComponent;
