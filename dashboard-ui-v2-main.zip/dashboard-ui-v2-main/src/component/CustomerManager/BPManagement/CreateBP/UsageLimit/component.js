import React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Form from 'react-bootstrap/Form';

const UsageLimitComponent = (props) => {
  const {
    handleSelectChange,
    handleChangeUserLimit,
    useageLimit,
    userLimit,
  } = props;

  return (
    <div className="cohortsec1">
      <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', marginLeft: '20px', justifyContent: 'space-evenly', flexWrap: 'wrap' }}>
          <Box
            sx={{
              width: 380,
              maxWidth: '100%',
            }}
            style={{ marginTop: '90px', marginRight: '20px' }}
          >
            <Form.Select
            style={{padding:"16px", borderRadius:"16px", marginLeft:"14px"}}
              aria-label="Default select example"
              name="limit_type_id"
              onChange={(e) => handleSelectChange(e.target.value)}
              value={userLimit.limit_type_id || ''}
            >
              <option> Select type id</option>
              {useageLimit &&
                useageLimit.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.type}_{item.sub_type}, {item.duration} {item.duration_unit.trim()}(s)
                  </option>
                ))}
            </Form.Select>

            <TextField
              fullWidth
              label="Value"
              name="value"
              value={userLimit.value}
              onChange={(e) => handleChangeUserLimit(e)}
              style={{ margin: '14px' }}
            />
          </Box>
        </div>
      </div>
    </div>
  );
};

export default UsageLimitComponent;
