import React, { useState } from "react";
import "./style.css";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import Table from "react-bootstrap/Table";
import eyeTag from "../../../../assests/eyeTag.svg";
import search from "../../../../assests/search.svg";
import emotions7 from "../../../../assests/emotions7.svg";
import Button from "@mui/material/Button";
import rechargeIcon from "../../../../assests/rechargeIcon.svg";
import addIcon from "../../../../assests/addicon.svg";
import { useNavigate, useParams } from "react-router-dom";
import redicon from "../../../../assests/redicon.svg";
import LoadingSpinner from "../../../Loading/component";

const BPListComponent = (props) => {
  const { seriesId } = useParams();
  console.log("seriesId:", seriesId);

  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };

  const navigate = useNavigate();

  const managePartnerDetails = (e, seriesId) => {
    navigate(`/home/walletandtag/tagpymanagementdetails/${seriesId}`);
  };

  return (
    <>
    {props.loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
<div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            BP Management
          </h2>
        </div>
        <div style={{ display: "flex", justifyContent: "end" }}></div>
        <div
          className="vmsearchdiv"
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <div className="input-container">
            <input
              type="search"
              placeholder="Search by Cop. ID / Corporate name"
              value={props.searchValue}
              onChange={props.handleSearchInputChange}
            />

            <button
              className="search-icon"
              onClick={props.handleFilterFranchisees}
            >
              <img src={search} alt="" />
            </button>
          </div>

          <div style={{ marginTop: "20px" }}>
            <Button
              variant="contained"
              color="primary"
              onClick={props.handleAddNewCorporate}
              style={{ width: "120px", color: "#fff" }}
            >
              + Add New
            </Button>
          </div>
        </div>
        <div className="vmtablebrand">
          <div
            ref={props.tableContainerRef}
            className="tableContainer"
            style={{
              height: "790px",
              overflow: "auto",
              margin: "auto",
              padding: "20px",
              width: "100%",
            }}
          >
            <Table striped hover>
              <thead>
                <tr
                  style={{
                    borderTop: "1px solid #ccc",
                    position: "relative",
                    top: "-30px",
                  }}
                >
                  <th> Sr.no</th>
                  <th> Corp. ID</th>
                  <th>Corporate Name</th>
                  <th>Status</th>
                  <th>Initial Balance</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {props.filteredTagSeriesList &&
                props.filteredTagSeriesList.length > 0 ? (
                  props.filteredTagSeriesList.map((item, index) => (
                    <React.Fragment key={item.index}>
                      <tr className="rowColor">
                        <td>{index + 1}</td>
                        <td>{item.id}</td>
                        <td>{item.name}</td>
                        <td>
                          <span
                            style={{
                              backgroundColor: item.is_active
                                ? "#E1FCD9"
                                : " #EB0000",
                              padding: "10px 27px",
                              borderRadius: "12px",
                              color: "#14AE78",
                            }}
                          >
                            {item.is_active ? "Active" : "Inactive"}
                          </span>
                        </td>

                        <td>
                          {item.domains && item.domains.length > 0
                            ? item.domains[0].initial_balance
                            : ""}
                        </td>
                        <td className="eyeIcon1">
                          <img src={eyeTag} alt="" />

                          <img
                            // onClick={(e) => managePartnerDetails(e, series.id)}
                            src={rechargeIcon}
                            alt=""
                            style={{
                              marginLeft: "10px",
                              cursor: "pointer",
                            }}
                          />
                          <img
                            src={redicon}
                            alt=""
                            style={{
                              marginLeft: "10px",
                              cursor: "pointer",
                            }}
                          />
                        </td>
                      </tr>
                    </React.Fragment>
                  ))
                ) : (
                  <></>
                  // ... (no data found message)
                )}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
)}
    </>


    
  );
};

export default BPListComponent;
