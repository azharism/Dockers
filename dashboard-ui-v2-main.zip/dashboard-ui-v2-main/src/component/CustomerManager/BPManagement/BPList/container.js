import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";

import { useParams } from "react-router-dom";
import { Link, useNavigate, useHistory } from "react-router-dom";

import BPListComponent from "./component";

const BPListContainer = (props) => {
  const { seriesId } = useParams;
  const navigate = useNavigate();
  const [BPList, setBPList] = useState([]);
  const [filteredTagSeriesList, setFilteredFranchiseeList] = useState([]);
  const [searchValue, setSearchValue] = useState("");
 


  const handleSearchInputChange = (event) => {
    const inputValue = event.target.value;
    setSearchValue(inputValue);
  };

  const handleAddNewCorporate=()=>{
    navigate("/home/customermanager/bpmanagement/createcorporate")
  }

  useEffect(() => {
    handleFilterTagSeries();
  }, [searchValue, BPList]);

  const tableContainerRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      const container = tableContainerRef.current;
      if (container) {
        const { scrollTop, clientHeight, scrollHeight } = container;
        if (scrollTop + clientHeight >= scrollHeight) {
          container.scrollTo({ behavior: "smooth" });
          handleGetCorporateSeries()
        }
      }
    };

    const container = tableContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, []);

  const handleSearchIconClick = () => {};

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
    }
  };
useEffect(()=>{
  handleGetCorporateSeries()
},[])

const handleGetCorporateSeries = () => {
 
  props.getDataFromAPI(
    `/partner/api/v2/corporate`,
    "GET",
    undefined,
    (response) => {
      setBPList(response);
     
    },
    (err) => {
     
      toastr.error("Failed", "Unable to fetch tag series ");
    }
  );
};

  

const handleFilterTagSeries = () => {
  const filteredList = BPList.filter((BpSeries) => {
    const searchString = searchValue.toLowerCase();
    const corporateId = (BpSeries.id || "").toString().toLowerCase(); 
    const corporateName = (BpSeries.name || "").toString().toLowerCase();
    return corporateId.includes(searchString) || corporateName.includes(searchString);
  });
  setFilteredFranchiseeList(filteredList);
};



  return (
    <>
      <BPListComponent
        filteredTagSeriesList={filteredTagSeriesList}
        tableContainerRef={tableContainerRef}
        handleSearchInputChange={handleSearchInputChange}
        handleSearchIconClick={handleSearchIconClick}
        handleFilterTagSeries={handleFilterTagSeries}
        handleKeyPress={handleKeyPress}
        handleAddNewCorporate={handleAddNewCorporate}
        searchValue={searchValue}
       
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(BPListContainer);