import React, { useState } from "react";
import Table from "react-bootstrap/Table";
import "./component.css";
import Dropdown from "react-bootstrap/Dropdown";
// import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import eyeIcon from "../../assests/eyeIcon.svg";
import search from "../../assests/search.svg";
import filter from "../../assests/filterIcon.svg";
import Sidebar from "../Navigation/Sidebar/Sidebar";
import LoadingSpinner from "../Loading/component";

export const AddCohortComp = ({
  loading,
  Search,
  filterCohortData,
  handleClick,
  props,
  stagecohortsTypes,
  handleCohortTypeClick,
  activeCohortType,
}) => {
  console.log("filter cohort data 111111111", filterCohortData);
  const [open, setOpen] = useState();

  return (
    <>
      {loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
        <div className="cohortsec">
          <div style={{ width: "100%" }}>
            <div className="searchDivision">
              <input
                type="search"
                placeholder="Search by Cohort Name/ Cohort ID"
                onChange={(e) => {
                  Search(e.target.value);
                }}
              />
              <img className="cohortsearchIcon" src={search} alt="" />
            </div>

            <div
              style={{
                // backgroundColor: "#ffffff",
                padding: "14px",
                borderRadius: "14px",
              }}
            >
              <Table striped className="scrolldown">
                <thead>
                  <tr style={{ border: "none" }}>
                    <th>Cohort ID</th>
                    <th>Cohort Name</th>

                    <th>Area Name</th>

                    <th>
                      <Dropdown className="cohort-type">
                        <Dropdown.Toggle
                          variant="none"
                          className="dropdown-toggle"
                          id="dropdown-basic"
                        >
                          <img
                            style={{ marginRight: "8px", marginTop: "-10px" }}
                            src={filter}
                            alt=""
                          />{" "}
                          <p style={{ color: "black", fontSize: "16px" }}>
                            Cohort Type
                          </p>
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                          {stagecohortsTypes &&
                            stagecohortsTypes.map((item) => (
                              <Dropdown.Item
                                key={item.id}
                                id={item.id}
                                active={activeCohortType === item.id}
                                onClick={() => {
                                  console.log(
                                    "Clicked on cohort type:",
                                    item.id
                                  );
                                  handleCohortTypeClick(item.id, item.type);
                                }}
                              >
                                {item.name}
                              </Dropdown.Item>
                            ))}
                        </Dropdown.Menu>
                      </Dropdown>
                    </th>

                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {filterCohortData &&
                    filterCohortData &&
                    filterCohortData.length &&
                    filterCohortData.map((el, index) => (
                      <tr key={el.id}>
                        {/* <td style={{ textAlign: "left" }}>{index + 1}</td> */}
                        <td style={{ textAlign: "left" }}>{el.id}</td>
                        <td style={{ textAlign: "left" }}>{el.name}</td>

                        <td style={{ textAlign: "" }}>{el.area_name}</td>
                        {/* <td style={{textAlign:"left"}}></td> */}

                        <td style={{ textAlign: "" }}>{el.type}</td>
                        {/* <td
                        onClick={(e) => {
                          addCohortsId(e, el.id, index);
                        }}
                      >
                        {open ? (
                          <>
                            <span className="plus-minus"></span>
                          </>
                        ) : (
                          <>
                            <span className="collapsed"></span>
                          </>
                        )}
                      </td> */}
                        <td>
                          <div>
                            {" "}
                            <input
                              id={el.id}
                              style={{ height: "18px", width: "30px" }}
                              type="checkbox"
                              onClick={handleClick}
                            />
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </Table>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
