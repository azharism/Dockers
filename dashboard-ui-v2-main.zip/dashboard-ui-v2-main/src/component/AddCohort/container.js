// https://api-prod.daalchini.co.in/dashboard/api/v2/admin/vendingmachines/vm-cohorts

import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { toastr } from "react-redux-toastr";
import { getDataFromAPI } from "../../HandleAPICalls/actions";
import { AddCohortComp } from "./component";
import { onChange_Createuser_Cohorts } from "../CreateUserComp/action";
import { Link, useNavigate, useParams } from "react-router-dom";
import { setLoading } from "../OrderComp/OrdersList/actions";

const CohortContainer = (props) => {
  const [data, setData] = useState([]);
  const [searchCohortList, setSearchCohortList] = useState();
  const [searchCohortValue, setSearchCohortValue] = useState();
  const [searchCohortData, setSearchCohortData] = useState(null);
  const [isCheck, setIsCheck] = useState([]);
  const [activeCohortType, setActiveCohortType] = useState("");
  const [filterCohortData, setFilterCohortData] = useState([]);
  const [loading, setLoading] = useState(true);
  var cohortsarray = [];
  const { userid } = useParams();
  const { id } = useParams();

  const stagecohortsTypes = [
    {
      id: 1,
      name: "mobility",
    },
    {
      id: 2,
      name: "franchisee",
    },
    {
      id: 3,
      name: "ABC",
    },
    {
      id: 4,
      name: "QA",
    },
    {
      id: 5,
      name: "FOOD",
    },
  ];

  useEffect(() => {
    console.log("cohort");

    props.getDataFromAPI(
      "/dashboard/api/v2/admin/vendingmachines/vm-cohorts",
      "GET",
      undefined,
      (response) => {
        console.log("sucess response list", response.list);
        setLoading(false);
        setData(response.list);
      },
      (err) => {
        console.log("errrororororooro", err);
        toastr.error(
          "Failed",
          "Unable to fetch vending machine cohort  listing"
        );
      }
    );
  }, []);

  const handleClick = (e) => {
    const { id, checked } = e.target;
    setIsCheck([...isCheck, id]);
    if (!checked) {
      setIsCheck(isCheck.filter((item) => item !== id));
    }

    console.log("isCheck", isCheck);
  };
  if (isCheck.length) {
    for (let k = 0; isCheck.length > k; k++) {
      const data = parseInt(isCheck[k]);

      cohortsarray.push(data);
    }
  }
  props.onChange_Createuser_Cohorts(cohortsarray);

  const onCohortSearch = (e) => {
    const searchName = e.target.value;
    console.log("searcch name", searchName);
    setSearchCohortValue(searchCohortValue);
    searchCohort(e.target.value);
  };
  const searchCohort = (searchCohortValue) => {
    setSearchCohortData(searchCohortValue);
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts?search_query=${searchCohortValue}`,
      "GET",
      undefined,
      (response) => {
        console.log("Ankit get response", response.list);
        setSearchCohortList(response);
        console.log("SEARCH RES----->", response.list);
      },
      (err) => {}
    );
  };

  console.log("cohort search", searchCohortData);
  const handleCohortTypeClick = (id) => {
    console.log("Clicked on cohort type with ID:", id);

    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts?associated_user_id=${userid}` +
        (id ? `&cohort_type_id=${id}` : ""),
      "GET",
      undefined,
      (response) => {
        console.log("Response from API:", response.list);

        setData(response.list);

        let filteredData = response.list;
        if (id) {
          filteredData = filteredData.filter((cohort) => cohort.type === id);
          console.log("filteredData12", filteredData);
        }

        if (filteredData.length > 0) {
          // check if filteredData is not empty
          setFilterCohortData(filteredData);
          setActiveCohortType(id);
        }
      },
      (err) => {
        console.error(err);
      }
    );
  };

  // const filterCohortData = searchCohortData
  // ? data.filter((vmlist) =>
  //     vmlist.name.toLowerCase().includes(searchCohortData.toLowerCase()) ||
  //     vmlist.id.toString().includes(searchCohortData)
  //   )
  // : data;

  const FilterCohortData = data
  .filter(
    (vmlist) =>
      !searchCohortData ||
      (vmlist.name.toLowerCase().includes(searchCohortData.toLowerCase()) ||
        vmlist.id.toString().includes(searchCohortData))
  )
  .filter(
    (cohort) =>
      !activeCohortType || cohort.type === activeCohortType
  );


  // console.log("my cohrt filter data", filterCohortData);

  return (
    <AddCohortComp
      Search={searchCohort}
      filterCohortData={FilterCohortData}
      handleClick={handleClick}
      handleCohortTypeClick={handleCohortTypeClick}
      isCheck={isCheck}
      stagecohortsTypes={stagecohortsTypes}
      activeCohortType={activeCohortType}
      loading={loading}
    />
  );
};
function mapStateToProps({ props }) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
  onChange_Createuser_Cohorts,
})(CohortContainer);
