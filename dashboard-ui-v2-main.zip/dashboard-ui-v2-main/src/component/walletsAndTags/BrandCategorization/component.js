import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import Table from "react-bootstrap/Table";
import Button from "@mui/material/Button";
import FilterListIcon from "@mui/icons-material/FilterList";
import { Menu, MenuItem } from "@mui/material";
import edit from "../../../assests/edit.svg";
import emotions7 from "../../../assests/emotions7.svg";
import LoadingSpinner from "../../Loading/component";

const BrandcategorizationComponent = (props) => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  return (
    <>

   
     {props.loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Brand Categorization
          </h2>
        </div>
        <div style={{ display: "flex", justifyContent: "end" }}>
          <div>
            <Button
              variant="contained"
              color="primary"
              startIcon={<FilterListIcon />}
              onClick={props.handleClick}
              style={{ width: "160px" }}
            >
              {props.buttonLabel ||
                (props.warehouseData.length > 0
                  ? props.warehouseData[0].warehouseName
                  : "")}
            </Button>

            <Menu
              className="menuwarehouse"
              anchorEl={props.anchorEl}
              open={Boolean(props.anchorEl)}
              onClose={props.handleClose}
            >
              {props.warehouseData.map((warehouse) => (
                <MenuItem
                  key={warehouse.warehouseId}
                  onClick={() =>
                    props.handleOptionClick(
                      warehouse.warehouseId,
                      warehouse.warehouseName
                    )
                  } 
                >
                  {warehouse.warehouseName}
                </MenuItem>
              ))}
            </Menu>
          </div>
        </div>
        <div className="tablebrand">
          <div
            ref={props.tableContainerRef}
            className="tableContainer"
            style={{ height: "790px", overflow: "auto", margin: "auto", padding:"10px" }}
          >
            <Table striped>
              <thead>
                <tr>
                  <th>Brands</th>
                  <th>Last 3 month Sales</th>
                  <th>Onboarded time</th>
                  <th>VM Count</th>
                  <th>Category</th>
                  <th>Billing Cycle</th>

                  <th></th>
                </tr>
              </thead>
              <tbody>
                {props.categoryData && props.categoryData.length > 0 ? (
                  props.categoryData.map((item, index) => {
                    const isEditable = props.editableRow === index;

                    const uppercaseBrandCategory = item.brandCategory
                      ? item.brandCategory.toUpperCase()
                      : "";

                    const isSTDChecked =
                      props.selectedCheckboxes.includes("std");
                    const isGMPChecked =
                      props.selectedCheckboxes.includes("gmp");
                    const isMPChecked = props.selectedCheckboxes.includes("mp");

                    return (
                      <tr key={index} className="rowColor">
                        <td>{item.displayName}</td>
                        <td>{item.last3MonthSales}</td>
                        <td>{item.onboardedTime}</td>
                        <td>{item.vmCount}</td>
                        <td>
                          {isEditable ? (
                            <>
                              <div className="tabledataitem">
                                <input
                                  type="checkbox"
                                  value="std"
                                  checked={isSTDChecked}
                                  onChange={(event) =>
                                    props.handleCheckboxChange(event, "std")
                                  }
                                  ref={(input) => {
                                    if (input) {
                                      input.indeterminate =
                                        !props.selectedCheckboxes.includes(
                                          "std"
                                        );
                                      input.style.setProperty(
                                        "--checkbox-color",
                                        "white"
                                      );
                                      input.style.setProperty(
                                        "--checkbox-background",
                                        "blue"
                                      );
                                    }
                                  }}
                                />
                                <p style={{ margin: "6px", color: "#713ABA" }}>
                                  STD
                                </p>

                                <input
                                  type="checkbox"
                                  value="gmp"
                                  checked={isGMPChecked}
                                  onChange={(event) =>
                                    props.handleCheckboxChange(event, "gmp")
                                  }
                                  ref={(input) => {
                                    if (input) {
                                      input.indeterminate =
                                        !props.selectedCheckboxes.includes(
                                          "gmp"
                                        );
                                      input.style.setProperty(
                                        "--checkbox-color",
                                        "white"
                                      );
                                      input.style.setProperty(
                                        "--checkbox-background",
                                        "blue"
                                      );
                                    }
                                  }}
                                />
                                <p style={{ margin: "6px", color: "#008E96" }}>
                                  GMP
                                </p>
                                <input
                                  type="checkbox"
                                  value="mp"
                                  checked={isMPChecked}
                                  onChange={(event) =>
                                    props.handleCheckboxChange(event, "mp")
                                  }
                                  ref={(input) => {
                                    if (input) {
                                      input.indeterminate =
                                        !props.selectedCheckboxes.includes(
                                          "mp"
                                        );
                                      input.style.setProperty(
                                        "--checkbox-color",
                                        "white"
                                      );
                                      input.style.setProperty(
                                        "--checkbox-background",
                                        "blue"
                                      );
                                    }
                                  }}
                                />
                                <p style={{ margin: "6px", color: "#A40E0E" }}>
                                  MP
                                </p>
                              </div>
                            </>
                          ) : (
                            <span
                              className={props.getPriorityClassName(
                                item.brandCategory
                              )}
                            >
                              {uppercaseBrandCategory}
                            </span>
                          )}
                        </td>

                        <td>
                          {isEditable ? (
                            <input
                              className="inputBrand"
                              type="number"
                              value={item.billingCycle}
                              onChange={(event) =>
                                props.handleInputChange(event, index)
                              }
                            />
                          ) : (
                            `${item.billingCycle} Days`
                          )}
                        </td>

                        <td className="eyeIcon1">
                          {isEditable ? (
                            <button
                              className="updateBtn"
                              onClick={props.handleSaveClick}
                            >
                              update
                            </button>
                          ) : (
                            <img
                              src={edit}
                              alt=""
                              onClick={() => props.handleEditClick(index)}
                            />
                          )}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <>
                    <div className="noVMFound">
                      <div>
                        <img className="noOrderImg" src={emotions7} alt="" />
                        <p className="noOrderPara">No Brand Found</p>
                      </div>
                    </div>
                  </>
                )}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
      )}
       </>
  );
};

export default BrandcategorizationComponent;
