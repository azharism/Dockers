import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";

import { toastr } from "react-redux-toastr";
import BrandcategorizationComponent from "./component";

const BrandcategorizationContainer = (props) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedOption, setSelectedOption] = useState("");
  const [categoryData, setCategoryData] = useState([]);
const [loading, setLoading] = useState(true);
  const [editableRow, setEditableRow] = useState([]);
  const [selectedCheckboxes, setSelectedCheckboxes] = useState('');
  const [showAdditionalCheckbox, setShowAdditionalCheckbox] = useState(false);
  const [warehouseData, setWarehouseData] = useState([]);
  const [buttonLabel, setButtonLabel] = useState("");
  const handleEditClick = (index) => {
    setEditableRow(index);

    const categoryValue = categoryData[index]?.brandCategory;

    setSelectedCheckboxes(categoryValue ? [categoryValue.toLowerCase()] : []);
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOptionClick = (warehouseId, warehouseName) => {
    handleClose();
    setSelectedOption(warehouseId);
    setButtonLabel(warehouseName);
    handleBrandCategories(warehouseId);
  };

  const handleInputChange = (event, index) => {
    const updatedData = [...categoryData]; // Create a copy of the data array
    updatedData[index].billingCycle = event.target.value; // Update the billingCycle value

    setCategoryData(updatedData); // Update the data array in the component's state
  };

  const tableContainerRef = useRef(null);

useEffect(() => {
  const handleScroll = () => {
    const container = tableContainerRef.current;
    if (container) {
      const { scrollTop, clientHeight, scrollHeight } = container;
      if (scrollTop + clientHeight >= scrollHeight) {
        
        container.scrollTo({  behavior: 'smooth' });
      }
    }
  };

  const container = tableContainerRef.current;
  if (container) {
    container.addEventListener("scroll", handleScroll);
  }

  return () => {
    if (container) {
      container.removeEventListener("scroll", handleScroll);
    }
  };
}, []);


  useEffect(() => {
    if (selectedOption) {
      handleBrandCategories(selectedOption);
    } else {
     
      if (warehouseData.length > 0) {
        handleBrandCategories(warehouseData[0].warehouseId);
      }
    }
  }, [selectedOption, warehouseData]);

  const handleBrandCategories = (warehouseId) => {
    props.getDataFromAPI(
      `/partner/api/v2/brand/warehouse/${warehouseId}`,
      "GET",
      undefined,
      (response) => {
        console.log("brand-------", response);
        setLoading(false)
        setCategoryData(response);
        // handleSaveClick();
      
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch Brand category listing");
      }
    );
    
  };

  const handleCheckboxChange = (event, checkbox) => {
    const lowercaseCheckbox = checkbox.toLowerCase(); 
    if (event.target.checked) {
      setSelectedCheckboxes([lowercaseCheckbox]); 
    } else {
      setSelectedCheckboxes([]); 
    }
  };

  const handleSaveClick = () => {
    setEditableRow(null);
  console.log("Updated categoryData:", categoryData);

    const updatedBrandCategory = {
      // name: categoryData[editableRow].displayName,
      displayName: categoryData[editableRow].displayName,
      isActive: 1,
      brandsCategory: selectedCheckboxes.map((checkbox) =>
        checkbox.toLowerCase()
      ),
      billingCycle: categoryData[editableRow].billingCycle,
    };
    
   
    const updatedData = [...categoryData];
    updatedData[editableRow].brandCategory = selectedCheckboxes.join(',').toUpperCase();

    setCategoryData(updatedData); 

    props.getDataFromAPI(
      `/dashboard/api/v5/brands/update/${categoryData[editableRow].brandId}`,
      "PATCH",
      updatedBrandCategory,
      (response) => {
        console.log("Brand updated:", response);
       
        setCategoryData(updatedData);
       
      },
      (err) => {
        console.log("Error updating brand:", err);
        
      }
    );
  };

  useEffect(() => {
    brandWarehouseApi();
  }, []);

  const brandWarehouseApi = () => {
    props.getDataFromAPI(
      "/partner/api/v2/warehouse/list",
      "GET",
      undefined,
      (response) => {
        console.log("warehouseData:", response);
        setLoading(false)
        setWarehouseData(response);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch Brand category listing");
      }
    );
  };

  const getPriorityClassName = (brandCategory) => {
    switch (brandCategory) {
      case "STD":
        return "STD-priority";
      case "GMP":
        return "GMP-priority";
      case "MP":
        return "MP-priority";

      default:
        return "";
    }
  };

  return (
    <>
      <BrandcategorizationComponent
        handleClick={handleClick}
        handleClose={handleClose}
        anchorEl={anchorEl}
        selectedOption={selectedOption}
        handleOptionClick={handleOptionClick}
        categoryData={categoryData}
        editableRow={editableRow}
        handleEditClick={handleEditClick}
        handleSaveClick={handleSaveClick}
        handleInputChange={handleInputChange}
        tableContainerRef={tableContainerRef}
        handleCheckboxChange={handleCheckboxChange}
        setShowAdditionalCheckbox={setShowAdditionalCheckbox}
        selectedCheckboxes={selectedCheckboxes}
        showAdditionalCheckbox={showAdditionalCheckbox}
        getPriorityClassName={getPriorityClassName}
        warehouseData={warehouseData}
        brandWarehouseApi={brandWarehouseApi}
        handleBrandCategories={handleBrandCategories}
        buttonLabel={buttonLabel}
        loading={loading}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(BrandcategorizationContainer);
