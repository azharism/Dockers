import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";
import TagpayDetailsComponent from "./component";
import { useParams, useNavigate } from "react-router-dom";

const TagpayDetailsContainer = (props) => {
  const [fetchRechargeDetails, setFetchRechargeDetails] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [isAllActive, setIsAllActive] = useState(true);
  const [buttonLabel, setButtonLabel] = useState("Deactivate All");
  const [amount, setAmount] = useState("");
  const [isRechargePopupOpen, setRechargePopupOpen] = useState(false);
  const [uid, setUid] = useState(null);
  const [reason, setReason] = useState("");
  const [rechargeAmount, setRechargeAmount] = useState("");
  const [selectedView, setSelectedView] = useState("all");
  const [loading, setLoading] = useState(true);
  const [cardStatus, setCardStatus] = useState([]);

  const { seriesId } = useParams();
  const navigate = useNavigate();

  const handleFetchTagRechargeDetails = (seriesId) => {
    props.getDataFromAPI(
      `/partner/api/v2/tag/series/${seriesId}/tag`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        const mappedResponse = response.map((tagDetail) => ({
          ...tagDetail,
          status: tagDetail.status === "new" ? "inactive" : tagDetail.status,
        }));

        let filteredResponse = [];

        switch (selectedView) {
          case "all":
            filteredResponse = mappedResponse;
            break;
          case "active":
            filteredResponse = mappedResponse.filter(
              (tagDetail) => tagDetail.status === "active"
            );
            break;
          case "inactive":
            filteredResponse = mappedResponse.filter(
              (tagDetail) => tagDetail.status === "inactive"
            );
            break;
          default:
            break;
        }

        setFetchRechargeDetails(filteredResponse);
      },
      (err) => {
        console.error("API Error:", err);
        toastr.error("Failed", "Unable to fetch tag series");
      }
    );
  };

  const handleSearchInputChange = (event) => {
    setSearchValue(event.target.value);
  };

  const filteredRechargeDetails = fetchRechargeDetails.filter((tagDetail) =>
    tagDetail.uid.includes(searchValue)
  );

  useEffect(() => {
    handleFetchTagRechargeDetails(seriesId, selectedView);
  }, [seriesId, selectedView]);

  const handleToggleCardStatus = (tagId, currentStatus) => {
    const desiredStatus = currentStatus === "active" ? "inactive" : "active";

    props.getDataFromAPI(
      `/partner/api/v1/tag/${tagId}`,
      "PATCH",
      { cardStatus: desiredStatus },
      (response) => {
        console.log("response---", response);

        const updatedDetails = fetchRechargeDetails.map((tagDetail) => {
          if (tagDetail.uid === tagId) {
            return { ...tagDetail, status: desiredStatus };
          }
          return tagDetail;
        });

        setFetchRechargeDetails(updatedDetails);
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to update card status");
      }
    );
  };

  const updateCardStatusApi = (tagId, desiredStatus) => {
    if (!tagId) {
      toastr.error("Error", "No selected tag");
      return Promise.reject("No selected tag");
    }

    return props.getDataFromAPI(
      `/partner/api/v1/tag/${tagId}`,
      "PATCH",
      { cardStatus: desiredStatus },
      (response) => {
        console.log("response---", response);
        return response;
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to update card status");
        return Promise.reject(err);
      }
    );
  };

  const handleActivateAll = () => {
    const desiredStatus = isAllActive ? "inactive" : "active";
    const tagsToUpdate = fetchRechargeDetails.map((tagDetail) => ({
      tagId: tagDetail.uid,
      desiredStatus,
    }));

    const cardStatusPromises = tagsToUpdate.map((tagInfo) =>
      updateCardStatusApi(tagInfo.tagId, tagInfo.desiredStatus)
    );

    Promise.all(cardStatusPromises)
      .then((responses) => {
        const updatedDetails = fetchRechargeDetails.map((tagDetail, index) => ({
          ...tagDetail,
          status: tagsToUpdate[index].desiredStatus,
        }));

        setFetchRechargeDetails(updatedDetails);
        setButtonLabel(isAllActive ? "Activate All" : "Deactivate All");
        setIsAllActive(!isAllActive);

        setSelectedView(desiredStatus);
      })
      .catch((error) => {
        console.error("Error updating statuses:", error);
        toastr.error("Failed", "Unable to update card statuses");
      });
  };

  const deactivateAllCards = () => {
    const desiredStatus = "inactive";
    const tagsToDeactivate = fetchRechargeDetails
      .filter((tagDetail) => tagDetail.status === "active")
      .map((tagDetail) => ({
        tagId: tagDetail.uid,
        desiredStatus,
      }));

    const cardStatusPromises = tagsToDeactivate.map((tagInfo) =>
      updateCardStatusApi(tagInfo.tagId, tagInfo.desiredStatus)
    );

    Promise.all(cardStatusPromises)
      .then(() => {
        const updatedDetails = fetchRechargeDetails.map((tagDetail, index) => ({
          ...tagDetail,
          status: tagsToDeactivate[index].desiredStatus,
        }));

        setFetchRechargeDetails(updatedDetails);
        setButtonLabel("Activate All");
        setSelectedView("inactive");
      })
      .catch((error) => {
        console.error("Error deactivating tags:", error);
        toastr.error("Failed", "Unable to deactivate tags");
      });
  };

  const handleReachargeApi = (rechargeAmount) => {
    const requestBody = {
      reason: "manual bulk recharge, test 1",
      details: [
        {
          uid: uid,
          amount: parseInt(rechargeAmount),
        },
      ],
    };

    props.getDataFromAPI(
      `/partner/api/v2/tag/series/${seriesId}/tag/bulk/recharge`,
      "POST",
      requestBody,
      (response) => {
        console.log("Recharge successful:", response);
        toastr.success("Success", "Recharge Successful");
      },
      (err) => {
        console.error("Recharge failed:", err);
        toastr.error("Failed", "Unable to recharge tags");
      }
    );
  };

  const handleOpenRechargePopup = (uid, amount, reason) => {
    setRechargeAmount(amount);
    setReason(reason);
    setUid(uid);
    setRechargePopupOpen(true);
  };

  const handleCloseRechargePopup = () => {
    setRechargePopupOpen(false);
  };

  const handleRechargeAmountChange = (e) => {
    setRechargeAmount(e.target.value);
  };

  const handleRechargeSubmit = () => {
    if (rechargeAmount.trim() === "") {
      toastr.error("Failed", "Please enter a valid recharge amount.");
      return;
    }

    handleReachargeApi(rechargeAmount);

    handleCloseRechargePopup();
  };

  const handleSubmit = ({ onClose, onSubmit }) => {
    onSubmit(amount);

    onClose();
  };

  return (
    <TagpayDetailsComponent
      fetchRechargeDetails={filteredRechargeDetails}
      searchValue={searchValue}
      handleSearchInputChange={handleSearchInputChange}
      updateCardStatusApi={updateCardStatusApi}
      // handleDeactivateAll={handleDeactivateAll}
      // handleToggleAll={handleToggleAll}
      buttonLabel={buttonLabel}
      amount={amount}
      setAmount={setAmount}
      handleSubmit={handleSubmit}
      handleOpenRechargePopup={handleOpenRechargePopup}
      isRechargePopupOpen={isRechargePopupOpen}
      handleRechargeAmountChange={handleRechargeAmountChange}
      handleRechargeSubmit={handleRechargeSubmit}
      handleReachargeApi={handleReachargeApi}
      rechargeAmount={rechargeAmount}
      uid={uid}
      handleCloseRechargePopup={handleCloseRechargePopup}
      handleToggleCardStatus={handleToggleCardStatus}
      selectedView={selectedView}
      setSelectedView={setSelectedView}
      isAllActive={isAllActive}
      handleActivateAll={handleActivateAll}
      loading={loading}
      deactivateAllCards={deactivateAllCards}
      // deactivateAllCardStatus={deactivateAllCardStatus}
    />
  );
};

export default connect(null, {
  getDataFromAPI,
})(TagpayDetailsContainer);
