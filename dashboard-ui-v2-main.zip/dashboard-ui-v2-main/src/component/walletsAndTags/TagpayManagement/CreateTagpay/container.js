import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import TagpayCreateComponent from "./component";

export const steps = ["Create new series", "Add Tags", "Activate", "Recharge"];

const TagpayCreateContainer = (props) => {
  const [activeStep, setActiveStep] = useState(0);
  const [createTagSeriesData, setCreateTagSeriesData] = useState({
    corporate_id: "",
    code: "",
    description: "",
    initial_balance: "",
  });
  const [activateResponse, setActivateResponse] = useState({
    uid: "",
    token: "",
  });
  const [inputs, setInputs] = useState([
    { uid: "", token: "", isChecked: false },
  ]);
  const [selectAll, setSelectAll] = useState(false);
  const [tagId, setTagId] = useState(null);
  const [corporateId, setCorporateId] = useState(null);
  const [validationErrors, setValidationErrors] = useState({});

  const [activeBtn, setActiveBtn] = useState("");
  const [activeBtn1, setActiveBtn1] = useState("");
  const [rechargeData, setRechargeData] = useState({
    monthly: {
      amount: "",
      reset_balance: true,
    },
    add_on: {
      amount: "",
      low_balance: "",
    },
  });

  const addMoreInputs = () => {
    setInputs([...inputs, { uid: "", token: "", isChecked: false }]);
  };

  const handleAddRechargeBtnClick = (value) => {
    setActiveBtn(value);
  };
  const handleAddRechargeBtnClick1 = (value) => {
    setActiveBtn1(value);
  };

  // const handleInputChange = (event, index, field) => {
  //   const updatedInputs = [...inputs];
  //   const inputValue = event.target.value;

  //   if (inputValue.length <= 10) {
  //     updatedInputs[index][field] = inputValue;
  //   }

  //   if (field === 'uid' && inputValue.length !== 10) {
  //     if (!updatedInputs[index][`${field}ReadOnly`]) {
  //       updatedInputs[index][`${field}ReadOnly`] = true;
  //       toastr.error("Validation Error", `UID should be exactly 10 digits`);
  //     }
  //   } else {
  //     updatedInputs[index][`${field}ReadOnly`] = false;
  //   }

  //   if (field === 'token' && (inputValue.length === 8 || inputValue.length <= 10)) {
  //     toastr.error("Validation Error", `Token should be between 8 and 10 digits`);
  //   }

  //   setInputs(updatedInputs);
  // };

  const handleInputChange = (event, index, field) => {
    const updatedInputs = [...inputs];
    const inputValue = event.target.value;

    if (inputValue.length <= 10) {
      updatedInputs[index][field] = inputValue;
    }

    if (field === "uid" && inputValue.length === 10) {
      if (!updatedInputs[index][`${field}ReadOnly`]) {
        updatedInputs[index][`${field}ReadOnly`] = true;
        toastr.error("Validation Error", `UID should be exactly 10 digits`);
      }
    } else {
      updatedInputs[index][`${field}ReadOnly`] = false;
    }

    if (
      field === "token" &&
      (inputValue.length == 8 || inputValue.length > 10)
    ) {
      toastr.error(
        "Validation Error",
        `Token should be between 8 and 10 digits`
      );
    }

    setInputs(updatedInputs);
  };

  const handleActivateInputChange = (event, index, fieldName) => {
    const newInputs = [...inputs];
    newInputs[index][fieldName] = event.target.value;
    setInputs(newInputs);
  };

  const navigate = useNavigate();

  const handleNext = async () => {
    console.log("handleNext function called");
   
    if (activeStep === 0) {
      if (validateStepOne()) {
        await handleCreateTagSeries();
      } else {
        toastr.error(
          "Validation Error",
          "Please complete all required fields For create the series"
        );
      }
    } else if (activeStep === 1) {
      const hasBlankUID = inputs.some((input) => input.uid.trim() === '');
      const hasBlankToken = inputs.some((input) => input.token.trim() === '');
  
      if (hasBlankUID && hasBlankToken) {
        toastr.error("Validation Error", "Invalid UID and Token. Both are required.");
        return;
      }
  
      // Validation for UID length
      const hasInvalidUIDLength = inputs.some((input) => input.uid.length !== 10);
      if (hasInvalidUIDLength) {
        toastr.error("Validation Error", "Invalid UID length. It should be exactly 10 digits.");
        return;
      }
  
      
      const hasInvalidTokenLength = inputs.some((input) => input.token.length < 8 || input.token.length > 10);
      if (hasInvalidTokenLength) {
        toastr.error("Validation Error", "Invalid Token length. It should be between 8 and 10 digits.");
        return;
      }
      if (validateStepTwo()) {
        await printTagId();
        // setActiveStep((prevStep) => prevStep + 1);
      } else {
        toastr.error(
          "Validation Error",
          "Already Tags exists in db "
        );
        return;  
      }
    } else if (activeStep === 2) {
      if (validateStepThree()) {
        await handleActivateTagApi();
        setActiveStep((prevStep) => prevStep + 1);
      } else {
        toastr.error(
          " Error",
          "Please select at least one checkbox For Activate Tag"
        );
      }
    } else if (activeStep === 3) {
      // if (validateRechargeData()) {
      //   await handleRechargeApi();
      //   setActiveStep((prevStep) => prevStep + 1);
      // } else {
      //   toastr.error(
      //     " Error",
      //     "Please Fill the required field For Recharge"
      //   );
      // }
      handleRechargeApi();
    }
  };

  const validateStepOne = () => {
    const { corporate_id, code, description, initial_balance } =
      createTagSeriesData;

    if (!corporate_id || !code || !description || !initial_balance) {
      return false;
    }

    return true;
  };

  const validateStepTwo = () => {
    const hasInvalidInputs = inputs.some((input) => !input.uid || !input.token);

    if (hasInvalidInputs) {
      const invalidInputs = inputs.filter(
        (input) => !input.uid || !input.token
      );
      console.log("Invalid inputs:", invalidInputs);
      return false;
    }

    return true;
  };

  const validateStepThree = () => {
    if (!inputs.some((input) => input.isChecked)) {
      return false;
    }

    return true;
  };
  // const validateRechargeData = () => {
  //   const { monthly, add_on, low_balance } = rechargeData;

  //   if (
  //     !monthly.name ||
  //     monthly.amount <= 0 ||
  //     !add_on.name ||
  //     add_on.amount <= 0 ||
  //     low_balance < 0
  //   ) {
  //     return false;
  //   }

  //   return true;
  // };

  const handleClose = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleChangeTagSeries = (event) => {
    const { name, value } = event.target;

    setCreateTagSeriesData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleCreateTagSeries = () => {
    const payload = {
      corporate_id: createTagSeriesData.corporate_id,
      code: createTagSeriesData.code,
      description: createTagSeriesData.description,
      initial_balance: createTagSeriesData.initial_balance,
    };

    props.getDataFromAPI(
      `/partner/api/v2/tag/series`,
      "POST",
      payload,
      (response) => {
        console.log("API success response:", response);

        if (response && response.id) {
          const receivedTagId = response.id;

          console.log("Received tagId:", receivedTagId);

          setTagId(receivedTagId);
          const receivedCorp_id = response.corporate_id;
          console.log("received corporate id:", receivedCorp_id);
          setCorporateId(receivedCorp_id);
          // toastr.error("Failed", "Unable to create Corporate Series");
          setActiveStep((prevStep) => prevStep + 1);
          toastr.success("Success", "Corporate Series created successfully");
        }
      },
      (err) => {
        console.log("Error creating franchisee:", err);
        toastr.error(`${err.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
    );
  };

  // const printTagId = async () => {
  //   try {
  //     console.log("tagId in handleAddTag:", tagId);
  //     const payload = inputs.map((input) => ({
  //       uid: input.uid,
  //       token: input.token,
  //     }));
  //     const response = await props.getDataFromAPI(
  //       `/partner/api/v2/tag/series/${tagId}/tag/bulk`,
  //       "POST",
  //       payload
  //     );

  //     console.log("API success response:", response);

  //     if (response && response) {
  //       const responseData = response;
  //       setActivateResponse(responseData);

  //       const updatedInputs = responseData.map((item, index) => ({
  //         uid: item.uid || inputs[index].uid || "",
  //         token: item.token || inputs[index].token || "",
  //         isChecked: false,
  //       }));
  //       setInputs(updatedInputs);

  //       toastr.success("Success", "Tags added successfully");
  //     } else {
  //       toastr.error("Failed", "Unable to add tags");
  //     }

  //     return response;
  //   } catch (err) {
  //     toastr.error(err.message);
  //   }
  // };
  const printTagId = async () => {
   
      console.log("tagId in handleAddTag:", tagId);
      const payload = inputs.map((input) => ({
        uid: input.uid,
        token: input.token,
      }));
  
      props.getDataFromAPI(
        `/partner/api/v2/tag/series/${tagId}/tag/bulk`,
        "POST",
        payload,
        (response ) => {
          const responseData = response;
          setActivateResponse(responseData);
    
          const updatedInputs = responseData.map((item, index) => ({
            uid: item.uid || inputs[index].uid || "",
            token: item.token || inputs[index].token || "",
            isChecked: false,
          }));
          setInputs(updatedInputs);
    
          toastr.success("Success", "Tags added successfully");
    
         
          setActiveStep((prevStep) => prevStep + 1);
        },

      
        (err) => {
         toastr.error("Failed", "Tag already exists in db")
        }
      
      );
  
   
  };
  
  
  
  
  

  const handleActivateTagApi = () => {
    console.log("tagId in handleActivateTagApi:", tagId);

    const selectedInputs = inputs.filter((input) => input.isChecked);

    if (selectedInputs.length === 0) {
      toastr.error("Error", "Select at least one checkbox before activating.");
      return;
    }

    const transformedPayload = selectedInputs.map((input) => input.uid);

    props.getDataFromAPI(
      `/partner/api/v2/tag/series/${tagId}/tag/bulk`,
      "PUT",
      transformedPayload,
      (response) => {
        console.log("API success response:", response);

        if (response && response) {
          toastr.success("Success", "Activated successfully");
          //navigate("/home/walletandtag/tagpymanagement");
        } else {
          console.log("Failed to add tags:", response);
          toastr.error("Failed", "Unable to Activate tags");
        }
      }
    );
  };

  useEffect(() => {
    setActivateResponse({});
  }, [inputs]);

  const handleChangeRecharge = (event, field) => {
    const { name, value } = event.target;

    setRechargeData((prevData) => ({
      ...prevData,
      [field]: {
        ...prevData[field],
        [name]: value,
      },
    }));
  };

  const handleResetBalanceChange = (value) => {
    setRechargeData((prevData) => ({
      ...prevData,
      monthly: {
        ...prevData.monthly,
        reset_balance: value,
      },
    }));
  };

  const handleRechargeApi = () => {
    const payload = {
      monthly: {
        name: `tagpay_monthly_${corporateId} `,
        amount: parseInt(rechargeData.monthly.amount),
        reset_balance: rechargeData.monthly.reset_balance,
      },
    };

    if (activeBtn === "Yes") {
      payload.add_on = {
        name: `tagpay_monthly_addon_${corporateId} `,
        amount: parseInt(rechargeData.add_on.amount),
        low_balance: parseInt(rechargeData.add_on.low_balance),
      };
    }
    if (!rechargeData.monthly.reset_balance) {
      payload.monthly.name = `tagpay_monthly_reset_${corporateId}`;
    }
    props.getDataFromAPI(
      `/partner/api/v2/corporate/${corporateId}/plan?account_type=WALLET_RFID`,
      "PUT",
      payload,
      (response) => {
        console.log("API success response:", response);

        if (response && response) {
          toastr.success("Success", "Recharge data added successfully");
          navigate("/home/walletandtag/tagpymanagement");
        } else {
          console.log("Failed to add recharge data:", response);
          toastr.error("Failed", "Unable to add recharge data");
        }
      },
      (err) => {
        console.log("Error adding recharge data:", err.message);
        toastr.error(`${err.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
    );
  };

  const handleSelectAll = () => {
    const updatedInputs = inputs.map((input) => ({
      ...input,
      isChecked: !selectAll,
    }));
    setInputs(updatedInputs);
    setSelectAll(!selectAll);
  };

  const handleCheckboxClick = (index) => {
    const updatedInputs = [...inputs];
    updatedInputs[index].isChecked = !updatedInputs[index].isChecked;
    setInputs(updatedInputs);
  };

  return (
    <>
      <TagpayCreateComponent
        activeStep={activeStep}
        handleNext={handleNext}
        handleClose={handleClose}
        steps={steps}
        handleChangeTagSeries={handleChangeTagSeries}
        handleCreateTagSeries={handleCreateTagSeries}
        createTagSeriesData={createTagSeriesData}
        setCreateTagSeriesData={setCreateTagSeriesData}
        printTagId={printTagId}
        tagId={tagId}
        addMoreInputs={addMoreInputs}
        handleInputChange={handleInputChange}
        inputs={inputs}
        setInputs={setInputs}
        handleActivateTagApi={handleActivateTagApi}
        handleActivateInputChange={handleActivateInputChange}
        activateTag={inputs}
        setActivateTag={setInputs}
        selectAll={selectAll}
        handleSelectAll={handleSelectAll}
        activateResponse={activateResponse}
        setActivateResponse={setActivateResponse}
        handleCheckboxClick={handleCheckboxClick}
        activeBtn={activeBtn}
        handleAddRechargeBtnClick={handleAddRechargeBtnClick}
        handleAddRechargeBtnClick1={handleAddRechargeBtnClick1}
        activeBtn1={activeBtn1}
        handleChangeRecharge={handleChangeRecharge}
        rechargeData={rechargeData}
        setActiveBtn={setActiveBtn}
        handleResetBalanceChange={handleResetBalanceChange}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}

export default connect(mapStateToProps, {
  getDataFromAPI,
})(TagpayCreateContainer);
