
import React from "react";
import "./component.css";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";

const ActivateComponent = (props) => {
  const {
    handleActivateInputChange,
   
    handleCheckboxClick,
    
  } = props;

  return (
    <div className="cohortsec1">
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        <div
          style={{
            display: "flex",
            marginLeft: "20px",
            justifyContent: "space-evenly",
            flexWrap: "wrap",
          }}
        >
          {props.activateTag.map((input, index) => (
            <Box
              key={index}
              sx={{
                width: 380,
                maxWidth: "100%",
              }}
              style={{ marginTop: "90px", marginRight: "20px" }}
            >
              <TextField
                fullWidth
                label="UID"
                name={`uid${index}`}
                value={input.uid}
                onChange={(event) =>
                  handleActivateInputChange(event, index, "uid")
                }
                style={{ margin: "14px" }}
              />
              <TextField
                fullWidth
                label="Token"
                name={`token${index}`}
                value={input.token}
                onChange={(event) =>
                  handleActivateInputChange(event, index, "token")
                }
                style={{ margin: "14px" }}
              />
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "end",
                }}
              >
                <input
                  type="checkbox"
                  style={{
                    color: "#3282FF",
                    fontSize: "18px",
                    fontWeight: "500",
                    cursor: "pointer",
                    height:"20px",
                    width:"20px"

                  }}
                  checked={input.isChecked}
                  onChange={() => handleCheckboxClick(index)}
                />
              </div>
            </Box>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ActivateComponent;
