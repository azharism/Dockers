import React from "react";
import "./component.css";
import leftArrow from "../../../../assests/leftArrow.svg";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Button from "@mui/material/Button";
import { Link, useNavigate, useHistory } from "react-router-dom";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import AddTagsComponent from "./Addtags/component";
import ActivateComponent from "./Activate/component";
import RechargeComponent from "./Recharge/component";
import TagpaySeriesComponent from "./CreateTagpaySeries/component";
import uploadsvg from "../../../../assests/uploadsvg.svg";
import Papa from "papaparse";
const TagpayCreateComponent = (props) => {
  const steps = ["Create new series", "Add Tags", "Activate", "Recharge"];

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };

  const handleCSVFileUpload = (file) => {
    if (file) {
      Papa.parse(file, {
        complete: (result) => {
          const csvData = result.data;

          if (csvData.length > 1) {
            const uidTokenPairs = csvData.slice(1).map((row) => ({
              uid: row[0],
              token: row[1],
            }));

            props.setInputs(uidTokenPairs);
          }
        },
        header: false,
      });
    }
  };

  const renderLeftSideButton = () => {
    if (props.activeStep === 1) {
      return (
        <>
          <input
            type="file"
            accept=".csv"
            onChange={(e) => handleCSVFileUpload(e.target.files[0])}
            style={{ display: "none" }}
            id="fileInput"
          />

          <label htmlFor="fileInput">
            <Button
              variant="contained"
              component="span"
              className="left-side-button"
            >
              <img style={{ marginRight: "8px" }} src={uploadsvg} alt="xyz" />
              Bulk Upload
            </Button>
          </label>
        </>
      );
    } else if (props.activeStep === 2) {
      return (
        <Button variant="contained" onClick={props.handleSelectAll}>
          Select All
        </Button>
      );
    } else {
      return null;
    }
  };

  return (
    <div className="main-div">
      <Sidebar />

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create a New Series
          </h2>
        </div>
        <div style={{ marginLeft: "20px", width: "100%" }}>
          <div style={{ width: "100%", display: "flex", alignItems: "center" }}>
            <div style={{ width: "100%", margin: "30px" }}>
              <Box sx={{ width: "534px" }}>
                <Stepper activeStep={props.activeStep}>
                  {steps.map((label, index) => {
                    const stepProps = {};
                    const labelProps = {};

                    return (
                      <Step key={label} {...stepProps}>
                        <StepLabel {...labelProps}>{label} </StepLabel>
                      </Step>
                    );
                  })}
                </Stepper>
              </Box>
            </div>

            <div className="left-side-button-container">
              {renderLeftSideButton()}
            </div>
          </div>

          <div>
            <React.Fragment>
              {props.activeStep === 1 ? (
                <>
                  <AddTagsComponent
                    inputs={props.inputs}
                    handleInputChange={props.handleInputChange}
                    addMoreInputs={props.addMoreInputs}
                  />
                </>
              ) : props.activeStep === 2 ? (
                <>
                  <ActivateComponent
                    handleActivateTagApi={
                      props.handleActivateTagApi && props.handleActivateTagApi
                    }
                    handleActivateInputChange={props.handleActivateInputChange}
                    activateTag={props.activateTag}
                    setActivateTag={props.setActivateTag}
                    addMoreInputsCheckbox={props.addMoreInputsCheckbox}
                    activateResponse={props.activateResponse}
                    setActivateResponse={props.setActivateResponse}
                    handleCheckboxClick={props.handleCheckboxClick}
                    selectAll={props.selectAll}
                  />
                </>
              ) : props.activeStep === 3 ? (
                <>
                  <RechargeComponent
                  activeBtn={props.activeBtn}
                  handleAddRechargeBtnClick={props.handleAddRechargeBtnClick}
                  handleAddRechargeBtnClick1={props.handleAddRechargeBtnClick1}
                  activeBtn1={props.activeBtn1}
                  handleChangeRecharge={props.handleChangeRecharge}
                  rechargeData={props.rechargeData}
                  setActiveBtn={props.setActiveBtn}
                  handleResetBalanceChange={props.handleResetBalanceChange}
                  
                  />
                </>
              ) : (
                <>
                  <TagpaySeriesComponent
                    handleChangeTagSeries={props.handleChangeTagSeries}
                    handleCreateTagSeries={props.handleCreateTagSeries}
                    createTagSeriesData={props.createTagSeriesData}
                    setCreateTagSeriesData={props.setCreateTagSeriesData}
                    tagId={props.tagId}
                    inputs={props.inputs}
                  />
                </>
              )}
            </React.Fragment>
          </div>

          <Box className="backbtnaddpage">
            <Button
              className="backbtnaddpage1"
              disabled={props.activeStep === 0}
              onClick={props.handleClose}
            >
              Back
            </Button>

            {props.activeStep === steps.length - 1 ? (
              <Button className="saveandcontinue" onClick={props.handleNext}>
                Save
              </Button>
            ) : (
              <Button className="saveandcontinue" onClick={props.handleNext}>
                Save and Continue
              </Button>
            )}
          </Box>
        </div>
      </div>
    </div>
  );
};

export default TagpayCreateComponent;
