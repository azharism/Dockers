import React, { useState } from "react";
import "./component.css";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";

const RechargeComponent = (props) => {
  const [selectedOption, setSelectedOption] = useState(""); 
  const [options, setOptions] = useState([]); 

  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);

    if (event.target.value === "month") {
      setOptions(Array.from({ length: 31 }, (_, i) => i + 1));
    } else if (event.target.value === "weeks") {
      setOptions(Array.from({ length: 48 }, (_, i) => i + 1));
    } else if (event.target.value === "days") {
      setOptions(Array.from({ length: 31 }, (_, i) => i + 1));
    } else {
      setOptions([]);
    }
  };

  return (
    <div className="cohortsec1">
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        <div
          style={{
            display: "flex",
            marginLeft: "20px",
            justifyContent: "space-evenly",
            flexWrap: "wrap",
          }}
        >
          <Box
            sx={{
              width: 380,
              maxWidth: "100%",
            }}
            style={{ marginTop: "20px", marginRight: "0px" }}
          >
          <p style={{color:"#3282FF", fontSize:"18px",margin:"20px"}}>+ Monthly</p>  
            <TextField
            style={{margin:"20px"}}
              fullWidth
              label="amount"
              type="number"
              id="monthlyAmount"
              name="amount"
              value={props.rechargeData.monthly.amount}
              onChange={(e) => props.handleChangeRecharge(e, "monthly")}
            />
 <div>
                  <label htmlFor="" className="couponLabelRecharge">
                    Revoke remaining balance at the end of the month
                  </label>
                  <div className="cashback-div" >
                    <button
                      className={`cashback-btn ${
                        props.activeBtn1 === "Yes"
                          ? "active-btn1"
                          : "inactive-btn1"
                      }`}
                      onClick={() => {
                        props.handleAddRechargeBtnClick1("Yes");
                        props.handleResetBalanceChange(false);
                      }}
                    >
                      Yes
                    </button>
                    <button
                      className={`cashback-btn ${
                        props.activeBtn1 === "No"
                          ? "active-btn1"
                          : "inactive-btn1"
                      }`}
                      onClick={() => {
                        props.handleAddRechargeBtnClick1("No");
                        props.handleResetBalanceChange(true);
                      }}
                    >
                      No
                    </button>
                  </div>
                </div>
            {/* <div className="container1">
              {options.length > 0 && (
                <Select
                  fullWidth
                  label="Duration"
                  value={props.selectedDate}
                  onChange={(event) => props.handleSelectDate(event)}
                  style={{ width: "180px", borderRadius: "16px" }}
                >
                  {options.map((date) => (
                    <MenuItem key={date} value={date}>
                      {date}
                    </MenuItem>
                  ))}
                </Select>
              )}
              <Select
                value={selectedOption}
                onChange={handleOptionChange}
                label="Select Option"
                style={{ width: "198px", borderRadius: "16px" }}
              >
                <MenuItem value="month">Month</MenuItem>
                <MenuItem value="weeks">Weeks</MenuItem>
                <MenuItem value="days">Days</MenuItem>
              </Select>
            </div> */}

            <div className="inputDiv" style={{ margin: "0px" }}>
              <Box
                sx={{
                  width: 600,
                  maxWidth: "100%",
                  alignItems: "center",
                }}
              >
                <p htmlFor=""  style={{color:"#3282FF", fontSize:"18px", margin:"20px"}}>
                + Add on
                </p>
                <div>
                  <div className="cashback-div">
                    <button
                      className={`cashback-btn ${
                        props.activeBtn === "Yes"
                          ? "active-btn1"
                          : "inactive-btn1"
                      }`}
                      onClick={() => props.setActiveBtn("Yes")}
                    >
                      Yes
                    </button>

                    <button
                      className={`cashback-btn ${
                        props.activeBtn === "No"
                          ? "active-btn1"
                          : "inactive-btn1"
                      }`}
                      onClick={() => props.setActiveBtn("No")}
                    >
                      No
                    </button>
                  </div>

                  {props.activeBtn === "Yes" && (
                    <>
                      <Box style={{  margin:"20px",width:"100%"  }}>
                        {/* <TextField
                          fullWidth
                          label="Add-on Amount"
                          type="number"
                          id="addOnAmount"
                          name="amount"
                          value={props.rechargeData.add_on.amount}
                          onChange={(e) =>
                            props.handleChangeRecharge(e, "add_on")
                          }
                        />
                        <TextField
                          fullWidth
                          label="Low Balance"
                          type="number"
                          id="lowBalance"
                          name="low_balance"
                          value={props.rechargeData.add_on.low_balance}
                          onChange={(e) =>
                            props.handleChangeRecharge(e, "add_on")
                          }
                        /> */}
                        <TextField
                          fullWidth
                          label="Add-on Amount"
                          type="number"
                          id="addOnAmount"
                          name="amount"
                          value={props.rechargeData.add_on.amount}
                          onChange={(e) =>
                            props.handleChangeRecharge(e, "add_on")
                          }
                        />
                        <TextField
                        style={{marginTop:"20px"}}
                          fullWidth
                          label="Low Balance"
                          type="number"
                          id="lowBalance"
                          name="low_balance"
                          value={props.rechargeData.add_on.low_balance}
                          onChange={(e) =>
                            props.handleChangeRecharge(e, "add_on")
                          }
                        />
                      </Box>
                    </>
                  )}
                </div>

               
              </Box>
            </div>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default RechargeComponent;
