import React from 'react'
import "./component.css"
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';


const TagpaySeriesComponent = (props) => {
  return (
    <div className="cohortsec1">
<div style={{ marginLeft:"40px" }}>
  
  <Box
            sx={{
              width: 500,
              maxWidth: '100%',
            }}
            style={{ marginTop: '90px', marginRight: "20px" }}
          >
        
            <TextField fullWidth label=" Corporate ID" name="corporate_id"  value={props.createTagSeriesData.corporate_id} onChange={props.handleChangeTagSeries} style={{ margin: '14px' }} />
            <TextField fullWidth label="Description" name="description" value={props.createTagSeriesData.description} onChange={props.handleChangeTagSeries}  style={{ margin: '14px' }} />
            <TextField fullWidth label="Code" name="code" value={props.createTagSeriesData.code} onChange={props.handleChangeTagSeries} style={{ margin: '14px' }} />
            <TextField fullWidth label="Initial Balance " name="initial_balance" value={props.createTagSeriesData.initial_balance} onChange={props.handleChangeTagSeries} style={{ margin: '14px' }} />
           
          </Box>
  </div>

  
  
</div>

  )
}

export default TagpaySeriesComponent;