
import React from "react";
import "./component.css";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";

const AddTagsComponent = (props) => {
  return (
    <div className="cohortsec1" style={{ overflow: "scroll", height: "700px" }}>
      <div>
        <div
          style={{
            display: "flex",
            marginLeft: "20px",
            justifyContent: "space-evenly",
            flexWrap: "wrap",
          }}
        >
          {props.inputs.map((input, index) => (
            <Box
              key={index}
              sx={{
                width: 380,
                maxWidth: "100%",
              }}
              style={{ marginTop: "90px", marginRight: "20px" }}
            >
              <TextField
                fullWidth
                label="UID"
                name={`uid${index}`}
                value={input.uid || ""}
                onChange={(event) =>
                  props.handleInputChange(event, index, "uid")
                }
                style={{ margin: "14px" }}
                readOnly={input.uidReadOnly}
                maxLength={10}  
              />
              <TextField
                fullWidth
                label="Token"
                name={`token${index}`}
                value={input.token || ""}
                onChange={(event) =>
                  props.handleInputChange(event, index, "token")
                }
                style={{ margin: "14px" }}
                readOnly={input.tokenReadOnly}
                maxLength={10}  
              />
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "end",
                }}
              >
                <p
                  style={{
                    color: "#3282FF",
                    fontSize: "18px",
                    fontWeight: "500",
                    cursor: "pointer",
                  }}
                  onClick={props.addMoreInputs}
                >
                  + Add more
                </p>
              </div>
            </Box>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AddTagsComponent;
