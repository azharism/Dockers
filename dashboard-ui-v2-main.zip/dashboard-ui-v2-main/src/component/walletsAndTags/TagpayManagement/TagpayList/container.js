import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";
import ManagePartnersComponent from "./component";
import { useParams } from "react-router-dom";
import { Link, useNavigate, useHistory } from "react-router-dom";
import TagpayListComponent from "./component";

const TagpayListContainer = (props) => {
  const { seriesId } = useParams;
  const navigate = useNavigate();
  const [tagSeriesList, setTagSeriesList] = useState([]);
  const [filteredTagSeriesList, setFilteredFranchiseeList] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [loading, setLoading] = useState(true)


  const handleSearchInputChange = (event) => {
    const inputValue = event.target.value;
    setSearchValue(inputValue);
  };

  const handleAddNewTags=()=>{
    navigate("/home/walletandtag/tagpymanagement/createtagpay")
  }

  useEffect(() => {
    handleFilterTagSeries();
  }, [searchValue, tagSeriesList]);

  const tableContainerRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      const container = tableContainerRef.current;
      if (container) {
        const { scrollTop, clientHeight, scrollHeight } = container;
        if (scrollTop + clientHeight >= scrollHeight) {
          container.scrollTo({ behavior: "smooth" });
          handleGetTagSeries()
        }
      }
    };

    const container = tableContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, []);

  const handleSearchIconClick = () => {};

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
    }
  };
useEffect(()=>{
  handleGetTagSeries()
},[])

const handleGetTagSeries = () => {
 
  props.getDataFromAPI(
    `/partner/api/v2/tag/series`,
    "GET",
    undefined,
    (response) => {
      setLoading(false)
      setTagSeriesList(response);
      console.log("response---", response);
    },
    (err) => {
      console.log("error---", err);
      toastr.error("Failed", "Unable to fetch tag series ");
    }
  );
};

  

const handleFilterTagSeries = () => {
  const filteredList = tagSeriesList.filter((tagSeries) => {
    const searchString = searchValue.toLowerCase();
    const ownerId = (tagSeries.corporate_id || "").toString().toLowerCase();
    const cohortId = (tagSeries.corporate_name || "").toString().toLowerCase();
    return ownerId.includes(searchString) || cohortId.includes(searchString);
  });
  setFilteredFranchiseeList(filteredList);
};


  return (
    <>
      <TagpayListComponent
        filteredTagSeriesList={filteredTagSeriesList}
        tableContainerRef={tableContainerRef}
        handleSearchInputChange={handleSearchInputChange}
        handleSearchIconClick={handleSearchIconClick}
        handleFilterTagSeries={handleFilterTagSeries}
        handleKeyPress={handleKeyPress}
        handleAddNewTags={handleAddNewTags}
        loading={loading}
       
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(TagpayListContainer);