import React, { useState } from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../Loading/component";
import wallet from "../../../assests/Wallet.svg"

export const CouponCashbackComponent = ({
    
    couponCreationStep10,
    flatAmount,
    handleBtnClick,
    activeBtn,
   
    handleCouponCashbackChange,
    couppnCashbackChange,
    maxCashback
   
   
}) => {
    
      
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  
  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create Coupon
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
            <div className="inputDiv">
      <Box
        sx={{
          width: 600,
          maxWidth: "100%",
          alignItems: "center"
        }}
      >
        <img src={wallet} alt="" />
        <label htmlFor="" className="couponLabel">
          Please select a cashback type
        </label>
        <div>
          <div className="cashback-div">
            <button
              className={`cashback-btn ${
                activeBtn === "flat" ? "active-btn" : "inactive-btn"
              }`}
              onClick={() => handleBtnClick("flat")}
            >
              Flat
            </button>
            <button
              className={`cashback-btn ${
                activeBtn === "percentage" ? "active-btn" : "inactive-btn"
              }`}
              onClick={() => handleBtnClick("percentage")}
            >
              Percentage
            </button>
          </div>

        

<TextField
  style={{ margin: "18px", padding: "0px", color: "#b2b2b2" }}
  fullWidth
  type="text"
  label={activeBtn === 'flat' ? 'Enter  Cashback Amount' : 'Enter Cashback Percentage '}
  id={activeBtn === 'flat' ? 'flat-cashback' : 'percentage-cashback'}
  value={activeBtn === 'flat' ? flatAmount : flatAmount  }
  onChange={(e) => handleCouponCashbackChange(e, activeBtn)}
/>


{activeBtn=== "percentage" && (
<TextField
  style={{ margin: "18px", padding: "0px", color: "#b2b2b2" }}
  fullWidth
  type="text"
  label="MaxCashBack %"
  id={activeBtn === 'flat' ? 'flat-cashback' : 'percentage-cashback'}
  value={maxCashback}
  onChange={(e) => couppnCashbackChange(e, activeBtn)}
/>

)}
        </div>
      </Box>

      <Box className="usersrolebtn">

        <Button className="backbtn" onClick={goback}  style={{textTransform: "capitalize"}}>
          Cancel
        </Button>

        <Button
        style={{textTransform: "capitalize"}}
  className="savebtnupdate"
  onClick={() => couponCreationStep10(activeBtn === 'flat' ? 1 : 2)}
  // disabled={!validCouponName || loading}
>
  Proceed
</Button>
      </Box>
    </div>
          </div>
        </div>
      </div>
    </div>
  );
};
