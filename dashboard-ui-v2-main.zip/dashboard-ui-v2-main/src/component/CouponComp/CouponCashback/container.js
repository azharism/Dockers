
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import { CouponAmountComponent, CouponCashbackComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
// import  CouponDeeplinkComponent  from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType_Step10 } from "../CouponCreate/action";


const CouponCashbackContainer = (props) => {
  console.log("CouponAmount props", props);
  const [flatAmount, setFlatAmount] = useState("");
  const [activeBtn, setActiveBtn] = useState("flat");
  const [maxCashback, setMaxCashback] =useState()
  // const [percentageAmount, setPercentageAmount] = useState(0);

  const navigate = useNavigate();

  // const handleCouponCashbackChange = (event, type) => {
  //   const amount = event.target.value.trim() === "" ? "" : parseFloat(event.target.value);
  //   if (type === 'flat') {
  //     setFlatAmount(amount);
  //   } else if (type === 'percentage') {
  //     const formattedAmount = amount === "" ? "" : amount + "%";
  //     setFlatAmount(formattedAmount);
  //   }
  // };
  
  const handleCouponCashbackChange = (event, type) => {
    const inputValue = event.target.value.trim();
    let amount = inputValue;
    
    if (inputValue !== "") {
      amount = parseFloat(inputValue);
      if (isNaN(amount)) {
        amount = inputValue;
      }
    }
  
    if (type === 'flat') {
      setFlatAmount(amount);
    } else if (type === 'percentage') {
      setFlatAmount(amount);
    }
  };
  
  const couppnCashbackChange = (e)=>{
    setMaxCashback(e.target.value)

  }

  const handleBtnClick = (type) => {
    setActiveBtn(type);
    if (type === "flat") {
      couponCreationStep10(1);
    } else if (type === "percentage") {
      couponCreationStep10(2);
    }
  };

  const couponCreationStep10 = (flatTypeId) => {
    console.log("CLICK", localStorage.getItem("draftId"));
   
    
    let cashbackDetails = {};
    if (activeBtn === "flat") {
      cashbackDetails = {
        flatTypeId: 1,
        flatAmount: flatAmount,
        maxCashback: null,
      };
    } else if (activeBtn === "percentage") {
      cashbackDetails = {
        flatTypeId: 2,
        flatAmount: flatAmount,
        
        maxCashback: maxCashback,
      };
    }
    
    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 10,
        draftId: props.props && props.props.coupon.step1_draftId,
        cashbackDetails: cashbackDetails,
      },
      
      (response) => {
        console.log("API response step 6:", response);
        setFlatAmount(flatAmount);
        // setPercentageAmount(percentageAmount);
        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response)
        props.onChange_CouponCashbackAmountType_Step10(response)
        navigate("/home/couponvmcreation")
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };
  
  
  
  
  

  
  
  
    
  
  return (
    <>
   
  <CouponCashbackComponent

  couponCreationStep10={couponCreationStep10}
  activeBtn={activeBtn}
flatAmount={flatAmount}
// percentageAmount={percentageAmount}
handleBtnClick={handleBtnClick}
handleCouponCashbackChange={handleCouponCashbackChange}
couppnCashbackChange={couppnCashbackChange}
maxCashback={maxCashback}
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    onChange_CouponDiscountAmount_Step6,
    onChange_CouponCashbackAmount_Step7,
    onChange_CouponCashbackAmountType_Step10,
    
  })(CouponCashbackContainer);
