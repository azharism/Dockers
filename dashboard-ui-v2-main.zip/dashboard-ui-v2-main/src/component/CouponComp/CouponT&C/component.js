import React, { useState } from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../Loading/component";
import { CouponSuccessComponent } from "../CouponSuccess/component";
import { CouponComponent } from "../CouponCreate/component";
import ClearIcon from "@mui/icons-material/Clear";
import { IconButton, InputAdornment } from "@mui/material";




export const CouponTermandConditionComponent = ({
  couponCreationStep18,
  tnc,
  handleClearCouponName,
  couponName,
  couponId,
  createCouponAPI,
  proccedstep15flag,
  nowcouponCreated,
  handleKeyPress,
  handleCouponDescriptionChange
}) => {
 
  console.log("nowcouponCreated", nowcouponCreated);

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  const ok = () => {
    navigate("/");
  };

  return (
    <>
      <div style={{ marginTop: "20px" }}>
        {proccedstep15flag && (
          
          <CouponComponent prefeildCouponName={couponName} fab={"false"}  />
        )}
        {
          <CouponSuccessComponent
            show={nowcouponCreated}
            couponName={couponName}
            couponId={couponId}
            okClick={ok}
          />
        }
      </div>

      <div>
        {!proccedstep15flag && (
          <>
            <div className="main-div">
              <div>
                <Sidebar />
              </div>

              <div>
                <div
                  style={{
                    marginLeft: "42px",
                    marginTop: "20px",
                    width: "400px",
                  }}
                >
                  <h2>
                    <img
                      onClick={handleClick}
                      style={{ width: "22px", cursor: "pointer" }}
                      src={leftArrow}
                      alt=""
                    />{" "}
                    Create Coupon
                  </h2>
                </div>

                <div className="bDetrails-div">
                  <div
                    style={{
                      display: "flex",
                      alignItems: "flex-start",
                      width: "1328px",
                    }}
                  >
                    <div className="inputDiv">
                      <Box
                        sx={{
                          width: 600,
                          maxWidth: "100%",
                          alignItems: "center",
                        }}
                      >
                        <label
                          htmlFor=""
                          className="couponLabel"
                          style={{ width: "1090px" }}
                        >
                          Enter Terms & Conditions
                        </label>
                        <div>
                          <>
                          <TextField
            style={{ margin: "18px", padding: "0px", color: "#b2b2b2", borderRadius:"12px",fontFamily: 'Crimson Text' }}
            fullWidth
            label=" Terms & Conditions"
            id="fullWidth"
            value={tnc}
            onChange={handleCouponDescriptionChange}
            multiline
            rows={4}
            maxRows={8}
            onKeyPress={handleKeyPress}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  {tnc && (
                    <IconButton onClick={handleClearCouponName}>
                      <ClearIcon />
                    </IconButton>
                  )}
                </InputAdornment>
              )
            }}
          />
                          </>
                        </div>
                      </Box>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
        {!proccedstep15flag && (
          <Box className="usersrolebtn">
            <Button className="backbtn" onClick={goback}>
              Cancel
            </Button>

            <Button className="savebtnupdate" onClick={couponCreationStep18}>
              Proceed
            </Button>
          </Box>
        )}
        {proccedstep15flag && (
          <Box className="usersrolebtn">
            <Button className="backbtn" onClick={goback}>
              Cancel
            </Button>

            <Button className="savebtnupdate" onClick={createCouponAPI}>
              Proceed
            </Button>
          </Box>
        )}
      </div>
    </>
  );
};
