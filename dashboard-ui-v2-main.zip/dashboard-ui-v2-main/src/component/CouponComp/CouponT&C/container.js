import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";
import { CouponTermandConditionComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType_Step10 } from "../CouponCreate/action";
import { onChange_CouponVendingMachines_Step11 } from "../CouponCreate/action";
import { onChange_CouponAplicableItem_Step12 } from "../CouponCreate/action";
import { onChange_CouponPaymentGateway_Step13 } from "../CouponCreate/action";
import { onChange_CouponUseDuration_Step14 } from "../CouponCreate/action";
import { onChange_CouponLimit_Step15 } from "../CouponCreate/action";
import { onChange_CouponTandC_Step18 } from "../CouponCreate/action";

const CouponTermandConditionContainer = (props) => {
  console.log("CouponAmount props", props);
  const [couponName, setCouponName] = useState("");
  const [couponId, setCouponId] = useState("");
  const [activeBtn, setActiveBtn] = useState("");
  // const [couponLimit, setCouponLimit] = useState("");
  const [show, setShow] = useState(false);
  const [proccedstep15flag, setProccedstep15flag] = useState(false);
  const [isCouponCreated, setIsCouponCreated] = useState();
  const [nowcouponCreated, setNowcouponCreated] = useState(false);
  const [tnc, setTnc]= useState("")

  const navigate = useNavigate();

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      couponCreationStep18();
    }
  };
  const handleClearCouponName = () => {
    setTnc("");
  };

  const handleCouponDescriptionChange = (event) => {
    const tnc = event.target.value;
    setTnc(tnc);
  };

  const couponCreationStep18 = (flatTypeId) => {
    console.log("CLICK", localStorage.getItem("draftId"));

    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 18,
        draftId: props.props && props.props.coupon.step1_draftId,
        tnc: tnc,
      },

      (response) => {
        console.log(" coupon name", response);

        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response);
        props.onChange_CouponCashbackAmountType_Step10(response);
        props.onChange_CouponVendingMachines_Step11(response);
        props.onChange_CouponAplicableItem_Step12(response);
        props.onChange_CouponPaymentGateway_Step13(response);
        props.onChange_CouponUseDuration_Step14(response);
        props.onChange_CouponLimit_Step15(response);
        props.onChange_CouponTandC_Step18(response)
         setShow(true);
        setCouponName(response.couponName);
        setCouponId(response.draftId);
        setProccedstep15flag(true);
        setTnc(response)
        createCouponAPI()
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };

  const createCouponAPI = () => {
    console.log("CLICK", localStorage.getItem("draftId"));

    console.log("createCouponAPI", createCouponAPI);

    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/${
        props && props.props && props.props.coupon.step1_draftId
      }`,
      "POST",
      {
        isCouponCreated: true,
      },

      (response) => {
        console.log("API response step 16:", response);
        setIsCouponCreated(isCouponCreated);

        setShow(true);

        setCouponId(response.couponId);

        setNowcouponCreated(true);
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
        setShow(false);
      },
      true
    );
  };

  return (
    <>
      <CouponTermandConditionComponent
        couponCreationStep18={couponCreationStep18}
        activeBtn={activeBtn}
       tnc={tnc}
       
        setShow={setShow}
        show={show}
        couponName={couponName}
        couponId={couponId}
        isCouponCreated={isCouponCreated}
        createCouponAPI={createCouponAPI}
        proccedstep15flag={proccedstep15flag}
        nowcouponCreated={nowcouponCreated}
        handleClearCouponName={handleClearCouponName}
        handleKeyPress={handleKeyPress}
        handleCouponDescriptionChange={handleCouponDescriptionChange}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
  onChange_CouponDescription_Step2,
  onChange_CouponImage_Step3,
  onChange_CouponDate_Step4,
  onChange_CouponDeeplink_Step5,
  onChange_CouponDiscountAmount_Step6,
  onChange_CouponCashbackAmount_Step7,
  onChange_CouponCashbackAmountType_Step10,
  onChange_CouponVendingMachines_Step11,
  onChange_CouponAplicableItem_Step12,
  onChange_CouponPaymentGateway_Step13,
  onChange_CouponUseDuration_Step14,
  onChange_CouponLimit_Step15,
  onChange_CouponTandC_Step18,
})(CouponTermandConditionContainer);
