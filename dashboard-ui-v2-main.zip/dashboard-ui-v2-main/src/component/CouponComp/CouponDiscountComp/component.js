import React, { useState } from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../Loading/component";
import discount from "../../../assests/Discount.svg"
import { display } from "@mui/system";


export const CouponDiscountCompComponent = ({
   
    couponCreationStep8,
    maxDiscount,
    handleBtnClick,
    activeBtn,
   flatAmount,
   handleChangeMaxCashbackPerecntage,
   couppnCashbackDiscountChange
}) => {
    // const [activeBtn, setActiveBtn] = useState("flat");
    // const [cashbackAmount, setCashbackAmount] = useState("");
  
    // const handleBtnClick = (type) => {
    //     setActiveBtn(type);
    //     if (type === 'flat') {
    //       couponCreationStep10(1);
    //     } else if (type === 'percentage') {
    //       couponCreationStep10(2);
    //     }
    //   };
      
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  
  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create Coupon
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
            <div className="inputDiv">
      <Box
        sx={{
          width: 600,
          maxWidth: "100%",
          alignItems: "center",
          
        }}
      >
        <div style={{display:"flex"}}>
        <img src={discount} alt="" />
        <label  htmlFor="" className="couponLabel" style={{width:"1090px", marginTop:"30px", fontSize:"20px"}}>
        Discount
        </label>
        </div>
        
        <div>
        <div className="cashback-div">
            <button
            disabled={true}
              className={`cashback-btn ${
                activeBtn === "flat" ? "active-btn" : "inactive-btn"
              }`}
              onClick={() => handleBtnClick("flat")}
            >
              Flat
            </button>
            <button
              className={`cashback-btn ${
                activeBtn === "percentage" ? "active-btn" : "inactive-btn"
              }`}
              onClick={() => handleBtnClick("percentage")}
            >
              Percentage
            </button>
          </div>
       
    
       <TextField
       style={{ margin: "18px", padding: "0px", color: "#b2b2b2" }}
       fullWidth
       label="Enter Discount Percentage"
      type="number"
       value={flatAmount}
       onChange={handleChangeMaxCashbackPerecntage}
     />
      <TextField
       style={{ margin: "18px", padding: "0px", color: "#b2b2b2" }}
       fullWidth
       label="Enter Maximum Discount Amount"
      type="number"
       value={maxDiscount}
       onChange={couppnCashbackDiscountChange}
     />
  
        </div>
        
      </Box>
     
     
      <Box className="usersrolebtn">
        <Button className="backbtn" onClick={goback}  style={{textTransform: "capitalize"}}>
          Cancel
        </Button>

        <Button
         style={{textTransform: "capitalize"}}
  className="savebtnupdate"
  onClick={couponCreationStep8}
  // disabled={!validCouponName || loading}
>
  Proceed
</Button>
      </Box>
      
    </div>
          </div>
          
        </div>
        
      </div>
    </div>
  );
};
