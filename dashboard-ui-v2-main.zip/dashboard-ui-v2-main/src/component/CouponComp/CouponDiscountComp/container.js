
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import {  CouponDiscountCompComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
// import  CouponDeeplinkComponent  from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType2_Step8} from "../CouponCreate/action"
import { onChange_CouponCashbackAmountType_Step10 } from "../CouponCreate/action";
import { onChange_CouponVendingMachines_Step11 } from "../CouponCreate/action";
import { onChange_CouponAplicableItem_Step12 } from "../CouponCreate/action";
import { onChange_CouponPaymentGateway_Step13 } from "../CouponCreate/action";
import { onChange_CouponUseDuration_Step14 } from "../CouponCreate/action";
import { onChange_CouponLimit_Step15 } from "../CouponCreate/action";



const CouponDiscountCompContainer = (props) => {
  console.log("CouponAmount props", props);
  
  const [flatAmount, setFlatAmount] = useState("");
  const [activeBtn, setActiveBtn] = useState("percentage");
  const [maxDiscount, setMaxDiscount] =useState()
  const navigate = useNavigate();

  
 const handleChangeMaxCashbackPerecntage= (e)=>{
  setFlatAmount(e.target.value)
 }
  
 const couppnCashbackDiscountChange = (e)=>{
  setMaxDiscount(e.target.value)

}
  const handleBtnClick = (value) => {
    setActiveBtn(value);
  };

  const couponCreationStep8 = (flatTypeId) => {
    console.log("CLICK", localStorage.getItem("draftId"));
  
    if(flatAmount===""){
      toastr.warning("Enter Discount Percentage")
      return;
    }
    if(maxDiscount===""){
      toastr.warning("Enter Max Discount Percentage")
      return;
    }
   
    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 17,
        draftId: props.props && props.props.coupon.step1_draftId,
        discountDetails: {
          flatTypeId: 2,
          flatAmount: flatAmount,
          maxDiscount: maxDiscount
          },
      },
      
      (response) => {
        console.log("API response step 6:", response);
        setFlatAmount(flatAmount)
        setMaxDiscount(maxDiscount)
        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response)
        props.onChange_CouponCashbackAmountType2_Step8(response)
        props.onChange_CouponCashbackAmountType_Step10(response)
        props.onChange_CouponVendingMachines_Step11(response)
        props.onChange_CouponAplicableItem_Step12(response)
        props.onChange_CouponPaymentGateway_Step13(response)
        props.onChange_CouponUseDuration_Step14(response)
        props.onChange_CouponLimit_Step15(response)
        navigate("/home/couponfreegift")
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };
  
   
  
  return (
    <>
   
  <CouponDiscountCompComponent

couponCreationStep8={couponCreationStep8}
  activeBtn={activeBtn}
flatAmount={flatAmount}
handleChangeMaxCashbackPerecntage={handleChangeMaxCashbackPerecntage}
handleBtnClick={handleBtnClick}
couppnCashbackDiscountChange={couppnCashbackDiscountChange}
maxDiscount={maxDiscount}
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    onChange_CouponDiscountAmount_Step6,
    onChange_CouponCashbackAmount_Step7,
    onChange_CouponCashbackAmountType2_Step8,
    onChange_CouponCashbackAmountType_Step10,
    onChange_CouponVendingMachines_Step11,
    onChange_CouponAplicableItem_Step12,
    onChange_CouponPaymentGateway_Step13,
    onChange_CouponUseDuration_Step14,
    onChange_CouponLimit_Step15,
    
  })(CouponDiscountCompContainer);
