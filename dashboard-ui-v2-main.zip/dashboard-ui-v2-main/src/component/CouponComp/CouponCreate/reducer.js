import { STEP2_NEXTSTEP } from "./constant.js";
import { STEP1_DRAFTID} from "./constant.js";
import {STEP3_NEXTSTEP} from "./constant.js";
import {STEP4_NEXTSTEP} from "./constant.js";
import {STEP5_NEXTSTEP} from "./constant.js";
import {STEP6_NEXTSTEP} from "./constant.js";
import {STEP7_NEXTSTEP} from "./constant.js";
import {STEP8_NEXTSTEP} from "./constant.js";
import {STEP10_NEXTSTEP} from "./constant.js";
import {STEP11_NEXTSTEP} from "./constant.js";
import {STEP12_NEXTSTEP} from "./constant.js";
import {STEP13_NEXTSTEP} from "./constant.js";
import {STEP14_NEXTSTEP} from "./constant.js";
import {STEP15_NEXTSTEP} from "./constant.js";
import {STEP18_NEXTSTEP} from "./constant.js";
   
    
    const initialState = {
      
      step1_draftId: '',
        
      
    };
    
    export default (state = initialState, action) => {
      console.log('CreateUser/reducer________', action);
      switch (action.type) {
        case STEP1_DRAFTID:
          console.log("coupon draft id reducer")
          return {
            ...state,
            step1_draftId: action.draftId,
          };
          case STEP2_NEXTSTEP:
          console.log("coupon draft id reducer")
          return {
            ...state,
            step2_nextStep: action.nextStep,
          };
          case STEP3_NEXTSTEP:
            console.log("coupon draft id reducer")
            return {
              ...state,
              step3_nextStep: action.nextStep,
            };
            case STEP4_NEXTSTEP:
              console.log("coupon draft id reducer")
              return {
                ...state,
                step4_nextStep: action.nextStep,
              };
              case STEP5_NEXTSTEP:
                console.log("coupon draft id reducer")
                return {
                  ...state,
                  step5_nextStep: action.nextStep,
                };
                case STEP6_NEXTSTEP:
                  console.log("coupon draft id reducer")
                  return {
                    ...state,
                    step6_nextStep: action.nextStep,
                  };
                  case STEP7_NEXTSTEP:
                    console.log("coupon draft id reducer")
                    return {
                      ...state,
                      step7_nextStep: action.nextStep,
                    };
                    case STEP8_NEXTSTEP:
                    console.log("coupon draft id reducer")
                    return {
                      ...state,
                      step8_nextStep: action.nextStep,
                    };
                    case STEP10_NEXTSTEP:
                      console.log("coupon draft id reducer")
                      return {
                        ...state,
                        step10_nextStep: action.nextStep,
                      };
                      case STEP11_NEXTSTEP:
                      console.log("coupon draft id reducer")
                      return {
                        ...state,
                        step11_nextStep: action.nextStep,
                      };
                      case STEP12_NEXTSTEP:
                      console.log("coupon draft id reducer")
                      return {
                        ...state,
                        step12_nextStep: action.nextStep,
                      };
                      case STEP13_NEXTSTEP:
                        console.log("coupon draft id reducer")
                        return {
                          ...state,
                          step13_nextStep: action.nextStep,
                        };
                        case STEP14_NEXTSTEP:
                        console.log("coupon draft id reducer")
                        return {
                          ...state,
                          step14_nextStep: action.nextStep,
                        };
                        case STEP15_NEXTSTEP:
                        console.log("coupon draft id reducer")
                        return {
                          ...state,
                          step15_nextStep: action.nextStep,
                        };
                        case STEP18_NEXTSTEP:
                        console.log("coupon draft id reducer")
                        return {
                          ...state,
                          step18_nextStep: action.nextStep,
                        };
     
        default:
          return state;
      }
    };