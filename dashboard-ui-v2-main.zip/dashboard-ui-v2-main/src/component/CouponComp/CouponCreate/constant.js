export const STEP1_DRAFTID = '@couponCreation/STEP1_DRAFTID';
export const STEP2_NEXTSTEP = '@couponDescription/STEP2_NEXTSTEP';
export const STEP3_NEXTSTEP = '@couponImage/STEP3_NEXTSTEP'
export const STEP4_NEXTSTEP = '@couponDate/STEP4_NEXTSTEP'
export const STEP5_NEXTSTEP = '@couponDeeplink/STEP5_NEXTSTEP'
export const STEP6_NEXTSTEP = '@couponDiscountAmount/STEP6_NEXTSTEP'
export const STEP7_NEXTSTEP = '@couponCashbackAmount/STEP7_NEXTSTEP'
export const STEP8_NEXTSTEP = '@couponCashbackAmountType2/STEP8_NEXTSTEP'
export const STEP10_NEXTSTEP = '@couponCashbackAmountType/STEP10_NEXTSTEP'
export const STEP11_NEXTSTEP = '@couponVendingMachine/STEP11_NEXTSTEP'
export const STEP12_NEXTSTEP = '@couponAlicableItem/STEP12_NEXTSTEP'
export const STEP13_NEXTSTEP = '@couponPaymentGateway/STEP13_NEXTSTEP'
export const STEP14_NEXTSTEP = '@couponDuration/STEP14_NEXTSTEP'
export const STEP15_NEXTSTEP = '@couponLimit/STEP14_NEXTSTEP'
export const STEP18_NEXTSTEP = '@couponT&C/STEP18_NEXTSTEP'

