import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { CouponComponent } from "./component";
import { toastr } from "react-redux-toastr";
import { onChange_CouponCreation_Step1 } from "./action";
// import { setDraftId } from "../action";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";








  const CouponContainer = (props) => {
    const [couponName, setCouponName] = useState("");
    const [draftId, setDraftId] = useState(null);

    const navigate = useNavigate();
  

    const handleKeyPress = (event) => {
      if (event.key === "Enter") {
        couponCreationStep1();
      }
    };

    const handleCouponNameChange = (event) => {
      const name = event.target.value.toUpperCase(); 
      setCouponName(name);
    };

    const handleClearCouponName = () => {
      setCouponName("");
    };
    
  
    const couponCreationStep1 = () => {
      if (couponName.length < 3) {
        toastr.warning("Enter at least 3 characters for the Coupon Name");
        return;
      }
      
      const isValidCouponName = /^[a-zA-Z0-9]+$/;
      
      if (!isValidCouponName.test(couponName)) {
        toastr.error("Invalid Coupon Name. Only alphanumeric characters are allowed.");
        return;
      }
      
      props.getDataFromAPI(
       
        `/partner/api/v1/coupon/create/draft`,
        "POST",
        {
          step: 1,
          couponName: couponName,
        },
        (response) => {
      
          
            console.log("API response:", response.draftId);
            //const { couponName, draftId } = response.data;
            //console.log("Coupon name:", couponName);
            localStorage.setItem("draftId",response.draftId)
            props.onChange_CouponCreation_Step1(response.draftId)
            setCouponName(couponName);
            setDraftId(draftId);
            navigate("/home/coupondescription");
          },

         
        
        (err) => {
          console.log("err ankit",err)
          toastr.error((`${err.message}`),{
            position:toast.POSITION.TOP_RIGHT,
            autoClose:1000
          });
        },
       
      );
      navigate("/home/coupondescription");
    };
    
    
    



 
  return (
    <>
      <CouponComponent
         couponName={couponName}
         handleCouponNameChange={handleCouponNameChange}
         handleKeyPress={handleKeyPress}
         handleNextButtonClick={couponCreationStep1}
         handleClearCouponName={handleClearCouponName}
        
      />
     
    </>
  );
};

function mapStateToProps({ props }) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
  onChange_CouponCreation_Step1,
 
})(CouponContainer);
