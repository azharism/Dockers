import { STEP1_DRAFTID } from "./constant.js";
import {STEP2_NEXTSTEP} from "./constant.js"
import { STEP3_NEXTSTEP } from "./constant.js";
import { STEP4_NEXTSTEP } from "./constant.js";
import { STEP5_NEXTSTEP } from "./constant.js";
import { STEP6_NEXTSTEP } from "./constant.js";
import { STEP7_NEXTSTEP } from "./constant.js";
import { STEP8_NEXTSTEP } from "./constant.js";
import { STEP10_NEXTSTEP } from "./constant.js";
import { STEP11_NEXTSTEP } from "./constant.js";
import { STEP12_NEXTSTEP } from "./constant.js";
import { STEP13_NEXTSTEP } from "./constant.js";
import { STEP14_NEXTSTEP } from "./constant.js";
import { STEP15_NEXTSTEP } from "./constant.js";
import { STEP18_NEXTSTEP } from "./constant.js";

export function onChange_CouponCreation_Step1(draftId) {
  console.log("coupon draft id",draftId)
  return {
    type: STEP1_DRAFTID,
    draftId,
  };
}

export function onChange_CouponDescription_Step2(nextStep) {
  console.log("coupon draft id description",nextStep)
  return {
    type: STEP2_NEXTSTEP,
    nextStep,
  };
}

export function onChange_CouponImage_Step3(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP3_NEXTSTEP,
    nextStep,
  };
}

export function onChange_CouponDate_Step4(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP4_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponDeeplink_Step5(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP5_NEXTSTEP,
    nextStep,
  };
  
}
export function onChange_CouponDiscountAmount_Step6(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP6_NEXTSTEP,
    nextStep,
  };
 
};
export function onChange_CouponCashbackAmount_Step7(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP7_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponCashbackAmountType2_Step8(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP8_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponCashbackAmountType_Step10(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP10_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponVendingMachines_Step11(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP11_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponAplicableItem_Step12(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP12_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponPaymentGateway_Step13(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP13_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponUseDuration_Step14(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP14_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponLimit_Step15(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP15_NEXTSTEP,
    nextStep,
  };
}
export function onChange_CouponTandC_Step18(nextStep) {
  console.log("coupon draft id image",nextStep)
  return {
    type: STEP18_NEXTSTEP,
    nextStep,
  };
}
