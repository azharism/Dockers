
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import { Button, Box, TextField } from "@mui/material";
import {  CouponDiscountCompComponent, CouponFreegiftComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
// import  CouponDeeplinkComponent  from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType2_Step8} from "../CouponCreate/action"
import { onChange_CouponCashbackAmountType_Step10 } from "../CouponCreate/action";
import { onChange_CouponVendingMachines_Step11 } from "../CouponCreate/action";
import { onChange_CouponAplicableItem_Step12 } from "../CouponCreate/action";
import { onChange_CouponPaymentGateway_Step13 } from "../CouponCreate/action";
import { onChange_CouponUseDuration_Step14 } from "../CouponCreate/action";
import { onChange_CouponLimit_Step15 } from "../CouponCreate/action";



const CouponFreegiftContainer = (props) => {
  console.log("CouponAmount props", props);
  const navigate = useNavigate();

  const [priorities, setPriorities] = useState([null, null, null]);

  

  // const handlePriorityChange = (index, event) => {
  //   const value = parseInt(event.target.value);
  //   if (!isNaN(value)) {
  //     const updatedPriorities = [...priorities];
  //     updatedPriorities[index] = value;
  //     setPriorities(updatedPriorities);
  //   }
  // };

  const handlePriorityChange = (index, event) => {
    const value = event.target.value;
    if (/^\d*$/.test(value)) {
      const updatedPriorities = [...priorities];
      updatedPriorities[index] = parseInt(value);
      setPriorities(updatedPriorities);
    }
  };
  
  
  
  

  const couponCreationStep8 = (flatTypeId) => {
    console.log("CLICK", localStorage.getItem("draftId"));
    const mvIdWithPriorities = [
      { mvId: 1, priority: priorities[0] },
      { mvId: 2, priority: priorities[1] },
      { mvId: 3, priority: priorities[2] }
    ];
    const payload = {
      step: 9,
      draftId: props.props && props.props.coupon.step1_draftId,
      freeGiftDetails: { mvIdWithPriorities }
    };
    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      payload,
      (response) => {
        console.log("API response step 6:", response);
  
        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response);
        props.onChange_CouponCashbackAmountType2_Step8(response);
        props.onChange_CouponCashbackAmountType_Step10(response);
        props.onChange_CouponVendingMachines_Step11(response);
        props.onChange_CouponAplicableItem_Step12(response);
        props.onChange_CouponPaymentGateway_Step13(response);
        props.onChange_CouponUseDuration_Step14(response);
        props.onChange_CouponLimit_Step15(response);
        navigate("/home/couponvmcreation");
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };
  
  
 
  const renderInputFields = () => {
    return priorities.map((priority, index) => (
      <div key={index} style={{ display: "flex", flexDirection: "column", position: "relative", top: "30px", width: "600px", margin: "auto" }}>
        <div style={{ margin: "20px", display: "flex", alignItems: "center", flexDirection: "row", width: "400px" }}>
          <div style={{ marginRight: "10px" }}> {index + 1} .</div>
          <div>
            <TextField
              style={{ margin: "18px", padding: "0px", color: "#b2b2b2" }}
              fullWidth
              type="number"
              value={priority === null ? "" : priority}
              onChange={(event) => handlePriorityChange(index, event)}
              placeholder=""
            />
          </div>
        </div>
      </div>
    ));
  };
  
  
  
  
  
  
  
  return (
    <>
   
  <CouponFreegiftComponent

couponCreationStep8={couponCreationStep8}
renderInputFields={renderInputFields}




  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    onChange_CouponDiscountAmount_Step6,
    onChange_CouponCashbackAmount_Step7,
    onChange_CouponCashbackAmountType2_Step8,
    onChange_CouponCashbackAmountType_Step10,
    onChange_CouponVendingMachines_Step11,
    onChange_CouponAplicableItem_Step12,
    onChange_CouponPaymentGateway_Step13,
    onChange_CouponUseDuration_Step14,
    onChange_CouponLimit_Step15,
    
  })(CouponFreegiftContainer);
