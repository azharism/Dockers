
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import { CouponDeeplinkComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
// import  CouponDeeplinkComponent  from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";



const CouponDeeplinkContainer = (props) => {
  console.log("CouponDesContainer props",props)
  const [deeplink, setDeeplink] = useState("");
  
  const navigate = useNavigate();
  

  const handleCouponDeeplinkChange = (event) => {
    const description = event.target.value;
    setDeeplink(description);
  };


  const handleClearCouponName = () => {
    setDeeplink("");
  };



  const couponCreationStep5 = () => {
   
   
    console.log("CKICK",localStorage.getItem("draftId"))
     if(deeplink===""){
      toastr.warning("Enter Coupon Deeplink")
      return;
    } 
    // const isValidCouponName = /^[a-zA-Z0-9]+$/;
      
    // if (!isValidCouponName.test(deeplink)) {
    //   toastr.error("Invalid Coupon Name. Only alphanumeric characters are allowed.");
    //   return;
    // }
    
    props.getDataFromAPI(

      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 5,
        draftId:props.props&&props.props.coupon.step1_draftId,
        deeplink: deeplink,
      },
      (response) => {
        console.log("API response step 2:", response);
        setDeeplink(deeplink)
      
        props.onChange_CouponDescription_Step2(response)
        props.onChange_CouponImage_Step3(response)
        props.onChange_CouponDate_Step4(response)
        props.onChange_CouponDeeplink_Step5(response)
       
       
        navigate("/home/coupondiscountamount");
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
    //navigate("/couponimage");
  };
  
  
    
  
  return (
    <>
   
  <CouponDeeplinkComponent
  handleCouponDeeplinkChange={handleCouponDeeplinkChange}
  couponCreationStep5={couponCreationStep5}
  deeplink={deeplink}
  handleClearCouponName={handleClearCouponName}
 
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    
  })(CouponDeeplinkContainer);
