import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../Loading/component";
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import gift from "../../../assests/gift.svg"
import discount from "../../../assests/Discount.svg"
import  wallet from "../../../assests/Wallet.svg"

export const CouponTypeComponent = ({
   
  handleCashback,
  
  handleDiscount,
  handleFreeGift,
 
  
}) => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  
  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create Coupon
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
          <div className="inputDiv" style={{display:"flex", flexDirection:"row", width:"100%"}}>
        <Box
          sx={{
            width: 800,
            maxWidth: "100%",
            alignItems: "center",
            
           
           
          }}
        >
            
          <label htmlFor="" className="couponLabel">
          Please select a coupon type
          </label>
          <div style={{width:"100% !important", display:"flex", justifyContent:"space-between", alignItems:"center", margin:"120px"}}>
          <div>
    <Card sx={{ maxWidth: "385px" , textAlign:"center", width:"300px", height:"280px", margin:"20px",boxShadow: "0px 4px 15px rgba(0, 0, 0, 0.13)"}}>
     
       <div style={{height:"160px", width:"100%"}}>
        <img style={{height:"100%", width:"100%"}} src={wallet} alt="" />
       </div>
       <CardContent>
          <Button className="coupon-typeBtn" variant="outlined" color="success" onClick={handleCashback}>Cashback</Button>
        </CardContent>
     
    </Card>
    </div>
    <div>
    <Card sx={{ maxWidth: "385px" , textAlign:"center", width:"300px", height:"280px",margin:"20px",boxShadow: "0px 4px 15px rgba(0, 0, 0, 0.13)"}}>
     
    <div style={{height:"160px", width:"100%"}}>
        <img style={{height:"100%", width:"100%"}} src={discount} alt="" />
       </div>
        <CardContent>
        <Button className="coupon-typeBtn"  variant="outlined" color="success" onClick={handleDiscount}>Discount</Button>
         
        </CardContent>
  
 </Card>
    </div>
    <div>
    <Card sx={{ maxWidth: "385px" , textAlign:"center", width:"300px", height:"280px",margin:"20px",boxShadow: "0px 4px 15px rgba(0, 0, 0, 0.13)"}}>
     
    <div style={{height:"160px", width:"100%"}}>
        <img style={{height:"100%", width:"100%"}} src={gift} alt="" />
       </div>
        <CardContent>
        <Button className="coupon-typeBtn"  variant="outlined" color="success" onClick={handleFreeGift}>Free Gift</Button>
         
        </CardContent>
     
    </Card>
    </div>
    
          </div>
          
        </Box>

       
      </div>

          </div>
        </div>
      </div>
    </div>
  );
};
