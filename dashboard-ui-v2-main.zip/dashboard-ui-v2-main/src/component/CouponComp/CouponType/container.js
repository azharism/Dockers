
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import {  CouponTypeComponent } from "./component";

import { useNavigate } from "react-router-dom";

import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType2_Step8 } from "../CouponCreate/action";



const CouponTypeContainer = (props) => {
  console.log("CouponAmount props",props)
  const navigate = useNavigate();
  const [couponType, setCouponType] = useState(); 

  const couponCreationStep8Cashback = () => {
    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 7,
        draftId: props.props && props.props.coupon.step1_draftId,
        couponType: 1
      },
      (response) => {
        console.log("API response step 8:", response);
        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response);
       
        navigate("/home/couponcashback")
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };
  
  const handleCashback = () => {
    setCouponType(1);
    couponCreationStep8Cashback();
  };
  

const handleDiscount = () => {
  setCouponType(5);
  props.getDataFromAPI(
    `/partner/api/v1/coupon/create/draft`,
    "POST",
    {
      step: 7,
      draftId: props.props && props.props.coupon.step1_draftId,
      couponType: 5
    },
    (response) => {
      console.log("API response step 8:", response);
      props.onChange_CouponDescription_Step2(response);
      props.onChange_CouponImage_Step3(response);
      props.onChange_CouponDate_Step4(response);
      props.onChange_CouponDeeplink_Step5(response);
      props.onChange_CouponDiscountAmount_Step6(response);
      props.onChange_CouponCashbackAmount_Step7(response);
      props.onChange_CouponCashbackAmountType2_Step8(response)
      navigate("/home/coupondiscountcomp")
    },
    (err) => {
      toastr.error("Error", "Failed to create coupon.");
    },
    true
  );
};


const handleFreeGift = () => {
  console.log("API response step free gift")
  setCouponType(2);
  couponCreationStep8FreeGift();
};

const couponCreationStep8FreeGift = () => {
  
  props.getDataFromAPI(
    `/partner/api/v1/coupon/create/draft`,
    "POST",
    {
      step: 7,
      draftId: props.props && props.props.coupon.step1_draftId,
      couponType: 2
    },
    (response) => {
      console.log("API response step 7:", response);
      props.onChange_CouponDescription_Step2(response);
      props.onChange_CouponImage_Step3(response);
      props.onChange_CouponDate_Step4(response);
      props.onChange_CouponDeeplink_Step5(response);
      props.onChange_CouponDiscountAmount_Step6(response);
      props.onChange_CouponCashbackAmount_Step7(response);
     
      navigate("/home/couponfreegift")
    },
    (err) => {
      toastr.error("Error", "Failed to create coupon.");
    },
    true
  );
};






  
  return (
    <>
   
  <CouponTypeComponent
  
  
  handleCashback={handleCashback}
  
  handleDiscount={handleDiscount}
  handleFreeGift={handleFreeGift}
  couponCreationStep8FreeGift={couponCreationStep8FreeGift}
  
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    onChange_CouponDiscountAmount_Step6,
    onChange_CouponCashbackAmount_Step7,
    onChange_CouponCashbackAmountType2_Step8
    
  })(CouponTypeContainer);
