
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import { CouponAmountComponent, CouponCashbackComponent, CouponPGComponent, CouponVMComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
// import  CouponDeeplinkComponent  from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType_Step10 } from "../CouponCreate/action";
import { onChange_CouponVendingMachines_Step11 } from "../CouponCreate/action";
import { onChange_CouponAplicableItem_Step12 } from "../CouponCreate/action";
import { onChange_CouponPaymentGateway_Step13 } from "../CouponCreate/action";


const CouponPGContainer = (props) => {
  console.log("CouponAmount props", props);
  const [flatAmount, setFlatAmount] = useState("");
  const [activeBtn, setActiveBtn] = useState("");
  const [percentageAmount, setPercentageAmount] = useState(0);
  const [pgIds, setPgIds] = useState([]);
  const [newPgIds, setNewPgIds] = useState([]);
  const navigate = useNavigate();

  const handleAddPgId = () => {
    if (newPgIds.trim() !== "") {
      const updatePgIds= pgIds.length > 0
      ? [...pgIds, `,${newPgIds}`] : [newPgIds]
      setPgIds(updatePgIds);
      setNewPgIds("");
    }
  };
 
  
  const handleChangePG = (event) => {
    setNewPgIds(event.target.value);
  };
  

  const handleBtnClick = (value) => {
    setActiveBtn(value);
  };

  const couponCreationStep13 = (flatTypeId) => {
    console.log("CLICK", localStorage.getItem("draftId"));
  
    
    if (!activeBtn) {
      toastr.error("Please select whether the coupon is applicable on certain Payment Gateway or not.");
      return;
    }
    
    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 13,
        draftId: props.props && props.props.coupon.step1_draftId,
        pgReliability: {
          isPg: activeBtn === "Yes",
          pgIds: pgIds
         
          }
      },
     
    
      (response) => {
        console.log("API response step 6:", response);
        
        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response)
        props.onChange_CouponCashbackAmountType_Step10(response)
        props.onChange_CouponVendingMachines_Step11(response)
        props.onChange_CouponAplicableItem_Step12(response)
        props.onChange_CouponPaymentGateway_Step13(response)
        navigate("/home/couponuseduration")
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };
  
  
  
  
  

  
  
  
    
  
  return (
    <>
   
  <CouponPGComponent
//   handleCouponCashbackFlatAmountChange={handleCouponCashbackFlatAmountChange}
//   handleCouponCashbackPercentageAmountChange={handleCouponCashbackPercentageAmountChange}
 
couponCreationStep13={couponCreationStep13}
  activeBtn={activeBtn}
flatAmount={flatAmount}
percentageAmount={percentageAmount}
handleBtnClick={handleBtnClick}
newPgIds={newPgIds}
handleAddPgId={handleAddPgId}
handleChangePG={handleChangePG}
pgIds={pgIds}
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    onChange_CouponDiscountAmount_Step6,
    onChange_CouponCashbackAmount_Step7,
    onChange_CouponCashbackAmountType_Step10,
    onChange_CouponVendingMachines_Step11,
    onChange_CouponAplicableItem_Step12,
    onChange_CouponPaymentGateway_Step13,
    
  })(CouponPGContainer);
