import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate } from "react-router-dom";
import ClearIcon from "@mui/icons-material/Clear";
import { IconButton, InputAdornment } from "@mui/material";

export const CouponImgComponent = ({
  couponImage,
  couponCreationStep3,
  handleCouponImageChange,
  handleKeyPress,
  handleClearCouponName,
}) => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create Coupon
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
            <div className="inputDiv">
              <Box
                sx={{
                  width: 500,
                  maxWidth: "100%",
                  alignItems: "center",
                }}
              >
                <label htmlFor="" className="couponLabel">
                  enter Coupon Image
                </label>

                <div
                  style={{
                    width: "600px",
                    height: "60px",
                    border: "1px solid #ccc",
                    borderRadius: "16px",
                    marginTop: "20px",
                    marginLeft: "20px",
                  }}
                >
                  <input
                    type="file"
                    value={couponImage}
                    onChange={handleCouponImageChange}
                    onKeyPress={handleKeyPress}
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          {couponImage && (
                            <IconButton onClick={handleClearCouponName}>
                              <ClearIcon />
                            </IconButton>
                          )}
                        </InputAdornment>
                      ),
                    }}
                  />
                </div>
                {/* <input type="file"  value={couponImage}  onChange={handleCouponImageChange}/> */}
              </Box>

              <Box className="usersrolebtn">
                <Button className="backbtn" onClick={goback}>
                  Cancel
                </Button>

                <Button className="savebtnupdate" onClick={couponCreationStep3}>
                  next
                </Button>
              </Box>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
