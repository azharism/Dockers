
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";

import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
import { CouponDesComponent, CouponImgComponent } from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";


const CouponImgContainer = (props) => {
  console.log("CouponImgContainer props",props)
  const [couponImage, setCouponImage] = useState("");
  
  const navigate = useNavigate();
  //const [draftId, setDraftId] = useState(null); // state variable for draftId
  // const { draftId } = props.location.state;

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      couponCreationStep3();
    }
  };
  const handleCouponImageChange = (event) => {
    const image = event.target.value;
    setCouponImage(image);
  };

  
  const handleClearCouponName = () => {
    setCouponImage("");
  };
  const couponCreationStep3 = () => {
    console.log("CKICK",localStorage.getItem("draftId"))
    if(couponImage===""){
      toastr.warning("Enter Coupon Image")
      return;
    } 
  
    console.log("couponImgcon-------")
    props.getDataFromAPI(

      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 3,
        draftId:props.props&&props.props.coupon.step1_draftId,
        couponImage: couponImage,
      },
      (response) => {
        console.log("API response step 3:", response);
        localStorage.getItem("draftId", response.draftId)
        setCouponImage(couponImage)
        props.onChange_CouponDescription_Step2(response)
        props.onChange_CouponImage_Step3(response)
       
        navigate("/home/coupondate");
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
    //navigate("/couponimage");
  };
  
  
    
  
  return (
    <>
   
  <CouponImgComponent
  handleCouponImageChange={handleCouponImageChange}
  couponCreationStep3={couponCreationStep3}
  couponImage={couponImage}
  handleKeyPress={handleKeyPress}
  handleClearCouponName={handleClearCouponName}
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    
  })(CouponImgContainer);
