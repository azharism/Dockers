import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../Loading/component";
import ClearIcon from "@mui/icons-material/Clear";
import { IconButton, InputAdornment } from "@mui/material";




export const CouponAmountComponent = ({
    handleCouponMinAmountChange,
  handleCouponMaxAmountChange,
  minAmount,
  maxAmount,
 couponCreationStep6,
 handleClearCouponName,
  
  
  
}) => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create Coupon
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
          <div className="inputDiv" style={{display:"flex", flexDirection:"row", width:"100%"}}>
        <Box
          sx={{
            width: 800,
            maxWidth: "100%",
            alignItems: "center",
           
           
          }}
        >
            
          <label htmlFor="" className="couponLabel" style={{width:"800px"}}>
          enter given order amount range for which the coupon is applicable 
          </label>
          <div style={{display:"flex"}}>

          <TextField
            style={{ margin: "18px", padding: "0px", color: "#b2b2b2", borderRadius:"12px" }}
           
            label=" Enter Minimum Amount"
           type="number"
            value={minAmount}
            onChange={handleCouponMinAmountChange}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  {minAmount && (
                    <IconButton onClick={handleClearCouponName}>
                      <ClearIcon />
                    </IconButton>
                  )}
                </InputAdornment>
              )
            }}
           
          />
          <div style={{borderLeft:"2px dashed #ccc", height:"70px", marginTop:"30px"}}> </div>
          
           <TextField
            style={{ margin: "18px", padding: "0px", color: "#b2b2b2", borderRadius:"12px" }}
            
            label=" Enter Maximum Amount"
           type="number"
            value={maxAmount}
            onChange={handleCouponMaxAmountChange}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  {maxAmount && (
                    <IconButton onClick={handleClearCouponName}>
                      <ClearIcon />
                    </IconButton>
                  )}
                </InputAdornment>
              )
            }}
            
          />
          </div>
          
        </Box>

        <Box className="usersrolebtn">
        <Button className="backbtn" onClick={goback}  style={{textTransform: "capitalize"}}>
         Cancel
        </Button>

        <Button
          className="savebtnupdate"
          onClick={couponCreationStep6}
          style={{textTransform: "capitalize"}}
          // disabled={!validCouponName || loading}
        >
        procced
        </Button>
      </Box>
      </div>

          </div>
        </div>
      </div>
    </div>
  );
};
