
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import { CouponAmountComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
// import  CouponDeeplinkComponent  from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";



const CouponAmountContainer = (props) => {
  console.log("CouponAmount props",props)
  const[minAmount, setMinAmount] = useState("")
  const[maxAmount, setMaxAmount] = useState("")
  
  const navigate = useNavigate();
  

  const handleCouponMinAmountChange = (event) => {
    const minimumAmount = event.target.value;
    setMinAmount(minimumAmount.toUpperCase());
  };
  const handleCouponMaxAmountChange = (event) => {
    const maximumAmount = event.target.value;
    setMaxAmount(maximumAmount.toUpperCase());
  };

  const handleClearCouponName = () => {
    setMinAmount("");
    setMaxAmount(" ")
  };

  const couponCreationStep6 = () => {
    console.log("CLICK", localStorage.getItem("draftId"));
    if (minAmount === "") {
      toastr.warning("Enter Coupon min amount");
      return;
    }
    if (maxAmount === "") {
      toastr.warning("Enter Coupon max amount");
      return;
    }
    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 6,
        draftId: props.props && props.props.coupon.step1_draftId,
        orderReliability: {
          maxAmount: maxAmount,
          minAmount: minAmount,
          isOrder: true, // include this if necessary
          cashbackAmount: null, // include this if necessary
        },
      },
      (response) => {
        console.log("API response step 6:", response);
        setMaxAmount(maxAmount);
        setMinAmount(minAmount);
  
        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
  
        navigate("/home/coupontype");
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };
  
  
  
    
  
  return (
    <>
   
  <CouponAmountComponent
  handleCouponMinAmountChange={handleCouponMinAmountChange}
  handleCouponMaxAmountChange={handleCouponMaxAmountChange}
  couponCreationStep6={couponCreationStep6}
  maxAmount={maxAmount}
  minAmount={minAmount}
  handleClearCouponName={handleClearCouponName}
  
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    onChange_CouponDiscountAmount_Step6,
    
  })(CouponAmountContainer);
