import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";
import { CouponUseDurationComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType_Step10 } from "../CouponCreate/action";
import { onChange_CouponVendingMachines_Step11 } from "../CouponCreate/action";
import { onChange_CouponAplicableItem_Step12 } from "../CouponCreate/action";
import { onChange_CouponPaymentGateway_Step13 } from "../CouponCreate/action";
import { onChange_CouponUseDuration_Step14 } from "../CouponCreate/action";
import { onChange_CouponLimit_Step15 } from "../CouponCreate/action";

const CouponLimitContainer = (props) => {
  console.log("CouponAmount props", props);

  const [activeBtn, setActiveBtn] = useState("");
  const [couponLimit, setCouponLimit] = useState("");
 
  const navigate = useNavigate();

  const handleChangeCouponLimit = (event) => {
    setCouponLimit(event.target.value);
  };

  const handleBtnClick = (value) => {
    setActiveBtn(value);
  };

  const couponCreationStep15 = (flatTypeId) => {
    console.log("CLICK", localStorage.getItem("draftId"));

    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 15,
        draftId: props.props && props.props.coupon.step1_draftId,
        couponLimit: couponLimit,
      },

      (response) => {
        console.log(" coupon name", response);

        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response);
        props.onChange_CouponCashbackAmountType_Step10(response);
        props.onChange_CouponVendingMachines_Step11(response);
        props.onChange_CouponAplicableItem_Step12(response);
        props.onChange_CouponPaymentGateway_Step13(response);
        props.onChange_CouponUseDuration_Step14(response);
        props.onChange_CouponLimit_Step15(response);
       
        navigate("/home/coupontnc")
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };

  // const createCouponAPI = () => {
  //   console.log("CLICK", localStorage.getItem("draftId"));

  //   console.log("createCouponAPI", createCouponAPI);

  //   props.getDataFromAPI(
  //     `/partner/api/v1/coupon/create/${
  //       props && props.props && props.props.coupon.step1_draftId
  //     }`,
  //     "POST",
  //     {
  //       isCouponCreated: true,
  //     },

  //     (response) => {
  //       console.log("API response step 16:", response);
  //       setIsCouponCreated(isCouponCreated);

  //       setShow(false);

  //       setCouponId(response.couponId);

  //       setNowcouponCreated(true);
  //     },
  //     (err) => {
  //       toastr.error("Error", "Failed to create coupon.");
  //       setShow(false);
  //     },
  //     true
  //   );
  // };

  return (
    <>
      <CouponUseDurationComponent
        couponCreationStep15={couponCreationStep15}
        activeBtn={activeBtn}
        couponLimit={couponLimit}
        handleChangeCouponLimit={handleChangeCouponLimit}
        handleBtnClick={handleBtnClick}
        
       
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
  onChange_CouponDescription_Step2,
  onChange_CouponImage_Step3,
  onChange_CouponDate_Step4,
  onChange_CouponDeeplink_Step5,
  onChange_CouponDiscountAmount_Step6,
  onChange_CouponCashbackAmount_Step7,
  onChange_CouponCashbackAmountType_Step10,
  onChange_CouponVendingMachines_Step11,
  onChange_CouponAplicableItem_Step12,
  onChange_CouponPaymentGateway_Step13,
  onChange_CouponUseDuration_Step14,
  onChange_CouponLimit_Step15,
})(CouponLimitContainer);
