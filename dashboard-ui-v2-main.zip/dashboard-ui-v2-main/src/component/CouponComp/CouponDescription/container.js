
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";

import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
import { CouponDesComponent } from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";

const CouponDesContainer = (props) => {
  console.log("CouponDesContainer props",props)
  const [couponDescription, setCouponDescription] = useState("");
  
  const navigate = useNavigate();
  //const [draftId, setDraftId] = useState(null); // state variable for draftId
  // const { draftId } = props.location.state;
  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      couponCreationStep2();
    }
  };
  const handleClearCouponName = () => {
    setCouponDescription("");
  };

  const handleCouponDescriptionChange = (event) => {
    const description = event.target.value;
    setCouponDescription(description);
  };
  
  const couponCreationStep2 = () => {
    console.log("CKICK",localStorage.getItem("draftId"))
   if(couponDescription===""){
      toastr.warning("Enter Coupon Description")
      return;
    } 
//     const isValidCouponDescription = /^[a-zA-Z0-9\s]+$/;

// if (!isValidCouponDescription.test(couponDescription)) {
//   toastr.error("Invalid Coupon Description. Only alphanumeric characters and spaces are allowed.");
//   return;
// }


    props.getDataFromAPI(

      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 2,
        draftId:props.props&&props.props.coupon.step1_draftId,
        couponDescription: couponDescription,
      },
      (response) => {
        console.log("API response step 2:", response);
        localStorage.setItem("draftId",response.draftId)
        setCouponDescription(couponDescription)
        props.onChange_CouponDescription_Step2(response)
       
        navigate("/home/couponimage");
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
    //navigate("/couponimage");
  };
  
  
    
  
  return (
    <>
   
  <CouponDesComponent
  handleCouponDescriptionChange={handleCouponDescriptionChange}
  couponCreationStep2={couponCreationStep2}
  couponDescription={couponDescription}
  handleKeyPress={handleKeyPress}
  handleClearCouponName={handleClearCouponName}
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    
  })(CouponDesContainer);
