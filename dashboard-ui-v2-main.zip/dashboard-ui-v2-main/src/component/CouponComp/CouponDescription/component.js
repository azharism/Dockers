import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../Loading/component";
import ClearIcon from "@mui/icons-material/Clear";
import { IconButton, InputAdornment } from "@mui/material";


export const CouponDesComponent = ({
  handleCouponDescriptionChange,
  couponDescription,
 couponCreationStep2,
 handleKeyPress,
 handleClearCouponName,
  
}) => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create Coupon
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
          <div className="inputDiv">
        <Box
          sx={{
            width: 500,
            maxWidth: "100%",
            alignItems: "center",
          }}
        >
          <label htmlFor="" className="couponLabel">
          enter Coupon description
          </label>
          <TextField
            style={{ margin: "18px", padding: "0px", color: "#b2b2b2", borderRadius:"12px",fontFamily: 'Crimson Text' }}
            fullWidth
            label=" Coupon Description"
            id="fullWidth"
            value={couponDescription}
            onChange={handleCouponDescriptionChange}
            multiline
            rows={4}
            maxRows={8}
            onKeyPress={handleKeyPress}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  {couponDescription && (
                    <IconButton onClick={handleClearCouponName}>
                      <ClearIcon />
                    </IconButton>
                  )}
                </InputAdornment>
              )
            }}
          />
        </Box>

        <Box className="usersrolebtn">
        <Button className="backbtn" onClick={goback}>
         Cancel
        </Button>

        <Button
          className="savebtnupdate"
          onClick={couponCreationStep2}
          // disabled={!validCouponName || loading}
        >
        next
        </Button>
      </Box>
      </div>

          </div>
        </div>
      </div>
    </div>
  );
};
