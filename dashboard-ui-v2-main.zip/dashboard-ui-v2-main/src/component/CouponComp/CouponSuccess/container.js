
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import {  CouponSuccessComponent, CouponVMComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType_Step10 } from "../CouponCreate/action";
import { onChange_CouponVendingMachines_Step11 } from "../CouponCreate/action";


const CouponSuccessContainer = (props) => {
  console.log("CouponAmount props", props);
  const [show, setShow]= useState()
 const handleClose = () => setShow(false);
 const handleShow = () => setShow(true);
  const navigate = useNavigate();

  
  
 


 

 

  const couponCreationStep11 = (flatTypeId) => {
    console.log("CLICK", localStorage.getItem("draftId"));
  
    
   
    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 11,
        draftId: props.props && props.props.coupon.step1_draftId,
        
      },
      
      (response) => {
        console.log("API response step 6:", response);
        
        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response)
        props.onChange_CouponCashbackAmountType_Step10(response)
        props.onChange_CouponVendingMachines_Step11(response)
        setShow(false)
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };
  
  
  return (
    <>
   
  <CouponSuccessComponent

couponCreationStep11={couponCreationStep11}
handleClose={handleClose}
show={show}
 
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    onChange_CouponDiscountAmount_Step6,
    onChange_CouponCashbackAmount_Step7,
    onChange_CouponCashbackAmountType_Step10,
    onChange_CouponVendingMachines_Step11,
    
  })(CouponSuccessContainer);
