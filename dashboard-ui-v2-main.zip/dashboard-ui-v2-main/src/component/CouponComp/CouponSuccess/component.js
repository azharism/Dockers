import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../Loading/component";
import emotion1 from "../../../assests/emotion1.png";
import Modal from "react-bootstrap/Modal";

export const CouponSuccessComponent = (props) => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };

  return (
    <>
      <Modal
        show={props.show}
        //onHide={handleClose}

        style={{ width: "100%", margin: "auto" }}
      >
        <Modal.Body>
          <img
            style={{ width: "150px", marginTop: "-70px" }}
            src={emotion1}
            alt=""
          />
          <p>coupon created</p>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <span>coupon name: {props.couponName}</span>
            <span> coupon id: {props.couponId}</span>
          </div>
        </Modal.Body>

        <Button
          variant="success"
          style={{
            backgroundColor: "green",
            width: "95%",
            color: "#fff",
            fontSize: "18px",
            fontWeight: "bold",
            margin: "12px 10px 10px 12px",
          }}
          onClick={props.okClick}
        >
          Ok
        </Button>
      </Modal>
    </>
  );
};
