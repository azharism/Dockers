import React, { useState } from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";

import ClearIcon from "@mui/icons-material/Clear";
import { IconButton, InputAdornment } from "@mui/material";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';

import CalendarTodayIcon from '@mui/icons-material/CalendarToday';





export const CouponDateComponent = ({
  couponCreationStep4,
  handleCouponDateChange,
  couponExpiry,
  date,
  currentDateString,
  handleKeyPress,
  handleClearCouponName,
  handleClearCouponDate

}) => {
  
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create Coupon
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
            <div className="inputDiv">
              <Box
                sx={{
                  width: 500,
                  maxWidth: "100%",
                  alignItems: "center",
                  display:"flex",
                  flexDirection:"column",
                  alignItems:"start"
                }}
              >
                <label htmlFor="" className="couponLabel" >
                  enter Coupon Expiry date
                </label>

              
        {/* <input type="date"  value={couponExpiry}  onChange={handleCouponDateChange}  style={{ margin: "18px", padding: "0px", borderRadius:"12px", width:"400px", height:"50px", border:"1px solid #ccc" }}
            fullWidth
            label=" Coupon Expiry Date"
           /> */}

<input

        type="date"
        value={couponExpiry}
        onChange={handleCouponDateChange}
        min={currentDateString} // Set the minimum date to disable previous dates
        style={{
          margin: "18px",
          padding:"20px",
          borderRadius: "12px",
          width: "400px",
          height: "50px",
          border: "1px solid #ccc",
          textTransform:"uppercase",
          fontSize:"20px",
          
        }}
        fullWidth
        label="Coupon Expiry Date"
        onKeyPress={handleKeyPress}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              {couponExpiry && (
                <IconButton onClick={handleClearCouponName}>
                  <ClearIcon />
                </IconButton>
              )}
            </InputAdornment>
          )
        }}
      />
     
     

              </Box>

              <Box className="usersrolebtn">
                <Button className="backbtn" onClick={goback}>
                  Cancel
                </Button>

                <Button
                  className="savebtnupdate"
                  onClick={couponCreationStep4}
                  // disabled={!validCouponName || loading}
                >
                  next
                </Button>
              </Box>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
