
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import { useNavigate } from "react-router-dom";
import { CouponDateComponent} from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import dayjs from "dayjs";


const CouponDateContainer = (props) => {
  console.log("CouponDateContainer props",props)
  const [couponExpiry, setCouponExpiry] = useState("");
  console.log("coupon expiry", couponExpiry)
  
  const navigate = useNavigate();
  
  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      couponCreationStep4();
    }
  };

  const handleCouponDateChange = (event) => {
    const date = event?.target?.value; // Add null check here
    if (date) {
      const formattedDate = dayjs(date).format('YYYY-MM-DD');
      setCouponExpiry(formattedDate);
    }
  };
  const handleClearCouponName = () => {
    setCouponExpiry("");
  };

  const handleClearCouponDate = () => {
    setCouponExpiry('');
  };
  
  
  const currentDate = new Date();
  const currentDateString = currentDate.toISOString().split('T')[0];

  

  const couponCreationStep4 = () => {
    console.log("CKICK",localStorage.getItem("draftId"))
    if(couponExpiry===""){
      toastr.warning("Enter Coupon Expiry Date")
      return;
    } 
    console.log("couponImgcon-------")
    props.getDataFromAPI(

      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 4,
        draftId:props.props&&props.props.coupon.step1_draftId,
        couponExpiry: couponExpiry,
      },
      (response) => {
        console.log("API response step 3:", response);
        setCouponExpiry(couponExpiry)
        props.onChange_CouponDescription_Step2(response)
        props.onChange_CouponImage_Step3(response)
        props.onChange_CouponDate_Step4(response)
       
        navigate("/home/coupondeeplink");
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
    //navigate("/couponimage");
  };
  
  
    
  
  return (
    <>
   
  <CouponDateComponent
  handleCouponDateChange={handleCouponDateChange}
  couponCreationStep4={couponCreationStep4}
  couponExpiry={couponExpiry}
  currentDateString={currentDateString}
  handleKeyPress={handleKeyPress}
  handleClearCouponName={handleClearCouponName}
  handleClearCouponDate={handleClearCouponDate}
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    
  })(CouponDateContainer);
