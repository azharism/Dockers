
import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { toastr } from "react-redux-toastr";
import { CouponAmountComponent, CouponAplicableItemComponent, CouponCashbackComponent, CouponVMComponent } from "./component";
import LoadingSpinner from "../../Loading/component";
import { useNavigate } from "react-router-dom";
// import  CouponDeeplinkComponent  from "./component";
import { onChange_CouponDescription_Step2 } from "../CouponCreate/action";
import { onChange_CouponImage_Step3 } from "../CouponCreate/action";
import { onChange_CouponDate_Step4 } from "../CouponCreate/action";
import { onChange_CouponDeeplink_Step5 } from "../CouponCreate/action";
import { onChange_CouponDiscountAmount_Step6 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmount_Step7 } from "../CouponCreate/action";
import { onChange_CouponCashbackAmountType_Step10 } from "../CouponCreate/action";
import { onChange_CouponVendingMachines_Step11 } from "../CouponCreate/action";
import { onChange_CouponAplicableItem_Step12 } from "../CouponCreate/action";


const CouponAplicableItemContainer = (props) => {
  console.log("CouponAmount props", props);
 
  const [activeBtn, setActiveBtn] = useState();
  
  const [activeMvIdBtn, setActiveMvIdBtn] = useState();
  const [showMvIdInput, setShowMvIdInput] = useState(false);
  const [activeSlotIdBtn, setActiveSlotIdBtn] = useState();
  const [showSlotIdInput, setShowSlotIdInput] = useState(false);
  const [activeMealIdBtn, setActiveMealIdBtn] = useState();
  const [showMealIdInput, setShowMealIdInput] = useState(false);
  
  const [newMvId, setNewMvId] = useState([]);
  const [newSlotId, setNewSlotId]= useState([])
  const [slotIds, setSlotIds] = useState([]);
  const [mvIds, setMvIds] = useState([]);
  const [mealTypeIds, setMealTypeIds] = useState([]);
  const [newMealTypeIds, setNewMealTypeIds]= useState([])
 
  const navigate = useNavigate();

  const handleAddMvId = () => {
    if (newMvId.trim() !== "") {
      const updateMvIds= mvIds.length > 0
      ? [...mvIds, `,${newMvId}`] : [newMvId]
      setMvIds(updateMvIds);
      setNewMvId("");
    }
  };
  
  const handleAddSlot = ()=>{
    if (newSlotId.trim() !== "") {
      const updateSlotIds= slotIds.length > 0
      ? [...slotIds, `,${newSlotId}`] : [newSlotId]
      setSlotIds(updateSlotIds);
      setNewSlotId("");
    }
  }

  const handleAddMeal = () => {
    if (newMealTypeIds.trim() !== "") {
      const updatedMealTypeIds = mealTypeIds.length > 0
        ? [...mealTypeIds, `,${newMealTypeIds}`]
        : [newMealTypeIds];
      setMealTypeIds(updatedMealTypeIds);
      setNewMealTypeIds("");
    }
  }
  
  
  const handleChangeSlotIds = (event) => {
    setNewSlotId(event.target.value);
  };
  const handleChangeMealTypesIds = (event) => {
    setNewMealTypeIds(event.target.value);
  };
  const handleChangeMvIds = (event) => {
    setNewMvId(event.target.value);
  };
  
  

  const handleMvIdBtnClick = (value) => {
    setActiveMvIdBtn(value);
    setShowMvIdInput(value === "Yes");
   
  };
  const handleSlotIdBtnClick = (value) => {
    setActiveSlotIdBtn(value);
    setShowSlotIdInput(value === "Yes");
   
  };
  const handleMealIdBtnClick = (value) => {
    setActiveMealIdBtn(value);
    setShowMealIdInput(value === "Yes");
   
  };
  

  const couponCreationStep12 = (flatTypeId) => {
    console.log("CLICK", localStorage.getItem("draftId"));
  
  
   
    props.getDataFromAPI(
      `/partner/api/v1/coupon/create/draft`,
      "POST",
      {
        step: 12,
        draftId: props.props && props.props.coupon.step1_draftId,
        mvReliability: {
          isMv: activeBtn === "Yes",
          mvIds: mvIds
        },
        slotIdReliability: {
          isSlotId: activeBtn === "Yes",
          slotIds: slotIds
        },
        mealTypeReliability: {
          isMealType: activeBtn === "Yes",
          mealTypeIds: mealTypeIds
        }
      
      
      },
      
      (response) => {
        console.log("API response step 6:", response);
        
        props.onChange_CouponDescription_Step2(response);
        props.onChange_CouponImage_Step3(response);
        props.onChange_CouponDate_Step4(response);
        props.onChange_CouponDeeplink_Step5(response);
        props.onChange_CouponDiscountAmount_Step6(response);
        props.onChange_CouponCashbackAmount_Step7(response)
        props.onChange_CouponCashbackAmountType_Step10(response)
        props.onChange_CouponVendingMachines_Step11(response)
        props.onChange_CouponAplicableItem_Step12(response)
        navigate("/home/couponpg")
      },
      (err) => {
        toastr.error("Error", "Failed to create coupon.");
      },
      true
    );
  };
  
  
  
  
  

  
  
  
    
  
  return (
    <>
   
  <CouponAplicableItemComponent

couponCreationStep12={couponCreationStep12}
  activeBtn={activeBtn}

newMealTypeIds={newMealTypeIds}
newMvId={newMvId}
newSlotId={newSlotId}
mvIds={mvIds}
slotIds={slotIds}
mealTypeIds={mealTypeIds}
handleChangeMvIds={handleChangeMvIds}
handleChangeSlotIds={handleChangeSlotIds}
handleChangeMealTypesIds={handleChangeMealTypesIds}
handleAddMeal={handleAddMeal}
handleAddMvId={handleAddMvId}
handleAddSlot={handleAddSlot}
handleMvIdBtnClick={handleMvIdBtnClick}
activeMvIdBtn={activeMvIdBtn}
showMvIdInput={showMvIdInput}
handleMealIdBtnClick={handleMealIdBtnClick}
activeMealIdBtn={activeMealIdBtn}
showMealIdInput={showMealIdInput}
handleSlotIdBtnClick={handleSlotIdBtnClick}
activeSlotIdBtn={activeSlotIdBtn}
showSlotIdInput={showSlotIdInput}
  />
     
    </>
  
  )
}

function mapStateToProps(props ) {
    return {
      props,
     
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    onChange_CouponDescription_Step2,
    onChange_CouponImage_Step3,
    onChange_CouponDate_Step4,
    onChange_CouponDeeplink_Step5,
    onChange_CouponDiscountAmount_Step6,
    onChange_CouponCashbackAmount_Step7,
    onChange_CouponCashbackAmountType_Step10,
    onChange_CouponVendingMachines_Step11,
    onChange_CouponAplicableItem_Step12,
    
  })(CouponAplicableItemContainer);
