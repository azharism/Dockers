import React, { useState } from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../Loading/component";

export const CouponAplicableItemComponent = ({
    
    couponCreationStep12,
    handleMvIdBtnClick,
    activeBtn,
    handleChangeMvIds,
    handleChangeSlotIds,
    handleChangeMealTypesIds,
    newMealTypeIds,
    newMvId,
    newSlotId,
    mvIds,
    handleAddVmId,
    newVmId,
    handleChangeVM,
    slotIds,
    mealTypeIds,
    handleAddMeal,
    handleAddMvId,
    handleAddSlot,
    activeMvIdBtn,
    handleBtnClick,
    showMvIdInput,
    handleMealIdBtnClick,
    activeMealIdBtn,
    showMealIdInput,
    handleSlotIdBtnClick,
    activeSlotIdBtn,
    showSlotIdInput





   
}) => {
    // const [activeBtn, setActiveBtn] = useState("flat");
    // const [cashbackAmount, setCashbackAmount] = useState("");
  
    // const handleBtnClick = (type) => {
    //     setActiveBtn(type);
    //     if (type === 'flat') {
    //       couponCreationStep10(1);
    //     } else if (type === 'percentage') {
    //       couponCreationStep10(2);
    //     }
    //   };
      
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  
  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create Coupon
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
            <div style={{display:"flex"}}>
            <div className="inputDiv">
      <Box
        sx={{
          width: 400,
          maxWidth: "100%",
          alignItems: "center"
        }}
      >
        <label htmlFor="" className="couponLabel">
        Is it only applicable on certain Slots?
        </label>
        <div>
          <div>
            
          </div>
        <div className="cashback-div1">
      <button
        className={`cashback-btn ${
          activeSlotIdBtn === "Yes" ? "active-btn" : "inactive-btn"
        }`}
        onClick={() => handleSlotIdBtnClick("Yes")}
      >
        Yes
      </button>
      <button
        className={`cashback-btn ${
          activeSlotIdBtn === "No" ? "active-btn" : "inactive-btn"
        }`}
        onClick={() => handleSlotIdBtnClick("No")}
      >
        No
      </button>
     
    </div>

        
 {showSlotIdInput  && (
    <>
       <TextField
       style={{ margin: "18px", padding: "0px", color: "#b2b2b2", width:"400px" }}
       
       label="Enter Slot ID"
      type="number"
       value={newSlotId}
       onChange={handleChangeSlotIds}
     />

<div style={{display:"flex", justifyContent:"end", width:"800", margin:"auto", textAlign:"end", flexDirection:"row"}}>
<button style={{border:"none ", backgroundColor:"none", color:"blue", }} variant="primary" onClick={handleAddSlot}>+add</button>

</div>


     </>
     
      )}

        </div>
        
      </Box>
     
     
    
      
    </div>
    <div className="inputDiv">
      <Box
        sx={{
          width: 400,
          maxWidth: "100%",
          alignItems: "center"
        }}
      >
        <label htmlFor="" className="couponLabel">
        2. Is it only applicable on certain Products?
        </label>
        <div>
        <div className="cashback-div1">
      <button
        className={`cashback-btn ${
          activeMvIdBtn === "Yes" ? "active-btn" : "inactive-btn"
        }`}
        onClick={() => handleMvIdBtnClick("Yes")}
      >
        Yes
      </button>
      <button
        className={`cashback-btn ${
          activeMvIdBtn === "No" ? "active-btn" : "inactive-btn"
        }`}
        onClick={() => handleMvIdBtnClick("No")}
      >
        No
      </button>
     
    </div>

        
 {showMvIdInput  && (
    <>
       <TextField
       style={{ margin: "18px", padding: "0px", color: "#b2b2b2",width:"400px" }}
      
       label="Enter MV ID"
      type="number"
       value={newMvId}
       onChange={handleChangeMvIds}
     />

<div style={{display:"flex", justifyContent:"end", width:"800", margin:"auto", textAlign:"end", flexDirection:"row"}}>
<button style={{border:"none ", backgroundColor:"none", color:"blue", }} variant="primary" onClick={handleAddMvId}>+add</button>

</div>





     </>
     
      )}

        </div>
        
      </Box>
     
     
     
      
    </div>
    <div className="inputDiv">
      <Box
        sx={{
          width: 400,
          maxWidth: "100%",
          alignItems: "center"
        }}
      >
        <label htmlFor="" className="couponLabel">
        3. Is it only applicable on certain Meal type?
        </label>
        <div>
        <div className="cashback-div1">
      <button
        className={`cashback-btn ${
          activeMealIdBtn === "Yes" ? "active-btn" : "inactive-btn"
        }`}
        onClick={() => handleMealIdBtnClick("Yes")}
      >
        Yes
      </button>
      <button
        className={`cashback-btn ${
          activeMealIdBtn === "No" ? "active-btn" : "inactive-btn"
        }`}
        onClick={() => handleMealIdBtnClick("No")}
      >
        No
      </button>
     
    </div>

        
 {showMealIdInput  && (
    <>
       <TextField
       style={{ margin: "18px", padding: "0px", color: "#b2b2b2" ,width:"400px "}}
       className="textfield"
       label="Enter Meal Type ID"
      type="number"
       value={newMealTypeIds}
       onChange={handleChangeMealTypesIds}
     />

<div style={{display:"flex", justifyContent:"end", width:"800", margin:"auto", textAlign:"end", flexDirection:"row"}}>
<button style={{border:"none ", backgroundColor:"none", color:"blue", }} variant="primary" onClick={handleAddMeal}>+add</button>

</div>





     </>
     
      )}

        </div>
        
      </Box>
     
    
     
      
    </div>
            </div>
            
          <div>

<Box className="usersrolebtn">
    <Button className="backbtn" onClick={goback}>
      Cancel
    </Button>

    <Button
className="savebtnupdate"
onClick={couponCreationStep12}

>
Proceed
</Button>
  </Box>
 
</div>
           
           
   
    
          </div>
          <div style={{ width:"1200px",position:"absolute",top:"600px", display:"flex", height:"95px", flexDirection:"column", marginLeft:"30px", padding:"10px",background: "#F6F6F6"
,borderRadius: "15px"}}>
   <div style={{display:"flex", flexDirection:"row"}}>
  Add slot ids :  {slotIds && slotIds.map((id) => (
        <div key={id}  >{id}</div>
        ))}
  </div> 
  <div style={{display:"flex", flexDirection:"row"}}>
  Add Mv ids :  {mvIds && mvIds.map((id) => (
        <div key={id} >{id}</div>
        ))}
  </div> 
  <div style={{display:"flex", flexDirection:"row"}}>
  Add Meal ids :  {mealTypeIds && mealTypeIds.map((id) => (
        <div key={id} >{id}</div>
        ))}
  </div> 
      </div>  
        </div>
       
      </div>
    </div>
  );
};
