export const ON_CHANGE_OTP = '@otp/ON_CHANGE_OTP ';
export const SAVE_OTP_RES = '@otp/SAVE_OTP_RES';
export const LOADING = '@login/LOADING';
  