import {
  LOADING,
  ON_CHANGE_OTP ,
SAVE_OTP_RES
} from '../ForgotOTP/constants';

export function onChange_OTP(mobile) {
  console.log("mobile",mobile)
  return {
    type:  ON_CHANGE_OTP,
    mobile,
  };
}

export function saveForgetOtpRes(forget_otp_res) {
  console.log("saveForgetOtpRes",forget_otp_res)
  return {
    type: SAVE_OTP_RES,
    forget_otp_res,
  };
}
export function setLoading(loading) {
  return {
    type: LOADING,
    loading,
  };
}