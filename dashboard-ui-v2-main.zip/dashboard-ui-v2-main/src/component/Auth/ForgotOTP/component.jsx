import React from 'react'
import "./style.css";
import { useState,useEffect, useRef } from 'react';
import logo from "../../../assests/Daalchini-logo.svg";
import JunkFood from "../../../assests/JunkFood.png";
import otpIcon from "../../../assests/otpIcon.svg";
import { Link } from 'react-router-dom';
import LoadingSpinner from '../../Loading/component';

const initialCount = 30;
const twoDigits = (num) => String(num).padStart(2,"0")


const ForgotOTP = ({onChangeOfOTP,onSubmit,resendOTP, loading}) => {
  const[otp, setOTP] = useState('')

  const [error, setError] = useState(false)
const [secondsRemaning, setSecondsRemaning] = useState(initialCount);
const secondsToDisplay = secondsRemaning % 60
const minutesRemaning = (secondsRemaning - secondsToDisplay) / 60
const minutesToDisplay = minutesRemaning % 60
const hoursToDisplay = (minutesRemaning - minutesToDisplay) / 60

const handleStart = async() =>{
  setStatus(STATUS.STARTED)
  setSecondsRemaning(initialCount)
  resendOTP()
}
const STATUS = {
  

  STOPPED:<b>  <div  className='col-10 d-flex justify-content-end'><a style={{
  color: "#BDBDBD",
  textDecoration: "none",}} type='button' onClick={handleStart} >RESEND OTP </a></div>  </b>
}
const [status,setStatus]= useState(STATUS.STOPPED)
useInterval(
  ()=>{
    if(secondsRemaning > 0){
      setSecondsRemaning(secondsRemaning - 1)
    }
    else{
      setStatus(STATUS.STOPPED)
    }
  },
  status === STATUS.STARTED ? 1000 : null,
)
function useInterval(callback, delay){
  const savedCallback = useRef();

  // Remember the latest callback
  
  useEffect(()=>{
    savedCallback.current = callback
  }, [callback])

  // set uo the interval
  useEffect(()=>{
    function tick(){
      savedCallback.current()
    } 
    if(delay !== null){
      let id = setInterval(tick, delay)
      return() => clearInterval(id)
    }
  },[delay])
}


// const submitClick = (e) =>{
// e.preventDefault()
// if(otp.length<=6){
//   setError(true)
// }
// if(otp){
//   console.log("click", otp)
// }
// }

  return (
    <>
{
  loading ? <><LoadingSpinner/></>:<div class="mainDiv">
  <div className="blurd"> </div>
  <div className="logo">
    <img src={logo} alt="" />
  </div>
  <div class="imgSec">
    <img  src={JunkFood} alt="" />
  </div>
  <div class="formWrapper ">
   
  <div class="row g-3  ">
        <div >
          <h4 className='heading'>Forgot Password</h4>
        </div>
        <div class="row ">
          <div class="col-10  py-2 w-700">
            <input
            onChange={onChangeOfOTP}
              style={{
                borderRadius: "18px",
                padding: "12px 46px 14px",
                fontSize: "20px",
                color: "#111111",
              }}
              
              type="number"
              class="form-control"
              placeholder="Enter OTP"
              aria-label="m Number"
              // onKeyDown={onSubmit}
             
            />
            <span>
              <img
                style={{ marginLeft: "14px", marginTop: "-90px" }}
                src={otpIcon}
                alt=""
              />
            </span>
            {error&&<span className='text-danger col-10'>OTP Can't be Empty</span>}

          </div>

          {/* <div class=" d-grid col-8 py-3">
            <input
              style={{
                borderRadius: "18px",
                padding: "12px 32px 14px ",
                fontSize: "20px",
                color: "#BDBDBD",
              }}
              type="password"
              id="myInput"
              class="form-control col-md-6"
              required="true"
              name="password"
              aria-label="password"
              placeholder="Password"
              onChange={onChangeOfPassword}
            />
            <span>
              <img
                style={{ marginTop: "-84px ", marginLeft: "6px" }}
                src={lock}
                alt=""
              />
            </span>
          </div> */}
        

          <div class="d-grid gap-4 col-10 ">
            <button
              style={{
                borderRadius: "18px",
                padding: "12px 32px 14px",
                fontSize: "20px",
              }}
              class="btn btn-success disable"
              type="submit"
              onClick={onSubmit}
              loading
            >

              SUBMIT
            </button>
          </div>
            {/* <div className="col-10 d-flex justify-content-end ">
           <Link style={{
                marginTop: "-40px",
                color: "#BDBDBD",
                textDecoration: "none",
              }}  to="/ForgotPassword"> RESEND OTP</Link>
           
           
          </div> */}
          {
                status == STATUS.STARTED ?
                <div className='col-10 d-flex justify-content-end'>
                  <b className='text-success'>Resend OTP : </b>
                  <b className='text-danger'> {twoDigits(minutesToDisplay)}:{twoDigits(secondsToDisplay)}</b>
                </div>
                :
                status
              }
          <div>
            <div className="col-10 d-grid py-2 justify-content-center">
            <p >
             Already Have an Account ?
             <Link style={{
                marginTop: "-40px",
               color: "#3282FF", fontWeight:"600",
                textDecoration: "none",
              }}  to="/"> Sign IN</Link>
            </p>
            </div>
          
          </div>
        </div>
      </div>
   
  </div>
  
</div>
}
    
  </>
  );
};

export default ForgotOTP;