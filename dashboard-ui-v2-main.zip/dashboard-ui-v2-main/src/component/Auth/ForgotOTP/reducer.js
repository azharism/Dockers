import {
  ON_CHANGE_OTP ,
SAVE_OTP_RES,
LOADING
  
} from './constants';
 
  
  const initialState = {
    
    forgetotp: '',
    forget_otp_res: '',
    loading: false,
    
  };
  
  export default (state = initialState, action) => {
    console.log('forgetOTP/reducer________', action);
    switch (action.type) {
      case ON_CHANGE_OTP:
        console.log("CASE MOBILE")
        return {
          ...state,
          forgetotp: action.forgetotp,
        };
  
      case SAVE_OTP_RES:
        return {
          ...state,
          forget_otp_res: action.forget_otp_res,
        };
        case LOADING:
        return {
          ...state,
          loading: action.loading,
        };
  

      default:
        return state;
    }
  };
  