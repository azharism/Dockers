import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { withRouter, redirect } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import Forgotpassword from "./component";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { saveForgetOtpRes, onChange_OTP} from "../ForgotOTP/action";
import { saveForgetpassRes, setLoading } from "../ForgotPassword/action";
import { createBrowserHistory } from "history";
import { useNavigate } from "react-router-dom";

import ForgotOTP from "./component";

const ForgetOtp = (props) => {

  console.log(
    "props--ForgetOtp---------->",
    props.props.forgetpassword.forget_password_res.token
  );
  let navigate = useNavigate();
  const history = createBrowserHistory();
  const [OTP, setOtp] = useState("");
  const [loading, setLoading]= useState(false);

  useEffect(() => {
    console.log("runing....");
  }, []);

  const onChangeOfOTP = (e) => {
    console.log("otp", e.target.value);
    const { value } = e.target;
    props.onChange_OTP(value);
    setOtp(value);
  };

  const resendOTP = (e) => {
    const mobile =
      props.props &&
      props.props.forgetpassword &&
      props.props.forgetpassword.forgetmobile;
    
    return props.getDataFromAPI(
      "/dashboard/api/v2/admin/auth/otp",
      "POST",
      { mobile },
      (response) => {
        console.log("res------------------------------------------", response);

        console.log("saveForgetpassRes", response);
        props.saveForgetpassRes(response);
        
        //navigate("/forgototp");
        
        return toastr.success("Success", "OTP Successfully Sent");
      },
      (err) => {
        console.log(err);
        // if (err.status === 404) {
        //     //this.props.logoutUser();
        //     return toast.error('Error', 'Incorrect OTP');
        // }
        // props.setLoading(false);
        return toastr.error("Error", err.message);
      }
    );
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const otp = OTP;
    const token = props.props.forgetpassword?.forget_password_res?.token;
    
    if (!otp || otp.length !== 6 || !Number.isInteger(Number(otp))) {
      toastr.error("Error", "Please enter a valid 6-digit OTP.");
      return;
    }
  
    setLoading(true);
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/auth/otp/verify",
      "POST",
      { otp, token },
      (response) => {
        console.log("ForgetOTP", response);
        props.saveForgetOtpRes(response);
        setLoading(false);
        navigate("/changepassword");
        toastr.success("Success", "OTP verification successful.");
      },
      (err) => {
        console.log(err);
        setLoading(false);
        toastr.error("Error", err.message);
        navigate("/forgototp");
      }
    );
  };
  
  return (
    <>
      <ForgotOTP
        onChangeOfOTP={onChangeOfOTP}
        onSubmit={onSubmit}
        resendOTP={resendOTP}
        loading={loading}
      />
    </>
  );
};
function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  onChange_OTP,
  saveForgetOtpRes,
  getDataFromAPI,
  saveForgetpassRes,
  
})(ForgetOtp);
