import React, { useState } from "react";
import "./style.css";
import avtar from "../../../assests/emotion1.png";
import {Link} from "react-router-dom"
import LoadingSpinner from "../../Loading/component";

export const Loginpopup = () => {
  const [loading, setLoading]= useState(true)
  return (
   <div className="popup-main">
    <div className="child-div">
      <div className="child-1">
        <img className="img-avtar" src={avtar} alt="" />
      </div>
      <div className="child-2">
        <p>Congratulations</p>
        <span>Password changed sucessfully.</span>
      </div>
      <div className="login-btn">
      <Link to="/" style={{textDecoration:"none"}}> <p className="login-inner">Login</p></Link> 
      </div>
    </div>
  </div>
 
    
  );
};
