import React, { useState } from 'react'
import "./style.css";
import { toastr } from 'react-redux-toastr';
import logo from "../../../assests/Daalchini-logo.svg";
import JunkFood from "../../../assests/JunkFood.png";
import phone from "../../../assests/phone.svg";
import { Link } from 'react-router-dom';
import LoadingSpinner from '../../Loading/component';
// import { ToastContainer} from "react-toastify"

const Forgotpassword = ({onChanegOfMobile,onSubmit, loading}) => {
  const [error, setError] = useState(false);
  const [mobileField, setMobileField] = useState();


  const inputStyle={
    borderRadius: "18px",
    padding: "12px 46px 14px",
    fontSize: "21px",
    background: "#FFFFFF"
  }
  const buttonStyle={
    borderRadius: "18px",
    padding: "12px 32px 14px",
    fontSize: "20px",
  }

// const handleError = (e)=>{
//   e.preventDefault()
//   if (!/^[6789]\d{9}$/.test(mobileField)) {
//     return ('Invalid Mobile Number', 'Please enter a 10-digit mobile number');
// }
// if (!password || password.length < 6) {
//     return toastr.warning('Invalid Password', 'Password must be 6 chars long');
// }

// afafa



  return (
    <>
{loading ? <><LoadingSpinner/>
</>:
<div class="mainDiv">
      <div className="blurd"> </div>
      <div className="logo">
        <img src={logo} alt="" />
      </div>
      <div class="imgSec">
        <img src={JunkFood} alt="" />
      </div>
      <div class="formWrapper ">
        {/* <form > */}
          <div class="row g-3  ">
            <div  >
              <h4 className="heading ">Forgot Password</h4>
            </div>
            <div class="row ">
              <div class="col-10  w-700">
                <input
                  maxlength="10"
                 onChange={onChanegOfMobile}
                  style={inputStyle}
                  // type="number"
                  required="true"
                  class="form-control"
                  placeholder="Enter Your Mobile Number"
                  aria-label="m Number"
                  
                />
                <span>
                  <img
                    style={{ marginLeft: "24px",
                    marginTop: "-82px", width:"14px"
                 }}
                    src={phone}
                    alt=""
                  />
                </span>
                {error&&<span className='text-danger col-10'>Mobile</span>}
              </div>

             

              <div class="d-grid gap-4 col-10 py-2">
                <button
                  onClick={onSubmit}
                  style={buttonStyle}
                  class="btn btn-success"
                  type="submit"
                  loading
                >
                 Request OTP
                 
                </button>
              </div>
              <div>
                <div className="col-10 d-grid justify-content-center">
                <p >
                 Already Have an Account ? 
                 <Link to="/"  style={{ color: "#3282FF" , textDecoration: "none", fontWeight:"600"}}> Sign in</Link>
                 
                </p>
                </div>
              
              </div>
            </div>
          </div>
        {/* </form> */}
      </div>
     
    </div>
 }

    
    </>
  );
};

export default Forgotpassword;