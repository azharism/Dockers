import {
  
  SAVE_FORGET_PASSWORD_RES,
  FORGET_PASSWORD_MOBILE
} from './constants';

export function onMobileChange(forgetmobile) {
 
  return {
    type:  FORGET_PASSWORD_MOBILE,
    forgetmobile,
  };
}

export function saveForgetpassRes(forgetpasswordres) {
  return {
    type: SAVE_FORGET_PASSWORD_RES,
    forgetpasswordres,
  };
}