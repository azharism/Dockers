import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { withRouter, redirect } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import Forgotpassword from "./component";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { onMobileChange, saveForgetpassRes } from "./action";
import { createBrowserHistory } from "history";
import { useNavigate } from "react-router-dom";

import Axios from "axios";
const ForgetpasswordContainer = (props) => {
  console.log("ForgetpasswordContainer", props);
  let navigate = useNavigate();
  const history = createBrowserHistory();
  const [mobile, setmobile] = useState();
  const [loading, setLoading] = useState(false);
  const [validMobile, setValidMobile] = useState(false);
  const [showError, setShowError] = useState(false);

  useEffect(() => {
    console.log("running....");
  }, []);

  const onChanegOfMobile = (e) => {
    console.log(e.target.value);
    const { value } = e.target;
    if (isNaN(value) || value === "") {
      setValidMobile(false);
      setShowError(true);
      return toastr.warning("warning", "Please enter a valid number");
    }
    if (value.length === 10) {
      setValidMobile(true);
      setShowError(false);
      props.onMobileChange(value);
    } else if (value.length > 10) {
      setValidMobile(false);
      setShowError(true);
      e.target.disabled = false;
      return toastr.warning("warning", "Mobile number should be exactly 10 digits");
    } else {
      setValidMobile(false);
      setShowError(false);
      e.target.disabled = false;
    }
    setmobile(value);
  };

  const onSubmit = (e) => {
    console.log("login Data--->");
    e.preventDefault();
    if (!mobile || !validMobile) {
      setShowError(true);
      return toastr.warning("warning", "Please enter a valid mobile number");
    }
    setLoading(true);
    return props.getDataFromAPI(
      "/dashboard/api/v2/admin/auth/otp",
      "POST",
      { mobile },
      (response) => {
        console.log("res------------------------------------------", response);

        console.log("saveForgetpassRes", response);
        props.saveForgetpassRes(response);

        setLoading(false);
        navigate("/forgototp");
        return toastr.success("Success", "OTP Successfully Sent");
      },
      (err) => {
        console.log(err);
        setLoading(false);
        // return toastr.error("Error", err.message);
        return toastr.warning("Please Enter a valid Mobile Number")
      }
    );
  };

  return (
    <Forgotpassword
      onChanegOfMobile={onChanegOfMobile}
      loading={loading}
      onSubmit={onSubmit}
      showError={showError}
    />
  );
};



// const ForgetpasswordContainer = (props) => {
//   console.log("ForgetpasswordContainer", props);
//   let navigate = useNavigate();
//   const history = createBrowserHistory();
//   const [mobile, setmobile] = useState();
//   const [loading, setLoading] = useState(false);

//   useEffect(() => {
//     console.log("runing....");
//   }, []);

 
//   const onChanegOfMobile = (e) => {
//     console.log(e.target.value);
    
//     const { value } = e.target;
//     if (isNaN(value) || value === "") {
//       return toastr.warning("warning", "Please enter a valid number");
//     }
//     if (value.length === 10) {
//       props.onMobileChange(value);
//     } else if (value.length > 10) {
//       e.target.disabled = false;
//       return toastr.warning("warning", "Mobile number should be exactly 10 digits");
//     } else {
//       e.target.disabled = false;
//     }
  
//     setmobile(value);
//   };
  



//   const onSubmit = (e) => {
//     console.log("login Data--->");
    
//     if (e.key === "Enter") {
//       e.preventDefault();
//     }
    
//     const dataSet = e.target.dataset;

//     if(!mobile && !mobile <= 10){
      
//     return  toastr.warning("error", "Please Enter a valid Mobile Number")

//     }   

//     setLoading(true);
//     return props.getDataFromAPI(
//       "dashboard/api/v2/admin/auth/otp",
//       "POST",
//       { mobile },
//       (response) => {
//         console.log("res------------------------------------------", response);

//         console.log("saveForgetpassRes", response);
//         props.saveForgetpassRes(response);

//         setLoading(false);
//         navigate("/forgototp");
       
//         return toastr.success("Success", "OTP Successfully Sent");
//       },
//       (err) => {
//         console.log(err);
//         // if (err.status === 404) {
//         //     //this.props.logoutUser();
//         //     return toast.error('Error', 'Incorrect OTP');
//         // }
//         // props.setLoading(false);
//         return toastr.error("Error", err.message);
//       }
//     );
//   };

//   return (
//     <Forgotpassword
//       onChanegOfMobile={onChanegOfMobile}
//       loading={loading}
//       onSubmit={onSubmit}
//     />
//   );
// };
function mapStateToProps({ forgetpasswordres }) {
  return {
    forgetpasswordres,
  };
}
export default connect(mapStateToProps, {
  onMobileChange,
  saveForgetpassRes,
  getDataFromAPI,
})(ForgetpasswordContainer);
