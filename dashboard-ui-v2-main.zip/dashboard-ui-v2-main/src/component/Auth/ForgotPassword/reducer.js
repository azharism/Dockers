import {
  
  SAVE_FORGET_PASSWORD_RES,
  FORGET_PASSWORD_MOBILE
} from './constants';
 
  
  const initialState = {
    
    forgetmobile: '',
    forget_password_res: '',
    
  };
  
  export default (state = initialState, action) => {
    console.log('forgetpassword/reducer________', action);
    switch (action.type) {
      case FORGET_PASSWORD_MOBILE:
        console.log("CASE MOBILE")
        return {
          ...state,
          forgetmobile: action.forgetmobile,
        };
  
      case SAVE_FORGET_PASSWORD_RES:
        return {
          ...state,
          forget_password_res: action.forgetpasswordres,
        };
  

      default:
        return state;
    }
  };
  