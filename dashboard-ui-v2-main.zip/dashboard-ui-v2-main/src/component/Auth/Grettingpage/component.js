import React from 'react'
import Sidebar from '../../Navigation/Sidebar/Sidebar'
import "./style.css"

export const LandingPage = () => {
  return (
 <div className='main-div'>
    <div>
        <Sidebar/>
    </div>
    <div className='cohortsec' style={{margin:"auto"}} >
      <div className='greatingMsg' >
       
       
      </div>
      <h3>Welcome To Daalchini </h3>
    </div>
 </div>
  )
}
