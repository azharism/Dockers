export const MOBILE_CHANGE = '@login/MOBILE_CHANGE';
export const PASSWORD_CHANGE = '@login/PASSWORD_CHANGE';
export const LOADING = '@login/LOADING';
export const LOGIN_SUCCESS = '@login/LOGIN_SUCCESS';
export const LOGIN_FAILED = '@login/LOGIN_FAILED';
export const SAVE_USER = '@login/SAVE_USER';