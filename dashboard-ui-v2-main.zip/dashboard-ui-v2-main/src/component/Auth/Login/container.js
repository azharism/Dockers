import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { toastr } from "react-redux-toastr";
import Login from "./component";

import { redirect } from "react-router-dom";
import {
  setLoading,
  onMobileChange,
  onPasswordChange,
  saveUser,
} from "./action";
import { getDataFromAPI, logoutUser } from "../../../HandleAPICalls/actions";

// import { getDataFromAPI } from '../../../HandleAPICalls/actions';

import { createBrowserHistory } from "history";

import Axios from "axios";
import { warning } from "toastr";

const LoginContainer = (props) => {
  console.log("props LoginContainer----->");
  const [auth, setAuth] = useState(localStorage.getItem("data"));
  const history = createBrowserHistory();
  const [mobile, setmobile] = useState();
  const [password, setpassword] = useState();
  const [disabled, setdisabled] = useState();
  const [loading, setLoading] = useState();
  const [apiHit, setApiHit] = useState();
  const [showPassword, setShowPassword] = useState(false);
  
  const onChanegOfMobile = (e) => {
    const { value } = e.target;
   
      props.onMobileChange(value);
     
   
  };
  
  const onChangeOfPassword = (e) => {
    console.log(e.target.value);
    const { value } = e.target;
    props.onPasswordChange(value);
  };
  const callPermissionApi = (data) => {
    console.log(
      "callPermissionApi___________________________"
    );
    let params = {
      "access-token": data.accessToken,
    };
    Axios.post(
      "/dashboard/api/v2/admin/auth/permissions",
      params,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    )
      .then((res) => {
        localStorage.setItem("allPermissions", JSON.stringify(res.data.data));
        console.log(res, "response1111111");
      })
      .catch((err) => {
        console.log("error faced while requesting -->>>", err);
      });
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      onSubmit(event);
    }
  };
  
  const onSubmit = (e) => {
    e.preventDefault();
    const mobile = props.login.mobile;
    const password = props.login.password;
    const payload = { mobile, password };
  
    const regex = /^([+]?[\s0-9]+)?(\d{3}|[(]?[0-9]+[)])?([-]?[\s]?[0-9])+$/i;
    if (!mobile || regex.test(mobile) === false) {
      toastr.warning("Mobile Number is Required to Login on Daalchini");
      return;
    }
    if (!password || password.length < 6) {
      toastr.warning("Password is Required to Login on Daalchini");
      return;
    }
  
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/login",
      "POST",
      payload,
      (response) => {
        callPermissionApi(response);
        localStorage.setItem("data", JSON.stringify(response));
        props.saveUser(response);
        setLoading(false);
        setApiHit(true);
        history.push("/home");
      },
      (err) => {
       
        if (err.status === 404) {
          toastr.error("Error", err.message);
          
        } else {
          toastr.error("Error", "Password incorrect");
        }
        setLoading(false);
      },
      true
    );
  };
  


  return (
    <Login
      mobile={mobile}
      password={password}
      disabled={disabled}
      loading={loading}
      onChanegOfMobile={onChanegOfMobile}
      onChangeOfPassword={onChangeOfPassword}
      onSubmit={onSubmit}
      handleKeyDown={handleKeyDown}
      showPassword = {showPassword}
  setShowPassword = {setShowPassword}
    />
  );
};
function mapStateToProps({ login }) {
  return {
    login,
  };
}
export default connect(mapStateToProps, {
  setLoading,
  onMobileChange,
  onPasswordChange,
  saveUser,
  getDataFromAPI,
})(LoginContainer);