import {
    MOBILE_CHANGE,
    PASSWORD_CHANGE,
    LOADING,
    SAVE_USER,
  } from '../Login/constants';
  import { LOGOUT_USER, CLEAR_STATE } from '../../../HandleAPICalls/constants';
  
  const initialState = {
    loading: false,
    mobile: '',
    password: '',
    user: null,
  };
  
  export default (state = initialState, action) => {
    console.log('login/reducer________', action);
    switch (action.type) {
      case MOBILE_CHANGE:
        console.log("CASE MOBILE")
        return {
          ...state,
          mobile: action.mobile,
        };
  
      case PASSWORD_CHANGE:
        return {
          ...state,
          password: action.password,
        };
  
      case LOADING:
        return {
          ...state,
          loading: action.loading,
        };
  
      case SAVE_USER:
        return {
          ...state,
          user: action.user,
        };
  
      case LOGOUT_USER:
        return initialState;
  
      case CLEAR_STATE:
        return initialState;
  
      default:
        return state;
    }
  };
  