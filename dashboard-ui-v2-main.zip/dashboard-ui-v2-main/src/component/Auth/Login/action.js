import {
    MOBILE_CHANGE,
    PASSWORD_CHANGE,
    LOADING,
    SAVE_USER,
  } from './constants';
  
  export function onMobileChange(mobile) {
    console.log("mobile",mobile)
    return {
      type: MOBILE_CHANGE,
      mobile,
    };
  }
  
  export function onPasswordChange(password) {
    return {
      type: PASSWORD_CHANGE,
      password,
    };
  }
  
  export function setLoading(loading) {
    return {
      type: LOADING,
      loading,
    };
  }
  
  export function saveUser(user) {
    return {
      type: SAVE_USER,
      user,
    };
  }
  