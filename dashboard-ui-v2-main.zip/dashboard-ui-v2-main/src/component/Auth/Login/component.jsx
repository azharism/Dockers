import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./style.css";
import { Link, redirect } from "react-router-dom";
import logo from "../../../assests/Daalchini-logo.svg";
import JunkFood from "../../../assests/JunkFood.png";
import phone from "../../../assests/phone.svg";
import lock from "../../../assests/lock.svg";
import Home from "../../Home/component";
import LoadingSpinner from "../../Loading/component";
import eyeIcon from "../../../assests/eyeIcon.svg";
import refillEye from "../../../assests/refillEye.svg";
import crossEye from "../../../assests/crossEye.svg";

const Login = ({
  mobile,
  password,
  disabled,
  loading,
  onSubmit,
  onChanegOfMobile,
  onChangeOfPassword,
  keyDownHandler,
  handleKeyDown,
  error,
  showPassword,
  setShowPassword,
}) => {
  let navigate = useNavigate();
  const isAuthenticated = localStorage.getItem("data")
    ? JSON.parse(localStorage.getItem("data"))
    : false;
  if (isAuthenticated && isAuthenticated.accessToken) {
    return <Home />;
  }

  const inputStyle = {
    borderRadius: "18px",
    padding: "12px 48px 14px",
    fontSize: "20px",
    background: "#FFFFFF",
    color: "#111111",
  };
  const inputStylePassword = {
    borderRadius: "18px",
    padding: "12px 52px 14px ",
    fontSize: "20px",
    background: "#FFFFFF",
  };
  const forgotPasswordStyle = {
    marginTop: "-22px",
    color: "#828282",
    marginRight: "6px",
    textDecoration: "none",
  };
  const signinStyle = {
    borderRadius: "18px",
    padding: "12px 32px 14px",
    fontSize: "20px",
    textTransform: "uppercase",
  };

  return (
    <>
      {loading ? (
        <LoadingSpinner />
      ) : (
        <div className="mainDiv">
          <div className="blurd"> </div>
          <div className="logo">
            <img src={logo} alt="" />
          </div>
          <div className="imgSec">
            <img src={JunkFood} alt="" />
          </div>
          <div className="formWrapper ">
            <form onSubmit={onSubmit}>
              <div className="row g-3  ">
                <div>
                  <h4 className="heading">Sign In to Daalchini</h4>
                </div>
                <div className="row ">
                  <div className="col-10  w-700">
                    <input
                      maxLength="10"
                      style={inputStyle}
                      // type="number"
                      required="true"
                      className="form-control"
                      placeholder="Enter Your Mobile Number"
                      aria-label="m Number"
                      value={mobile}
                      disabled={loading}
                      onChange={onChanegOfMobile}
                      // onKeyDown={onSubmit}
                      autocomplete="off"
                    />
                    <span>
                      <img
                        style={{
                          marginLeft: "24px",
                          marginTop: "-82px",
                          width: "14px",
                        }}
                        src={phone}
                        alt=""
                      />
                    </span>
                  </div>

                  <div className=" d-grid col-10 ">
                    <input
                      style={inputStylePassword}
                      type={showPassword ? "text" : "password"}
                      id="myInput"
                      className="form-control col-6"
                      required={true}
                      value={password}
                      autoComplete="off"
                      onKeyDown={handleKeyDown}
                      placeholder="Password"
                      onChange={onChangeOfPassword}
                    />
                    <div
                      style={{
                        justifyContent: "space-between",

                        display: "flex",
                        marginRight: "30px",
                      }}
                    >
                      <span>
                        <img
                          style={{
                            marginTop: "-84px ",
                            marginLeft: "20px",
                          }}
                          src={lock}
                          alt=""
                        />
                      </span>
                      <span>
                        <img
                          style={{
                            marginTop: "-84px ",
                            marginLeft: "20px",
                            cursor: "pointer",
                            color: "red",
                          }}
                          src={showPassword ? crossEye : refillEye}
                          alt=""
                          onClick={() => setShowPassword(!showPassword)}
                        />
                      </span>
                    </div>
                  </div>
                  <div className="col-10 d-flex justify-content-end ">
                    <Link
                      style={forgotPasswordStyle}
                      loading
                      to="/forgetpassword"
                    >
                      Forgot Password ?
                    </Link>
                  </div>

                  <div className="d-grid gap-4 col-10 py-5">
                    <button
                      style={signinStyle}
                      className="btn btn-success"
                      type="button"
                      loading={loading}
                      onClick={onSubmit}
                      disabled={disabled}
                    >
                      Sign In
                    </button>
                  </div>
                  <div>
                    <div className="col-10 d-grid justify-content-center">
                      <p>
                        Don’t Have an Account ?
                        <span style={{ color: "#3282FF", fontWeight: "600" }}>
                         
                          Request Sign Up
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default Login;
