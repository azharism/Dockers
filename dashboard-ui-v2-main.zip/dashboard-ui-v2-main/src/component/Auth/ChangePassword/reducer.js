import { CHANGE_PASSWORD, CHANGE_PASSWORD_CONFIRM , CHANGE_PASSWORD_RES} from "../ChangePassword/constant";
   
    
    const initialState = {
      
      changepassword: '',
      confirmpassword: '',
      changepasswordres:'',
      
    };
    
    export default (state = initialState, action) => {
      console.log('forgetOTP/reducer________', action);
      switch (action.type) {
        case CHANGE_PASSWORD:
          console.log("CASE MOBILE")
          return {
            ...state,
            changepassword: action.changePassword,
          };
    
        case CHANGE_PASSWORD_CONFIRM:
          return {
            ...state,
            confirmpassword: action.changePasswordConfirm,
          };
    
        
          case  CHANGE_PASSWORD_RES:
            return {
              ...state,
              changepasswordres: action.changePasswordRes,
            };
  
        default:
          return state;
      }
    };
    