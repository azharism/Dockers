export const CHANGE_PASSWORD = '@changePassword/CHANGE_PASSWORD';
export const CHANGE_PASSWORD_CONFIRM = '@changePassword/CHANGE_PASSWORD_CONFIRM';
export const CHANGE_PASSWORD_RES = '@changePassword/CHANGE_PASSWORD_RES';
