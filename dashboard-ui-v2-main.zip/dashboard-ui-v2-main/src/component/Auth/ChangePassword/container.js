import React, { Component, useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { withRouter,redirect } from 'react-router-dom';
import { toastr } from 'react-redux-toastr';
import ChangePassword from './component';
import { getDataFromAPI } from '../../../HandleAPICalls/actions';
import { onChange_Password , onChange_Password_Confrim , onChange_Password_Res } from './action';
import { createBrowserHistory } from 'history';
import { useNavigate } from 'react-router-dom';
import { success } from 'toastr';


const ChangepasswordContainer=(props)=> {
   
    console.log("changepassword props",props.props)
    let navigate = useNavigate();
	const [Password,setPassword]=useState();
    const [confrimpassword,setConfirmassword]=useState();
    const [loading, setLoading] = useState(false)


useEffect(()=>{
	console.log("runing....")

},[])

 
    const onChangeOfPassword=(e)=> {
        console.log(e.target.value)
        const { value } = e.target;
        props.onChange_Password(value);
        setPassword(value)
    }

    const onChangeOfPasswordConfirm=(e)=> {
        console.log(e.target.value)
        const { value } = e.target;
        props.onChange_Password_Confrim(value);
        setConfirmassword(value)
    }
  
    
	
    const onSubmit=(e, err)=>{
       

        console.log("login Data--->");
		if (e.key === 'Enter') {
			e.preventDefault();
	
		}
         const dataSet = e.target.dataset;
        const password=Password
        const confirmPassword=confrimpassword
        const token=props.props.forgetotp&&props.props.forgetotp.forget_otp_res.token
        const specialCharRegex = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
if (specialCharRegex.test(password)) {
  toastr.warning('Special characters are not allowed in the password.');
  return;
}

        if(!Password && !Password <= 20){
      
            return toastr.error("error", "Please Enter New Password")
      
          }  
          if(!confrimpassword && !confrimpassword <= 20){
            return toastr.error("error", "Please Enter Confirm Password")
          }
        return props.getDataFromAPI(
            '/dashboard/api/v2/admin/auth/reset',
           'POST',
            {password,confirmPassword,token},
            (response) => {
                console.log("res------------------------------------------",response)
               
             
                props.onChange_Password_Res(response); 
                
                setLoading(true)
               
                navigate('/changepasswordsuccess'); 
            
               
              
            },
            (err) => {
                console.log(err)
                if (err.status === 404) {
                    //this.props.logoutUser();
                    navigate("/forgotpassword")
                    return toastr.error('Error', 'User not found');
                }
                //this.props.setLoading(false);
                return toastr.error('Error', err.message);
            },
        );
	
		
    }
	
    return(

      
            <ChangePassword
               
             
            onChangeOfPassword={onChangeOfPassword}
            onChangeOfPasswordConfirm={onChangeOfPasswordConfirm}        
                onSubmit={onSubmit}
                loading={loading}
            />
    )
    }
function mapStateToProps(props) {
    return {
        props
    };
}
export default connect(mapStateToProps, {
  
    onChange_Password,
    onChange_Password_Confrim , 
    onChange_Password_Res,
    getDataFromAPI,
  
})(ChangepasswordContainer);
