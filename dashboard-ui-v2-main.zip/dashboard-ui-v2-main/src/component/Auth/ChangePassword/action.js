import { CHANGE_PASSWORD,CHANGE_PASSWORD_CONFIRM,CHANGE_PASSWORD_RES } from "./constant";

export function onChange_Password(changePassword) {

  return {
    type: CHANGE_PASSWORD,
    changePassword,
  };
}

export function onChange_Password_Confrim(changePasswordConfirm) {
  console.log("saveForgetOtpRes",changePasswordConfirm)
  return {
    type: CHANGE_PASSWORD_CONFIRM,
    changePasswordConfirm,
  };
}

export function onChange_Password_Res(changePasswordRes) {
  console.log("saveForgetOtpRes",changePasswordRes)
  return {
    type: CHANGE_PASSWORD_RES,
    changePasswordRes,
  };
}