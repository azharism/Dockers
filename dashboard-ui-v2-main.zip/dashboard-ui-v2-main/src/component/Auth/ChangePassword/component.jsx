import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet'; 
import { useEffect } from 'react';
import "./style.css";
import {Link} from "react-router-dom"
import logo  from "../../../assests/Daalchini-logo.svg"
import JunkFood from "../../../assests/JunkFood.png";
import phone from "../../../assests/phone.svg";
import lock from "../../../assests/lock.svg";
import LoadingSpinner from '../../Loading/component';
import avtar from "../../../assests/emotion1.png";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { Loginpopup } from '../LoginPopup/Loginpopup';


const  ChangePassword= ({onChangeOfPassword,onChangeOfPasswordConfirm,onSubmit, loading}) => 



{
  const navigate=useNavigate();

  useEffect(() => {
    
    const isAuthenticated = localStorage.getItem('data') ? JSON.parse(localStorage.getItem('data')) : false;
    if (isAuthenticated && isAuthenticated.accessToken) {
      return ( navigate('/'));
    }
  },[])
   const [show, setShow] = useState(false);

const handleClose = () => setShow(false);
const handleShow = () =>

setShow(true);

  return (
    
   
   <>
   {
    loading ? <><LoadingSpinner/></> : <div className="mainDiv">
    <div className="blurd"> </div>
    <div className="logo">
      <img src={logo} alt="" />
    </div>
    <div className="imgSec">
      <img src={JunkFood} alt="" />
    </div>
    <div className="formWrapper ">
    
        <div className="row g-3  ">
          <div >
            <h4 className='heading '>Change Password</h4>
          </div>
          <div className="row ">
            <div className="col-10 py-1 w-700">
              <input
                style={{
                  borderRadius: "18px",
                  padding: "12px 46px 14px",
                  fontSize: "20px",
                  background: "#FFFFFF"
                 
                }}
                type="text"
                required="true"
                className="form-control"
                placeholder="Enter New Password"
                aria-label="m Number"
                min='10'
                max='10'
                onChange={onChangeOfPassword}
                
              />
              <span>
                <img
                  style={{ marginLeft: "24px",
                    marginTop: "-82px", width:"14px"
                 }}
                  src={phone}
                  alt=""
                />
              </span>
            </div>

            <div className=" d-grid col-10 py-3">
              <input
                style={{
                  borderRadius: "18px",
                  padding: "12px 38px 14px ",
                  fontSize: "20px",
                  background: "#FFFFFF"
                 
                }}
                type="password"
                id="myInput"
                className="form-control col-6"
                required="true"
              
                placeholder=" Confirm Password"
                onChange={onChangeOfPasswordConfirm}
              />
              <span>
                <img
                  style={{ marginTop: "-84px ",marginLeft: "20px" }}
                  src={phone}
                  alt=""
                />
              </span>
            </div>
            
           

    {/* <Button  
                type="submit"  >
     save
    </Button> */}
    <Modal show={show} onHide={handleClose}>
    <div>
      <div className="child-div">
        <div className="child-1">
          <img className="img-avtar" src={avtar} alt="" />
        </div>
        <div className="child-2">
          <p>Congratulations</p>
          <span>Password changed sucessfully.</span>
        </div>
        <div className="login-btn">
        <Link to="/" style={{textDecoration:"none"}}> <p className="login-inner">Login</p></Link> 
        </div>
      </div>
    </div>
        
        
        
        
      </Modal>

    {/* <Modal show={show} onHide={handleClose}>
     <Loginpopup/>
     <Button onClick={onSubmit} >save</Button>
    </Modal> */}
  
            <div className="d-grid gap-4 col-10 py-5">
              <button
                style={{
                  borderRadius: "18px",
                  padding: "12px 32px 14px",
                  fontSize: "20px",
                  textTransform:'uppercase'
                }}
                className="btn btn-success"
                type="submit"
                onClick={onSubmit}
              >
                Save
              </button>
            </div>
            <div>
              <div className="col-10 d-grid justify-content-center">
              <p >
               Already Have an Account ? 
               <Link to="/"  style={{ color: "#3282FF" , textDecoration: "none",}}> Sign in</Link>
               
              </p>
              </div>
            
            </div>
          </div>
        </div>
      
    </div>
  </div>
   }
   
   </>
  );
};

export default ChangePassword;
