import React from "react";
import "./component.css";
import { useNavigate } from "react-router-dom";
import leftArrow from "../../assests/leftArrow.svg";
import Sidebar from "../Navigation/Sidebar/Sidebar";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Button from "@mui/material/Button";

import CohortContainer from "../AddCohort/container";
import CreateusersDetails from "../CreateUserComp/container.js";
import AddWarehouseContainer from "../AddWarehouseComp/container.js";
import avtar2 from "../../assests/emotions2.svg";
import { Link } from "react-router-dom";
import Modal from "react-bootstrap/Modal";
import { useState } from "react";
const CreateUser = (props) => {

  const steps = ["Basic Details", "Add to Cohort", "Add to Warehouse"];
 

  const [role, setRole] = React.useState(false);
 
  
  // const handleClose = () => {
  //   console.log("yes go back")
  //   props.setActiveStep((prevActiveStep) => prevActiveStep - 1);
  // };
  
  const handleChange = (event) => {
    setRole(event.target.value);
  };
  

  const handleBack = () => {
    props.setShow(true);
    // navigate(-1)
   
  };
  const handleCancel = () => {
    props.setShow(false);
   
  };
  const buttonClassName = props.isRadioClicked ? "warehouse active" : "warehouse inactive";

 
  const navigate = useNavigate();
  const arrowClick = () => {
    navigate("/home/users/list");
  };
 

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>
      <div style={{ marginLeft: "20px", width: "100%" }}>
        <div style={{ marginLeft: "22px", marginTop: "20px" , display:"flex"}}>
        <img
              onClick={arrowClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />
          <h2 style={{marginLeft:"10px"}}>
           
            Create New User
          </h2>
        </div>
        <div style={{ width: "550px", margin: "30px" }}>
          <Box sx={{ width: "100%" }}>
            <Stepper activeStep={props.activeStep}>
              {steps.map((label, index) => {
                const stepProps = {};
                const labelProps = {};
              
                return (
                  <Step key={label} {...stepProps}>
                    <StepLabel {...labelProps}>{label} </StepLabel>
                  </Step>
                );
              })}
            </Stepper>
          </Box>
        </div>
        <div>
          {props.activeStep === steps.length ? (
            <React.Fragment>
              {/* <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
               <Box sx={{ flex: '1 1 auto' }} />
               <Button onClick={handleReset}>Reset</Button>
             </Box> */}
            </React.Fragment>
          ) : (
            <React.Fragment>
              {props.activeStep ? (
                <>
                  {" "}
                  {props.activeStep === 1 ? (
                    <>
                      <CohortContainer />
                    </>
                  ) : (
                    <>
                      <AddWarehouseContainer />
                    </>
                  )}
                </>
              ) : (
                <>
                  <CreateusersDetails />
                </>
              )}
            </React.Fragment>
          )}
        </div>
        <div>
          <Modal
            className="logout-main"
            show={props.show}
            onHide={() => props.setShow(false)}
          >
            <div className="child-div">
              <div className="child-1">
                <img className="img-avtar" src={avtar2} alt="" />
              </div>

              <div className="child-2">
                <p>Want to go back ?</p>
                <span>Want to go back ? All unsaved changes will be lost.</span>
              </div>
              <div className="logout-btn">
                <Button className="cancelBtn" onClick={handleCancel}>
                  Cancel
                </Button>
                <Button  className="logoutBtn1"  onClick={props.handleClose} >
                  Yes, go back
                </Button>
              </div>
            </div>
          </Modal>
        </div>

       

        <Box className="backbtnaddpage">
          <Button
            className="backbtnaddpage1"
            disabled={props.activeStep === 0}
           onClick={handleBack}
          >
            Back
          </Button>

          {props.activeStep === steps.length - 1 ? (
            <Button     className="saveandcontinue"   onClick={props.Createuserapi}>
            <Link to={"/"} style={{textDecoration:"none", color:"#fff"}}>Save</Link>
            </Button>
          ) : (
            <Button className="saveandcontinue" onClick={(props.handleNext)} >
              Save and Continue
            </Button>
          )}
        </Box>
      </div>
    </div>
  );
};

export default CreateUser;
