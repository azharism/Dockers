import React, { useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";
import CreateUser from "./component";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
const CreateUserContainer = (props) => {
  const [error, setEroor] = useState();
  const [show, setShow] = React.useState(false);
  const [showDiv, setShowDiv] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [isRadioClicked, setIsRadioClicked] = useState(false);

  let navigate = useNavigate();

  console.log("Createuserapi", props.createNewuser);
  const handleNext = () => {
    if (
      !props.createNewuser.add_name ||
      props.createNewuser.add_name.length < 3
    ) {
      return toastr.warning("Invalid", "Name is Mandatory");
    }
    if (!props.createNewuser.add_role) {
      return toastr.warning("Invalid", "Role is Mandatory");
    }

    if (!props.createNewuser.add_email || !/\S+@\S+\.\S+/.test(props.createNewuser.add_email)) {
      return toastr.warning("Invalid", "EMAIL Id is Mandatory");
    }
    

   

    if (
      !props.createNewuser.add_mobile ||
      props.createNewuser.add_mobile.length !== 10
    ) {
      return toastr.warning("Invalid","Mobile Number is Mandatory");
    }

    if (
      !props.createNewuser.add_password ||
      props.createNewuser.add_password.length < 6
    ) {
      return toastr.warning("Invalid", "Password is Mandatory");
    }

    // if (
    //   !props.createNewuser.add_warehouse  ) {
    //   return toastr.warning("Invalid", "warehouseis Mandatory");
    // }
    // if(!props.warehouseId){
    //   return toast.warning("Invalid", "warehouseis Mandatory")
    // }

setActiveStep((activeStep) => activeStep + 1)
    
  };

  const handleClose = () => {
    console.log("yes go back")
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
    
    setShow(false)
  };


  const Createuserapi = () => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/users/new",
      "POST",
      {
        mobile: props && props.createNewuser && props.createNewuser.add_mobile,
        password:
          props && props.createNewuser && props.createNewuser.add_password,
        roleId: props && props.createNewuser && props.createNewuser.add_role,
        warehouseId:
          props && props.createNewuser && props.createNewuser.add_warehouse,
        fullName: props && props.createNewuser && props.createNewuser.add_name,
        email: props && props.createNewuser && props.createNewuser.add_email,
        vmCohortIdColl:
          props && props.createNewuser && props.createNewuser.add_cohorts,
      },
      (response) => {
        console.log("res------------------------------------------", response);

        console.log("saveusercreate response", response);
        props.saveForgetpassRes(response);
        navigate("/home/users/list")
        toastr.success("user created")
       
       
      },
      (err) => {
        console.log(err);

        return toastr.error("Error", err.message);
      }
    );
  };
  return (
    <CreateUser
      Createuserapi={Createuserapi}
      show={show}
      setShow={setShow}
      handleNext={handleNext}
      activeStep={activeStep}
      showDiv={showDiv}
      setShowDiv={setShowDiv}
      handleClose={handleClose}
      isRadioClicked={isRadioClicked}
      // handleSubmit={handleSubmit}
    />
  );
};
function mapStateToProps({ createNewuser }) {
  return {
    createNewuser,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(CreateUserContainer);
