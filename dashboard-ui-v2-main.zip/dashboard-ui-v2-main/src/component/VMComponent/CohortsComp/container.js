import React, { Component, useState, useEffect, useRef } from "react";
import { connect } from "react-redux";
import { toastr } from "react-redux-toastr";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { setLoading } from "../../OrderComp/OrdersList/actions";
import { Navigate, useParams } from "react-router-dom";
import LoadingSpinner from "../../Loading/component";
import dayjs from "dayjs";
import { v4 as uuidv4 } from "uuid";
import Tesseract from "tesseract.js";
import { createWorker } from "tesseract.js";
import { useNavigate, useLocation } from "react-router-dom";
import _ from "lodash";
import ScreensaversComp from "./component";
import DaalchiniPointsComp from "./component";
import CohortListComp from "./component";

const CohortListContainer = (props) => {
  const navigate = useNavigate();
  const location = useLocation();
  console.log("order list container", props.match);
  const [data, setData] = useState([]);
  const [searchOrderList, setSearchOrderList] = useState();
  const [searchOrderValue, setSearchOrderValue] = useState();
  const [loading, setLoading] = useState(true);
  const [searchOrderData, setSearchOrderData] = useState(null);
  const [to_timestamp, setTo_timestamp] = useState();
  const [from_timestamp, setFrom_timestamp] = useState();
  const [morescroll, setMorescroll] = useState(true);
  const [start, setStart] = useState(0);
  const [SelectedDate, setSelectedDate] = useState(null);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [dateWithNoInitialValue, setDateWithNoInitialValue] =
    React.useState(null);
  const [dateWithInitialValue, setDateWithInitialValue] = React.useState(
    dayjs("00-00-00T00:00")
  );
  const [order, setOrder] = useState();
  const [onScroll, setOnScroll] = useState();
  const [dragActive, setDragActive] = React.useState(false);
  const [pickDate, setPickDate] = useState(dayjs("00-00-00T00:00"));
  const [year, setYear] = useState();
  const [month, setMonth] = useState();
  const [day, setDay] = useState();
  const [hours, setHours] = useState();
  const [second, setSecond] = useState();
  const [minute, setMinute] = useState();
  const [previewImage, setPreviewImage] = useState(null);
  const [imageDropped, setImageDropped] = useState(false);
  const inputRef = useRef(null);
  const [orderDetails, setOrderDetails] = useState(null);
  const [image, setImage] = useState(null);
  const [imagePath, setImagePath] = useState("");
  const [text_ocr, setText] = useState("");
  const [orderID, setOrderID] = useState("-1");
  const [orderFound, setOrderFound] = useState(true);
  const [orderId, setOrderId] = useState();
  const [orderIDFound, setOrderIDFound] = useState();
  const [retryClicked, setRetryClicked] = useState(false);
  const [showFileInput, setShowFileInput] = useState(false);
  const [inputFile, setInputFile] = useState("");
  const [SelectedFile, setSelectedFile] = useState(null);
  const [open, setOpen] = React.useState(false);
  // const [filteredOrderList, setFilteredOrderList] = useState(data);
  const [isFocused, setIsFocused] = useState(false);
  const [isSearchClicked, setIsSearchClicked] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchOption, setSearchOption] = useState("order_id");

  const order_id = [];
  const phone = [];
  const { orderid } = useParams();

  const handleFocus = () => {
    setIsFocused(true);
  };

  // useEffect(() => {
  //   LoadOrderDetails();
  // }, []);
  useEffect(() => {
    const handleScroll = () => {
      fetchUsersListNext(start + 1);
      setStart(start + 1);
      // LoadOrderDetails();
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [start, data, morescroll]);

  const rowColors = [
    "#E0FAF1",
    "#FF00A921",
    "#713ABA2E",
    "#A9CFF354",
    "#FF00A921",
  ];

  const handleDateChange = (newValue) => {
    console.log("mynew value", newValue);

    setYear(newValue.$y);

    setMonth(newValue.$M + 1);
    setDay(newValue.$D);
    setHours(newValue.$H);
    setMinute(newValue.$m);
    setSecond(newValue);
    console.log("mynewyear", year);

    // dt.push()
    // console.log("newyear", dt)
    // setDateWithInitialValue(newValue);
    // console.log("UI value", newValue);
    setPickDate(newValue);
    console.log("yearpick", newValue.$y);
  };

  const orderDateFilter = () => {
    setFrom_timestamp(from_timestamp);
    setTo_timestamp(to_timestamp);

    setStart(start + 1);
    props.getDataFromAPI(
      `/partner/api/v1/admin/orders?search_query=${searchOrderValue}&page_number=${start}&page_size=10`,
      "GET",
      "undefined",
      (response) => {
        console.log("Get response order date ", response);
        setSearchOrderList(response);
        console.log("Order date RES----->", response);
      },
      (err) => {}
    );
  };

  const handleSearchOptionChange = (event) => {
    setSearchOption(event.target.value);
    setSearchOrderValue("");
  };

  // const onSearchInputChange = (e) => {
  //   const searchName = e.target.value;
  //   console.log("searchName", searchName);
  //  localStorage.getItem('searchName',searchName)
  //   setSearchOrderValue(searchName);

  // };
  const onSearchInputChange = (e) => {
    const searchName = e.target.value;
    console.log("searchName", searchName);

    localStorage.setItem("searchName", searchName);
    setSearchOrderValue(searchName);
  };

  useEffect(() => {
    const storedSearchName = localStorage.getItem("searchName");

    if (storedSearchName) {
      setSearchOrderValue(storedSearchName);

      orderSearch(storedSearchName);
    }
  }, []);

  const onSearchClick = (searchName) => {
    if (
      searchOption === "order_id" ||
      searchOption === "phone" ||
      searchOption === "dcCode"
    ) {
      if (searchOrderValue && searchOrderValue.length >= 4) {
        setIsLoading(true);
        orderSearch(searchOrderValue);

        localStorage.getItem("searchName", searchName);

        navigate(`/home/ordersview/${searchOrderValue}`);
      } else {
        displayErrorToast(
          "Invalid order ID. Please enter at least 4 characters."
        );
      }
    } else {
      displayErrorToast(
        "Please select 'Order ID' & Phone to perform the search."
      );
    }
  };

  // const onSearchClick = () => {
  //   if (searchOrderValue && searchOrderValue.length >= 3) {
  //     setIsLoading(true); // set loading to true
  //     orderSearch(searchOrderValue);
  //   }
  // };

  const onSearchInputKeyDown = (e) => {
    if (e.keyCode === 13) {
      setIsLoading(true);
      orderSearch(searchOrderValue);
    }
  };
  const orderSearch1 = (event) => {

    if (isFocused && searchOrderValue && searchOrderValue.length >= 4) {
      const url = `/partner/api/v1/admin/orders/?search_query=${searchOrderValue}&page_number=0&page_size=100&from_timestamp=${fromTimestampFormatted}&to_timestamp=${toTimestampFormatted}`;

      return props.getDataFromAPI(
        url,
        "GET",
        "undefined",
        (response) => {
          console.log("Get response order search ", response);
          setSearchOrderList(response);
          console.log("SEARCH RES----->", response);
        },
        (err) => {}
      );
    }
  };

  const currentDate = new Date();
  const toTimestamp = currentDate.toISOString();

  currentDate.setDate(currentDate.getDate() - 30);
  const fromTimestamp = currentDate.toISOString();

  const fromTimestampFormatted = fromTimestamp.slice(0, 19).replace("T", " ");
  const toTimestampFormatted = toTimestamp.slice(0, 19).replace("T", " ");

  const displayErrorToast = (message) => {
    toastr.error(message);
  };

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const queryType = searchParams.get("query_type");
    const storedSearchValue = localStorage.getItem("searchOrderValue");

    if (queryType && storedSearchValue) {
      setSearchOption(queryType);
      setSearchOrderValue(storedSearchValue);

      orderSearch(storedSearchValue);
    }
  }, [location.search]);

  const orderSearch = (searchOrderValue, event) => {
    console.log("orderSearch");

    setSearchOrderData(searchOrderValue);

    if (searchOrderValue && searchOrderValue.length >= 4) {
      let queryType = "";
      if (searchOption === "phone") {
        queryType = "phone";
      } else if (searchOption === "order_id") {
        queryType = "order_id";
      } else if (searchOption === "dcCode") {
        queryType = "dcCode";
      }
      const url = `/partner/api/v1/admin/orders/?search_query=${searchOrderValue}&queryType=${queryType}&page_number=0&page_size=100&from_timestamp=${fromTimestampFormatted}&to_timestamp=${toTimestampFormatted}`;

      return props.getDataFromAPI(
        url,
        "GET",
        "undefined",
        (response) => {
          console.log("Get response order search ", response);
          setSearchOrderList(response);
          setIsLoading(false);
          console.log("SEARCH RES----->", response);
        },
        (err) => {
          setIsLoading(false);
          displayErrorToast("Failed to fetch data. Please try again.");
        }
      );
    } else {
      setSearchOrderList([]);
      setIsLoading(false);
      if (searchOrderValue) {
        if (searchOption === "phone") {
          displayErrorToast(
            "Invalid phone number. Please enter at least 4 digits."
          );
        } else if (searchOption === "order_id") {
          displayErrorToast(
            "Invalid order ID. Please enter at least 4 characters."
          );
        } else if (searchOption === "dcCode") {
          displayErrorToast("Invalid DC Code. Please enter at least 4 digits");
        }
      }
    }
  };

  const tableContainerRef = useRef(null);
  useEffect(() => {
    const handleScroll = _.throttle(() => {
      const container = tableContainerRef.current;
      if (container) {
        const { scrollTop, clientHeight, scrollHeight } = container;

        if (scrollTop + clientHeight >= scrollHeight) {
          searchOrderList(start);
          fetchUsersListNext(start)
        }
      }
    }, 200);

    const container = tableContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, [start]);

  const filteredOrderList =
  searchOrderData && searchOrderData.length >= 4
    ? searchOrderList &&
      searchOrderList.filter((order) => {
        if (searchOrderData) {
          
          const lowerCaseSearchValue = searchOrderData.toLowerCase();
          if (
            order &&
            (order.phone || '').includes(lowerCaseSearchValue) ||
            (order.order_id || '').includes(lowerCaseSearchValue) ||
            (order.dcCode || '').includes(lowerCaseSearchValue)
          ) {
            return true;
          }
        }
        return true;
      })
    : [];

console.log("filteredOrderList", filteredOrderList);



  console.log("filteredOrderList", filteredOrderList);

  // const LoadOrderDetails = () => {
  //   console.log("/partner/api/v1/admin/orders");

  //   return props.getDataFromAPI(
  //     `/partner/api/v1/admin/orders/?page_number=${start}&page_size=100`,

  //     "GET",
  //     undefined,

  //     (response) => {
  //       setData(response);
  //       setLoading(false);
  //       console.log("orders data response", response);
  //     },
  //     (err) => {
  //       // toastr.error("ERROR", err.data.message);
  //     },
  //     true
  //   );
  // };

  // const onSearchScroll= ()=>{
  //   props.getDataFromAPI(
  //     `partner/api/v1/admin/orders?from_timestamp=${year}-0${month}-0${day}%2012:00:00&to_timestamp=2023-02-06%2012:00:00&search_query=${searchOrderValue}&page_number=${start}&page_size=100`,
  //     "GET",
  //     "undefined",
  //     (response) => {
  //       if (response) {
  //         setData([...data, ...response]);
  //         console.log("onchange orderlist", response)
  //       }
  //       if (!response) {
  //         setMorescroll(false);
  //       }
  //     },
  //     (err) => {}
  //   );
  // };

  const fetchUsersListNext = () => {
    console.log("onchange order length", data.length);
    setStart(start + 1);
    props.getDataFromAPI(
      `/partner/api/v1/admin/orders/?page_number=${start}&page_size=100`,
      "GET",
      undefined,
      (response) => {
        if (response) {
          setData([...data, ...response]);
          console.log("onchange orderlist", response);
        }
        if (!response) {
          setMorescroll(false);
        }
      },
      (err) => {}
    );
  };
  console.log("filter order data", searchOrderData);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewImage(e.target.result);
        setImageDropped(true);
        setImagePath(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const onButtonClick = (e, type) => {
    if (type === "box") {
      inputRef.current.click();
    }
  };

  const handleClickImg = () => {
    if (imagePath !== "") {
    }
    setShowFileInput(false);
    Tesseract.recognize(imagePath, "eng", {
      logger: (m) => console.log(m),
    })
      .catch((err) => {
        console.error(err);
      })
      .then((result) => {
        console.log(" look at words----> ", result.data.words);
        const t = result.data.words;
        let orderIdFound = false;
        t.map((e) => {
          if (e.text.length === 16) {
            let a = e.text.replace(/O/, "0");
            setOrderID(a);
            console.log(" found this ----> ", a);
            navigate(`/home/ordersview/${a}`);
            orderIdFound = true;
          }
          return 0;
        });

        setText(t);
        setOrderFound(orderIDFound);
        if (!orderIdFound) {
          setOrderId("-1");
        }
      });
  };

  const handleChangeImage = (e) => {
    if (!e || !e.target || !e.target.files || e.target.files.length === 0) {
      setPreviewImage(null);
      setImageDropped(false);
      return;
    }

    const file = e.target.files[0];
    setSelectedFile(file);

    setImagePath(URL.createObjectURL(file));
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewImage(e.target.result);
      setImageDropped(true);
    };
    reader.readAsDataURL(file);
    setShowFileInput(false);
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleCloseD = () => {
    setOpen(false);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  const handleRetry = () => {
    setOrderFound(true);
    setOrderId("");
    setImagePath("");
    setPreviewImage(null);
    setImageDropped(false);
    setSelectedFile(null);
    setShowFileInput(true);
  };

  return (
    <CohortListComp
      filteredOrderList={filteredOrderList}
      // filteredOrderList={filteredOrderList}
      orderSearch={orderSearch}
      onSearchInputChange={onSearchInputChange}
      loading={loading}
      fetchNextUserslist={fetchUsersListNext}
      data={data}
      morescroll={morescroll}
      handleDateChange={handleDateChange}
      SelectedDate={SelectedDate}
      orderDateFilter={orderDateFilter}
      pickDate={pickDate}
      rowColors={rowColors}
      handleDrag={handleDrag}
      handleDrop={handleDrop}
      // handleChange={handleChange}
      onButtonClick={onButtonClick}
      dragActive={dragActive}
      inputRef={inputRef}
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
      previewImage={previewImage}
      imageDropped={imageDropped}
      // orderSearch1={orderSearch1}
      open={open}
      orderId={orderID}
      handleCloseD={handleCloseD}
      handleChangeImage={handleChangeImage}
      handleClickOpen={handleClickOpen}
      handleClickImg={handleClickImg}
      orderFound={orderFound}
      handleRetry={handleRetry}
      retryClicked={retryClicked}
      showFileInput={showFileInput}
      handleFocus={handleFocus}
      isFocused={isFocused}
      handleBlur={handleBlur}
      searchOrderData={searchOrderData}
      //  handleSearchClick={handleSearchClick}
      searchOrderValue={searchOrderValue}
      onSearchClick={onSearchClick}
      onSearchInputKeyDown={onSearchInputKeyDown}
      isLoading={isLoading}
      handleSearchOptionChange={handleSearchOptionChange}
      searchOption={searchOption}
      tableContainerRef={tableContainerRef}
    />
  );
};
function mapStateToProps({ props }) {
  return {
    props,
  };
}

export default connect(mapStateToProps, {
  getDataFromAPI,
  setLoading
})(CohortListContainer);
