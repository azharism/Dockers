import React, { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
  Modal,
} from '@mui/material';
// import Sidebar from '../../../Navigation/Sidebar/Sidebar';
// import LoadingSpinner from '../../../Loading/component';
import { useNavigate } from 'react-router-dom';
import leftArrow from "../../../assests/leftArrow.svg";
import search from "../../../assests/search.svg";
import Table from "react-bootstrap/Table";
import LoadingSpinner from '../../Loading/component';
import Sidebar from '../../Navigation/Sidebar/Sidebar';

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 800,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

const MfidFormComponent = (props) => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleClick = () => {
    navigate(-1);
  };

  return (
    <>
      <div className="main-div" style={{ margin: "auto", backgroundColor: "#fff" }}>
        <div>
          <Sidebar />
        </div>

        {props.loading ? (
          <LoadingSpinner />
        ) : (
          <>
            <div>
              <div>
                <h2 style={{ width: "360px", margin: "32px" }}>
                  <img
                    onClick={handleClick}
                    style={{ width: "22px", cursor: "pointer" }}
                    src={leftArrow}
                    alt=""
                  />{" "}
                  Create New MFIDs
                </h2>
              </div>

              <div style={{ width: "1200px" }}>
                <Box
                  component="form"
                  sx={{
                    width: 590,
                    margin: "80px auto",
                    padding: 2,
                    borderRadius: 2,
                    backgroundColor: "#fff",
                    boxShadow: 2,
                  }}
                >
                  <FormControl fullWidth margin="normal">
                    <InputLabel>Purchase Type</InputLabel>
                    <Select
                      name="purchaseType"
                      value={props.formDataMfids.purchaseType}
                      onChange={props.handleChangeCreateMfids}
                      label="Purchase Type"
                    >
                      <MenuItem value="">Select Purchase Type</MenuItem>
                      {props.dropdownData &&
                        props.dropdownData.map((item) => (
                          <MenuItem key={item.id} value={item.id}>{item.name}</MenuItem>
                        ))}
                    </Select>
                  </FormControl>

                  <Box sx={{ position: "relative", mb: 2 }}>
                    <Button
                      variant="outlined"
                      sx={{
                        position: "absolute",
                        right: 0,
                        top: '50%',
                        transform: 'translateY(-50%)',
                      }}
                      onClick={handleOpen}
                    >
                      Select Vendor
                    </Button>
                    <TextField
                      fullWidth
                      name="vendorName"
                      value={props.formDataMfids.vendorName}
                      onChange={props.handleChangeCreateMfids}
                      label="Vendor Name"
                      InputProps={{
                        readOnly: true,
                      }}
                      sx={{ pr: 12 }}
                    />
                  </Box>

                  <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                  >
                    <Box sx={style}>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", marginBottom: 2 }}>
                          <img
                            onClick={handleClick}
                            style={{ width: "22px", cursor: "pointer", marginRight: 1 }}
                            // src={leftArrow}
                            alt=""
                          />
                          <Typography variant="h6">Search Vandor</Typography>
                        </div>

                        <div className="cohortsec">
                          <div className="searchDivision">
                            <TextField
                              type="search"
                              placeholder="Search by Cohort Name/ Cohort ID"
                              onChange={(e) => {
                                props.Search(e.target.value);
                              }}
                              fullWidth
                            />
                          </div>

                          <Table striped className="scrolldown">
                            <thead>
                              <tr>
                                <th>Cohort ID</th>
                                <th>Cohort Name</th>
                                <th>Area Name</th>
                                <th>Type</th>
                                <th>Select</th>
                              </tr>
                            </thead>

                            <tbody>
                              {props.FilterCohortData &&
                                props.FilterCohortData.length > 0 &&
                                props.FilterCohortData.map((el) => (
                                  <tr key={el.id}>
                                    <td>{el.id}</td>
                                    <td>{el.name}</td>
                                    <td>{el.area_name}</td>
                                    <td>{el.type}</td>
                                    <td>
                                      <input
                                        type="checkbox"
                                        checked={props.userdetailsCohort?.some((dt) => dt.id === el.id)}
                                        onChange={(e) => {
                                          if (e.target.checked) {
                                            props.addCohorthandleClick(el.id);
                                          } else {
                                            props.removedCohort(el.id);
                                          }
                                        }}
                                      />
                                    </td>
                                  </tr>
                                ))}
                            </tbody>
                          </Table>
                        </div>

                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
                          <Button variant="contained" color="secondary" onClick={handleClose}>
                            Back
                          </Button>
                          <Button variant="contained" color="primary" onClick={handleClose}>
                            Save
                          </Button>
                        </Box>
                      </div>
                    </Box>
                  </Modal>

                  <Box sx={{ display: "flex", gap: 2 }}>
                    <TextField
                      fullWidth
                      name="purchasePrice"
                      value={props.formDataMfids.purchasePrice}
                      onChange={props.handleChangeCreateMfids}
                      label="Purchase Price"
                      type="number"
                      margin="normal"
                      placeholder="Example: ₹ 6"
                    />
                    <TextField
                      fullWidth
                      name="mrp"
                      value={props.formDataMfids.mrp}
                      onChange={props.handleChangeCreateMfids}
                      label="M.R.P"
                      type="number"
                      margin="normal"
                      placeholder="Example: ₹ 6"
                    />
                  </Box>

                  <TextField
                    fullWidth
                    name="sellingPrice"
                    value={props.formDataMfids.sellingPrice}
                    onChange={props.handleChangeCreateMfids}
                    label="Selling Price"
                    type="number"
                    margin="normal"
                    placeholder="Example: ₹ 6"
                  />

                  <Box sx={{ display: "flex", justifyContent: "space-between", mt: 3 }}>
                    <Button
                      variant="contained"
                      color="error"
                      onClick={() =>
                        props.setFormData({
                          purchaseType: "",
                          vendorName: "",
                          purchasePrice: "",
                          mrp: "",
                          sellingPrice: "",
                        })
                      }
                    >
                      Cancel
                    </Button>
                    <Button variant="contained" color="primary" onClick={props.handleCretateMfidApi}>
                      Save
                    </Button>
                  </Box>
                </Box>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default MfidFormComponent;
