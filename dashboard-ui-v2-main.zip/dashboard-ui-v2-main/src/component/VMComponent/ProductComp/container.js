import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { toastr } from "react-redux-toastr";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import ProductsListComp from "./component";
import { Link, useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

const ProductListContainer = (props) => {
  const [loading, setLoading] = useState(true);
  const [brandList, setBrandList] = useState([]);
  const [itemList, setItemList] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredItemList, setFilteredItemList] = useState([]);
  const [productList, setProductList] = useState([]);
  const [sortDataList, setSortDataList] = useState([]);
  const [selectedOption, setSelectedOption] = useState("");
  const [selectedBrands, setSelectedBrands] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState("All");
  const [searchClicked, setSearchClicked] = useState(false);
  const [initialSearch, setInitialSearch] = useState(true);
  const { variantId } = useParams();

  const navigate = useNavigate();

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSearchItemList();
    }
  };

  const handleVariantDetails = (e, variantId) => {
    navigate(`/home/configuration/productsvariantdetails/${variantId}`);
  };

  const isSearchEmpty = searchQuery.trim().length < 3 && !initialSearch;
  const hasFilteredItems = filteredItemList && filteredItemList.length > 0;

  useEffect(() => {
    const savedSearchQuery = localStorage.getItem("searchQuery");
    const savedFilteredItemList = JSON.parse(
      localStorage.getItem("filteredItemList")
    );
    const savedBrandList = JSON.parse(localStorage.getItem("brandList"));
    const savedProductList = JSON.parse(localStorage.getItem("productList"));

    if (savedSearchQuery) {
      setSearchQuery(savedSearchQuery);
    }
    if (savedFilteredItemList) {
      setFilteredItemList(savedFilteredItemList);
    }
    if (savedBrandList) {
      setBrandList(savedBrandList);
    }
    if (savedProductList) {
      setProductList(savedProductList);
    }

    setInitialSearch(false);
  }, []);

  useEffect(() => {
    if (selectedOption) {
      handleSortItemList();
    }
  }, [selectedOption]);

  const handleSearchChange = (event) => {
    const { value } = event.target;
    setSearchQuery(value);
    if (searchClicked === true && value.length > 4) {
      setSearchClicked(false);
    }
  };

  const clearAllFilters = () => {
    setSelectedBrands([]);
    setSelectedProducts([]);
    setSelectedStatus("All");

    setTimeout(() => {
      setSelectedBrands([]);
      setSelectedProducts([]);
      setSelectedStatus("All");
    }, 100);
  };

  const handleStatusChange = (status) => {
    setSelectedStatus(status);
    let isActive = "";

    if (status === "All") {
      isActive = "";
    } else if (status === "Active") {
      isActive = "true";
    } else if (status === "Inactive") {
      isActive = "false";
    }

    handleChangeStatusRadio(isActive);
  };

  const handleChangeStatusRadio = (isActive) => {
    setLoading(true);
    props.getDataFromAPI(
      `/partner/api/v2/productSearch/variant?variantName=${searchQuery}&productName=&brandName=&isActive=${isActive}`,
      "GET",
      undefined,
      (response) => {
        setLoading(false);
        if (
          response &&
          response.variantResponse &&
          response.brandResponse &&
          response.productResponse
        ) {
          const variantList = response.variantResponse;
          const brandList = response.brandResponse;
          const productList = response.productResponse;

          setItemList(variantList);
          setFilteredItemList(variantList);
          setBrandList(brandList);
          setProductList(productList);
        } else {
          console.error("Incomplete response received");
          toastr.error("Failed", "Incomplete response received");
          setItemList([]);
          setFilteredItemList([]);
          setBrandList([]);
          setProductList([]);
        }
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch item list listing");
      }
    );
  };

  const handleSearchItemList = () => {
    if (searchQuery.trim().length < 3) {
      toastr.warning(
        "Error",
        "Minimum 3 characters are required for searching"
      );
      return;
    }

    setLoading(true);
    props.getDataFromAPI(
      `/partner/api/v2/productSearch/variant?variantName=${searchQuery}&productName=&brandName=&isActive=`,
      "GET",
      undefined,
      (response) => {
        setLoading(false);
        if (
          response &&
          response.variantResponse &&
          response.brandResponse &&
          response.productResponse
        ) {
          const variantList = response.variantResponse;
          const brandList = response.brandResponse;
          const productList = response.productResponse;

          setFilteredItemList(variantList);
          setBrandList(brandList);
          setProductList(productList);

          localStorage.setItem("searchQuery", searchQuery);
          localStorage.setItem("filteredItemList", JSON.stringify(variantList));
          localStorage.setItem("brandList", JSON.stringify(brandList));
          localStorage.setItem("productList", JSON.stringify(productList));
        } else {
          console.error("Incomplete response received");
          toastr.error("Failed", "Incomplete response received");
          setFilteredItemList([]);
          setBrandList([]);
          setProductList([]);
        }
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch item list listing");
        setLoading(false);
      }
    );
  };

  const handleSortItemList = () => {
    setLoading(true);
    props.getDataFromAPI(
      `/partner/api/v2/productSearch/variant?variantName=${searchQuery}&productName=&brandName=&isActive=&sortBy=${selectedOption}`,
      "GET",
      undefined,
      (response) => {
        setLoading(false);
        if (response && response.variantResponse) {
          setFilteredItemList(response.variantResponse);
        } else {
          setFilteredItemList([]);
        }
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch sort item list listing");
        setLoading(false);
      }
    );
  };

  const handleCheckBoxChange = (brandName) => {
    const updatedBrands = selectedBrands.includes(brandName)
      ? selectedBrands.filter((brand) => brand !== brandName)
      : [...selectedBrands, brandName];

    setSelectedBrands(updatedBrands);
    handleCheckBoxItemList(updatedBrands, selectedProducts);
  };

  const handleBrandCheckboxChange = (brandName) => {
    const updatedBrands = selectedBrands.includes(brandName)
      ? selectedBrands.filter((brand) => brand !== brandName)
      : [...selectedBrands, brandName];

    setSelectedBrands(updatedBrands);
    handleCheckBoxItemList(updatedBrands, selectedProducts);
  };

  const handleProductCheckboxChange = (productName) => {
    const updatedProducts = selectedProducts.includes(productName)
      ? selectedProducts.filter((product) => product !== productName)
      : [...selectedProducts, productName];

    setSelectedProducts(updatedProducts);
    handleCheckBoxItemList(selectedBrands, updatedProducts);
  };

  // const handleCheckBoxItemList = (selectedBrands, selectedProducts) => {
  //   if (selectedBrands.length === 0 && selectedProducts.length === 0) {
  //     handleSearchItemList();
  //   } else {
  //     setLoading(true);
  //     props.getDataFromAPI(
  //       `/partner/api/v2/productSearch/variant?variantName=${searchQuery}&productName=${selectedProducts.join(
  //         ","
  //       )}&brandName=${selectedBrands.join(",")}&sortBy=${selectedOption}`,
  //       "GET",
  //       undefined,
  //       (response) => {
  //         setLoading(false);
  //         if (response && response.variantResponse) {
  //           setFilteredItemList(response.variantResponse);
  //         } else {
  //           setFilteredItemList([]);
  //         }
  //       },
  //       (err) => {
  //         console.log("error:", err);
  //         toastr.error("Failed", "Unable to fetch filtered item list");
  //       }
  //     );
  //   }
  // };
  const handleCheckBoxItemList = (selectedBrands, selectedProducts) => {
  const formatQueryParam = (arr) => arr.join(",").replace(/&/g, "%26");

  if (selectedBrands.length === 0 && selectedProducts.length === 0) {
    handleSearchItemList();
  } else {
    setLoading(true);
    props.getDataFromAPI(
      `/partner/api/v2/productSearch/variant?variantName=${searchQuery}&productName=${formatQueryParam(
        selectedProducts
      )}&brandName=${formatQueryParam(selectedBrands)}&sortBy=${selectedOption}`,
      "GET",
      undefined,
      (response) => {
        setLoading(false);
        if (response && response.variantResponse) {
          setFilteredItemList(response.variantResponse);
        } else {
          setFilteredItemList([]);
        }
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch filtered item list");
      }
    );
  }
};


  const handleSortChange = (event) => {
    setSelectedOption(event.target.value);
  };

  return (
    <ProductsListComp
      loading={loading}
      productList={productList}
      brandList={brandList}
      filteredItemList={filteredItemList}
      searchQuery={searchQuery}
      itemList={itemList}
      handleSearchChange={handleSearchChange}
      handleSearchItemList={handleSearchItemList}
      handleKeyPress={handleKeyPress}
      selectedOption={selectedOption}
      handleSortChange={handleSortChange}
      setFilteredItemList={setFilteredItemList}
      handleCheckBoxChange={handleCheckBoxChange}
      handleBrandCheckboxChange={handleBrandCheckboxChange}
      handleProductCheckboxChange={handleProductCheckboxChange}
      handleStatusChange={handleStatusChange}
      selectedStatus={selectedStatus}
      clearAllFilters={clearAllFilters}
      searchClicked={searchClicked}
      setSelectedBrands={setSelectedBrands}
      setSelectedProducts={setSelectedProducts}
      setSelectedStatus={setSelectedStatus}
      handleVariantDetails={handleVariantDetails}
      isSearchEmpty={isSearchEmpty}
      hasFilteredItems={hasFilteredItems}
      initialSearch={initialSearch}
      setInitialSearch={setInitialSearch}
    />
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}

export default connect(mapStateToProps, {
  getDataFromAPI,
})(ProductListContainer);
