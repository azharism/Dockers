import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { useNavigate } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import CreateVendorComponent from "./component";
import {  toast } from "react-toastify";



const CreateVendorContainer = (props) => {

  const [loading, setLoading]= useState(false)
  const [stateName, setStateName] = useState([]);
  const [cityName, setCityName] = useState([]);
  const [stateId, setStateId] = useState(undefined);
  const [formData, setFormData] = useState({
    name: '',
    phoneNumber: '',
    email: '',
    gstNumber: '', 
    fssaiNumber: '',
    state_id: '',
    city_id: '',
    street: '',
    addressLine1: null,
    pinCode: '',
    lat: null,
    lng: null
  });
  const navigate = useNavigate();

  const handleChangeCreateVendor = (event) => {
    const { name, value } = event.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  useEffect(() => {
    handleGetStateName();
  }, []);

  const handleGetStateName = () => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/vendingmachines/location/states",
      "GET",
      undefined,
      (response) => {
        setStateName(response.list);
        setStateId(response.list[0]?.id);
        handleGetCityName(response.list[0]?.id);
      },
      (err) => {
        toastr.error("Failed", "Unable to fetch state listing");
      }
    );
  };

  useEffect(() => {
    if (stateId) {
      handleGetCityName(stateId);
    }
  }, [stateId]);

  const handleGetCityName = (stateId) => {
    if (stateId) {
      props.getDataFromAPI(
        `/dashboard/api/v2/admin/vendingmachines/location/${stateId}/cities`,
        "GET",
        undefined,
        (response) => {
          setCityName(response.list);
        },
        (err) => {
          toastr.error("Failed", "Unable to fetch city listing");
        }
      );
    }
  };

  const handleCreateVendorApi = async () => {
    const payload = {
      name: formData.name,
      phoneNumber: formData.phoneNumber,
      email: formData.email,
      gstNumber: formData.gstNumber,
      fssaiNumber: formData.fssaiNumber,
      state_id: formData.state_id,
      city_id: formData.city_id,
      street: formData.street,
      addressLine1: formData.addressLine1,
      pinCode: formData.pinCode,
      lat: formData.lat,
      lng: formData.lng
    };

    try {
      await props.getDataFromAPI(
        "/partner/api/v2/productSearch/create/vendor",
        "POST",
        payload,
        (response) => {
          toastr.success("Success", "Vendor Created");
          navigate(-1);
        },
        (err) => {
      
        toastr.error(`${err.status.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
      );
    } catch (err) {
      toastr.error("Failed", "Error creating vendor");
    }
  };

  return (
    <CreateVendorComponent
      formData={formData}
      handleChangeCreateVendor={handleChangeCreateVendor}
      handleCreateVendorApi={handleCreateVendorApi}
      setFormData={setFormData}
      stateName={stateName}
      cityName={cityName}
      loading={loading}
    />
  );
};

function mapStateToProps(props) {
  return {
   props,
  };
}

export default connect(mapStateToProps, {
  getDataFromAPI,
})(CreateVendorContainer);
