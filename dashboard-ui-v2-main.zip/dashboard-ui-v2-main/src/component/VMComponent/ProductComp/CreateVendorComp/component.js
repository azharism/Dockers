import React from "react";
import {
  Box,
  Button,
  MenuItem,
  TextField,
  Grid
} from "@mui/material";
import "./style.css";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import LoadingSpinner from "../../../Loading/component";
import { useNavigate } from "react-router-dom";
import leftArrow from "../../../../assests/leftArrow.svg";

const CreateVendorComponent = (props) => {
  const navigate = useNavigate();

  const goback = () => {
    navigate(-1);
  };
  console.log("props.stateName.list", props.stateName.list)

  return (
    <>
      <div className="main-div" style={{ margin: "auto" }}>
        <div>
          <Sidebar />
        </div>

        {props.loading ? (
          <LoadingSpinner />
        ) : (
          <div>
            <div>
              <h2 style={{ width: "360px", margin: "32px" }}>
                <img
                  onClick={goback}
                  style={{ width: "22px", cursor: "pointer" }}
                  src={leftArrow}
                  alt=""
                />{" "}
                Create Vendor
              </h2>
            </div>

            <div
              style={{
                backgroundColor: "#fff",
                height: "779px",
                position: "relative",
                width: "1300px",
                bottom: "70px",
                left: "40px",
                top: "10px",
                borderRadius: "15px",
              }}
            >
              <Box sx={{ p: 6, mx: '10px' }}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      required
                      id="vendor-name"
                      name="name"
                      label="Vendor Name"
                      fullWidth
                      variant="outlined"
                      placeholder="Example: Priya General Store"
                      value={props.formData.name}
                      onChange={props.handleChangeCreateVendor}
                    />
                  </Grid>
                  <Grid item xs={6} sm={6}>
                    <TextField
                      select
                      id="state"
                      name="state_id"
                      label="State"
                      fullWidth
                      variant="outlined"
                      value={props.formData.state_id}
                      onChange={props.handleChangeCreateVendor}
                    >
                      {props.stateName && props.stateName.map((el, index) => (
                        <MenuItem key={index} value={el.id}>
                          {el.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      required
                      id="vendor-phone"
                      name="phoneNumber"
                      label="Vendor Phone Number"
                      fullWidth
                      variant="outlined"
                      placeholder="Example: 0123456789"
                      value={props.formData.phoneNumber}
                      onChange={props.handleChangeCreateVendor}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      select
                      id="city"
                      name="city_id"
                      label="City Name"
                      fullWidth
                      variant="outlined"
                      value={props.formData}
                      onChange={props.handleChangeCreateVendor}
                    >
                      {props.cityName && props.cityName.map((el, index) => (
                        <MenuItem key={index} value={el.id}>
                          {el.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      required
                      id="vendor-email"
                      name="email"
                      label="Vendor Email ID"
                      fullWidth
                      variant="outlined"
                      placeholder="Abcd@gmail.com"
                      value={props.formData.email}
                      onChange={props.handleChangeCreateVendor}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      id="street-address"
                      name="street"
                      label="Street Address"
                      fullWidth
                      variant="outlined"
                      placeholder="Example: 123 Abc colony abc Nagar"
                      value={props.formData.street}
                      onChange={props.handleChangeCreateVendor}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      id="gst-number"
                      name="gstNumber"
                      label="GST Number"
                      fullWidth
                      variant="outlined"
                      placeholder="Enter GST Number"
                      value={props.formData.gstNumber}
                      onChange={props.handleChangeCreateVendor}
                    />
                  </Grid>
                  <Grid item xs={6} sm={6}>
                    <TextField
                      id="pincode"
                      name="pinCode"
                      label="Pincode"
                      fullWidth
                      variant="outlined"
                      placeholder="Enter Area Pincode"
                      value={props.formData.pinCode}
                      onChange={props.handleChangeCreateVendor}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      id="fssai"
                      name="fssaiNumber"
                      label="FSSAI"
                      fullWidth
                      variant="outlined"
                      placeholder="Enter FSSAI"
                      value={props.formData.fssaiNumber}
                      onChange={props.handleChangeCreateVendor}
                    />
                  </Grid>
                  <Box className="usersrolebtnCohort">
                    <Button className="MfidCancelBtn" onClick={goback}>
                      Cancel
                    </Button>
                    <Button className="savebtnupdate" onClick={props.handleCreateVendorApi}>
                      Save
                    </Button>
                  </Box>
                </Grid>
              </Box>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default CreateVendorComponent;
