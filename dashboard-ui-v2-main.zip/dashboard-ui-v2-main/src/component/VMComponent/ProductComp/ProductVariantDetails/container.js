import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import ProductVariantDetailsComponent from "./component";
import { toastr } from "react-redux-toastr";
import { useParams } from "react-router-dom";

import { useNavigate } from "react-router-dom";

const ProductVariantDetailsContainer = (props) => {
  const { variantId, id } = useParams();
  console.log("ankit mfid", id);
  const [productData, setProductData] = useState([]);
  const [manufacturerVariantData, setManufacturerVariantData] = useState([])
  const [loading, setLoading] = useState(true);
 const [mfidCountData, setMfidCountData] = useState([])
  const navigate = useNavigate();
  console.log("tahzeeb", props.match);

  useEffect(() => {
    handleGetProductDetailsApi();
  }, []);

  
 
const handleGetProductDetailsApi = () => {
  return props.getDataFromAPI(
    `/partner/api/v2/productSearch/variant/${variantId}`,
    "GET",
    undefined,
    (response) => {
      setLoading(false);
      console.log("handleAPi---mfid",response.manufacturerVariant)
      setProductData(response.variantResponse)
    setManufacturerVariantData(response.manufacturerVariant)
     setMfidCountData(response)

      console.log("response---------> order", response);
    },
    (err) => {},
    true
  );
};

console.log("mfidc", mfidCountData)


  return (
    <>
      <ProductVariantDetailsComponent
       
        loading={loading}
        productData={productData}
       manufacturerVariantData={manufacturerVariantData}
       mfidCountData={mfidCountData}
      />
     
    </>
  );
};

function mapStateToProps({ props }) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
 
})(ProductVariantDetailsContainer);
