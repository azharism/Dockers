import { useState, useCallback, useEffect } from "react";
import LoadingSpinner from "../../../Loading/component";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg"
import mrpImg from "../../../../assests/Label.png";
import  "./component.css";
import styles from "./styles.module.css"
import Button from "@mui/material/Button";
import { Link, useNavigate, useHistory, useParams } from "react-router-dom";

const ProductVariantDetailsComponent = (props, data) => {
  console.log(
    "props product ",
    props.productData && props.productData
  );
    const { variantId } = useParams();
    const {  id } = useParams();
    console.log("mfidget", id)
  const navigate = useNavigate();
   const handleClick = () => {
     navigate(-1);
   };
   const handleCreateMfids =(variantId)=>{
    navigate(
      `/home/configuration/productsvariantdetails/createmfid/${variantId}`
    );
   }
    const handleUpdateMfids = (variant) => {
      navigate(
        `/home/configuration/productsvariantdetails/updatemfid/${variant.id}/${variantId}`,
        { state: { variant } }
      );
    };
  return (
    <>
      <div
        className="main-div"
        style={{ margin: "auto", backgroundColor: "#fff" }}
      >
        <div>
          <Sidebar />
        </div>

        {props.loading ? (
          <>
            <LoadingSpinner />
          </>
        ) : (
          <>
            {data && data && (
              <div>
                <div>
                  <div
                    style={{
                      marginLeft: "102px",
                      marginTop: "10px",
                      display: "flex",
                      justifyContent: "space-between",
                    }}
                  >
                    <div>
                      <h2 style={{ width: "360px" }}>
                        <img
                          onClick={handleClick}
                          style={{ width: "22px", cursor: "pointer" }}
                          src={leftArrow}
                          alt=""
                        />{" "}
                        {props.productData && props.productData.productName}
                      </h2>
                    </div>

                    <div>
                      <Button
                        style={{
                          fontSize: "14px",
                          backgroundColor: "#3282FF  ",
                          border: "1px solid #4caf50",
                          padding: "8px",
                          color: "#fff",
                        }}
                        // variant="warning"
                        onClick={() =>
                          handleCreateMfids(
                            props.productData && props.productData.variantId
                          )
                        }
                      >
                        Create New MFID
                      </Button>
                    </div>
                  </div>

                  <section className={styles.frameWrapper}>
                    <div className={styles.charmcrossParent}>
                      <div className={styles.frameChild} />

                      <img
                        className={styles.frameItem}
                        alt="No image Available"
                        src={`https://s3.ap-south-1.amazonaws.com/daalchini/dcprod/${
                          props.productData.variantImages &&
                          props.productData.variantImages[0].imageId
                        }`}
                      />

                      <div className={styles.frameContainer}>
                        <div className={styles.frameParent}>
                          <div className={styles.variantId4698Wrapper}>
                            <div className={styles.variantIdContainer}>
                              <span>{`Variant ID - `}</span>
                              <span className={styles.span}>
                                {props.productData &&
                                  props.productData.variantId}
                              </span>
                            </div>
                          </div>
                          <div className={styles.brandNameContainer}>
                            <span className={styles.brandNameContainer1}>
                              <span>{`Brand Name - `}</span>
                              <span className={styles.britannia}>
                                {props.productData &&
                                  props.productData.brandName}
                              </span>
                            </span>
                          </div>
                          <div className={styles.productNameContainer}>
                            <span>{`Product Name - `}</span>
                            <span className={styles.britanniaFruit}>
                              {props.productData &&
                                props.productData.productName}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                  <div style={{ marginLeft: "100px", marginTop: "20px" }}>
                    <p>
                      MFIDs- (
                      {props.mfidCountData.mfIdCount &&
                        props.mfidCountData.mfIdCount}
                      )
                    </p>
                  </div>
                  <div>
                    {props.manufacturerVariantData &&
                      props.manufacturerVariantData.length > 0 &&
                      props.manufacturerVariantData.map((item) => (
                        <section key={item.id} className={styles.frameWrapper1}>
                          <div className={styles.charmcrossParent1}>
                            <div
                              style={{
                                width: "1194px",
                                borderTop: "1px solid #ccc",
                                display: "flex",
                                position: "absolute",
                                marginBottom: "160px",
                              }}
                            />

                            <div className={styles.frameContainer}>
                              <span className={styles.span1}>
                                {`MFIDs  - `} {item.id}
                              </span>
                              <Button
                                style={{
                                  position: "relative",
                                  left: "1100px",
                                  bottom: "80px",
                                }}
                                variant="outlined"
                                onClick={() => handleUpdateMfids(item)}
                              >
                                Edit
                              </Button>
                              {console.log(
                                "getmfidissueeeeeeee",
                                props.manufacturerVariantData.id &&
                                  props.manufacturerVariantData.id
                              )}
                              <div className={styles.frameParent}>
                                <div
                                  className={styles.variantId4698Wrapper}
                                  style={{ marginTop: "-30px" }}
                                >
                                  <div className={styles.variantIdContainer}>
                                    <span>{`Vender Name  - `}</span>
                                    <span className={styles.span}>
                                      {item.manufacturerName}
                                    </span>
                                  </div>
                                </div>
                                <div className={styles.productNameContainer}>
                                  <span>{`Purchase Type - `}</span>
                                  <span className={styles.britanniaFruit}>
                                    {item.purchaseType
                                      ? item.purchaseType
                                      : "null"}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className={styles.frameContainer}>
                              <div className={styles.frameParent}>
                                <div
                                  className={styles.variantId4698Wrapper}
                                  style={{ marginTop: "30px" }}
                                >
                                  <div className={styles.variantIdContainer}>
                                    <span>{`M.R.P - `}</span>
                                    <span className={styles.span}>
                                      {item.mrp}
                                    </span>
                                  </div>
                                </div>
                                <div className={styles.productNameContainer}>
                                  <span>{`Purchase price - `}</span>
                                  <span className={styles.britanniaFruit}>
                                    {item.vendorPrice}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div
                              className={styles.frameItem1}
                              style={{ marginTop: "30px" }}
                            >
                              <div style={{ margin: "20px 15px 20px 36px" }}>
                                <p className={styles.britanniaFruit}>
                                  Selling Price
                                </p>
                                <span
                                  className={styles.britanniaFruit}
                                  style={{ position: "relative", left: "30px" }}
                                >
                                  &nbsp; {item.offerPrice}
                                </span>
                              </div>
                            </div>
                          </div>
                        </section>
                      ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
};

export default ProductVariantDetailsComponent;
