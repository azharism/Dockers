import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { useNavigate, useParams } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import UpdateMfidFormComponent from "./component";

const UpdateMfidContainer = (props) => {
  const { id, variantId } = useParams();
   

  const [dropdownData, setDropdownData] = useState([]);
  const [vandorListData, setVandorListData] = useState([]);
  const [filteredVendorList, setFilteredVendorList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mfidDetailsData, setMfidDetailsData] = useState([]);

  const navigate = useNavigate();
const [formData, setFormData] = useState({
    zohoItemTypeId: "",
    vendorPrice: "",
    mrp: "",
    offerPrice: "",
    vendorName: "",
    manufacturerId: "",
    mvId: id,
    zohoItemTypeName: "",
   
  });

  useEffect(() => {
    if (mfidDetailsData) {
      setFormData({
        zohoItemTypeId: mfidDetailsData.zohoItemTypeId || "",
        vendorPrice: mfidDetailsData.vendorPrice || "",
        mrp: mfidDetailsData.mrp || "",
        offerPrice: mfidDetailsData.offerPrice|| "",
        vendorName: mfidDetailsData.vendorName || "",
        manufacturerId: mfidDetailsData.manufacturerId || "",
        mvId: id,
        zohoItemTypeName: mfidDetailsData.zohoItemTypeName || "",
      });
    }
  }, [mfidDetailsData, id]);

  // useEffect(() => {
  //   console.log("Form data updated:", formData);
  // }, [formData]);
  

  

  
  useEffect(() => {
    handleGetDropdownItemApi();
    handleGetVandorListApi();
    handleGetMfidDetailsApi();
  }, []);

  const handleGetDropdownItemApi = () => {
    return props.getDataFromAPI(
      `/dashboard/api/v2/admin/form/dropdowns`,
      "GET",
      undefined,
      (response) => {
        console.log("handleAPi---mfid", response.itemTypes);
        setLoading(false)
        setDropdownData(response.itemTypes);
        console.log("response---------> order", response);
      },
      (err) => {},
      true
    );
  };

  const handleGetVandorListApi = () => {
    return props.getDataFromAPI(
      `/dashboard/api/v5/vendors/all`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        setVandorListData(response);
        setFilteredVendorList(response);
      },
      (err) => {},
      true
    );
  };
console.log("vendor name", mfidDetailsData.offerPrice)
  const handleGetMfidDetailsApi = () => {
    return props.getDataFromAPI(
      `/partner/api/v2/productSearch/variant/${variantId}`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        const filteredData = response.manufacturerVariant.filter(
          (item) => item.id === parseInt(id)
        );
        if (filteredData.length > 0) {
          const data = filteredData[0];
          setMfidDetailsData(data);
          setFormData({
            zohoItemTypeId: data.zohoItemTypeId || "",
            manufacturerId: data.manufacturerId || "",
            vendorPrice: data.vendorPrice || "",
            mrp: data.mrp || "",
            offerPrice: data.offerPrice || "",
            
            mvId: id
          });
          setLoading(false);
        } else {
          toastr.error("Error", "Manufacturer variant not found");
          setLoading(false);
        }
      },
      (err) => {
        toastr.error("Error", "Failed to fetch manufacturer variant details");
        setLoading(false);
      },
      true
    );
  };

  const handleSearch = (searchTerm) => {
    const lowercasedTerm = searchTerm.toLowerCase();
    const filteredList = vandorListData.filter(
      (vendor) =>
        vendor.name.toLowerCase().includes(lowercasedTerm) ||
        vendor.id.toString().includes(lowercasedTerm)
    );
    setFilteredVendorList(filteredList);
  };

  const handleUpdateMfidApi = async () => {
    const payload = {
      zohoItemTypeId: formData.zohoItemTypeId,
      manufacturerId: formData.manufacturerId,
      
      mrp: formData.mrp,
      offerPrice: formData.offerPrice,
      vendorPrice: formData.vendorPrice,
      mvId: formData.mvId
    };

    try {
      const response = await props.getDataFromAPI(
        `/partner/api/v2/productSearch/update/mfid`,
        "PUT",
       payload,
        (response) => {
          console.log("handleAssignCharges API response:", response);
          setFormData(response);
          toastr.success("Success", "MFID Updated ");
          navigate(-1);
        },
        (err) => {
          console.log(" handleAssignCharges err refund api ", err.message);
          toastr.error(`${   "Error",err.status.message}`, {
            position: "top-right",
            autoClose: 1000,
          });
        }
      );
    } catch (err) {
      console.log("Error assigning charges:", err);
    }
  };


  return (
    <>
      <UpdateMfidFormComponent
        formData={formData}
        // handleChange={handleChange}
        handleUpdateMfidApi={handleUpdateMfidApi}
        setFormData={setFormData}
        dropdownData={dropdownData}
        vandorListData={vandorListData}
        filteredVendorList={filteredVendorList}
        handleSearch={handleSearch}
        loading={loading} 
        mfidDetailsData={mfidDetailsData}
      />
    </>
  );
};

function mapStateToProps(state) {
  return {
    props: state,
  };
}

export default connect(mapStateToProps, { getDataFromAPI })(UpdateMfidContainer);
