import React, { useState } from "react";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import "./style.css";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import LoadingSpinner from "../../../Loading/component";
import { Link, useNavigate } from "react-router-dom";
import leftArrow from "../../../../assests/leftArrow.svg";
import search from "../../../../assests/search.svg";
import Modal from "@mui/material/Modal";
import Table from "react-bootstrap/Table";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 1390,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

const MfidFormComponent = (props) => {
  const [selectedVendor, setSelectedVendor] = useState({ id: "", name: "" });
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleClose = () => setOpen(false);
  const handleOpen = () => {
    console.log("openmodal");
    setOpen(true);
  };
  const goback = () => {
    navigate(-1);
  };
  const handleClick = () => {
    navigate(-1);
  };

  const handleCreateNewVendor = ()=>{
    navigate("/home/configuration/productsvariantdetails/createnewvendor");

  }
  const handleVendorSelect = (vendor) => {
    setSelectedVendor({ id: vendor.id, name: vendor.name });
    props.setFormDataMfids((prevState) => ({
      ...prevState,
      manufacturerId: vendor.id,
      vendorName: vendor.name, 
    }));
   
  };

  const handlePurchaseTypeChange = (event) => {
    const { value } = event.target;
    const selectedType = props.dropdownData.find((item) => item.id === value);
    props.setFormDataMfids((prevState) => ({
      ...prevState,
      zohoItemTypeId: value,
      zohoItemTypeName: selectedType ? selectedType.name : "",
    }));
  };

  return (
    <>
      <div className="main-div" style={{ margin: "auto" }}>
        <div>
          <Sidebar />
        </div>

        {props.loading ? (
          <LoadingSpinner />
        ) : (
          <div>
            <div>
              <h2 style={{ width: "360px", margin: "32px" }}>
                <img
                  onClick={handleClick}
                  style={{ width: "22px", cursor: "pointer" }}
                  src={leftArrow}
                  alt=""
                />{" "}
                Create New MFID
              </h2>
            </div>

            <div
              style={{
                backgroundColor: "#fff",
                height: "779px",
                position: "relative",
                width: "1300px",
                bottom: "70px",
                left: "40px",
                borderRadius: "15px",
              }}
            >
              <Box
                component="form"
                sx={{
                  width: 590,
                  margin: " 80px",
                  padding: 4,
                  borderRadius: 2,
                  backgroundColor: "#fff",
                }}
              >
                <FormControl fullWidth margin="normal">
                  <InputLabel>Purchase Type</InputLabel>
                  <Select
                    name="zohoItemTypeId"
                    value={props.formDataMfids?.zohoItemTypeId || ""}
                    onChange={handlePurchaseTypeChange}
                    label="Purchase Type"
                  >
                    <MenuItem value="">Select Purchase Type</MenuItem>
                    {props.dropdownData &&
                      props.dropdownData.map((item) => (
                        <MenuItem key={item.id} value={item.id}>
                          {item.name}
                        </MenuItem>
                      ))}
                  </Select>
                </FormControl>

                <div>
                  <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                  >
                    <Box sx={style}>
                      <div>
                        <div
                          style={{
                            marginLeft: "42px",
                            marginTop: "20px",
                            display: "flex",
                          }}
                        >
                          <img
                            onClick={goback}
                            style={{
                              width: "22px",
                              cursor: "pointer",
                              marginLeft: "14px",
                            }}
                            src={leftArrow}
                            alt=""
                          />
                          <h2 style={{ marginLeft: "10px" }}>Search Vendor</h2>
                        </div>
                        <div className="cohortsec">
                          <div style={{ width: "100%" }}>
                            <div className="searchDivision">
                              <input
                                type="search"
                                placeholder="Search by Vendor Name/ID"
                                onChange={(e) =>
                                  props.handleSearch(e.target.value)
                                }
                              />
                              <img
                                className="cohortupdatesearchIcon1"
                                src={search}
                                alt=""
                              />
                              <div
                                style={{
                                  position: "absolute",
                                  left: "1100px",
                                  top: "100px",
                                }}
                              >
                                <Button
                                  variant="contained"
                                  //  onClick={handleCreateNewVendor}
                                >
                                  Create New Vendor
                                </Button>
                              </div>
                            </div>

                            <div
                              style={{
                                padding: "14px",
                                borderRadius: "14px",
                              }}
                            >
                              <Table striped className="scrolldown">
                                <thead>
                                  <tr style={{ border: "none" }}>
                                    <th>ID</th>
                                    <th>Vendor Name</th>
                                    <th>Phone Number</th>
                                    <th>Email ID</th>
                                    <th></th>
                                  </tr>
                                </thead>

                                <tbody style={{ position: "relative" }}>
                                  {props.filteredVendorList &&
                                    props.filteredVendorList.length > 0 &&
                                    props.filteredVendorList.map((el) => (
                                      <tr key={el.id}>
                                        <td style={{ textAlign: "left" }}>
                                          {el.id}
                                        </td>
                                        <td style={{ textAlign: "" }}>
                                          {el.name}
                                        </td>
                                        <td style={{ textAlign: "left" }}>
                                          {el.phoneNumber}
                                        </td>
                                        <td
                                          style={{ textAlign: "left" }}
                                          className="ctypes"
                                        >
                                          {el.email}
                                        </td>
                                        <td>
                                          <input
                                            id={el.id}
                                            style={{
                                              height: "18px",
                                              width: "30px",
                                              marginLeft: "20px",
                                            }}
                                            type="radio"
                                            onChange={() =>
                                              handleVendorSelect(el)
                                            }
                                            checked={
                                              selectedVendor.id === el.id
                                            }
                                          />
                                        </td>
                                      </tr>
                                    ))}
                                </tbody>
                              </Table>
                            </div>
                          </div>
                          <Box className="usersrolebtnCohort">
                            <Button
                              className="backbtncohort"
                              style={{ color: "black !important" }}
                            >
                              Back
                            </Button>
                            <Button
                              className="savebtnupdate"
                              onClick={handleClose}
                            >
                              Save
                            </Button>
                          </Box>
                        </div>
                      </div>
                    </Box>
                  </Modal>
                </div>

                <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                  <TextField
                    fullWidth
                    name="vendorName"
                    value={selectedVendor.name}
                    InputProps={{
                      readOnly: true,
                    }}
                    label="Vendor Name"
                    sx={{ flexGrow: 1, mr: 1 }}
                  />
                  <Button variant="outlined" onClick={handleOpen}>
                    Select Vendor
                  </Button>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <TextField
                    fullWidth
                    name="vendorPrice"
                    value={props.formDataMfids?.vendorPrice || ""}
                    onChange={props.handleChangeCreateMfids}
                    label="Purchase Price"
                    type="number"
                    margin="normal"
                    placeholder="Example: ₹ 6"
                  />
                  <TextField
                    fullWidth
                    name="mrp"
                    value={props.formDataMfids?.mrp || ""}
                    onChange={props.handleChangeCreateMfids}
                    label="M.R.P"
                    type="number"
                    margin="normal"
                    placeholder="Example: ₹ 6"
                    style={{ marginLeft: "10px" }}
                  />
                </Box>

                <TextField
                  fullWidth
                  name="offerPrice"
                  value={props.formDataMfids?.offerPrice || ""}
                  onChange={props.handleChangeCreateMfids}
                  label="Selling Price"
                  type="number"
                  margin="normal"
                  placeholder="Example: ₹ 6"
                />

                <Box className="usersrolebtnCohort">
                  <Button className="MfidCancelBtn" onClick={goback}>
                    Cancel
                  </Button>
                  <Button
                    className="savebtnupdate"
                    onClick={props.handleCreateMfidApi}
                  >
                    Save
                  </Button>
                </Box>
              </Box>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default MfidFormComponent;
