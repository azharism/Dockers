

import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import {  toast } from "react-toastify";


import "react-toastify/dist/ReactToastify.css";
import MfidFormComponent from "./component";
import CreateVendorComponent from "../CreateVendorComp/component";



const CreateMfidContainer = (props) => {
 const {variantId}= useParams()
 console.log("variantID", variantId)
 const [dropdownData,setDropdownData] = useState([])
 const [vandorListData, setVandorListData] = useState([])
 const [filteredVendorList, setFilteredVendorList] = useState([]);

  const navigate = useNavigate();
   const [formDataMfids, setFormDataMfids] = useState({
    zohoItemTypeId: '',
    manufacturerId: '',
    vendorPrice: '',
    mrp: '',
    offerPrice: '',
    variantId:variantId,
  });

 const handleChangeCreateMfids = (event) => {
    const { name, value } = event.target;
    setFormDataMfids((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

useEffect(()=>{
    handleGetDropdownItemApi()
},[])

  const handleGetDropdownItemApi = () => {
  return props.getDataFromAPI(
    `/dashboard/api/v2/admin/form/dropdowns`,
    "GET",
    undefined,
    (response) => {
     
      console.log("handleAPi---mfid",response.itemTypes)
      setDropdownData(response.itemTypes)
   
     

      console.log("response---------> order", response);
    },
    (err) => {},
    true
  );
};

useEffect(()=>{
handleGetVandorListApi()
},[])
  const handleGetVandorListApi = () => {
    return props.getDataFromAPI(
      `/dashboard/api/v5/vendors/all`,
      "GET",
      undefined,
      (response) => {
        setVandorListData(response);
        setFilteredVendorList(response);
      },
      (err) => {},
      true
    );
  };

  const handleSearch = (searchTerm) => {
    const lowercasedTerm = searchTerm.toLowerCase();
    const filteredList = vandorListData.filter(vendor => 
      vendor.name.toLowerCase().includes(lowercasedTerm) || 
      vendor.id.toString().includes(lowercasedTerm)
    );
    setFilteredVendorList(filteredList);
  }; 

   
 const handleCreateMfidApi = async () => {
  
   const payload = {
      zohoItemTypeId: formDataMfids.zohoItemTypeId,
      manufacturerId: formDataMfids.manufacturerId,
      variantId: formDataMfids.variantId,
      mrp: formDataMfids.mrp,
      offerPrice: formDataMfids.offerPrice,
      vendorPrice: formDataMfids.vendorPrice,
    };

  try {
    const response = await props.getDataFromAPI(
      `/partner/api/v2/productSearch/create/mfid`,
      "POST",
      payload,
      (response) => {
        console.log("handleCretateMfidApi API response:", response);
        setFormDataMfids(response);
        toastr.success("Success","MFID Created ");
        navigate(-1)
      },
      (err) => {
        console.log(" handleAssignCharges err  api ", err.status.message);
        toastr.error(`${err.status.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
    );
  } catch (err) {
    console.log("Error assigning charges:", err);
  }
};


  return (
    <>
      <MfidFormComponent
      formDataMfids={formDataMfids}
      handleChangeCreateMfids={handleChangeCreateMfids}
      handleCreateMfidApi={handleCreateMfidApi}
      setFormDataMfids={setFormDataMfids}
      dropdownData={dropdownData}
      vandorListData={vandorListData}
      filteredVendorList={filteredVendorList}
      handleSearch={handleSearch}
      
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}

export default connect(mapStateToProps, {
  getDataFromAPI,
  
})(CreateMfidContainer);
