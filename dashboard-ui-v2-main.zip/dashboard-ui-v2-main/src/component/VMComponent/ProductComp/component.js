import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";
import "./global.css";
import styles from "./Frame.module.css";
import search from "../../../assests/search.svg";
import leftArrow from "../../../assests/leftArrow.svg";
import emotions7 from "../../../assests/emotions7.svg";
import mingcute_eye from "../../../assests/mingcute_eye.svg";
import LoadingSpinner from "../../Loading/component";
import Sidebar from "../../Navigation/Sidebar/Sidebar";

const ProductsListComp = (props) => {
  const { variantId } = useParams();
  const navigate = useNavigate();
  const [showAllBrands, setShowAllBrands] = useState(false);
  const [showAllProducts, setShowAllProducts] = useState(false);
  const [selectedOption, setSelectedOption] = useState("");
  const [showEyeIcon, setShowEyeIcon] = useState(false);
  // const [initialSearch, setInitialSearch] = useState(true);

  const handleVariantDetails = (variantId) => {
    navigate(`/home/configuration/productsvariantdetails/${variantId}`);
  };

  const handleMouseEnter = () => {
    setShowEyeIcon(true);
  };

  const handleMouseLeave = () => {
    setShowEyeIcon(false);
  };

  useEffect(() => {
    if (selectedOption) {
      const sortedList = [...props.filteredItemList].sort((a, b) => {
        if (selectedOption === "asc") {
          return a.variantName.localeCompare(b.variantName);
        } else if (selectedOption === "desc") {
          return b.variantName.localeCompare(a.variantName);
        }
        return 0;
      });
      props.setFilteredItemList(sortedList);
    }
  }, [selectedOption]);

  const handleSortChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const arrowClick = () => {
    navigate("/");
  };

  const toggleBrands = () => {
    setShowAllBrands(!showAllBrands);
  };

  const toggleProducts = () => {
    setShowAllProducts(!showAllProducts);
  };

  return (
    <>
      <div className={styles.div}>
        <div>
          <input className={styles.icon} type="search" />
        </div>
        <div className={styles.item} />
        <div className={styles.frameParent}>
          {props.initialSearch ? (
            <div
              style={{
                margin: "auto",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                width: "1200px",
                height: "80vh",
              }}
            >
              <p
                style={{
                  color: "var(--color-darkslategray-100)",
                  fontWeight: "500",
                  fontSize: "22px",
                }}
              >
                Please search for a product.
              </p>
            </div>
          ) : (
            <>
              {props.loading ? (
                <CircularProgress
                  style={{ position: "relative", left: "500px", top: "300px" }}
                />
              ) : (
                <div className={styles.componentParent}>
                  {props.hasFilteredItems ? (
                    props.filteredItemList.map((item) => (
                      <div
                        key={item.variantId}
                        className={styles.rectangleParent}
                        onMouseEnter={handleMouseEnter}
                        onMouseLeave={handleMouseLeave}
                        onClick={() => handleVariantDetails(item.variantId)}
                      >
                        {item.variantImages &&
                          item.variantImages.length > 0 && (
                            <img
                              className={styles.componentChild}
                              alt="No image Available"
                              src={`https://s3.ap-south-1.amazonaws.com/daalchini/dcprod/${item.variantImages[0].imageId}`}
                            />
                          )}
                        <div className={styles.eyeIconContainer}>
                          <img
                            src={mingcute_eye}
                            alt="eyeicon"
                            className={styles.eyeIcon}
                            style={{
                              visibility: showEyeIcon ? "visible" : "hidden",
                            }}
                          />
                        </div>
                        <div
                          className={styles.britanniaBritanniaFruitContainer}
                        >
                          <span
                            className={styles.britanniaBritanniaFruitContainer1}
                          >
                            <p className={styles.britannia}>
                              <span className={styles.britannia1}>
                                <b>{item.brandName}</b>
                              </span>
                            </p>
                            <p className={styles.britannia}>
                              <span className={styles.britannia1}>
                                <span className={styles.britanniaFruit}>
                                  {item.productName}
                                </span>
                              </span>
                            </p>
                            <p className={styles.britannia}>
                              <span className={styles.britannia1}>
                                <span>{item.variantName}</span>
                              </span>
                            </p>
                            <p className={styles.mrpNa}>
                              <span className={styles.mrp501}>
                                {`M.R.P - N/A                           `}
                              </span>
                              <b className={styles.b}>{`   `}</b>
                              <span className={styles.id98989}>
                                {" "}
                                ID - {item.variantId}
                              </span>
                            </p>
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="noVMFound">
                        <div>
                          <img className="noOrderImg" src={emotions7} alt="" />
                          <p className="noOrderPara">No Product Found</p>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
            </>
          )}
        </div>
        <div className={styles.groupParent}>
          <div className={styles.productSearchParent}>
            <div className={styles.productSearch}>Product Search</div>
            <img
              className={styles.groupChild}
              alt=""
              src={leftArrow}
              onClick={arrowClick}
            />
          </div>

          <div className={styles.groupDiv}>
            <input
              className={styles.groupItem}
              type="search"
              placeholder="Search by Brand name, Product name, or Variant name"
              value={props.searchQuery}
              onChange={(e) => {
                props.handleSearchChange(e);
                props.setInitialSearch(false);
              }}
              onKeyPress={props.handleKeyPress}
            />
            <img
              className={styles.icroundSearchIcon}
              alt=""
              src={search}
              onClick={() => {
                props.handleSearchItemList();
                props.setInitialSearch(false);
              }}
            />
          </div>

          {!props.isSearchEmpty && (
            <div>
              <div>
                <select
                  aria-label="Sort by"
                  name="Sort BY"
                  style={{ color: "blue" }}
                  className={styles.sortByParent}
                  value={props.selectedOption}
                  onChange={handleSortChange}
                >
                  <option value="">Sort by</option>
                  <option value="asc">A to Z</option>
                  <option value="desc">Z to A</option>
                </select>
              </div>
            </div>
          )}
        </div>
        {!props.isSearchEmpty && (
          <div className={styles.inner}>
            <div className={styles.frameGroup}>
              <div className={styles.frameContainer}>
                <div>
                  <div className={styles.brandsParent}>
                    <div className={styles.brands}>BRANDS</div>

                    {showAllBrands ? (
                      <>
                        {props.brandList &&
                          props.brandList.map((brand, index) => (
                            <div key={index} className={styles.britanniaParent}>
                              <div className={styles.biscuits}>
                                {brand.brandName}
                              </div>
                              <input
                                type="checkbox"
                                variant="success"
                                className={styles.icon}
                                checked={
                                  props.selectedBrands &&
                                  props.selectedBrands.includes(brand.brandName)
                                }
                                onChange={() =>
                                  props.handleBrandCheckboxChange(
                                    brand.brandName
                                  )
                                }
                              />
                            </div>
                          ))}
                      </>
                    ) : (
                      <>
                        {props.brandList &&
                          props.brandList.slice(0, 4).map((brand, index) => (
                            <div key={index} className={styles.britanniaParent}>
                              <div className={styles.biscuits}>
                                {brand.brandName}
                              </div>
                              <input
                                type="checkbox"
                                variant="success"
                                className={styles.icon}
                                checked={
                                  props.selectedBrands &&
                                  props.selectedBrands.includes(brand.brandName)
                                }
                                onChange={() =>
                                  props.handleBrandCheckboxChange(
                                    brand.brandName
                                  )
                                }
                              />
                            </div>
                          ))}
                      </>
                    )}

                    <div className={styles.viewLessWrapper}>
                      <div className={styles.viewLess} onClick={toggleBrands}>
                        {showAllBrands ? "View Less" : "View More"}
                      </div>
                    </div>
                  </div>
                </div>

                <>
                  <div className={styles.brandsParent}>
                    <div className={styles.brands}>Products</div>

                    {showAllProducts ? (
                      <>
                        {props.productList.map((products, index) => (
                          <div key={index} className={styles.britanniaParent}>
                            <div className={styles.biscuits}>
                              {products.productName}
                            </div>
                            <input
                              type="checkbox"
                              variant="success"
                              className={styles.icon}
                              checked={
                                props.selectedProducts &&
                                props.selectedProducts.includes(
                                  products.productName
                                )
                              }
                              onChange={() =>
                                props.handleProductCheckboxChange(
                                  products.productName
                                )
                              }
                            />
                          </div>
                        ))}
                      </>
                    ) : (
                      <>
                        {props.productList
                          .slice(0, 4)
                          .map((products, index) => (
                            <div key={index} className={styles.britanniaParent}>
                              <div className={styles.biscuits}>
                                {products.productName}
                              </div>
                              <input
                                type="checkbox"
                                variant="success"
                                className={styles.icon}
                                checked={
                                  props.selectedProducts &&
                                  props.selectedProducts.includes(
                                    products.productName
                                  )
                                }
                                onChange={() =>
                                  props.handleProductCheckboxChange(
                                    products.productName
                                  )
                                }
                              />
                            </div>
                          ))}
                      </>
                    )}

                    <div className={styles.viewLessWrapper}>
                      <div className={styles.viewLess} onClick={toggleProducts}>
                        {showAllProducts ? "View Less" : "View More"}
                      </div>
                    </div>
                  </div>
                </>

                <div className={styles.brandsParent}>
                  <div className={styles.brands}>Status</div>
                  <div className={styles.britanniaParent}>
                    <div className={styles.biscuits}>All</div>
                    <input
                      type="radio"
                      className={styles.icon}
                      value="All"
                      checked={props.selectedStatus === "All"}
                      onChange={() => props.handleStatusChange("All")}
                    />
                  </div>
                  <div className={styles.britanniaParent}>
                    <div className={styles.biscuits}>Active</div>
                    <input
                      type="radio"
                      className={styles.icon}
                      value="Active"
                      checked={props.selectedStatus === "Active"}
                      onChange={() => props.handleStatusChange("Active")}
                    />
                  </div>
                  <div className={styles.example4Parent}>
                    <div className={styles.chocolates}>Inactive</div>
                    <input
                      type="radio"
                      className={styles.icon}
                      value="Inactive"
                      checked={props.selectedStatus === "Inactive"}
                      onChange={() => props.handleStatusChange("Inactive")}
                    />
                  </div>
                </div>
              </div>
              <div className={styles.rectangleDiv} />
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default ProductsListComp;
