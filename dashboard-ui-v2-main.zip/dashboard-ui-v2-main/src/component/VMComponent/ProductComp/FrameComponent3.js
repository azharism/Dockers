import styles from "./FrameComponent3.module.css";

const FrameComponent = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.componentChild} />
      <div className={styles.componentItem} />
      <b className={styles.aToZ}>A to Z</b>
      <b className={styles.zToA}>Z to A</b>
    </div>
  );
};

export default FrameComponent;
