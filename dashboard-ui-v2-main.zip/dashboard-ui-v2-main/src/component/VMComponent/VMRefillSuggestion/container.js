import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";

import { toastr } from "react-redux-toastr";
import VMRsuggestionComponent from "./component";

const VMRsuggestionContainer = (props) => {
  const [anchorEl, setAnchorEl] = useState(null);
  // const [selectedOption, setSelectedOption] = useState(null);
  const [refillSuggestionData, setRefillSuggestionData] = useState([]);

  const [editableRow, setEditableRow] = useState(null);
  // const [selectedCheckboxes, setSelectedCheckboxes] = useState([]);
  const [showAdditionalCheckbox, setShowAdditionalCheckbox] = useState(false);
  const [isNewRowOpen, setIsNewRowOpen] = useState([]);
  const [selectedMachineId, setSelectedMachineId] = useState(null);
  const [selectedCheckboxes, setSelectedCheckboxes] = useState(["URGENT", "HIGH", "MEDIUM", "LOW"]);
const [selectedOption, setSelectedOption] = useState("1");
const [filteredData, setFilteredData] = useState([]); 

const [loading, setLoading] = useState(true);

  // const [filteredData, setFilteredData] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [warehouseData, setWarehouseData] = useState([]);
  const [buttonLabel, setButtonLabel] = useState("");
  const [isLoading, setIsLoading] = useState(true); 
  const handleEyeIconClick = (machineId) => {
    setSelectedMachineId((prevMachineId) =>
      prevMachineId === machineId ? null : machineId
    );
  };

  const handleEditClick = (index) => {
    setEditableRow(index);
  };

  const handleSaveClick = () => {
    setEditableRow(null);
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOptionClick = (warehouseId, warehouseName) => {
    setSelectedOption(warehouseId);
    setButtonLabel(warehouseName);
  
  
    handleVMRefillSuggestion(warehouseId, selectedCheckboxes);
  
    handleClose();
  };
  
  

  const tableContainerRef = useRef(null);

useEffect(() => {
  const handleScroll = () => {
    const container = tableContainerRef.current;
    if (container) {
      const { scrollTop, clientHeight, scrollHeight } = container;
      if (scrollTop + clientHeight >= scrollHeight) {
       
        container.scrollTo({  behavior: 'smooth' });
      }
    }
  };

  const container = tableContainerRef.current;
  if (container) {
    container.addEventListener("scroll", handleScroll);
  }

  return () => {
    if (container) {
      container.removeEventListener("scroll", handleScroll);
    }
  };
}, []);


  const handleSearchInputChange = (e) => {
    setSearchValue(e.target.value);
    filterData();
  };

  const handleSearchIconClick = () => {
    filterData();
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      filterData();
    }
  };
  const handleVMRefillSuggestion = (warehouseId) => {
    
    const priorityParam = warehouseId ? "all" : "URGENT,HIGH,MEDIUM,LOW";
  
    props.getDataFromAPI(
      `/partner/api/v1/refill/suggestion?warehouseId=${warehouseId}&priority=${priorityParam}`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        setRefillSuggestionData(response);
  
       
        const filteredDataWithCheckboxes = response.filter((item) =>
          selectedCheckboxes.includes(item.priority)
        );
  
       
        setFilteredData(filteredDataWithCheckboxes);
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch refill suggestion listing");
      }
    );
  };
  
  
  
  
  
  
  

   useEffect(() => {
    if (selectedOption) {
      handleVMRefillSuggestion(selectedOption);
    } else {
      
      if (warehouseData.length > 0) {
        handleVMRefillSuggestion(warehouseData[0].warehouseId);
      }
    }
  }, [selectedOption, warehouseData]);

  useEffect(() => {
    
    handleVMRefillSuggestion(selectedOption, selectedCheckboxes);
  }, [selectedOption, selectedCheckboxes]); 
  
  
  

  useEffect(() => {
    filterData();
  }, [selectedCheckboxes, searchValue, refillSuggestionData]);

  const filterData = () => {
    const trimmedSearchValue = searchValue.trim().toLowerCase();
  
    let filteredDataWithCheckboxes = refillSuggestionData.filter((item) =>
      selectedCheckboxes.includes(item.priority)
    );
  
    if (trimmedSearchValue === "") {
      setFilteredData(filteredDataWithCheckboxes);
    } else {
      const filteredDataWithSearch = filteredDataWithCheckboxes.filter((item) => {
        return (
          item.machineName.toLowerCase().includes(trimmedSearchValue) ||
          item.machineId.toString().includes(trimmedSearchValue)
        );
      });
      setFilteredData(filteredDataWithSearch);
    }
  };
  

  const handleCheckboxChange = (event, checkboxValue) => {
    const isChecked = event.target.checked;
  
    let updatedSelectedCheckboxes;
  
    if (isChecked) {
      updatedSelectedCheckboxes = [...selectedCheckboxes, checkboxValue];
    } else {
      updatedSelectedCheckboxes = selectedCheckboxes.filter(
        (checkbox) => checkbox !== checkboxValue
      );
    }
  
    setSelectedCheckboxes(updatedSelectedCheckboxes);
  
   
    const filteredDataWithCheckboxes = refillSuggestionData.filter((item) =>
      updatedSelectedCheckboxes.includes(item.priority)
    );
  
    
    setFilteredData(filteredDataWithCheckboxes);
  };
  
  
  


  useEffect(() => {
    brandWarehouseApi();
  }, []);

  const brandWarehouseApi = () => {
    props.getDataFromAPI(
      "/partner/api/v2/warehouse/list",
      "GET",
      undefined,
      (response) => {
        console.log("warehouseData:", response);
        setWarehouseData(response);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch Brand category listing");
      }
    );
  };


  const getPriorityClassName = (priority) => {
    switch (priority) {
      case "URGENT":
        return "urgent-priority";
      case "HIGH":
        return "high-priority";
      case "MEDIUM":
        return "medium-priority";
      case "LOW":
        return "low-priority";
      default:
        return "";
    }
  };

  

  return (
    <>
      <VMRsuggestionComponent
        handleClick={handleClick}
        handleClose={handleClose}
        anchorEl={anchorEl}
        selectedOption={selectedOption}
        handleOptionClick={handleOptionClick}
        refillSuggestionData={refillSuggestionData}
        editableRow={editableRow}
        handleEditClick={handleEditClick}
        handleSaveClick={handleSaveClick}
        // handleInputChange={handleInputChange}
        tableContainerRef={tableContainerRef}
        handleCheckboxChange={handleCheckboxChange}
        setShowAdditionalCheckbox={setShowAdditionalCheckbox}
        selectedCheckboxes={selectedCheckboxes}
        showAdditionalCheckbox={showAdditionalCheckbox}
        handleSearchInputChange={handleSearchInputChange}
        handleSearchIconClick={handleSearchIconClick}
        searchValue={searchValue}
        handleEyeIconClick={handleEyeIconClick}
        isNewRowOpen={isNewRowOpen}
        selectedMachineId={selectedMachineId}
        filteredData={filteredData}
        handleKeyPress={handleKeyPress}
        getPriorityClassName={getPriorityClassName}
        warehouseData={warehouseData}
        buttonLabel={buttonLabel}
        loading={loading}
       
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(VMRsuggestionContainer);
