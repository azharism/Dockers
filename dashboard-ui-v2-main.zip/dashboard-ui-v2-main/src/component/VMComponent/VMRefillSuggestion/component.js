import React, { Component, useEffect, useState, useRef } from "react";
import "./style.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import Table from "react-bootstrap/Table";
import refillEye from "../../../assests/refillEye.svg";
import search from "../../../assests/search.svg";
import crossEye from "../../../assests/crossEye.svg";
import minus from "../../../assests/minus.svg";
import emotions7 from "../../../assests/emotions7.svg";
import Button from "@mui/material/Button";
import FilterListIcon from "@mui/icons-material/FilterList";
import { Menu, MenuItem } from "@mui/material";
import LoadingSpinner from "../../Loading/component";

const VMRsuggestionComponent = (props) => {
  const [isTableExtended, setTableExtended] = useState(false);

  const handleEyeIconClick = () => {
    setTableExtended(!isTableExtended);
  };

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };

  return (
    <>
     {props.loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
<div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Refill Suggestion
          </h2>
        </div>
        <div style={{ display: "flex", justifyContent: "end" }}></div>
        <div className="vmtablebrand1">
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <div className="vmsearchdiv">
              <div className="input-container">
                <input
                  type="search"
                  placeholder="Search by VM Name/ VM ID"
                  value={props.searchValue}
                  onChange={props.handleSearchInputChange}
                  onKeyPress={props.handleKeyPress}
                />
                <button
                  className="search-icon"
                  onClick={props.handleSearchIconClick}
                >
                  <img src={search} alt="" />
                </button>
              </div>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "flex-start",
                margin: "auto",
                flexDirection: "row",
              }}
            >
        
              <input
                style={{
                  backgroundColor: "blue",
                  color: "red ",
                  height: "22px",
                  width: "20px",
                  marginTop: "22px",
                }}
                type="checkbox"
                value="URGENT"
                checked={props.selectedCheckboxes.includes("URGENT")}
                onChange={(event) => props.handleCheckboxChange(event, "URGENT")}
                ref={(input) => {
                  if (input) {
                    input.indeterminate =
                      !props.selectedCheckboxes.includes("URGENT");
                    input.style.setProperty("--checkbox-color", "white");
                    input.style.setProperty("--checkbox-background", "blue");
                  }
                }}
              />

              <p
                style={{ margin: "16px", color: "#B30000", marginTop: "20px" }}
              >
                Urgent
              </p>

              <input
                style={{
                  backgroundColor: "blue",
                  color: "red ",
                  height: "22px",
                  width: "20px",
                  marginTop: "22px",
                }}
                type="checkbox"
                value="HIGH"
                checked={props.selectedCheckboxes.includes("HIGH")}
                onChange={(event) => props.handleCheckboxChange(event, "HIGH")}
                ref={(input) => {
                  if (input) {
                    input.indeterminate =
                      !props.selectedCheckboxes.includes("HIGH");
                    input.style.setProperty("--checkbox-color", "white");
                    input.style.setProperty("--checkbox-background", "blue");
                  }
                }}
              />
              <p
                style={{ margin: "16px", color: "#B70079", marginTop: "20px" }}
              >
                High
              </p>
              <input
                style={{
                  backgroundColor: "blue",
                  color: "red ",
                  height: "22px",
                  width: "20px",
                  marginTop: "22px",
                }}
                type="checkbox"
                value="MEDIUM"
                checked={props.selectedCheckboxes.includes("MEDIUM")}
                onChange={(event) =>
                  props.handleCheckboxChange(event, "MEDIUM")
                }
                ref={(input) => {
                  if (input) {
                    input.indeterminate =
                      !props.selectedCheckboxes.includes("MEDIUM");
                    input.style.setProperty("--checkbox-color", "white");
                    input.style.setProperty("--checkbox-background", "blue");
                  }
                }}
              />
              <p
                style={{ margin: "16px", color: "#713ABA", marginTop: "20px" }}
              >
                Medium
              </p>
              <input
                style={{
                  backgroundColor: "blue",
                  color: "red ",
                  height: "22px",
                  width: "20px",
                  marginTop: "22px",
                }}
                type="checkbox"
                value="LOW"
                checked={props.selectedCheckboxes.includes("LOW")}
                onChange={(event) => props.handleCheckboxChange(event, "LOW")}
                ref={(input) => {
                  if (input) {
                    input.indeterminate =
                      !props.selectedCheckboxes.includes("LOW");
                    input.style.setProperty("--checkbox-color", "white");
                    input.style.setProperty("--checkbox-background", "blue");
                  }
                }}
              />
              <p
                style={{ margin: "16px", color: "#028D4B", marginTop: "20px" }}
              >
                Low
              </p>
            </div>
            <div style={{marginTop:"30px", marginRight:"30px"}}>
            <Button
              variant="contained"
              color="primary"
              startIcon={<FilterListIcon />}
              onClick={props.handleClick}
              style={{ width: "140px" }}
            >
              {props.buttonLabel ||
                (props.warehouseData.length > 0
                  ? props.warehouseData[0].warehouseName
                  : "")}
            </Button>

            <Menu
            className="menuwarehouse"
              anchorEl={props.anchorEl}
              open={Boolean(props.anchorEl)}
              onClose={props.handleClose}
            >
              {props.warehouseData.map((warehouse) => (
                <MenuItem
                  key={warehouse.warehouseId}
                  onClick={() =>
                    props.handleOptionClick(
                      warehouse.warehouseId,
                      warehouse.warehouseName
                    )
                  } 
                >
                  {warehouse.warehouseName}
                </MenuItem>
              ))}
            </Menu>
          </div>
          </div>
         
         
     

          <div
            ref={props.tableContainerRef}
            className="tableContainer"
            style={{
              height: "790px",
              overflow: "auto",
              margin: "auto",
              padding: "20px",
              width: "100%",
            }}
          >
            <Table striped hover>
              <thead>
                <tr
                  style={{
                    borderTop: "1px solid #ccc",
                    position: "relative",
                    top: "-30px",
                  }}
                >
                  <th>VM ID</th>
                  <th>VM Name</th>
                  <th>Urgency Score</th>
                  <th>Urgency Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {props.filteredData && props.filteredData.length > 0 ? (
                  props.filteredData.map((item) => (
                    <React.Fragment key={item.machineId}>
                      <tr className="rowColor">
                        <td>{item.machineId}</td>
                        <td>{item.machineName}</td>
                        <td>{item.urgencyScore}</td>
                        <td>
                          <span
                            className={props.getPriorityClassName(
                              item.priority
                            )}
                          >
                            {item.priority}
                          </span>
                        </td>

                        <td className="eyeIcon1">
                    
                          <img
                            src={
                              props.selectedMachineId === item.machineId
                                ? crossEye
                                : refillEye
                            }
                            alt=""
                            onClick={() =>
                              props.handleEyeIconClick(item.machineId)
                            }
                          />
                        </td>
                      </tr>

                      {props.selectedMachineId === item.machineId && (
                        <tr>
                          <td
                            colSpan="5"
                            style={{
                              backgroundColor: "white",
                              boxShadow: "1px 12px 13px 0px #ccc",
                            }}
                          >
                            <div
                              style={{
                                width: "100%",
                                backgroundColor: "white",
                              }}
                            >
                              <div
                                className="newLayout"
                                style={{
                                  display: "flex",
                                  justifyContent: "space-between",
                                  padding: "10px",
                                }}
                              >
                                <div className="machineAddress">
                                  Address:{" "}
                                  <p className="machineaddContent">
                                    {item.machineAddress}
                                  </p>{" "}
                                </div>
                                <div className="machineAddress">
                                  Last Refilled:{" "}
                                  <p className="machineaddContent">
                                    {item.lastRefilled}
                                  </p>{" "}
                                </div>
                                <div className="machineAddress">
                                  Weekday Average Sale:{" "}
                                  <p className="machineaddContent">
                                    {item.weeklyAverageSales}
                                  </p>
                                </div>
                                <div className="machineAddress">
                                  Non Empty Coil:{" "}
                                  <p className="machineaddContent">
                                    {" "}
                                    {item.nonEmptyRatio}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))
                ) : (
                  <>
                    <div className="noVMFound">
                      <div>
                        <img className="noOrderImg" src={emotions7} alt="" />
                        <p className="noOrderPara">No VM Found</p>
                      </div>
                    </div>
                  </>
                )}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
    )}
    </>
    
  );
};

export default VMRsuggestionComponent;
