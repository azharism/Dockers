import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import SingingContract from "../../../assests/SingingContract.svg";
import { Button, Box, TextField } from "@mui/material";
import leftArrow from "../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";

export const OrderRefundComponent = ({
 
  refundOrderId,
  
  refundOrderAmount,
  handleRefundOrderAmount,
  
  orderRefundApi,
 
  handleKeyPress,
  
  handleRefundReason,
  refundReason,
 
}) => {
//   console.log("console props", props);
// console.log("handleclcickckckcc ", handleRefundClick)
  const navigate = useNavigate();
  const handleClick = () => {
    navigate(-1);
  };
 
  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Bank Refund
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
            <div className="inputDiv">
              <Box
                sx={{
                  width: 500,
                  maxWidth: "100%",
                  
                  alignItems: "center",
                }}
              >
                {/* <TextField
                  style={{ margin: "18px", padding: "0px", color: "#b2b2b2" }}
                  fullWidth
                  label="Enter Order Id"
                  id="fullWidth"
                  value={refundOrderId}
                  onChange={handleRefundOrderId}
                  onKeyPress={handleKeyPress}
                  
                /> */}
 
                <TextField
                  style={{ margin: "18px", padding: "0px", color: "#b2b2b2" }}
                  fullWidth
                  label="Enter Refund Amount"
                  id="fullWidth"
                  type="number"
                  value={refundOrderAmount}
                  onChange={handleRefundOrderAmount}
                  onKeyPress={handleKeyPress}
                  autoComplete="off"
                />
                 <TextField
                  style={{ margin: "18px", padding: "0px", color: "#b2b2b2" }}
                  fullWidth
                  label="Reason for Refund"
                  id="fullWidth"
                  type="text"
                  value={refundReason}
                  onChange={handleRefundReason}
                  onKeyPress={handleKeyPress}
                  autoComplete="off"
                />
              </Box>

              <Box className="usersrolebtn">
                <Button
                  fullWidth
                  className="refundBtn"
                  variant="outlined"
                  onClick={orderRefundApi}
                  
                >
                  Refund
                </Button>
              </Box>
            </div>
            <div style={{ margin: "auto",width:"50%", height:"50%"  }}>
              <img style={{width:"100%", height:"100%"}} src={SingingContract} alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
