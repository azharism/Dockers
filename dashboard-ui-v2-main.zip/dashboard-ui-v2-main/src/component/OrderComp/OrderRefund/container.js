

import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import  {OrderRefundComponent}  from "./component";
import { toastr } from "react-redux-toastr";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { setLoading } from "../OrdersList/actions";
import LoadingSpinner from "../../Loading/component";
import { useNavigate,useLocation } from "react-router-dom";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";

const OrdersRefundContainer = (props) => {
  const { orderid } = useParams();
  const navigate = useNavigate();
 
    const [loading, setLoading] = useState(true)
    const [refundOrderId, setRefundOrderId] = useState("");
    const [refundOrderAmount, setRefundOrderAmount] = useState("");
    const [refundReason, setRefundReason] = useState("")
  
console.log("refundOrderId", refundOrderId)

const { pg_name,id } = useParams();
const handleKeyPress = (event) => {
  if (event.key === "Enter") {
    orderRefundApi();
  }
};
  
    const handleRefundOrderId = (e) => {
        console.log("Order ID:", e.target.value);
        setRefundOrderId(e.target.value);
      };
      
      const handleRefundOrderAmount = (e) => {
        console.log("Order Amount:", e.target.value);
        const decimalValue = parseFloat(e.target.value);
        setRefundOrderAmount(decimalValue);
      };
      
      const handleRefundReason = (e) => {
        console.log("Order ID:", e.target.value);
        setRefundReason(e.target.value);
      };
     
      const orderRefundApi = () => {
        if ( !refundOrderAmount) {
          toastr.error("Please Enter All Details to Process the Refund");
          return;
        }
      
        // const isValidOrderId = (orderId) => {
        //   return /^[A-Za-z0-9]+$/.test(orderId);
        // };
      
        const isValidOrderAmount = (amount) => {
          return /^\d+(?:\.\d{0,2})?$/.test(amount);
        };
      
        // if (!isValidOrderId(refundOrderId)) {
        //   toastr.warning("Please enter a valid order ID");
        //   return;
        // }
      
        if (!isValidOrderAmount(refundOrderAmount)) {
          toastr.warning("Please enter a valid refund amount");
          return;
        }
        if (refundReason === "") {
          toastr.warning("Please enter a valid reason to process the Refund");
          return;
        }
      
        
        const payload = {
          pgName: pg_name ,
          orderId: id,
          refundAmount: parseFloat(refundOrderAmount),
          reason: refundReason
        };
       
        props.getDataFromAPI(
          `/partner/api/v1/wallet/bankrefund`,
          "POST",
          payload,
          (response) => {
            console.log("API response:", response);
      
            setRefundOrderId("");
            setRefundOrderAmount("");
            setRefundReason("");
            toastr.success("Refund Processed!");
            navigate(-1);
          },
          (err) => {
            console.log("err refund api ", err.message);
            toastr.error(`${err.message}`, {
              position: toast.POSITION.TOP_RIGHT,
              autoClose: 1000
            });
          }
        );
      };
      
      
      
      
      
   
  return (
    <>
   
  
     <OrderRefundComponent

loading={loading}
orderRefundApi={orderRefundApi}
// refundHandler={refundHandler}
refundOrderId={refundOrderId}
refundOrderAmount={refundOrderAmount}
handleRefundOrderId={handleRefundOrderId}
handleRefundOrderAmount={handleRefundOrderAmount}
handleKeyPress={handleKeyPress}
refundReason={refundReason}
handleRefundReason={handleRefundReason}

   /> 
    </>
  
  )
}

function mapStateToProps({ props }) {
    return {
      props,
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
    setLoading
  })(OrdersRefundContainer);
