import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import profile from "../../../assests/gprofile.svg";
import Avatar from "../../../assests/Avatar.png";
import infoIcon from "../../../assests/infoIcon.svg";
import phone1 from "../../../assests/phone11.svg";
import mail from "../../../assests/mail.svg";
import dateTime from "../../../assests/dateTime.svg";
import city from "../../../assests/city.svg";
import kiosk from "../../../assests/kiosk.svg";
import vm from "../../../assests/vm.svg";
import leftArrow from "../../../assests/leftArrow.svg";
import { useNavigate } from "react-router-dom";
import Table from "react-bootstrap/Table";
import RefundPay from "../../../assests/refundpay.svg";
import itemDetails from "../../../assests/itemDetails.svg";
import refund from "../../../assests/refund.svg";
import success from "../../../assests/success.svg";
import cross from "../../../assests/cross.svg";
// import moment from "moment/moment";
import panding from "../../../assests/panding.svg";
import LoadingSpinner from "../../Loading/component";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import moment from "moment-timezone";
import refillEye from "../../../assests/refillEye.svg";
import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import FormControl from "@mui/material/FormControl";
import cancel from "../../../assests/cancel.svg";
import checkIcon from "../../../assests/checkIcon.svg";
import awaitingIcon from "../../../assests/awaitingIcon.svg";
import Box from "@mui/material/Box";
import failedrefund from "../../../assests/failedrefund.gif";
import refundSucessIcon from "../../../assests/refundSuccessIcon.gif"

const steps = ["Refund Scheduled", "Refund Initiated", "Refund Successful"];

export const OrdersViewComp = ({
  data,
  loading,
  show,
  handleClose,
  handleShow,
  handleSubmit,
  issue,
  handleIssueChange,
  selectedIssue,
  handleIssueTextChange,
  handleCopyInfo,
  orderStatus,
  fetchOrderStatus,
}) => {
  {
    console.log("orderStatusssss--", orderStatus);
  }
  const [pgName, setPgName] = useState("");
  const [orderId, setOrderId] = useState("");
  const [showDetails, setShowDetails] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(null);
  const createdTime = moment(data && data.created_at);
  const currentTime = moment();
  const timeDifferenceInSeconds = currentTime.diff(createdTime, "seconds");
  const initialRemainingTime = Math.max(0, 35 * 60 - timeDifferenceInSeconds);
  const [remainingTime, setRemainingTime] = useState(0);
  const [dialogData, setDialogData] = useState(null);

  const handleOpenStatusModal = (
    orderId,
    refundAmount,
    pgName,
    resultStatus,
    resultMsg
  ) => {
    const selectedRefundItem = {
      orderId: orderId,
      refundAmount: refundAmount,
      pgName: pgName,
      resultStatus: resultStatus,
      resultMsg: resultMsg,
    };

    setDialogData(selectedRefundItem);
    setShowStatusModal(true);

    fetchOrderStatus();
  };

  const handleCloseStatusModal = () => {
    setShowStatusModal(false);
  };

  //  const getActiveStep = (resultMsg) => {
  //    switch (resultMsg) {
  //      case "Refund Successfull":
  //        return steps.length - 1;
  //      case "Refund Schadule":
  //        return 1;
  //      case "Refund Initiated":
  //        return 2;
  //      default:
  //        return 0;
  //    }
  //  };

  const getActiveStep = (resultMsg) => {
    switch (resultMsg) {
      case "Refund Successfull":
        return steps.length;
      case "Refund Schadule":
        return 1;
      case "Refund Initiated":
        return 0;
      default:
        return 0;
    }
  };

  useEffect(() => {
    if (data && data.created_at) {
      const createdTime = moment(data.created_at);
      const currentTime = moment();
      const maxAllowedTimeInSeconds = 35 * 60;
      const timeDifferenceInSeconds = currentTime.diff(createdTime, "seconds");
      const remainingTimeInSeconds =
        maxAllowedTimeInSeconds - timeDifferenceInSeconds;

      if (remainingTimeInSeconds > 0) {
        setRemainingTime(remainingTimeInSeconds);

        const timer = setInterval(() => {
          setRemainingTime((prevRemainingTime) => {
            const newRemainingTime = prevRemainingTime - 1;
            return newRemainingTime;
          });
        }, 1000);

        return () => {
          clearInterval(timer);
        };
      }
    }
  }, [data]);

  const minutes = Math.floor(remainingTime / 60);
  const seconds = remainingTime % 60;

  const handleShowDetails = () => {
    setShowDetails(true);
  };

  console.log("orders view details", data);
  const navigate = useNavigate();

  const arrowClick = (event) => {
    event.preventDefault();
    navigate("/home/ordersview");
  };

  const handleInitiateRefund = () => {
    console.log("heeloo refund");
    const pg_name =
      data && data.payment_details && data.payment_details.pg_name !== "null"
        ? data.payment_details.pg_name
        : "";

    const id = data && data.id;

    navigate(`/home/orderview/manualrefund/${pg_name}/${id}`);
  };

  const imgStyle = {
    width: "78px",
    height: "79px",
    borderRadius: "36.22214px",
  };
  return (
    <div className="main-div" style={{ margin: "auto" }}>
      <div>
        <Sidebar />
      </div>

      {loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
        <>
          {data && data && (
            <div style={{ margin: "auto" }}>
              <div>
                <div
                  style={{
                    marginLeft: "42px",
                    marginTop: "10px",
                    display: "flex",
                    justifyContent: "space-between",
                  }}
                >
                  <div>
                    <h2 style={{ width: "360px", marginLeft: "-28px" }}>
                      <img
                        onClick={arrowClick}
                        style={{ width: "22px", cursor: "pointer" }}
                        src={leftArrow}
                        alt=""
                      />{" "}
                      Mini Order ID : {data && data.dcCode}
                    </h2>
                    <h5 style={{ color: "grey" }}>
                      Order ID :{data && data.id}{" "}
                    </h5>
                  </div>

                  <div className="user-statusCompleted">
                    <p className="user-status-text">{data && data.status}</p>
                  </div>
                  <div>
                    <Button
                      style={{ fontSize: "14px" }}
                      variant="primary"
                      onClick={handleShow}
                    >
                      {" "}
                      Copy Details
                    </Button>
                  </div>

                  <div>
                    <Button
                      style={{
                        fontSize: "14px",
                        backgroundColor: "#4caf50  ",
                        border: "1px solid #4caf50",
                        padding: "8px",
                      }}
                      // variant="warning"
                      onClick={handleInitiateRefund}
                    >
                      Initiate Refund
                    </Button>
                  </div>
                </div>

                <>
                  <Modal show={show} onHide={handleClose}>
                    <Modal.Body>
                      <Form>
                        <Form.Group
                          className="mb-3"
                          controlId="exampleForm.ControlTextarea1"
                        >
                          <Form.Label>Customer issues :</Form.Label>

                          <select
                            id="issue"
                            value={selectedIssue}
                            onChange={handleIssueChange}
                            style={{
                              borderRadius: "10px",
                              marginLeft: "18px",
                              width: "235px",
                              padding: "8px",
                            }}
                          >
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value=""
                            >
                              -- Select --
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value={issue}
                            >
                              Vending Failed
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value={issue}
                            >
                              Product got stuck
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value={issue}
                            >
                              Success Unsuccess
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value={issue}
                            >
                              Order X got Y
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value={issue}
                            >
                              Prices Mismatched
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value={issue}
                            >
                              Refilling Request
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value={issue}
                            >
                              Machine not working
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value={issue}
                            >
                              Tab not workin
                            </option>
                            <option
                              style={{ fontFamily: "Crimson Text" }}
                              value="other"
                            >
                              Other
                            </option>
                          </select>
                          {selectedIssue === "other" && (
                            <Form.Control
                              value={issue}
                              onChange={handleIssueTextChange}
                              as="textarea"
                              rows={3}
                              style={{ marginTop: "20px" }}
                            />
                          )}
                        </Form.Group>
                      </Form>
                    </Modal.Body>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        margin: "10px",
                      }}
                    >
                      <Button
                        variant="secondary"
                        style={{ fontSize: "14px" }}
                        onClick={handleClose}
                      >
                        Close
                      </Button>
                      <Button
                        variant="primary"
                        style={{ fontSize: "14px", marginLeft: "20px" }}
                        onClick={handleSubmit}
                      >
                        Copy Details
                      </Button>
                    </div>
                  </Modal>
                </>

                <div className="informationDiv">
                  <div className="customerDetails">
                    <div className="basicSecOrder">
                      <img src={profile} alt="" />
                      <p>Customer Details</p>
                    </div>

                    <div className="backgroundImg">
                      <div>
                        <div
                          style={{
                            width: "453px",
                            backgroundColor: "white",
                            height: "198px",
                            margin: "auto",
                          }}
                        >
                          <div>
                            <div className="designationDiv">
                              <img style={imgStyle} src={Avatar} alt="" />
                              <div className="roleHead">
                                <p>
                                  {data &&
                                    data.user_details &&
                                    data.user_details.name}
                                </p>
                              </div>
                            </div>
                            <div
                              style={{
                                display: "flex",
                                margin: "10px",
                                width: "266px",
                                justifyContent: "space-evenly",
                                flexDirection: "column",
                              }}
                            >
                              <div
                                style={{
                                  display: "flex",
                                  justifyContent: "flex-start",
                                  flexDirection: "row",
                                }}
                              >
                                <img
                                  style={{ width: "22px" }}
                                  src={phone1}
                                  alt=""
                                />
                                <p style={{ marginLeft: "10px" }}>
                                  {data && data.phone}
                                </p>
                              </div>
                              <div
                                style={{
                                  display: "flex",
                                  justifyContent: "flex-start",
                                  flexDirection: "row",
                                }}
                              >
                                <img
                                  style={{ width: "22px" }}
                                  src={mail}
                                  alt=""
                                />
                                <p style={{ marginLeft: "10px" }}>
                                  {data &&
                                    data.user_details &&
                                    data.user_details.email}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="orderInfo">
                    <div className="orderSec">
                      <div style={{ display: "flex" }}>
                        <img src={infoIcon} alt="" />
                        <p>Order Information</p>
                      </div>
                      <div>
                        <Button
                          onClick={handleCopyInfo}
                          style={{ margin: "auto", fontSize: "14px" }}
                        >
                          copy info
                        </Button>
                      </div>
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "740px",
                        margin: "20px",
                      }}
                    >
                      <div>
                        <div className="orderinfodetails">
                          <img src={dateTime} alt="" />
                          <p>
                            Date & Time:
                            {moment
                              .utc(data && data.created_at)
                              .tz("Asia/Kolkata")
                              .format("YYYY-MM-DD hh:mm:ss A")}
                          </p>
                        </div>
                        <div className="orderinfodetails">
                          <img src={city} alt="" />
                          <p>City: {data && data.city}</p>
                        </div>
                        <div className="orderinfodetails">
                          <img src={city} alt="" />
                          <p>
                            Vending Machine Address: {data && data.vmAddress}
                          </p>
                        </div>
                      </div>

                      <div>
                        <div className="orderinfodetails">
                          <img src={kiosk} alt="" />
                          <p>Order Via: {data && data.source}</p>
                        </div>
                        <div className="orderinfodetails">
                          <img src={vm} alt="" />
                          <p>Vending Machine Name: {data && data.name}</p>
                        </div>
                        <div className="orderinfodetails">
                          <img src={vm} alt="" />
                          <p>Vending Machine ID: {data && data.machine_id}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="itemDetais">
                  <div className="itemDetailsIcon">
                    <img src={itemDetails} alt="" />
                    <p>Items Details</p>
                  </div>
                  <div>
                    <div
                      style={{
                        width: "1318px",
                        borderRadius: "15px",
                        margin: "auto",
                      }}
                    >
                      <Table
                        striped
                        hover
                        className="scrol1ldown"
                        id="scrollableDiv"
                        style={{
                          height: "260px",
                          overflowY: "auto",
                          display: "block",
                        }}
                      >
                        <thead>
                          <tr>
                            <th>Product</th>
                            <th>Slot Number</th>
                            <th>MRP</th>
                            <th>Offer Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Status</th>
                          </tr>
                        </thead>

                        <tbody>
                          {data &&
                            data.line_items &&
                            data.line_items.length > 0 &&
                            data.line_items.map((item) => (
                              <tr key={item.id}>
                                <td style={{ textAlign: "left" }}>
                                  {item.name}
                                </td>
                                <td style={{ textAlign: "left" }}>
                                  {item.slot_id}
                                </td>
                                <td style={{ textAlign: "left" }}>
                                  {item.mrp}
                                </td>
                                <td style={{ textAlign: "left" }}>
                                  {item.offer_price}
                                </td>
                                <td style={{ textAlign: "left" }}>
                                  {item.item_count}
                                </td>
                                <td style={{ textAlign: "left" }}>
                                  {item.sub_total}
                                </td>
                                <td style={{ textAlign: "left" }}>
                                  <div key={item.id}>
                                    {item.success_count > 0 && (
                                      <>
                                        <span>{item.success_count}</span>{" "}
                                        <img src={success} alt="Success" />
                                      </>
                                    )}
                                    {item.failure_count > 0 && (
                                      <>
                                        <span>{item.failure_count}</span>{" "}
                                        <img src={cross} alt="Failure" />
                                      </>
                                    )}
                                    {item.vend_remaining_count > 0 && (
                                      <>
                                        <span>{item.vend_remaining_count}</span>{" "}
                                        <img src={panding} alt="Pending" />
                                      </>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            ))}
                        </tbody>
                      </Table>
                    </div>
                  </div>
                </div>

                <div style={{ width: "1318px" }}>
                  <div className="paymentDetails">
                    <div className="paymentIconDiv">
                      <img src={refund} alt="" />
                      <p>Payment Details</p>
                    </div>
                    <div className="itemDetailsPayment">
                      <div className="paymentSucces">
                        <div className="logoRefund">
                          <h3>₹ {data && data.amount}</h3>
                        </div>

                        <div className="paymentItemsDetailsDiv">
                          <div>
                            <p style={{ fontWeight: "bold" }}>ID</p>
                            {data &&
                              data.payment_details &&
                              data.payment_details.id}
                          </div>
                          <div>
                            <p style={{ fontWeight: "bold" }}>Status</p>
                            {data &&
                              data.payment_details &&
                              data.payment_details.status}
                          </div>
                          <div>
                            <p style={{ fontWeight: "bold" }}>Date & Time</p>
                            {moment
                              .utc(
                                data &&
                                  data.payment_details &&
                                  data.payment_details.updated_at
                              )
                              .tz("Asia/Kolkata")
                              .format("YYYY-MM-DD hh:mm:ss A")}
                          </div>
                          <div>
                            <p style={{ fontWeight: "bold" }}>
                              Payments Gateway
                            </p>
                            {data &&
                              data.payment_details &&
                              data.payment_details.pg_name}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="itemDetais1">
                  <div className="itemDetailsIcon1">
                    <div
                      style={{
                        width: "140px",
                        display: "flex",
                        justifyContent: "space-around",
                      }}
                    >
                      <img src={refund} alt="" />
                      Refund Details
                    </div>
                    <div> {data.refund_details.length} Refund </div>
                  </div>

                  <div>
                    <Table
                      striped
                      hover
                      className="scrol1ldown"
                      id="scrollableDiv"
                      style={{
                        height: "260px",
                        overflowY: "auto",
                        display: "block",
                      }}
                    >
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Date & Time</th>
                          <th>Amount</th>
                          <th>PG</th>
                          <th>Reason</th>
                          <th> Type</th>

                          <th> Status</th>
                          <th>View Details</th>
                        </tr>
                      </thead>

                      <tbody>
                        {data.refund_details.map((refundItem) => (
                          <tr key={refundItem.id}>
                            <td>{refundItem.id}</td>

                            <td style={{ fontSize: "10px" }}>
                              {moment
                                .utc(refundItem.updated_at)
                                .tz("Asia/Kolkata")
                                .format("YYYY-MM-DD hh:mm:ss A")}
                            </td>

                            <td>{refundItem.amount}</td>
                            <td>{refundItem.pg_name}</td>
                            <td>
                              <span
                                style={{
                                  color: "#FF5050",
                                  fontSize: "14px",
                                  backgroundColor: "#FF000014",
                                  width: "100px",
                                  padding: "8px 2px 8px 2px",
                                  borderRadius: "8px",
                                  fontSize: "14px",
                                }}
                              >
                                {refundItem.reason}
                              </span>
                            </td>
                            <td>{refundItem.status}</td>
                            <td>{refundItem.refundStatus}</td>
                            <td>
                              {" "}
                              <img
                                src={refillEye}
                                onClick={() =>
                                  handleOpenStatusModal(
                                    refundItem.id,
                                    refundItem.amount,
                                    refundItem.pg_name,
                                    refundItem.result_status,
                                    refundItem.result_msg
                                  )
                                }
                                alt="View"
                                style={{ cursor: "pointer" }}
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>

                    <Dialog open={showStatusModal}>
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <DialogTitle style={{ fontWeight: "600" }}>
                          Refund ID : {dialogData?.orderId}{" "}
                          <p style={{ fontWeight: "400", color: "#343A406E" }}>
                            Amount : ₹ {dialogData?.refundAmount}
                          </p>
                        </DialogTitle>

                        <DialogTitle>
                          <img
                            onClick={() => handleCloseStatusModal()}
                            src={cancel}
                            alt=""
                            title="Click to cancel"
                            style={{ cursor: "pointer" }}
                          />
                        </DialogTitle>
                      </div>

                      <DialogContent
                        style={{
                          width: "731px",
                          height: "490px",
                          borderRadius: "16px",
                          display: "flex",
                          alignItems: "center",
                          margin: "auto",
                        }}
                      >
                        {/* <Box sx={{ width: "100%" }}>
                          {orderStatus &&
                          orderStatus.resultMsg === "Refund Successfull" ? (
                            <>
                              <div
                                style={{
                                  width: "100%",
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                  flexDirection: "column",
                                }}
                              >
                                <img
                                  style={{ height: "100px", width: "100px" }}
                                  src="https://media1.tenor.com/m/Hw7f-4l0zgEAAAAC/check-green.gif"
                                  alt=""
                                />
                                <span>{orderStatus.resultMsg}</span>
                                <span>
                                  {orderStatus &&
                                    orderStatus.refundDetailInfoList &&
                                    orderStatus.refundDetailInfoList.length >
                                      0 && (
                                      <>
                                        <span>
                                          {moment
                                            .utc(
                                              orderStatus &&
                                                orderStatus.refundDetailInfoList &&
                                                orderStatus.refundDetailInfoList
                                                  .userCreditExpectedDate
                                            )
                                            .tz("Asia/Kolkata")
                                            .format("YYYY-MM-DD hh:mm:ss A")}
                                        </span>
                                      </>
                                    )}
                                </span>
                              </div>
                            </>
                          ) : (
                            <>
                              <div
                                style={{
                                  width: "100%",
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                  flexDirection: "column",
                                }}
                              >
                                <img src={awaitingIcon} alt="" />
                                <span>
                                  {orderStatus
                                    ? orderStatus.resultMsg
                                    : "No data found"}
                                </span>
                                <span> 10/12/2023</span>
                              </div>
                            </>
                          )}
                        </Box> */}

                        <Box sx={{ width: "100%" }}>
                          {orderStatus && (
                            <>
                              {orderStatus.refundStatus ===
                                "Refund Successfull" && (
                                <div
                                  className="status-container"
                                  style={{
                                    height: "200px",
                                    width: "200px",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    flexDirection: "column",
                                    margin: "auto",
                                  }}
                                >
                                  <img
                                    className="status-icon"
                                    src={refundSucessIcon}
                                    alt=""
                                    style={{ width: "100%", height: "100%" }}
                                  />
                                  <span>{orderStatus.refundStatus}</span>
                                  <span>
                                    {orderStatus.refundDetailInfoList &&
                                      orderStatus.refundDetailInfoList.length >
                                        0 && (
                                        <span>
                                          {moment
                                            .utc(
                                              orderStatus
                                                .refundDetailInfoList[0]
                                                .userCreditExpectedDate
                                            )
                                            .tz("Asia/Kolkata")
                                            .format("YYYY-MM-DD hh:mm:ss A")}
                                        </span>
                                      )}
                                  </span>
                                </div>
                              )}

                              {orderStatus.refundStatus === "AWAITING" && (
                                <div
                                  className="status-container"
                                  style={{
                                    height: "200px",
                                    width: "200px",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    flexDirection: "column",
                                    margin: "auto",
                                  }}
                                >
                                  <img
                                    className="status-icon"
                                    src={awaitingIcon}
                                    alt=""
                                    style={{ width: "100%", height: "100%" }}
                                  />
                                  <span>{orderStatus.refundStatus}</span>
                                  <span>
                                    {orderStatus.refundDetailInfoList &&
                                      orderStatus.refundDetailInfoList.length >
                                        0 && (
                                        <span>
                                          {moment
                                            .utc(
                                              orderStatus
                                                .refundDetailInfoList[0]
                                                .userCreditExpectedDate
                                            )
                                            .tz("Asia/Kolkata")
                                            .format("YYYY-MM-DD hh:mm:ss A")}
                                        </span>
                                      )}
                                  </span>
                                </div>
                              )}

                              {orderStatus.refundStatus ===
                                "RECORD NOT FOUND" && (
                                <div
                                  className="status-container"
                                  style={{
                                    height: "200px",
                                    width: "200px",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    flexDirection: "column",
                                    margin: "auto",
                                  }}
                                >
                                  <img
                                    className="status-icon"
                                    src={failedrefund}
                                    alt=""
                                    style={{ width: "100%", height: "100%" }}
                                  />
                                  <span>{orderStatus.refundStatus}</span>
                                  <span>
                                    {orderStatus.refundDetailInfoList &&
                                      orderStatus.refundDetailInfoList.length >
                                        0 && (
                                        <span>
                                          {moment
                                            .utc(
                                              orderStatus
                                                .refundDetailInfoList[0]
                                                .userCreditExpectedDate
                                            )
                                            .tz("Asia/Kolkata")
                                            .format("YYYY-MM-DD hh:mm:ss A")}
                                        </span>
                                      )}
                                  </span>
                                </div>
                              )}
                            </>
                          )}

                          {!orderStatus && (
                            <div
                              className="status-container"
                              style={{
                                height: "200px",
                                width: "200px",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                flexDirection: "column",
                                margin: "auto",
                              }}
                            >
                              <img
                                className="status-icon"
                                src={failedrefund}
                                alt=""
                                style={{ width: "100%", height: "100%" }}
                              />
                              <span>Record Not Found</span>
                            </div>
                          )}
                        </Box>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
