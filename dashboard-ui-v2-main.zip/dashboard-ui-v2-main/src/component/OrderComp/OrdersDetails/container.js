import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { OrdersViewComp } from "./component";
import { toastr } from "react-redux-toastr";
import { useParams } from "react-router-dom";
import { setLoading } from "../OrdersList/actions";
import ClipboardJS from "clipboard";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { OrderRefundComponent } from "../OrderRefund/component";

const OrdersViewContainer = (props) => {
  const { orderid } = useParams();
  console.log("ankit orderid", orderid);
  const [orderData, setOrderData] = useState();
  const [loading, setLoading] = useState(true);
  const [show, setShow] = useState(false);
  const [issue, setIssue] = useState("");
  const [orderStatus, setOrderStatus] = useState([])
  const [selectedIssue, setSelectedIssue] = useState("");
  const [showStatusModal, setShowStatusModal] = React.useState(null);
  const [refundId, setRefundId] = useState('')
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const navigate = useNavigate();
  console.log("tahzeeb", props.match);

  useEffect(() => {
    LoadOrderView();
  }, []);

  const handleIssueChange = (event) => {
    const selectedValue = event.target.value;
    setSelectedIssue(selectedValue);

    if (selectedValue !== "other") {
      
      setIssue(selectedValue);
    }
  };

  const handleIssueTextChange = (event) => {
   
    setIssue(event.target.value);
  };

  // const LoadOrderView = () => {
  //   return props.getDataFromAPI(
  //     `/partner/api/v1/admin/orders/${orderid}`,
  //     "GET",
  //     undefined,
  //     (response) => {
  //       setLoading(false);
  //       setOrderData(response);

  //       console.log("response---------> order", response);
  //     },
  //     (err) => {},
  //     true
  //   );
  // };
// const LoadOrderView = () => {
//   return props.getDataFromAPI(
//     `/partner/api/v1/admin/orders/${orderid}`,
//     "GET",
//     undefined,
//     (response) => {
//       setLoading(false);
//       setOrderData(response);
      
//       // Assuming response contains refund_details array
//        setRefundId(response.refund_details.id);
//       // fetchOrderStatus(refundId); // Call fetchOrderStatus with the refund ID

//       console.log("response---------> order", response);
//     },
//     (err) => {},
//     true
//   );
// };
const LoadOrderView = () => {
  return props.getDataFromAPI(
    `/partner/api/v1/admin/orders/${orderid}`,
    "GET",
    undefined,
    (response) => {
      setLoading(false);
      setOrderData(response);
      
      // Assuming response contains refund_details array
      if (response.refund_details && response.refund_details.length > 0) {
        const firstRefundId = response.refund_details[0].id;
        setRefundId(firstRefundId);
        // fetchOrderStatus(firstRefundId); // Call fetchOrderStatus with the refund ID
      }

      console.log("response---------> order", response);
    },
    (err) => {},
    true
  );
};

  // const fetchOrderDetails = async () => {
  //   try {
  //     const response = await axios.get(
  //       "/partner/api/v1/admin/orders/${orderid}"
  //     );
  //     setOrderData(response.data);
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };

  const handleSubmit = () => {
    if (orderData && orderData.id && orderData.status && orderData.created_at && issue) {
      const { id, status, created_at, phone } = orderData;
      const name = localStorage.data
        ? JSON.parse(localStorage.data).details.userDetails.full_name
        : 'N/A';
  
      const phoneValue = phone ? phone : 'N/A';
  
      const utcTime = orderData&&orderData.created_at;
      const utcDate = new Date(utcTime);
      
      const istTimeOptions = { timeZone: 'Asia/Kolkata', hour12: true };
      const istTimeString = utcDate.toLocaleString('en', istTimeOptions);
      
      console.log("IST Time:", istTimeString);
      

      
      const orderText = `${id}\t${status}\t${istTimeString}\t${phoneValue}\t${issue}\t${name}`;
  
      navigator.clipboard
        .writeText(orderText)
        .then(() => {
          console.log('Order details copied to clipboard');
          setShow(false);
        })
        .catch((error) => {
          console.error('Failed to copy order details:', error);
        });
    }
  };
  
  const handleCopyInfo= () => {
    console.log("copy click")
    if (orderData && orderData.machine_id && orderData.city && orderData.name && orderData.vmAddress) {
      const { machine_id, city, created_at, vmAddress, name } = orderData;
      // const name = localStorage.data
      //   ? JSON.parse(localStorage.data).details.userDetails.full_name
      //   : 'N/A';
  
      // const phoneValue = phone ? phone : 'N/A';
  
      const utcTime = orderData&&orderData.created_at;
      const utcDate = new Date(utcTime);
      
      const istTimeOptions = { timeZone: 'Asia/Kolkata', hour12: true };
      const istTimeString = utcDate.toLocaleString('en', istTimeOptions);
      
      console.log("IST Time:", istTimeString);
      

      
      const orderText = `${machine_id}\t${city}\t${name}\t${vmAddress}`;
  
      navigator.clipboard
        .writeText(orderText)
        .then(() => {
          console.log('Order details------- copied to clipboard');
          setShow(false);
        })
        .catch((error) => {
          console.error('Failed to copy order details:', error);
        });
    }
  };
  
 useEffect(()=>{
fetchOrderStatus()
 },[])
console.log("orderStatus", orderStatus)

  // const fetchOrderStatus = async () => {
  //   try {
  //     const response = await axios.get(
  //       `partner/api/v2/bankRefund/status/${orderid}`
  //     );
  //     setOrderStatus(response.data);
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };

console.log("refundid--", refundId)
 const fetchOrderStatus = () => {
  return props.getDataFromAPI(
      `/partner/api/v2/bankRefund/status/${orderid}/payment/${refundId}`,
    "GET",
    undefined,
    (response) => {
      setOrderStatus(response);
      console.log("response---------> order", response);
    },
    (err) => {},
    true
  );
};



  return (
    <>
      <OrdersViewComp
        data={orderData}
        loading={loading}
        // fetchOrderDetails={fetchOrderDetails}
        // copyOrderDetails={handleButtonClick}
        show={show}
        handleClose={handleClose}
        handleShow={handleShow}
        handleSubmit={handleSubmit}
        handleIssueChange={handleIssueChange}
        selectedIssue={selectedIssue}
        handleIssueTextChange={handleIssueTextChange}
        // showStatusModal={setShowStatusModal}
        // handleCloseStatusModal={handleCloseStatusModal}
        // handleOpenStatusModal={handleOpenStatusModal}
        handleCopyInfo={handleCopyInfo}
        orderStatus={orderStatus}
        fetchOrderStatus={fetchOrderStatus}
      />
     
    </>
  );
};

function mapStateToProps({ props }) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
  setLoading,
})(OrdersViewContainer);
