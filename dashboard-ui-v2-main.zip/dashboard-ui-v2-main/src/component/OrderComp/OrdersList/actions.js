import {
    SET_LOADING,
    SAVE_DATA,
  } from './constants';
  
  export function setLoading(isLoading) {
    return {
      type: SET_LOADING,
      isLoading,
    };
  }
  
  export function saveData(data) {
    return {
      type: SAVE_DATA,
      data,
    };
  }
  