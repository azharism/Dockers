import {
    SET_LOADING,
    SAVE_DATA,
  } from './constants';
  import { CLEAR_STATE } from '../HandleAPICalls/constants';
  
  const initialState = {
    loading: true,
    details: [],
  };
  
  export default function (state = initialState, action) {
    switch (action.type) {
      case SET_LOADING:
        return {
          ...state,
          loading: action.isLoading,
        };
  
      case SAVE_DATA:
        return {
          ...state,
          details: action.data,
        };
  
      case CLEAR_STATE:
        return initialState;
  
      default: return state;
    }
  }
  