export const SET_LOADING = '@orderDetails/SET_LOADING';
export const SAVE_DATA = '@orderDetails/SAVE_DATA';
