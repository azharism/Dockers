import React, { useEffect, useState } from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import { Link, useNavigate } from "react-router-dom";
import leftArrow from "../../../assests/leftArrow.svg";
import Table from "react-bootstrap/Table";
import search from "../../../assests/search.svg";
import eyeIcon from "../../../assests/eyeIcon.svg";
import filterIcon from "../../../assests/filterIcon.svg";
// import moment from "moment";
import LoadingSpinner from "../../Loading/component";
import dayjs from "dayjs";
import AlarmIcon from "@mui/icons-material/Alarm";
import SnoozeIcon from "@mui/icons-material/Snooze";
import TextField from "@mui/material/TextField";
import ClockIcon from "@mui/icons-material/AccessTime";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
// import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { MobileDateTimePicker } from "@mui/x-date-pickers/MobileDateTimePicker";
// import moment from "moment-timezone";
import InfiniteScroll from "react-infinite-scroll-component";
import { success } from "toastr";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import SendIcon from "@mui/icons-material/Send";
import Stack from "@mui/material/Stack";
import retryicon from "../../../assests/retryicon.svg";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import uploadsvg from "../../../assests/uploadsvg.svg";
import PropTypes from "prop-types";
import unableImage from "../../../assests/unableImage.svg";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Typography from "@mui/material/Typography";
import { useParams } from "react-router-dom";
import { CompressOutlined } from "@mui/icons-material";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";
import emotions7 from "../../../assests/emotions7.svg";
import moment from 'moment-timezone';
import {
  LocalizationProvider,
  DatePicker,
  TimePicker,
} from "@mui/x-date-pickers";
import Modal from '@mui/material/Modal';
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
const style = {
  position: 'absolute',
  top: '20%',
  left: '60%',
  transform: 'translate(-50%, -50%)',
  width: 200,
  height:300,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 2,
 overflowY: "scroll"
};

const OrdersListComp = ({
  filteredOrderList,
  orderSearch,
  onSearchInputChange,
  loading,
  fetchUsersListNext,
  data,
  morescroll,
  handleDateChange,
  handleOpen,
  pickDate,
  rowColors,
  handleDrag,
  handleDrop,
handleEndTimeChange,
  onButtonClick,

  inputRef,
  imageDropped,

  previewImage,

  handleClickImg,
  handleCloseD,
  handleChangeImage,
  orderFound,
  handleRetry,
  handleClickOpen,
  showFileInput,
  open,
  isFocused,
  handleFocus,
  handleBlur,
  onSearchClick,
  onSearchInputKeyDown,
  searchOrderValue,
  isLoading,
  searchOption,
  tableContainerRef,
  orderSearchViaCity,
  searchCityValue,
  handleClose,

  openFilter,
  handleApplyFilterCity,
  filteredList,
  handleOpenAmount,
  openFilterAmount,

  orderSearchViaAmount,
  
  handleApply,
  startTime,
  setStartTime,
  endTime,
  setEndTime,
  list,
}) => {
  const { orderid } = useParams();

  const [showDatePicker, setShowDatePicker] = useState(false);

  const [dateWithNoInitialValue, setDateWithNoInitialValue] =
    React.useState(null);
  const [dateWithInitialValue, setDateWithInitialValue] = React.useState(
    dayjs("00-00-00T00:00")
  );

  useEffect(() => {}, [filteredList]);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");

  const [ctlist, setctlist] = useState(null);

  const [orderDetails, setOrderDetails] = useState(null);
  const [imagePath, setImagePath] = useState("");

  useEffect(() => {
    if (!ctlist || !ctlist[0]) {
      setctlist(filteredList);
    }
  }, [filteredList]);

  const handleRowClick = (e, orderid) => {
    navigate(`/home/ordersview/${orderid}`);
  };

  function handleTimeChange(event) {
    setTime(event.target.value);
  }

  function handleFilterClick() {
    setShowDatePicker(!showDatePicker);
  }

  function handleApplyFilter() {
    console.log(`Selected date: ${date} Selected time: ${time}`);
    // Your code to apply the filter goes here
  }
  const navigate = useNavigate();

  const arrowClick = () => {
    navigate("/");
  };
  const handleCancel = () => {
    setShowDatePicker(!showDatePicker);
  };

  const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    "& .MuiDialogContent-root": {
      padding: theme.spacing(2),
    },
    "& .MuiDialogActions-root": {
      padding: theme.spacing(1),
    },
  }));

  function BootstrapDialogTitle(props) {
    const { children, onClose, ...other } = props;

    return (
      <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
        {children}
        {onClose ? (
          <IconButton
            aria-label="close"
            onClick={onClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>
        ) : null}
      </DialogTitle>
    );
  }

  BootstrapDialogTitle.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
  };

  return (
    <>
      {isLoading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
        <div className="main-div">
          <div>
            <Sidebar />
          </div>

          <div style={{ margin: "auto" }}>
            <div className="ordersHeading">
              <img
                onClick={arrowClick}
                style={{ width: "22px", cursor: "pointer" }}
                src={leftArrow}
                alt=""
              />
              <p className="ordersText">Orders</p>
            </div>
            {isLoading && (
              <div>
                {" "}
                <Box sx={{ display: "flex", color: "yellow" }}>
                  {/* <CircularProgress /> */}
                  <LoadingSpinner />
                </Box>
              </div>
            )}

            <div
              style={{
                display: "flex",
                flexDirection: " row",
                justifyContent: "space-between",
                width: "100%",
              }}
            >
              <div>
                <div className="order-searchbar">
                  {/* <select
                    variant="primary"
                    name=""
                    id=""
                    className="paramsSearch"
                    value={searchOption}
                    onChange={handleSearchOptionChange}
                  >
                    <option value="order_id">Order ID</option>
                    <option value="phone">Mobile Number</option>
                  </select> */}
                  <input
                    className="inputfirlf"
                    type="text"
                    placeholder={
                      searchOption === "phone"
                        ? "Search by Mobile Number"
                        : "Search by Order ID"
                    }
                    onFocus={handleFocus}
                    onBlur={handleBlur}
                    value={searchOrderValue}
                    onChange={onSearchInputChange}
                    onKeyDown={onSearchInputKeyDown}
                  />
                  <img
                    style={{ marginLeft: "10px" }}
                    className="search-icon"
                    src={search}
                    alt=""
                    // onClick={onSearchClick}
                  />
                </div>
              </div>

              <div
                style={{ position: "relative", top: "80px", right: "10px" }}
                className="uploadimg"
              >
                <Stack direction="row" spacing={2}>
                  <Button onClick={handleClickOpen}>
                    <img
                      src={uploadsvg}
                      alt=""
                      style={{ marginRight: "10px" }}
                    />
                    <span className="uploadtext" style={{ color: "#fff" }}>
                      Upload Screenshot
                    </span>
                  </Button>
                </Stack>
              </div>
            </div>

            <div>
              <BootstrapDialog
                onClose={handleCloseD}
                aria-labelledby="customized-dialog-title"
                open={open}
              >
                <BootstrapDialogTitle
                  id="customized-dialog-title"
                  onClose={handleCloseD}
                >
                  <div style={{ padding: "24px" }}>
                    <p className="uploadHead">Upload Screenshot</p>
                    <Typography>
                      Upload the screenshot of payment transaction
                    </Typography>
                  </div>
                </BootstrapDialogTitle>
                <DialogContent id="form-file-upload">
                  {orderFound ? (
                    <div>
                      <div
                        className="dragDropBox"
                        onDrop={handleDrop}
                        onDragEnter={handleDrag}
                        onDragOver={handleDrag}
                        onDragLeave={handleDrag}
                        onClick={(e) => onButtonClick(e, "box")}
                      >
                        {previewImage ? (
                          <div
                            style={{
                              height: "350px ",
                              margin: "10px",
                              width: "100%",
                            }}
                          >
                            <img
                              src={previewImage}
                              alt="Preview"
                              style={{ maxWidth: "100%", maxHeight: "100%" }}
                            />
                          </div>
                        ) : (
                          <div
                            style={{
                              margin: "auto",
                              textAlign: "center",
                              alignItems: "center",
                            }}
                          >
                            <p className="boxheading">
                              Drop screenshot here, or{" "}
                              <a
                                onClick={(e) => onButtonClick(e, "button")}
                                href=""
                                style={{
                                  textDecoration: "none",
                                  marginLeft: "4px",
                                }}
                              >
                                {" "}
                                Browse{" "}
                              </a>
                            </p>
                          </div>
                        )}
                        <div
                          style={{
                            position: "fixed",
                            margin: "auto",
                            width: "711px",
                          }}
                        >
                          {imageDropped && (
                            <div style={{ marginTop: "20px" }}>
                              <Button
                                onClick={(e) => onButtonClick(e, "button")}
                                className="changeimage-button"
                              >
                                change image
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>

                      {previewImage ? (
                        <div style={{ marginTop: "50px" }}>
                          <Button
                            onClick={handleClickImg}
                            type="submit"
                            loading={loading}
                            variant="contained"
                            color="success"
                            size="large"
                            style={{ marginLeft: "0px", width: "100%" }}
                          >
                            Submit
                          </Button>
                        </div>
                      ) : (
                        <div style={{ marginTop: "50px" }}>
                          <Button
                            //  onClick={handleClickImg}
                            type="submit"
                            disabled={true}
                            variant="secondary"
                            color="success"
                            size="large"
                            style={{
                              marginLeft: "0px",
                              width: "710px",
                              display: "none",
                            }}
                          >
                            Submit
                          </Button>
                        </div>
                      )}

                      <div
                        style={{ display: showFileInput ? "block" : "none" }}
                      >
                        <input
                          ref={inputRef}
                          // id="input-file-upload"
                          id="myFileInput"
                          multiple={true}
                          type="file"
                          onChange={handleChangeImage}
                          style={{ display: "none" }}
                        />
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div>
                        <img src={unableImage} alt="" />
                        <h4 style={{ textTransform: "capitalize" }}>
                          Unable to find order id
                        </h4>
                      </div>
                      <a
                        href="#"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRetry(orderFound);
                        }}
                      >
                        Retry <img src={retryicon} alt="" />
                      </a>

                      {showFileInput && (
                        <div>
                          <input
                            ref={inputRef}
                            id="myFileInput"
                            multiple={true}
                            type="file"
                            onChange={handleChangeImage}
                            style={{ display: "none" }}
                          />
                        </div>
                      )}
                    </div>
                  )}
                </DialogContent>
              </BootstrapDialog>
            </div>

            <div className="order-main-sec">
              <div>
                <div
                  style={{ width: "1310px", borderRadius: "15px" }}
                  className="scrolldown"
                  ref={tableContainerRef}
                >
                  <InfiniteScroll
                    dataLength={data.length}
                    next={fetchUsersListNext}
                    hasMore={true}
                    scrollableTarget="scrollableDiv"
                    height={700}
                    endMessage={
                      <p style={{ textAlign: "center" }}>
                        <b>Yay! You have seen it all</b>
                      </p>
                    }
                  >
                    <div>
                      <Modal
                        open={openFilter}
                        onClose={handleClose}
                        aria-labelledby="modal-modal-title"
                        aria-describedby="modal-modal-description"
                      >
                        <Box sx={style}>
                          {/* <input type="search" placeholder="Search City" value={searchCityValue} onChange={handleInputChange} /> */}
                          <div>
                            <h4>City List</h4>
                            {ctlist &&
                              ctlist.map((item) => (
                                <>
                                  <p
                                    className="row_design"
                                    key={item.city}
                                    onClick={() =>
                                      orderSearchViaCity(item.city)
                                    }
                                    style={{ cursor: "pointer" }}
                                  >
                                    {item.city}
                                  </p>
                                </>
                              ))}
                          </div>
                          {/* <DialogActions>
            <Button variant="contained" onClick={handleApplyFilterCity}>
              Apply
            </Button>
            <Button variant="outlined" onClick={handleClose}>
              Cancel
            </Button>
          </DialogActions> */}
                        </Box>
                      </Modal>
                    </div>
                    <div>
                      <> {console.log("ctlist", ctlist)}</>
                      <Modal
                        open={openFilterAmount}
                        onClose={handleClose}
                        aria-labelledby="modal-modal-title"
                        aria-describedby="modal-modal-description"
                      >
                        <Box sx={style}>
                          {/* <input type="search" placeholder="Search amount" value={searchAmountValue} onChange={handleAmountInputChange} /> */}
                          <div>
                            <h4>Amount List</h4>
                            {ctlist &&
                              ctlist.map((el) => (
                                <>
                                  <p
                                    className="row_design"
                                    key={el.amount}
                                    onClick={() =>
                                      orderSearchViaAmount(el.amount)
                                    }
                                    style={{ cursor: "pointer" }}
                                  >
                                    {el.amount}
                                  </p>
                                </>
                              ))}
                          </div>
                          {/* <DialogActions>
            <Button variant="contained" onClick={handleApplyFilterAmount}>
              Apply
            </Button>
            <Button variant="outlined" onClick={handleClose}>
              Cancel
            </Button>
          </DialogActions> */}
                        </Box>
                      </Modal>
                    </div>
                    <Table striped className="scrol1ldown" id="scrollableDiv">
                      <thead>
                        <tr>
                          <th>
                            {showDatePicker && (
                              <LocalizationProvider dateAdapter={AdapterMoment}>
                                <Stack spacing={2}>
                                  {/* Date Picker */}
                                  <DatePicker
                                    value={pickDate}
                                    onChange={(newValue) =>
                                      handleDateChange(
                                        moment(newValue).tz("IST")
                                      )
                                    }
                                    renderInput={(params) => (
                                      <TextField
                                        {...params}
                                        label="Select Date"
                                      />
                                    )}
                                  />
<div style={{display:"flex", flexDirection:"row", justifyContent:"space-between"}}>
 <TimePicker
 
                                    label="Start Time"
                                    value={startTime}
                                    onChange={(newValue) => {
                                      const updatedStartTime = moment(newValue)
                                        .tz("IST")
                                        .set({
                                          year: pickDate.get("year"),
                                          month: pickDate.get("month"),
                                          date: pickDate.get("date"),
                                        });
                                      setStartTime(updatedStartTime);
                                    }}
                                    renderInput={(params) => (
                                      <TextField {...params}  style={{width:"140px"}}/>
                                    )}
                                  />

                               
                                  <TimePicker
                                    label="End Time"
                                    value={endTime}
                                    onChange={(newValue) => {
                                      const updatedEndTime = moment(newValue)
                                        .tz("IST")
                                        .set({
                                          year: pickDate.get("year"),
                                          month: pickDate.get("month"),
                                          date: pickDate.get("date"),
                                        });
                                      setEndTime(updatedEndTime);
                                    }}
                                    renderInput={(params) => (
                                      <TextField {...params} style={{width:"140px"}} />
                                    )}
                                  />
</div>
                                 
                                 

                                  {/* Buttons */}
                                  <div
                                    style={{
                                      display: "flex",
                                      justifyContent: "space-around",
                                    }}
                                  >
                                    <Button
                                      onClick={handleCancel}
                                      variant="outlined"
                                      style={{
                                        width: "80px",
                                        fontSize: "14px",
                                      }}
                                    >
                                      Cancel
                                    </Button>
                                    <Button
                                      variant="contained"
                                      style={{
                                        width: "80px",
                                        fontSize: "14px",
                                      }}
                                      onClick={handleApply}
                                    >
                                      Apply
                                    </Button>
                                  </div>
                                </Stack>
                              </LocalizationProvider>
                            )}
                            <img
                              style={{ position: "relative" }}
                              onClick={handleFilterClick}
                              src={filterIcon}
                              alt=""
                            />
                            <span style={{ marginLeft: "10px" }}>
                              Order Date & Time
                            </span>
                          </th>

                          <th>Order ID</th>
                          <th>Mini order ID</th>
                          <th>Phone Number</th>
                          <th>
                            <img
                              style={{ position: "relative" }}
                              onClick={handleOpen}
                              src={filterIcon}
                              alt=""
                            />
                            <span style={{ marginLeft: "10px" }}>City</span>
                          </th>

                          <th>
                            <img
                              style={{ position: "relative" }}
                              src={filterIcon}
                              alt=""
                              onClick={handleOpenAmount}
                            />
                            <span style={{ marginLeft: "10px" }}>Amount</span>
                          </th>
                          <th> Status</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredList && filteredList.length > 0 ? (
                          filteredList.map((el, index) => (
                            <tr
                              key={el.id}
                              style={{ cursor: "pointer" }}
                              className="rowColor"
                              onClick={(e) => handleRowClick(e, el.id)}
                            >
                              <td style={{ textAlign: "left" }}>
                                {/* {moment(el.createdAt).format("YYYY-MM-DD hh:mm:ss A")} */}
                                {moment
                                  .utc(el.createdAt)
                                  .tz("Asia/Kolkata")
                                  .format("YYYY-MM-DD hh:mm:ss A")}
                              </td>
                              <td style={{ textAlign: "left" }}>{el.id}</td>
                              <td>{el.dcCode}</td>
                              <td style={{ textAlign: "left" }}>{el.phone}</td>
                              <td style={{ textAlign: "left" }}>{el.city}</td>
                              <td style={{ textAlign: "left" }}>{el.amount}</td>
                              <td style={{ textAlign: "left" }}>
                                <span
                                  className="tableData"
                                  style={{
                                    backgroundColor:
                                      rowColors[index % rowColors.length],
                                  }}
                                >
                                  {el.status}
                                </span>
                              </td>
                              <td className="eyeicon1">
                                <img src={eyeIcon} loading alt="" />
                              </td>
                            </tr>
                          ))
                        ) : (
                          <>
                            {filteredOrderList ? (
                              <div className="noOrderFound">
                                <div>
                                  <img
                                    className="noOrderImg"
                                    src={emotions7}
                                    alt=""
                                  />
                                  <p className="noOrderPara">No Order Found</p>
                                </div>
                              </div>
                            ) : (
                              <div className="noOrderFound">
                                <div>
                                  <img
                                    className="noOrderImg"
                                    src={emotions7}
                                    alt=""
                                  />
                                  <p className="noOrderPara">
                                    Search your order
                                  </p>
                                </div>
                              </div>
                            )}
                          </>
                        )}
                      </tbody>
                    </Table>
                  </InfiniteScroll>
                </div>
                {console.log("heloo order ", filteredOrderList)}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default OrdersListComp;
