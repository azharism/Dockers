import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import SingingContract from "../../assests/SingingContract.svg";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Box from "@mui/material/Box";
import "./createuser.css";

const statusOptions = [
  { key: "active", text: "Active", value: 1 },
  { key: "inactive", text: "Inactive", value: 0 },
];

export const CreateusersDetails = (props) => {
  console.log("roleList", props.roleList);

  const textFieldStyle = {
    margin: "14px",
    padding: "0px",
    color: "#b2b2b2",
    marginLeft: "-2px "
  };

  return (
    <div className="cohortsec">
      <div style={{ display: "flex", justifyContent: "space-around" }}>
        <Box
          sx={{
            width: 500,
            maxWidth: "100%",
            marginTop: "39px",
            alignItems: "flex-start",
          }}
          component="form"
          noValidate
          autoComplete="off"
        >
          <TextField
            className="textfieldStyle"
            style={textFieldStyle}
            fullWidth
            label="Full Name"
            id="fullWidth"
            name="name"
            onChange={(e) => {
              props.handleUserName(e);
            }}
            placeholder="Example: Ram Singh"
          />

          <FormControl  style={{marginLeft: "8px !important", minHeight: "3.4375em !important"}} fullWidth>
            <InputLabel id="demo-simple-select-label">Role</InputLabel>
            <Select 
            
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              label="Role"
              select
              size="small"
              className="selectrole"
            >
              {props.roleList.map((el, index) => {
                return (
                  <MenuItem
                    value={index}
                    //id={el}
                    onClick={(e) => {
                      props.handleUserRole(e, el.id);
                    }}
                  >
                    {el.name}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
          <TextField
            style={textFieldStyle}
            fullWidth
            label="Email ID"
            id="fullWidth"
            name="email"
            onChange={(e) => {
              props.handleUserEmail(e);
            }}
            placeholder="Example: DaalChini@gmail.com"
          />
          <TextField
            style={textFieldStyle}
            fullWidth
            label="Mobile Number"
            id="fullWidth"
            name="mobile"
            // type="number"
            InputProps={{
              disableUnderline: true,
            }}
            inputProps={{
              maxLength: 10,
            }}
            maxLength="10"
            onChange={(e) => {
              props.handleUserMobile(e);
            }}
            placeholder="Example: 9012323134"
          />
          <TextField
            style={textFieldStyle}
            onChange={(e) => {
              props.handleUserPassword(e);
            }}
            name="password"
            fullWidth
            id="outlined-error-helper-text"
            label="Password"
            placeholder="Password"
            type="password"
          />
        
        </Box>

        <div sx={{ width: 600, maxWidth: "100%" }}>
          <img style={{ width: "100%" }} src={SingingContract} alt="" />
        </div>
      </div>
    </div>
  );
};
