export const ADD_FULL_NAME = '@createNewuser/ADD_FULL_NAME';
export const ADD_EMAIL = '@createNewuser/ADD_EMAIL';
export const ADD_MOBILE = '@createNewuser/ADD_MOBILE';
export const ADD_PASSWORD = '@createNewuser/ADD_PASSWORD';
export const ADD_ROLE = '@createNewuser/ADD_ROLE';
export const ADD_WAREHOUSE= '@createNewuser/ADD_WAREHOUSE'
export const ADD_COHORTS= '@createNewuser/ADD_COHORTS'