import { ADD_FULL_NAME, ADD_ROLE , ADD_EMAIL, ADD_MOBILE,ADD_PASSWORD,ADD_COHORTS,ADD_WAREHOUSE} from "./constant.js";
   
    
    const initialState = {
      
      add_name: '',
      add_email:'',
      add_mobile:'',
      add_password:'',
      add_role:'',
      add_cohorts:'',
      add_warehouse:''
      
    };
    
    export default (state = initialState, action) => {
      console.log('CreateUser/reducer________', action);
      switch (action.type) {
        case ADD_FULL_NAME:
          console.log("ADD_FULL_NAME")
          return {
            ...state,
            add_name: action.name,
          };
    
        case ADD_EMAIL:
          return {
            ...state,
            add_email: action.email,
          };
    
        
          case  ADD_MOBILE:
            return {
              ...state,
              add_mobile: action.mobile,
            };
            case  ADD_PASSWORD:
            return {
              ...state,
              add_password: action.password,
            };
            case  ADD_ROLE:
              return {
                ...state,
                add_role: action.role,
              };
              case  ADD_WAREHOUSE:
              return {
                ...state,
                add_warehouse: action.warehouse,
              };
              case  ADD_COHORTS:
              return {
                ...state,
                add_cohorts: action.cohorts,
              };
  
        default:
          return state;
      }
    };