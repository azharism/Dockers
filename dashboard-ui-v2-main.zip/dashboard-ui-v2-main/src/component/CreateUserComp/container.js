import React, { useEffect, useState } from 'react'
import { CreateusersDetails } from './createusers'
import {onChange_Createuser_Name,onChange_Createuser_Mobile,onChange_Createuser_Password,onChange_Createuser_Role,onChange_Createuser_Email} from './action.js'
import { connect } from "react-redux";
import { getDataFromAPI } from "../../HandleAPICalls/actions";
import { toastr } from 'react-redux-toastr';
import parseResponsetoOptions from '../../utilits/parseResponsetoOptions';
 
const CreateUserContainer = (props) => {
  const[ roleList, setRoleList]= useState([]);
  
  

  
  useEffect(()=>{
props.getDataFromAPI('/dashboard/api/v2/admin/users/roles/all',
'GET',
undefined,
response =>{
  console.log("roleList---container  user role responseer", response.list)
  setRoleList(response.list)
}

)
  },[])

console.log("props.createNewuser.add_name",props.createNewuser.add_name)
  const handleUserName=(e)=>{
    console.log("username",e.target.value)
        props.onChange_Createuser_Name(e.target.value)
      }

  

      const handleUserEmail=(e)=>{
        console.log("username",e.target.value)
            props.onChange_Createuser_Email(e.target.value)
          }
          const handleUserMobile = (e) => {
            const mobile = e.target.value;
          
         
          
            console.log("mobile number", mobile);
            props.onChange_Createuser_Mobile(mobile);
          };
          
    
          const handleUserPassword = (e) => {
            const password = e.target.value;
            const specialSymbolPattern = /[$&+,:;=?@#|'<>.^*()%!-]/; // regular expression pattern to match special symbols
          
            // Disable the input field if the password length is less than 8 or if it doesn't contain a special symbol
            if (password.length < 8 || !specialSymbolPattern.test(password)) {
              e.target.disabled = false;
            } else {
              // Enable the input field if the password meets the requirements
              e.target.disabled = false;
            }
          
            console.log("password", password);
            props.onChange_Createuser_Password(password);
          };


                  const handleUserRole=(e,id)=>{
                    console.log("userid",id)
                        props.onChange_Createuser_Role(id)
                      }
          
    // const   handleSubmit = () => {
     
    //     if (!props.createNewuser.add_name || props.createNewuser.add_name.length<3) {
          
    //       return toastr.warning('Invalid', 'Name is too small');
    //     }


    //     if (!props.createNewuser.add_email ) {
          
    //       return toastr.warning('Invalid', 'EMAIL WRONG');
    //     }
    //     // if (!roleId) {
        
    //     //   return toastr.warning('Invalid', 'Please select a role');
    //     // }
        
    //     if (!props.createNewuser.add_mobile || !props.createNewuser.add_mobile.length==10) {
          
    //       return toastr.warning('Invalid', 'Mobile number is required');
    //     }
    //     if (!props.createNewuser.add_password || props.createNewuser.add_password.length < 6) {
        
    //       return toastr.warning('Invalid', 'Password is too small');
    //     }
    
        
  
    //   };  
  return (
    <CreateusersDetails
    handleUserName={handleUserName}
    handleUserEmail={handleUserEmail}
    handleUserMobile={handleUserMobile}
    handleUserPassword={handleUserPassword}
    handleUserRole={handleUserRole}
    // handleSubmit={handleSubmit}
    roleList={roleList}
    
      />
  )
}
function mapStateToProps({createNewuser}) {
  return {
    createNewuser
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
  onChange_Createuser_Name,
  onChange_Createuser_Email,
  onChange_Createuser_Mobile,
  onChange_Createuser_Password,
  onChange_Createuser_Role
})(CreateUserContainer);
