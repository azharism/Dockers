import { ADD_FULL_NAME,ADD_EMAIL,ADD_MOBILE,ADD_PASSWORD,ADD_ROLE, ADD_COHORTS, ADD_WAREHOUSE } from "./constant.js";

export function onChange_Createuser_Name(name) {
  console.log("username is",name)
  return {
    type: ADD_FULL_NAME,
    name,
  };
}

export function onChange_Createuser_Email(email) {
  console.log("email",email)
  return {
    type: ADD_EMAIL,
    email,
  };
}

export function onChange_Createuser_Mobile(mobile) {
  console.log("mobile",mobile)
  return {
    type: ADD_MOBILE,
    mobile,
  };
}
  export function onChange_Createuser_Password(password) {
    console.log("password",password)
    return {
      type: ADD_PASSWORD,
      password,
    };
  }
    export function onChange_Createuser_Role(role) {
      console.log("ADD_ROLE",role)
      return {
        type: ADD_ROLE,
        role,
      };
    }

    export function onChange_Createuser_Cohorts(cohorts) {
      console.log("ADD_COHORTS",cohorts)
      return {
        type: ADD_COHORTS,
        cohorts,
      };
    }

    export function onChange_Createuser_Warehouse(warehouse) {
      console.log("ADD_WAREHOUSE",warehouse)
      return {
        type: ADD_WAREHOUSE,
        warehouse,
      };
    }

