// import React from 'react';
// import { Route, Navigate } from 'react-router-dom';

// export default function AuthenticatedRoute({ component: Component, ...rest }) {
//   const isAuthenticated = localStorage.getItem('data');
//   return (
//     <Route {...rest} element={isAuthenticated ? <Component /> : <Navigate to="/" replace />} />
//   );
// }

// import React from 'react';
// import { Route, Navigate } from 'react-router-dom';

// export default function AuthenticatedRoute({ component: Component, ...rest }) {
//   const isAuthenticated = localStorage.getItem('data');

//   if (isAuthenticated) {
//     return <Route {...rest} element={<Component />} />;
//   } else {
//     return <Navigate to="/" replace />;
//   }
// }

// AuthenticatedRoute.jsx
// AuthenticatedRoute.jsx

// AuthenticatedRoute.js
// AuthenticatedRoute.js
// AuthenticatedRoute.js
import { Navigate, Route } from 'react-router-dom';

function AuthenticatedRoute({ element: Element, ...rest }) {
  const isAuthenticated = localStorage.getItem('data');

  return (
    <Route
      {...rest}
      element={
        isAuthenticated ? (
          Element
        ) : (
          <Navigate to="/" replace />
        )
      }
    />
  );
}

export default AuthenticatedRoute;







