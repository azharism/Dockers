import React, { useState, useEffect } from "react";

import "./style.css";

import { createBrowserHistory } from "history";

import { useNavigate } from "react-router-dom";

import Sidebar from "../Sidebar/Sidebar";
import UserDetailsComp from "../UsersRoleComp/UserDetails/component";
import UserPermissionContainer from '../../UserPermission/container'
import { LandingPage } from "../../Auth/Grettingpage/component";

//   return {
//     key,
//     icon,
//     children,
//     label,
//     type,
//   };
// }
// const items = [
//   getItem("Dashboard", "sub1", <RxDashboard style={{ fontSize: "20px" }} />, [
//     getItem("Reports and Analytics", "1"),
//     getItem("Orders", "2"),
//   ]),
//   getItem("Add Center", "sub2", <GrAnnounce style={{ fontSize: "20px" }} />, [
//     getItem("Screensavers", "1"),
//     getItem("Coupons", "2"),
//   ]),
//   getItem(
//     "Wallets and Tags",
//     "sub3",
//     <IoWalletOutline style={{ fontSize: "20px" }} />,
//     [getItem("Daalchini points", "1"), getItem("Tag pay", "2")]
//   ),
//   getItem("Customer Manager", "sub4", <GrCopy style={{ fontSize: "20px" }} />),
//   getItem(
//     "Configuration",
//     "sub5",
//     <SettingOutlined style={{ fontSize: "20px" }} />,
//     [
//       getItem("Vanding machines", "9"),
//       getItem("Cohorts", "10"),
//       getItem("Warehousees", "11"),
//       getItem("Products", "12"),
//     ]
//   ),
//   getItem(
//     "Users and Roles",
//     "sub6",
//     <HiOutlineUserGroup style={{ fontSize: "20px" }} />
//   ),
// ];

// submenu keys of first level
// const rootSubmenuKeys = ["sub1", "sub2", "sub3", "sub4", "sub5"];
const App = ({ props, clear }) => {
  let navigate = useNavigate();
  const handleClose = () => setShow(false);
  const [show, setShow] = useState(false);
  const [openKeys, setOpenKeys] = useState([""]);
  // const [logout, setLogout] = useState(false);
  const history = createBrowserHistory();
  const [apiHit, setApiHit] = useState();

  // const onOpenChange = (keys) => {
  //   const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
  //   if (rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
  //     setOpenKeys(keys);
  //   } else {
  //     setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
  //   }
  // };
  const logout = () => {
    console.log("hello");
    localStorage.removeItem("data");
    localStorage.removeItem("allPermissions");
    // history.push('/')
    navigate("/");
  };
const SidebarSTyle = {
  display: "flex",
  justifyContent: "flex-start ",
  flexDirection: "row",
  margin: "auto",
}


  return (
    <>
      <div
        style={SidebarSTyle}
      >
        <div>
          <section>
            <div>
              <div>
                <div>
                  {/* <Sidebar /> */}
                </div>
              </div>
            </div>
          </section>
        </div>
        <div
          style={{ marginLeft: "120px", width: "1324px", marginTop: "40px" }}
        >
          {/* <UserPermissionContainer /> */}
          {/* <LandingPage/> */}
        </div>
      </div>
    </>
  );
};
export default App;
