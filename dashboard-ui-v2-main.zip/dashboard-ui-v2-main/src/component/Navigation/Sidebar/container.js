import React, { useEffect, useState } from 'react'
import Sidebar from "./component"
import { connect } from 'react-redux';
import { logoutUser, clearState } from "../../../HandleAPICalls/actions"
import App from './component';

const SidebarContainer = (
props

) =>{
    // const logout =()=>{
    //     props.logoutUser()
    //     props.clearState()
        
    //     console.log("clicked logout")
    // }
   
    const [userPermission , setUserPermission] = useState('');
    const [allPermission,setAllPermission ] = useState('')
    useEffect(()=>{
        const userPermission = JSON.parse(localStorage.getItem('data'));
	const allPermission = JSON.parse(localStorage.getItem('allPermissions'));
    setUserPermission(userPermission)
    setAllPermission(allPermission)


    }, [])
    return(
<>
<App

logout={logout}
allPermission={allPermission}
userPermission={userPermission}


/>

</>
    )

    
}
function mapStateToProps({ app }) {
    return {
        app,
       

    };
}
export default connect(mapStateToProps, {
   logoutUser,
   clearState,
    
})(SidebarContainer);