import React, { useState, useEffect } from "react";
import styled from "styled-components";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import avtar2 from "../../../assests/emotions2.svg";
import { useNavigate } from "react-router-dom";
import logo from "../../../assests/Daalchini-logo.svg";
import Avtar from "../../../assests/Avatar.png";
import "./style.css";
import { Link } from "react-router-dom";
import SubMenu from "../Sidebar/SidebarItem";
import { SidebarData } from "./SidebarData";
import { useParams } from "react-router-dom";

export default function Sidebar(data, props) {
  let navigate = useNavigate();
  const { userid } = useParams();
  const handleClose = () => setShow(false);
  const [show, setShow] = useState(false);
  const [openKeys, setOpenKeys] = useState([""]);
  const [sidebar, setSidebar] = useState(false);

  const showSidebar = () => setSidebar(!sidebar);
  const Nav = styled.div`
    height: 80px;
    display: flex;
    justify-content: center;
    align-items: center;
  `;

  const NavIcon = styled(Link)`
    margin-left: 2rem;
    font-size: 2rem;
    height: 80px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
  `;

  const SidebarNav = styled.nav`
    margin-top: -80px;
    width: 250px;
    height: 60vh;
    display: flex;
    justify-content: center;
    margin:auto,
   
   
    left: ${({ sidebar }) => (sidebar ? "0" : "-100%")};
    transition: 350ms;
    z-index: 10;
  `;

  const SidebarWrap = styled.div`
    width: 100%;
  `;

  // const logout = () => {
  //   console.log("hello");
  //   localStorage.removeItem("data");
  //   localStorage.removeItem("allPermissions");

  //   // history.push('/')
  //   navigate("/");
  // };
  const logout = () => {
    localStorage.removeItem("allPermissions");
    localStorage.removeItem("data");

    window.location.href = "/";
  };

  const [openDropdownIndex, setOpenDropdownIndex] = useState(null);

  const handleCloseDropdown = () => {
    setOpenDropdownIndex(null);
  };

  const viewProfile = () => {
    navigate(`/userlist/${195}`);
  };
  return (
    <>
      <div className="side-div1">
        <div className="sidebar">
          <div className="">
            <div className="logo-div">
              <img src={logo} alt="" />
            </div>
            <div className="main-profile">
              {/* <div className="profileDiv">
                <img src={Avtar} alt="" />
               {
                 <div className="designation">
                 <p style={{textTransform:"capitalize"}}>{localStorage.data ? JSON.parse(localStorage.data).details.userDetails.full_name : 'N/A'}</p>
                 <span>{localStorage.data ? JSON.parse(localStorage.data).details.userRole.role_name : 'N/A'}</span>
               </div>
               }
               
              
              </div> */}
              <div className="profileDiv">
                <img src={Avtar} alt="" />
                {localStorage.data && (
                  <div className="designation">
                    <p style={{ textTransform: "capitalize" }}>
                      {
                        JSON.parse(localStorage.data).details.userDetails
                          .full_name
                      }
                    </p>
                    <span>
                      {JSON.parse(localStorage.data).details.userRole.role_name}
                    </span>
                    {/* {JSON.parse(localStorage.data).details.userDetails.status === "active" ? (
        <div className="dot green"><div style={{height:"14px", width:"14px", color:"green",borderRadius:"50%", background:"green", position:"relative", right:"24px"}}></div></div>
      ) : (
        <div className="dot red"><div style={{height:"10px", width:"10px", color:"red", borderRadius:"50%", background:"red"}}></div></div>
      )} */}
                  </div>
                )}
              </div>
              <div className="view-profile">
                <Link
                  to={`/users/userlist/${
                    localStorage.data
                      ? JSON.parse(localStorage.data).details.userDetails.id
                      : "N/A"
                  }`}
                >
                  <div
                    style={{ border: "0.1px solid #ccc", marginTop: "30px" }}
                  >
                    <button className="viewBtn">View Profile</button>
                  </div>
                </Link>
              </div>
            </div>
          </div>

          <div style={{ marginTop: "20px" }}>
           
            {SidebarData.map((item) => (
              <SubMenu
                key={item.title}
                item={item}
                openDropdownIndex={openDropdownIndex}
                setOpenDropdownIndex={setOpenDropdownIndex}
                handleCloseDropdown={handleCloseDropdown}
              />
            ))}
          </div>
        </div>
        <div>
          <div className="logoutOutter">
            <Button
              style={{
                padding: "10px 48px",
                backgroundColor: "#fff",
                fontSize: "18px",
                color: "black",
              }}
              variant="outline-danger"
              size="lg"
              onClick={() => setShow(true)}
            >
              Logout
            </Button>
          </div>
        </div>

        <Modal
          className="logout-main"
          show={show}
          onHide={() => setShow(false)}
        >
          <div className="child-div">
            <div className="child-1">
              <img className="img-avtar" src={avtar2} alt="" />
            </div>

            <div className="child-2">
              <p>Log Out</p>
              <span>Are you sure want to Log Out ?</span>
            </div>
            <div className="logout-btn">
              <Button className="cancelBtn" onClick={handleClose}>
                Cancel
              </Button>
              <Button className="logoutBtn1" onClick={logout}>
                Yes, Logout
              </Button>
            </div>
          </div>
        </Modal>
      </div>
    </>
  );
}
