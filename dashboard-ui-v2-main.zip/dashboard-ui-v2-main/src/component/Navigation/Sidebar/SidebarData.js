import React from 'react'
import dashboard from "../../../assests/dashboard.svg";
import addCenter from "../../../assests/add-center.svg";
import wallets from "../../../assests/wallets-tags.svg";
import customer from "../../../assests/customerM.svg";
import configure from "../../../assests/configuration.svg";
import users from "../../../assests/user-roles.svg";
import {MdOutlineKeyboardArrowDown} from "react-icons/md";
 import {MdOutlineKeyboardArrowUp} from "react-icons/md";
export const SidebarData = [
    {
      title: "Dashboard",
      icon: `${dashboard}`,
      path: "",
      iconClosed:  <MdOutlineKeyboardArrowDown /> ,
      iconOpened: <MdOutlineKeyboardArrowUp />,
      
      subNav: [
        {
          title: "Reports and Analytics",

          path: "/home/reportsandanalytics",
        },
        {
          title: "Orders",

          path: "/home/ordersview",
        },
        {
          title: "Brand Categorization",
          path: "/home/brandcategorization",
        },
        {
          title: "Refill Suggestion",
          path: "/home/refillsuggestion",
        },
       
      ],
      index: 0,
    },
    {
      title: "Add Center",
      icon: `${addCenter}`, 
      iconClosed:  <MdOutlineKeyboardArrowDown /> ,
      iconOpened: <MdOutlineKeyboardArrowUp />,

      subNav : [
        {
          title: "Screensavers",
          path: "/home/addcenter/screensavers",
          cName: "sub-nav",
        },
        {
          title: "Coupons",
          path: "/home/couponcreate",
          cName: "sub-nav",
        },
      ],
      index: 1,
    },
    {
      title: "Wallets and Tags",
      icon: `${wallets}`,
      
      iconClosed:  <MdOutlineKeyboardArrowDown />,
      iconOpened: <MdOutlineKeyboardArrowUp />,
      subNav: [
        {
          title: "Daalchini points",
          path: "/home/walletsandtags/daalchinipoints",
        },

        {
          title: "Tag pay",
          path: "/home/walletandtag/tagpymanagement",
        },
       

      ],
      index: 2,
    },
    
    {
      title: "Customer Manager",
      icon: `${customer}`,
     
      iconClosed:  <MdOutlineKeyboardArrowDown />,
      iconOpened: <MdOutlineKeyboardArrowUp />,
      subNav: [
        {
          title: "BP Management",
          path: "/home/customermanager/bpmanagementlist",
        },

       
      ],
      index: 3,
    },
    {
      title: "Configuration",
      icon: `${configure}`,
    
      iconClosed:  <MdOutlineKeyboardArrowDown /> ,
      iconOpened: <MdOutlineKeyboardArrowUp />,
      subNav: [
        {
          title: "Vending machines",
          path: "/home/configuration/vmlist",
        },
        {
          title: "Cohorts",
          path: "/home/configuration/cohorts",
        },
        {
          title: "Warehouses",
          path: "/home/configuration/warehouse",
        },
        {
          title: "Products",
          path: "/home/configuration/products",
        },
        {
          title: "Manage Partners",
          path: "/home/configuration/managepartners",
        },
      ],
      index: 4,
    },
    {
      title: "Users and Roles",
      icon: `${users}`,
      path: "/home/users/list",
    },
  ];