
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { MdOutlineKeyboardArrowDown, MdOutlineKeyboardArrowUp } from 'react-icons/md';

const SidebarLink = styled(Link)`
  display: flex;
  color: rgba(36, 34, 32, 0.6) !important;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  list-style: none;
  height: 60px;
  text-decoration: none;
  font-size: 18px;
  &:hover {
    background: #f4f2e5;
    border-left: 4px solid #f4de58;
    cursor: pointer;
    color: rgba(36, 34, 32, 0.6);
  }
`;

const SidebarLabel = styled.span`
  margin-left: 12px;
`;

const DropdownLink = styled(Link)`
  height: 40px;
  padding-left: rem;
  display: flex;
  text-align: left;
  background: #fff;
  align-items: center;
  text-decoration: none;
  color: rgba(36, 34, 32, 0.6) !important;
  font-size: 14px;
  &:hover {
    cursor: pointer;
    color: rgba(36, 34, 32, 0.6) !important;
  }
`;

const SubMenu = ({ item, openDropdownIndex, setOpenDropdownIndex, handleCloseDropdown }) => {
  const handleItemClick = (index) => {
    setOpenDropdownIndex((prevIndex) => (prevIndex === index ? null : index));
  };

  return (
    <>
      <SidebarLink to={item.path} onClick={() => handleItemClick(item.index)}>
        <div>
          <img src={item.icon} alt="" />
          <SidebarLabel style={{ fontSize: '17px' }}>{item.title}</SidebarLabel>
        </div>
        <div className="dropdownns">
          {item.subNav && openDropdownIndex === item.index
            ? item.iconOpened
            : item.subNav
            ? item.iconClosed
            : null}
        </div>
      </SidebarLink>
      {item.subNav && openDropdownIndex === item.index && (
        <div>
          {item.subNav.map((subItem, index) => (
            <DropdownLink to={subItem.path} key={index}>
              <SidebarLabel style={{ marginLeft: '34px', width: '220px' }}>
                <input
                  style={{
                    marginLeft: '-18px',
                    marginTop: '4px',
                    cursor: 'pointer',
                  }}
                  type="radio"
                  variant="success"
                />
                {subItem.title}
              </SidebarLabel>
            </DropdownLink>
          ))}
        </div>
      )}
      {openDropdownIndex !== null && <div className="overlay" onClick={handleCloseDropdown} />}
    </>
  );
};

export default SubMenu;
