import React from "react";
import Sidebar from "../../Sidebar/Sidebar";
import "./style.css";
import Button from "react-bootstrap/Button";
import Table from "react-bootstrap/Table";
import leftArrow from "../../../../assests/leftArrow.svg";
import daalchini from "../../../../assests/daalchini.jpg";
import profile from "../../../../assests/gprofile.svg";
import Avatar from "../../../../assests/Avatar.png";
import uid from "../../../../assests/uid.svg";
import phone1 from "../../../../assests/phone11.svg";
import warehouse from "../../../../assests/warehouse.svg";
import mail from "../../../../assests/mail.svg";
import cohorts from "../../../../assests/cohorts.svg";
import watch from "../../../../assests/watch.svg";
import calander from "../../../../assests/calander.svg";
import { Link, useNavigate } from "react-router-dom";
import LoadingSpinner from "../../../Loading/component";
import moment from "moment";
import { useParams } from "react-router-dom";

const UserDetailsComp = ({ data, props, loading }) => {
  const { userid } = useParams();
  console.log("user details data props", data && data.warehouse);
  const navigate = useNavigate();

  const handleBack = () => {
    navigate("/home/users/list");
    console.log("handle back to home ");
  };
  const editBasicDetails = () => {
    navigate("/updateuserdetails");
  };
  const editWarehouse = () => {
    navigate("/addwarehouse");
  };
  const editCohort = () => {
    navigate("/createcohort");
  };
  const imgwidth = {
    width: "26px",
  };
  const colorAccess = { backgroundColor: "rgba(242,186,186, 0.43)", textAlign:"center" };

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>
      {loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
        <div style={{ padding: "10px", marginLeft: "100px" }}>
          <div style={{ marginLeft: "42px" , marginTop:"18px", display:"flex"}}>
          <img
                onClick={handleBack}
                style={{ width: "22px", cursor: "pointer" }}
                src={leftArrow}
                alt=""
              />
            <h2 style={{marginLeft:"10px"}}>
              
              Users Details
            </h2>
          </div>
          <div className="informationDiv">
            {data && data.userDetails && (
              <div className="basicInfo">
                <div className="basicSec">
                  <p style={{ fontSize: "16px" }}>
                    <img src={profile} alt="" /> Basic Information
                  </p>
                  <Button>
                  <Link to={`/updateuserdetails/${userid}`}
                    style={{ padding: "4px 20px", fontSize: "14px", textDecoration:"none", color:"#fff"}}
                    variant="outline-primary"
                   
                  >
                 Edit 
                  </Link>
                  </Button>
                 
                </div>
                {console.log("heloooo ---> ", data.data)}

                <div className="backgroundImg">
                  <div className="right-divactive" style={{ display: "flex" }}>
                    <div className="activeDiv">
                      <div className="designationD">
                        <img
                          style={{
                            width: "78px",
                            height: "79px",
                            borderRadius: "36.22214px",
                          }}
                          src={Avatar}
                          alt=""
                        />

                        <div style={{ marginRight: "20px", width: "210px" }}>
                          <p>{data && data.userDetails.full_name}</p>
                          <span
                            style={{
                              fontSize: "14px",
                              color: "rgba(61,61,61, 0.7)",
                            }}
                          >
                            {data && data.userRole.role_name}
                          </span>
                        </div>
                        <div className={data && data.userDetails.status=== "active" ?"activeBtn": "deactiveBtn" }>
                          <p>{data && data.userDetails.status }</p>
                        </div>
                      </div>
                    </div>
                    <div className="detailsDiv">
                      <div className="detailsItem">
                        <div className="detailsItemDiv">
                          <img style={imgwidth} src={uid} alt="" />
                          <p>User ID : {data && data.userDetails.id}</p>
                        </div>

                        <div className="detailsItemDiv">
                          <img style={imgwidth} src={phone1} alt="" />
                          <p>{data && data.userDetails.mobile}</p>
                        </div>
                        <div className="detailsItemDiv">
                          <img style={imgwidth} src={mail} alt="" />
                          <p>{data && data.userDetails.email}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="loginDiv">
                    <div className="lastlogeDiv">
                      <div className="loggedDiv">
                        <img src={watch} alt="" />
                        <p>
                          {moment
                            .utc(data && data.userDetails.since)
                            .local()
                            .format("DD/MM/YYYY HH:mm:ss A")}
                        </p>
                      </div>
                      <div className="loggedDiv">
                        <img src={calander} alt="" />
                        <p>
                          {moment
                            .utc(data && data.userDetails.last_login)
                            .local()
                            .format("DD/MM/YYYY HH:mm:ss A")}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {/* Warehouse start */}

            {data && data.warehouse && (
              <div className="warehouseInfo">
                <div className="warehouseSec">
                  <p style={{ fontSize: "16px" }}>
                    <img src={warehouse} alt="" /> Warehouse
                  </p>
                  <Button style={{color:"#fff"}}>
                  <Link to={`/updatewarehouse/${userid}`}
                    style={{ padding: "4px 20px", fontSize: "14px", textDecoration:"none", color:"#fff"}}
                    variant="outline-primary"
                   
                  >
                 Edit 
                  </Link>
                  </Button>
                  
                </div>
                <div>
                  <p className="warehouseText">
                    The user is added in the below warehouse
                  </p>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: "100px",
                    }}
                  >
                    <div>
                      <h2 style={{ fontSize: "22px", textAlign: "center" }}>
                        {data && data.warehouse.name}
                      </h2>
                      <p style={{ fontSize: "18px", textAlign: "center" }}>
                        {data && data.warehouse.id}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Cohorts section start */}
          </div>

          <div className="cohortsDetails">
            <div className="cohortsSec">
              <p style={{ fontSize: "16px" }}>
                <img src={cohorts} alt="" /> Cohorts
              </p>
              <Button style={{color:"#fff"}}>
              <Link to={`/updatecohortdetails/${userid}`}
                    style={{ padding: "4px 20px", fontSize: "14px", textDecoration:"none", color:"#fff"}}
                    variant="outline-primary"
                   
                  >
                 Edit 
                  </Link>
              </Button>
              
            </div>
  {/* cohort section */}
            <div>
              <p className="cohortsPara">
                The user is added in the below cohorts
              </p>
              <Table
                striped
                hover
                style={{ padding: "20px", height: "300px" }}
                className="scrolldown1"
              >
                <thead>
                  <tr>
                    <th>Cohort ID</th>
                    <th>Cohort Name</th>
                    <th>Area Name</th>
                    <th>Cohort Type</th>
                  </tr>
                </thead>
                <tbody>
                  {data &&
                    data &&
                    data.cohorts.map((item) => {
                      return (
                        <tr>
                          <td style={{ textAlign: "center" }}>{item.id}</td>
                          <td style={{ textAlign: "center" }}>{item.name}</td>
                          <td style={{ textAlign: "center" }}>
                            {item.area_name}
                          </td>
                          <td  >
                            <div style={colorAccess} className="citypayout">
                              <p >{item.cohort_type_name}</p>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </Table>
            </div>
          </div>

          {/* cohort finished */}
        </div>
      )}
    </div>
  );
};

export default UserDetailsComp;
