import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import UserDetailsComp from "./component";
import { useParams } from "react-router-dom";

const UserBasicContainer = (props) => {

  const { userid } = useParams();
  console.log("user id khan", userid)
    const [details, setBasicDetails] = useState();
    const [loading, setLoading] = useState(true)
    
console.log(("whatsapp",props.match))
    useEffect(()=>{
        LoadBasicDetails()
    },[])
   
    const LoadBasicDetails = () => {
        return props.getDataFromAPI(
          `/dashboard/api/v2/admin/users/details?userId=${userid}`,
          "GET",
          undefined,
          (response) => {
            setLoading(false)
            setBasicDetails(response);
            console.log("response---------> details", response);
           
          },
          (err) => {},
          true
        );
      };
  return (
   <UserDetailsComp
 data={details}
 loading={loading}
   />
  )
}

function mapStateToProps({ props }) {
    return {
      props,
    };
  }
  export default connect(mapStateToProps, {
    getDataFromAPI,
  })(UserBasicContainer);
