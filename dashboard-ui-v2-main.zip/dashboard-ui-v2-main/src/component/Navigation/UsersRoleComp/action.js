import { SET_LOADING, SAVE_DATA, SET_FILTER, SET_ACTIVE_PAGE } from './constants';

export function setLoading(isLoading) {
  return {
    type: SET_LOADING,
    isLoading
  };
}

export function saveData(data) {
  return {
    type: SAVE_DATA,
    data
  };
}

export function setFilter(filter) {
  return {
    type: SET_FILTER,
    filter
  };
}

export function setActivePage(pageNumber) {
  return {
    type: SET_ACTIVE_PAGE,
    pageNumber
  };
}
