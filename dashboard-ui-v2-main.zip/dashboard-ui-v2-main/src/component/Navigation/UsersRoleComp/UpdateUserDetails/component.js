import React, { useState } from "react";
import "./component.css";
import Sidebar from "../../Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import TextField from "@mui/material/TextField";
import SingingContract from "../../../../assests/SingingContract.svg";
import { Button } from "@mui/material";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Chip from "@mui/material/Chip";
import Box from "@mui/material/Box";
import LoadingSpinner from "../../../Loading/component";
import { Height } from "@mui/icons-material";

const UserBasciDetailsComponent = (props) => {
  console.log("basic role", props.basicRole);

  const navigate = useNavigate();
  // const history = useHistory();

  const handleClick = () => {
    navigate(-1);
  };
  // const arrowClick = () => {
  //   navigate("/");
  // };
  const goback = () => {
    navigate(-1);
  };

  return (
    <>

    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Basic Details
          </h2>
        </div>
        <div className="bDetrails-div">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              width: "1328px",
            }}
          >
            <div>
              <div className="user-status-main">
                <span>User status</span>
              </div>

              <Box
                sx={{
                  width: 500,
                  maxWidth: "100%",
                  marginTop: "39px",
                  alignItems: "flex-start",
                }}
              >
             
                <div className="operation-div">
                  <button
                    onClick={props && props.handleButtonsUpdate}
                    value={"active"}
                    className={"active-btn"}
                    style={{
                      border:
                        props &&
                        props.userStatus == "active" &&
                        "1px solid blue",
                      color: props && props.userStatus == "active" && "blue",
                    }}
                  >
                    ACTIVE
                  </button>
                  <button
                    onClick={props && props.handleButtonsUpdate}
                    value={"deleted"}
                    className="inactive-btn"
                    style={{
                      border:
                        props &&
                        props.userStatus !== "active" &&
                        "1px solid red",
                      color: props && props.userStatus !== "active" && "red",
                    }}
                  >
                    INACTIVE
                  </button>
                </div>

                <TextField
                  style={{ margin: "20px", padding: "0px" }}
                  fullWidth
                  label="Full Name"
                  id="fullWidth"
                  value={props && props.userName}
                  onChange={(e) => {
                    props.handleUpdateUserName(e);
                  }}
                />

                {/* <FormControl
                  style={{ margin: "14px", padding: "0px" }}
                  fullWidth
                >
                  <InputLabel id="demo-simple-select-label">Role</InputLabel>
                  <Select
                    placeholder="Select Role"
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={props && props.userRole.roleName}
                    select
                    size="small"
                    search
                    style={{ borderRadius: "70px", height: "150px !important" }}
                  >
                    {props.basicRole.map((el, index) => {
                      return (
                        <MenuItem
                          value={index}
                          onClick={(e) => {
                            props.handleUpdateUserRole(e, el.id);
                          }}
                        >
                          {el.name}
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl> */}
                <FormControl   style={{ margin: "14px", padding: "0px" }}
                   fullWidth>
            <InputLabel id="demo-simple-select-label">Role</InputLabel>
            <Select 
            
            placeholder="Select Role"
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={props && props.userRole.roleName}
              label="Role"
              select
              size="small"
              className="selectrole"
              style={{ borderRadius: "70px", height: "150px !important" }}
            >
              {props.basicRole.map((el, index) => {
                      return (
                        <MenuItem
                          value={index}
                          onClick={(e) => {
                            props.handleUpdateUserRole(e, el.id);
                          }}
                        >
                          {el.name}
                        </MenuItem>
                      );
                    })}
            </Select>
          </FormControl>
                <TextField
                  style={{ margin: "14px", padding: "0px", color: "#b2b2b2" }}
                  fullWidth
                  label="Email ID"
                  id="fullWidth"
                  value={props && props.userEmail}
                  onChange={(e) => {
                    props.handleUpdateUserEmail(e);
                  }}
                />
              </Box>
              <Box className="usersrolebtn">
                <Button className="backbtn" onClick={goback}>
                  Back
                </Button>

                <Button className="savebtnupdate" onClick={props.UpdateUserApi}>
                  save
                </Button>
              </Box>
            </div>
            <div style={{ margin: "auto" }}>
              <img src={SingingContract} alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>

    </>
    
  );
};
export default UserBasciDetailsComponent;
