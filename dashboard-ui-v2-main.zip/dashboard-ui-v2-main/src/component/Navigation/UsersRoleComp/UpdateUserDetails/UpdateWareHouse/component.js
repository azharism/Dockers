import React, { useState } from "react";
import "./componentWarehouse.css";
import search from "../../../../../assests/search.svg";
import filter from "../../../../../assests/filterIcon.svg";
import Table from "react-bootstrap/Table";
import Radio from "@mui/material/Radio";
import Form from "react-bootstrap/Form";
import { success } from "toastr";
import Box from "@mui/material/Box";
import { Button } from "@mui/material";
import Sidebar from "../../../Sidebar/Sidebar";
import leftArrow from "../../../../../assests/leftArrow.svg";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import LoadingSpinner from "../../../../Loading/component";

export const UpdateWarehouseComponent = (props) => {
  const navigate = useNavigate();
  const { userid } = useParams();
  const [open, setOpen] = useState();
 
  const handleSaveClick = () => {
    props.UpdateUserwarehouseApi();
    navigate(-1)
    return toastr.success("Warehouse Update")
   
  };


  
  const radioChange = () => {
    setOpen(!open);
  };
  console.log("data", props.data);
  const [selectedValue, setSelectedValue] = React.useState("a");
  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };
  const controlProps = (item) => ({
    checked: selectedValue === item,
    onChange: handleChange,
    value: item,
    name: "color-radio-button-demo",
    inputProps: { "aria-label": item },
  });
  const backUpdateWarehouse = () => {
    navigate(-1);
  };
  const buttonClassNameWarehouse = props.isRadioClicked ? "saveWarehousebtn0 active" : "saveWarehousebtn1 inactive";

  return (
    <>
      <div className="main-div">
        <div>
          <Sidebar />
        </div>
        {props.loading ? (
          <>
            <LoadingSpinner />
          </>
        ) : (
          <div className="cohortsec">
            <div>
              <div className="searchDivision">
                <input
                  type="search"
                  placeholder="Search by Warehouse Name/ Warehouse ID"
                />
                <img className="warehousesearchIcon" src={search} alt="" />
              </div>

              <div
                style={{
                  padding: "14px",
                  borderRadius: "14px",
                  width: "100%",
                }}
              >
                <Table striped hover className="scrolldown">
                  <thead>
                    <tr>
                      <th>Warehouse ID</th>
                      <th>Warehouse Name</th>
                      <th>Area Name</th>

                      <th> select</th>
                    </tr>
                  </thead>
                  <tbody style={{position:"relative"}}>
                    {props.data &&
                      props.data &&
                      props.data.length &&
                      props.data.map((el) => {
                        return (
                          <tr key={el.id} style={{ textAlign: "left" }}>
                            <td>{el.warehouseId}</td>
                            <td style={{ textAlign: "left" }}>
                              {el.warehouseName}
                            </td>
                            <td style={{ textAlign: "left" }}>
                              {el.warehouseCity}
                            </td>

                            <td>
                              <input
                                variant="success"
                                style={{ width: "20px", height: "20px" }}
                                type="radio"
                                onClick={(event) =>
                                  props.handleRadioChange(event, el.warehouseId)
                                }
                                name="radio-group"
                              />

                              {/* <input
                                variant="success"
                                style={{ width: "20px", height: "20px" }}
                                type="radio"
                                onClick={(event) =>
                                  props.handleRadioChange(event, el.warehouseId)
                                }
                                name="radio-group"
                                value={el.warehouseId} // set the value of the radio button to the warehouse ID
                                checked={
                                  props.warehouseValue === el.warehouseId
                                } // set the checked attribute based on the selected warehouse value
                              
                              /> */}
                              {/* {console.log("warehousevalue", props.warehouseValue)} */}
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </Table>
              </div>
            </div>
        
            <Box className="usersrolebtn">
              <Button className="backbtn" onClick={backUpdateWarehouse}>
                Back
              </Button>

              {/* <Button
                className={buttonClassNameWarehouse}
                onClick={handleSaveClick}
                disabled={!props.isRadioClicked}
                style={{color:"#111"}}
              >
               
                  Save
               
              </Button> */}
              <Button  
                onClick={handleSaveClick}
                disabled={!props.isRadioClicked}   className={props.isRadioClicked ? "ButtonSaveWarehouse Active" : "ButtonSaveWarehouse Disabled"}> save</Button>
            </Box>
          </div>
        )}
      </div>
    </>
  );
};
