import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import { getDataFromAPI } from "../../../../../HandleAPICalls/actions";
import { UpdateWarehouseComponent } from "./component";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useHistory } from "react-router-dom";
const UpdateWarehouseContainer = (props) => {
  // const history = useHistory();
  const { userid } = useParams();
  const [warehouseData, setwarehouseData] = useState();
  const [loading, setLoading] = useState(false);
  const [updateWarehouse, setUpdateWarehouse] = useState();
  const [warehouseValue, setWarehouseValue] = useState([]);
  const [warehouseId, setWarehouseId]= useState()
  const [isRadioClicked, setIsRadioClicked] = useState(false);

  const navigate = useNavigate();
  
  console.log("warehosuevalue", warehouseValue)
  
  useEffect(() => {
    console.log("warehouse");

    props.getDataFromAPI(
      "/partner/api/v2/warehouse/list",
      "GET",
      undefined,
      (response) => {
        console.log("warehouse", response.list);
        setwarehouseData(response);
      },
      (err) => {
        console.log("errrororororooro", err);
        toastr.error(
          "Failed",
          "Unable to fetch vending machine warehouse listing"
        );
      }
    );
  }, []);
  
  // const warehouseError = ()=>{
  //   if (!warehouseId=== ""){
  //     return toastr.warning("plz choose any warehouseid")
  //   }
  // }

  const UpdateUserwarehouseApi = () => {
  
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/${userid}`,
      "PATCH",
       {warehouseId: warehouseId} ,
      (response) => {
        console.log("update warehouse USer response--------", response);
        setUpdateWarehouse(response);
        setLoading(true);
      //  navigate("/userlist")
       
      }
    );
  };
  
  const handleWarehouse = (e, warehouseId) => {
    setIsRadioClicked(true);
    setWarehouseId(warehouseId);
   
    console.log("handleWarehouse id", warehouseId);
  };
 

  return (
    <UpdateWarehouseComponent
      loading={loading}
      data={warehouseData}
      
      handleRadioChange={handleWarehouse}
      updateWarehouse={updateWarehouse}
      UpdateUserwarehouseApi={UpdateUserwarehouseApi}
      warehouseValue={warehouseValue}
      warehouseId={warehouseId}
      isRadioClicked={isRadioClicked}
    />
  );
};
function mapStateToProps({ props }) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(UpdateWarehouseContainer);
