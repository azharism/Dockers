import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";

import { Navigate, useNavigate, useParams } from "react-router-dom";
import UserBasciDetailsComponent from "./component";
import { toastr } from "react-redux-toastr";

const UserBasicDetailsContainer = (props) => {
  const [basicRole, setBasicRole] = useState([]);
  const [updateUser, setUpdateUser] = useState();
  const [fullName, setUpdateName] = useState();
  const [roleId, setUpdateRole] = useState();
  const [email, setUpdateEmail] = useState();
  const [updateStatus, setUpdateStatus] = useState();
  const [loading, setLoading] = useState();
  const [status,setStatus] = useState();
  const [details, setEditBasicDetails] = useState();
  const { userid } = useParams();
  const navigate = useNavigate();
  const [userStatus,setUserStatus]=useState('')
  const [userName,setUserName]=useState('')
  const [userRole,setUserRole]=useState('')
  const [userEmail,setUserEmail]=useState('')


  // const handleButtonsUpdate = (e) => {
  //   console.log("handleButtons",e.target.value)
  //   if (e.target.value === "active") {
  //     setUserStatus("active")
  //   } else if (e.target.value === "deleted") {
  //     setUserStatus("deleted")
  //   }
  // };
  // const handleButtonsUpdate = (e) => {
  //   if (e.target.value === "active") {
  //     setUserStatus("active");
  //   } else if (e.target.value === "deleted") {
  //     setUserStatus("deleted");
  //   }
  // };
  const handleButtonsUpdate = (e) => {
    const buttonValue = e.target.value;
    setUserStatus(buttonValue);
  };

  useEffect(()=>{
    EditBasicDetails()
},[])

const EditBasicDetails = () => {
    return props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/details?userId=${userid}`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        setEditBasicDetails(response.userDetails);
        console.log("response---------> details-----------", response);
        setUserStatus(response.userDetails.status)
       setUserName(response.userDetails.full_name)
       setUserRole({roleName:response.userRole.role_name,roleId:response.userRole.role_id})
       setUserEmail(response.userDetails.email)
       
      },
      (err) => {},
      true
    );
  };

  
  
  useEffect(() => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/users/roles/all",
      "GET",
      undefined,
      (response) => {
        console.log(
          "roleList---container  user role responseer",
          response.list
        );
        setBasicRole(response.list);
      }
    );
  }, []);

  const handleUpdateUserStatus = (status) => {
    setUserStatus(status);
  };
  
  
  

  const handleUpdateUserName = (e) => {
    console.log("username", e.target.value);
    setUserName(e.target.value);
  };

  const handleUpdateUserRole = (e, id) => {
    console.log("userid", id);
    setUserRole(parseInt(id));
  };

  const handleUpdateUserEmail = (e) => {
    console.log("useremail", e.target.value);
    setUserEmail(e.target.value);
  };
  // const handleUpdateUserStatus = (e) => {
  //   console.log("username", e.target.value);
  //   setUpdateStatus(e.target.value);
  // };

 

  const UpdateUserApi = () => {
    
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/${userid}`,
      "PATCH",
      { 
        
        fullName: userName,
        roleId: userRole,
        email: userEmail,
     status: userStatus
       
      },
      (response) => {
        console.log("update User response--------", response);
        setUpdateUser(response);
        setLoading(true);
        toastr.success("Details Updated")
        navigate("/home/users/list");
      }
    );
  };

  return (
    <UserBasciDetailsComponent
      loading={loading}
      basicRole={basicRole}
      handleUpdateUserName={handleUpdateUserName}
      handleUpdateUserRole={handleUpdateUserRole}
      handleUpdateUserEmail={handleUpdateUserEmail}
      updateUser={updateUser}
      UpdateUserApi={UpdateUserApi}
      handleUpdateUserStatus={handleUpdateUserStatus}
      handleButtonsUpdate={handleButtonsUpdate}
      status={status}
      basicdetails={details}
      userStatus={userStatus}
      userName={userName}
      userEmail={userEmail}
      userRole={userRole}
    />
  );
};

function mapStateToProps({ props }) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(UserBasicDetailsContainer);
