import {isCHECKBOX} from "./constant"
const initialState = {
    isCheck :"",

}
export default (state= initialState, action)=>{
    console.log("icheckboxCheck/reducer----", action)
switch(action.type){
    case isCHECKBOX:
        console.log("icheckboxCheck")
        return{
            ...state,
            isCheck:action.check
        }
        default:
            return state;
}
}