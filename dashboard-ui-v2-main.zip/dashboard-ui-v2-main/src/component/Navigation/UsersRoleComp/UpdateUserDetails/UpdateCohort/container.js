import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { toastr } from "react-redux-toastr";
// import { getDataFromAPI } from "../../HandleAPICalls/actions";
import { getDataFromAPI } from "../../../../../HandleAPICalls/actions";
import { UpdateCohortComp, stagecohortsTypes } from "./component";
import { Link, useNavigate, useParams } from "react-router-dom";
// import { stagecohortsTypes } from './component';
import PropTypes from "prop-types";
const UpdateCohortContainer = (props) => {
  const stagecohortsTypes = [
    {
      id: 1,
      name: "mobility",
    },
    {
      id: 2,
      name: "franchisee_payouts",
    },
    {
      id: 3,
      name: "meals",
    },
    {
      id: 4,
      name: "city_payouts",
    },
    {
      id: 5,
      name: "df_access",
    },
  ];

  const { userid } = useParams();
  const { id } = useParams();

  const [data, setData] = useState([]);
  // const [filteredData, setFilteredData] = useState([]);

  const [searchCohortList, setSearchCohortList] = useState([]);
  const [searchCohortValue, setSearchCohortValue] = useState([]);
  const [searchCohortData, setSearchCohortData] = useState(null);
  const [addedVmCohortIds, setIsCheck] = useState([]);
  const [userdetailsCohort, setUserdetailsCohort] = useState([]);
  const [updateCohort, setUpdateCohort] = useState();
  const [filterCohortType, setFilterCohortType] = useState(null);
  const [updateUser, setUpdateUser] = useState([]);
  const [removedVmCohortIds, setRemovedVmCohortIds] = useState([]);
  const [cohortVMTypeData, setCohortVMTypesData] = useState([]);
 
  const [filterCohortData, setFilterCohortData] = useState([]);
  const [activeCohortType, setActiveCohortType] = useState("");
  const navigate = useNavigate();
  let cohortsarray = [];
  console.log("filterCohorttype", filterCohortData);
  useEffect(() => {
    userBasicDetailsCohort();
    // errorHandle()
  }, []);

  const userBasicDetailsCohort = () => {
    return props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/details?userId=${userid}`,
      "GET",
      undefined,
      (response) => {
        setUserdetailsCohort(response.cohorts);
        console.log("response Cohort---------> details", response.cohorts);
      },
      (err) => {},
      true
    );
  };

  useEffect(() => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/vendingmachines/vm-cohorts",
      "GET",
      undefined,
      (response) => {
        console.log("update  cohorts length", response.list.length);
        setData(response.list);
        //console.log("dataaaa",data)
        if (response.list.success) {
          navigate("/");
        }
      },
      (err) => {
        console.log("errrororororooro", err);
        toastr.error(
          "Failed",
          "Unable to fetch vending machine cohort  listing"
        );
      }
    );
  }, []);

  const addCohorthandleClick = React.useCallback(
    (e) => {
      console.log("removedVmCohortIds addddd");
      const { id, checked } = e.target;

      if (checked) {
       
        const updatedAddedVmCohortIds = [...addedVmCohortIds, parseInt(id)];
        setIsCheck(updatedAddedVmCohortIds);

        
        const updatedUserdetailsCohort = [
          ...userdetailsCohort,
          { id: parseInt(id) },
        ];
        setUserdetailsCohort(updatedUserdetailsCohort);
      } else {
       
      }
    },
    [addedVmCohortIds, userdetailsCohort]
  );
console.log("user details", userdetailsCohort)
  const removedCohort = (e, id) => {
    const updatedAddedVmCohortIds = addedVmCohortIds.filter(
      (dataId) => dataId !== parseInt(id)
    );
    setIsCheck(updatedAddedVmCohortIds);

    const updatedUserdetailsCohort = userdetailsCohort.filter(
      (data) => data.id !== parseInt(id)
    );
    setUserdetailsCohort(updatedUserdetailsCohort);

    const updatedRemovedVmCohortIds = [...removedVmCohortIds, parseInt(id)];
    setRemovedVmCohortIds(updatedRemovedVmCohortIds);
  };

  const updateuserCohort = () => {
    console.log("update user cohort");

    const requestData = {
      addedVmCohortIds: addedVmCohortIds,
      removedVmCohortIds: removedVmCohortIds,
    };

    props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/${userid}`,
      "PATCH",
      requestData,
      (response) => {
        console.log("update User response--------", response);
        setUpdateUser(response);
        if (response.success) {
          navigate("/users/userlist");
        }
      }
    );
  };

  const onCohortSearch = (e) => {
    const searchName = e.target.value;
    console.log("search name", searchName);
    setSearchCohortValue(searchName);
    searchCohort(searchName);
  };

  const searchCohort = (searchCohortValue) => {
    setSearchCohortData(searchCohortValue);
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts?search_query=${searchCohortValue}`,
      "GET",
      undefined,
      (response) => {
        console.log("Ankit get response", response.list);
        setSearchCohortList(response);
        console.log("SEARCH RES----->", response.list);
      },
      (err) => {}
    );
  };


  const handleCohortTypeClick = (id) => {
    console.log("Clicked on cohort type with ID:", id);

    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts?associated_user_id=${userid}` +
        (id ? `&cohort_type_id=${id}` : ""),
      "GET",
      undefined,
      (response) => {
        console.log("Response from API:", response.list);

        setData(response.list);

        let filteredData = response.list;
        if (id) {
          filteredData = filteredData.filter((cohort) => cohort.type === id);
          console.log("filteredData12", filteredData);
        }

        if (filteredData.length > 0) {
         
          setFilterCohortData(filteredData);
          setActiveCohortType(id);
        }
      },
      (err) => {
        console.error(err);
      }
    );
  };

  
  console.log("searchCohortData:", searchCohortData);

  const FilterCohortData = data
  .filter(
    (vmlist) =>
      !searchCohortData ||
      (vmlist.name.toLowerCase().includes(searchCohortData.toLowerCase()) ||
        vmlist.id.toString().includes(searchCohortData))
  )
  .filter(
    (cohort) =>
      !activeCohortType || cohort.type === activeCohortType
  );


  return (
    <UpdateCohortComp
      Search={searchCohort}
      //filterData={filterData}
      FilterCohortData={FilterCohortData}
      addCohorthandleClick={addCohorthandleClick}
      addedVmCohortIds={addedVmCohortIds}
      data={data}
      removedVmCohortIds={removedVmCohortIds}
      updateuserCohort={updateuserCohort}
      userdetailsCohort={userdetailsCohort}
      filterCohortType={filterCohortType}
      cohortVMTypeData={cohortVMTypeData}
      removedCohort={removedCohort}
      stagecohortsTypes={stagecohortsTypes}
      handleCohortTypeClick={handleCohortTypeClick}
      activeCohortType={activeCohortType}
      //  setActiveCohortType={setActiveCohortType}
    />
  );
};
function mapStateToProps({ props }) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(UpdateCohortContainer);
