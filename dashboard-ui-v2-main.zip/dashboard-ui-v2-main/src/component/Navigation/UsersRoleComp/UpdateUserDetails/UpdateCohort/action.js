import {ADD_ISCHECK} from "./constant"
export function onChange_check(isCheck){
    return{
        type: ADD_ISCHECK,
        isCheck,
    }
}