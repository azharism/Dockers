import React, { useState } from "react";
import Table from "react-bootstrap/Table";
import "./component.css";
import Dropdown from "react-bootstrap/Dropdown";
// import Table from "react-bootstrap/Table";
import Box from "@mui/material/Box";
import Button from "react-bootstrap/Button";
import eyeIcon from "../../../../../assests/eyeIcon.svg";
import search from "../../../../../assests/search.svg";
import filter from "../../../../../assests/filterIcon.svg";
import Sidebar from "../../../Sidebar/Sidebar";
import { toastr } from "react-redux-toastr";
import { Link, useNavigate } from "react-router-dom";

export const UpdateCohortComp = (props, isCheck) => {
  // const [activeCohortType, setActiveCohortType] = useState(null);
  console.log("filter cohort data 111111111", props.userdetailsCohort);
  const navigate = useNavigate();
  const cohortBack = () => {
    navigate(-1);
  };


  const handleSaveClick = () => {
    props.updateuserCohort()
    navigate(-1)
    return toastr.success("cohort update")
   
  };

  return (
    <>
      <div className="main-div">
        <div>
          <Sidebar />
        </div>
        <div className="cohortsec">
          <div style={{ width: "100%" }}>
            <div className="searchDivision">
              <input
                type="search"
                placeholder="Search by Cohort Name/ Cohort ID"
                onChange={(e) => {
                  props.Search(e.target.value);
                }}
              />
              <img className="cohortupdatesearchIcon" src={search} alt="" />
            </div>

            <div
              style={{
                // backgroundColor: "#ffffff",
                padding: "14px",
                borderRadius: "14px",
              }}
            >
              <Table striped className="scrolldown">
                <thead>
                  <tr style={{ border: "none" }}>
                    <th>Cohort ID</th>
                    <th>Cohort Name</th>

                    <th>Area Name</th>

                    <th>
                      <Dropdown
                        className="cohort-type1"
                        style={{ border: "none !important" }}
                      >
                        <Dropdown.Toggle
                          variant="none"
                          className="dropdown-toggle"
                          id="dropdown-basic"
                        >
                          <img
                            style={{ marginLeft: "48px", border: "none" }}
                            src={filter}
                            alt=""
                          />{" "}
                          <span
                            style={{
                              marginBottom: "-30px ",
                              position: "absolute",
                              left: "90px",
                              bottom: "30px",
                              color: "black",
                              fontSize: "17px",
                            }}
                          >
                            Cohort Type
                          </span>
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                          {props.stagecohortsTypes &&
                            props.stagecohortsTypes.map((item) => (
                              <Dropdown.Item
                                key={item.id}
                                id={item.id}
                                active={props.activeCohortType === item.id}
                                onClick={() => {
                                  console.log(
                                    "Clicked on cohort type:",
                                    item.id
                                  );
                                  props.handleCohortTypeClick(
                                    item.id,
                                    item.type
                                  );
                                }}
                              >
                                {item.name}
                              </Dropdown.Item>
                            ))}
                        </Dropdown.Menu>
                      </Dropdown>
                    </th>

                    <th></th>
                  </tr>
                </thead>

                <tbody>
                  {props.FilterCohortData &&
                    props.FilterCohortData.length > 0 &&
                    props.FilterCohortData.map((el, index, cohort) => (
                      <tr key={el.id}>
                        <td style={{ textAlign: "left" }}>{el.id}</td>
                        <td style={{ textAlign: "" }}>{el.name}</td>
                        <td style={{ textAlign: "left" }}>{el.area_name}</td>
                        <td style={{ textAlign: "left" }} className="ctypes">
                          {el.type}
                        </td>
                        <td>
                          <div>
                            <input
                              id={el.id}
                              style={{
                                height: "18px",
                                width: "30px",
                                marginLeft: "20px",
                              }}
                              type="checkbox"
                              onChange={(e) => {
                                if (
                                  props.userdetailsCohort?.find(
                                    (dt) => dt.id === el.id
                                  )
                                ) {
                                  props.removedCohort(e, el.id);
                                } else {
                                  props.addCohorthandleClick(e);
                                }
                              }}
                              checked={props.userdetailsCohort?.find((dt) =>
                                dt.id === el.id ? true : false
                              )}
                            />
                          </div>
                        </td>
                      </tr>
                    ))}
                  {console.log(
                    "filterCohortData response",
                    props.filterCohortData
                  )}
                </tbody>
              </Table>
            </div>
          </div>
          <Box className="usersrolebtn">
            <Button
              className="backbtn"
             
              onClick={cohortBack}
            >
              Back
            </Button>

            <Button className="savebtnupdate" onClick={ handleSaveClick}>
              {/* <Link
                to={"/users/list"}
                style={{
                  textDecoration: "none",
                  color: "#fff",
                  fontSize: "14px",
                }}
              >
                save
              </Link> */}
              save
            </Button>
          </Box>
        </div>
      </div>
    </>
  );
};
