import { SET_LOADING, SAVE_DATA, SET_FILTER, SET_ACTIVE_PAGE } from './constants';
import { CLEAR_STATE } from '../HandleAPICalls/constants';

const initialState = {
  loading: true,
  userList: [],
  filter: '',
  activePage: 1
};

export default function (state = initialState, action) {
  switch (action.type) {
    case SET_LOADING:
      return {
        ...state,
        loading: action.isLoading
      };

    case SAVE_DATA:
      return {
        ...state,
        userList: action.data
      };

    case SET_FILTER:
      return {
        ...state,
        filter: action.filter
      };

    case SET_ACTIVE_PAGE:
      return {
        ...state,
        activePage: action.pageNumber
      };

    case CLEAR_STATE:
      return initialState;

    default:
      return state;
  }
}
