export const SET_LOADING = '@users/SET_LOADING';
export const SAVE_DATA = '@users/SAVE_DATA';
export const SET_FILTER = '@users/SET_FILTER';
export const SET_ACTIVE_PAGE = '@users/SET_ACTIVE_PAGE';
