import React from "react";
import Dropdown from "react-bootstrap/Dropdown";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import eyeIcon from "../../../assests/eyeIcon.svg";
import search from "../../../assests/search.svg";
import filter from "../../../assests/filterIcon.svg";
import { useNavigate } from 'react-router-dom';
import "./style.css";

const UsersroleList = ({
  loading,
  usersList,
  totalPages,
  activePage,
  onPageChange,
  onClickOfDelete,
  history,
  limit,
  totalCount,
}) => {
  const navigate= useNavigate();
  const handleClick = ()=>{
    navigate('/userdetails')
  }
  return (
    <div>
      <div style={{ height: "150px" }}>
        <div>
          <h2 className="userHeading">Users & Roles</h2>
        </div>
        <div className="searchbar">
          <div
            className="searchDiv"
            style={{ width: "435px", backgroundColor: "#f3f3f3" }}
          >
            <input
              type="search"
              placeholder="search by Full name / Mobile number"
            style={{color:"black"}}
            />
            <img src={search} alt="" />
          </div>
          <Button style={{ fontSize: "14px" }} variant="primary" size="lg">
            {" "}
            + Add User{" "}
          </Button>{" "}
        </div>
      </div>
      {/* <div
        style={{
          backgroundColor: "#ffffff",
          padding: "14px",
          borderRadius: "14px",
        }}
      >
        <Table striped>
          <thead>
            <tr>
              <th>S.No</th>
              <th>Full Name</th>
              <th>User ID</th>
              <th>Mobile Number</th>
              <th >
                <Dropdown
                  style={{
                    justifyContent: "start",
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "start",
                    position:"absolute",
                   
    marginLeft: "-39px",
    marginTop: "-20px"

                  }}
                >
                  <Dropdown.Toggle
                    variant="secondary"
                    style={{
                      display: "flex",
                      alignItems: "center",
                      backgroundColor: "#fff",
                      border: "none",
                      justifyContent: "start",
                    }}
                    id="dropdown-basic"
                  >
                    <img style={{border:"none"}} src={filter} alt="" /> 
                  </Dropdown.Toggle>
                  Role
                  <Dropdown.Menu>
                    <Dropdown.Item href="#/action-1" active={true} >Manager</Dropdown.Item>
                    <Dropdown.Item href="#/action-2">
                      General Manager
                    </Dropdown.Item>
                    <Dropdown.Item href="#/action-3">
                      Amin
                    </Dropdown.Item>
                    <Dropdown.Item href="#/action-3">
                     Delivery Boy
                    </Dropdown.Item>
                    <Dropdown.Item href="#/action-3">
                      Product Manager
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              
              </th>
              <th>
              <Dropdown
                  style={{
                    justifyContent: "start",
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "start",
                    position:"absolute",
                   
    marginLeft: "-39px",
    marginTop: "-20px"

                  }}
                >
                  <Dropdown.Toggle
                    variant="secondary"
                    style={{
                      display: "flex",
                      alignItems: "center",
                      backgroundColor: "#fff",
                      border: "none",
                      justifyContent: "start",
                    }}
                    id="dropdown-basic"
                  >
                    <img src={filter} alt="" /> 
                  </Dropdown.Toggle>
                 status
                  <Dropdown.Menu>
                    <Dropdown.Item href="#/action-1">Active</Dropdown.Item>
                    <Dropdown.Item href="#/action-2">
                     Inactive
                    </Dropdown.Item>
                   
                  </Dropdown.Menu>
                </Dropdown>
            
              </th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {usersList &&
              usersList.length &&
              usersList.map((item, index) => (
                <tr
                  key={item.id}
                  className="tr1"
                  style={{ borderRadius: "15px", padding: "10px" }}
                >
                  <td>{index + 1}</td>
                  <td>{item.full_name}</td>
                  <td>{item.id}</td>
                  <td>{item.mobile}</td>
                  <td>{item.user_role}</td>
                  <td>{item.status}</td>
                  <td  >
                    <img src={eyeIcon} alt="" />
                  </td>
                </tr>
              ))}

            <tr
              className="tr1"
              style={{ borderRadius: "15px", padding: "10px " }}
            >
              <td>1</td>
              <td >Mark</td>
              <td>Otto</td>
              <td>Role</td>
              <td>Role</td>
              <td>Role</td>
              <td className="eyeicon">
                <img  onClick={handleClick} style={{cursor:"pointer"}} src={eyeIcon} alt="" />
              </td>
            </tr>

            <tr>
              <td>2</td>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
              <td>Role</td>
              <td>Role</td>
              <td className="eyeicon">
                <img   src={eyeIcon} alt="" />
              </td>
            </tr>
          </tbody>
        </Table>
      </div> */}
    </div>
  );
};

export default UsersroleList;
