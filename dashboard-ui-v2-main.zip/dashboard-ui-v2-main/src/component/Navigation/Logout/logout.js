import React from 'react'
import "./style.css";
import avtar from "../../../assests/emotions.svg";
import avtar2 from "../../../assests/emotions2.svg"
import {createBrowserRouter, Link} from "react-router-dom"
// import { Button, Space } from 'antd';
import { useState,useEffect } from "react";

import { createBrowserHistory } from 'history';
const Logout = (props) => {
 
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);

//   const [show, setShowing] = useState(false);

//   const handleClose = () => setShowing(false);
// const [logout , setLogout] = useState(false)
// const[apiHit, setApiHit] = useState()
// const history = createBrowserRouter()
// useEffect(()=>{
// 	console.log("runing....")
// if(!localStorage.getItem("data")) history.push("/")
// },[apiHit])
//   const logoutHandler = (e) =>{
//     e.preventDefault();
//     console.log("clicke logout")
//     localStorage.clear("data")
//     props.setLogout(true);

// }




  return (
    <div className="piopup-main1">
      <div className="child-div">
        <div className="child-1">
          <img className="img-avtar" src={avtar2} alt="" />
        </div>
        <div className="child-2">
          <p>Log Out</p>
          <span>Are you sure want to Log Out ?</span>
        </div>
        <div className="logout-btn">
        
    
    
 
        </div>
      </div>
    </div>
  )
}

export default Logout;