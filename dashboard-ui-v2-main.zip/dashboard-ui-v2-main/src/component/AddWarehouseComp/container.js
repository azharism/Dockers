import React, { Component, useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { toastr } from 'react-redux-toastr';
import { getDataFromAPI } from '../../HandleAPICalls/actions';
import { WarehouseComponent } from './component';
import { onChange_Createuser_Warehouse } from '../CreateUserComp/action';

const AddWarehouseContainer = (props) => {
    const[warehouseData, setwarehouseData] = useState();
    const [loading, setLoading] = useState()
    const [isRadioClicked, setIsRadioClicked] = useState(false);
    // const [morescroll, setMorescroll] = useState(true);
    // const [start, setStart] = useState(0);


    // useEffect(() => {
    //   const handleScroll = () => {
       
    //     fetchWarehouseListNext(start + 1);
    //       setStart(start + 1);
    //       // LoadOrderDetails();
      
    //   };
  
    //   window.addEventListener('scroll', handleScroll);
     
    //   return () => {
    //     window.removeEventListener('scroll', handleScroll);
    //   };
    // }, [start, warehouseData, morescroll]);


    // const fetchWarehouseListNext = () => {
    //   console.log("onchange order length", warehouseData.length)
    //   setStart(start + 1 )
    //     props.getDataFromAPI(
    //       'partner/api/v2/warehouse/list',
    //       'GET',
    //       undefined,
    //       (response) => {
    //         if (response) {
    //           setwarehouseData([...warehouseData, ...response]);
    //           console.log("onchange orderlist", response)
    //         }
    //         if (!response) {
    //           setMorescroll(false);
    //         }
    //       },
    //       (err) => {
    //         // handle error
    //       }
    //     );
    //   };

    useEffect(()=>{
        console.log("warehouse")

           props.getDataFromAPI(
              '/partner/api/v2/warehouse/list',
              'GET',
              undefined,
              response => {
                console.log("warehouse",response)
                
                setwarehouseData(response);
                
                
              },
              err => {
                console.log("errrororororooro",err);
                toastr.error('Failed', 'Unable to fetch vending machine warehouse listing');
           
              }
            );
          
        
    }, [])
    const handleWarehouse=(e,id)=>{
      console.log("handleWarehouseid",id)
      setIsRadioClicked(true);
      props.onChange_Createuser_Warehouse(id)

    }
  return (
   
     <WarehouseComponent 
    data={warehouseData}
    handleWarehouse={handleWarehouse}
    isRadioClicked={isRadioClicked}
    // fetchWarehouseListNext={fetchWarehouseListNext}
  
    /> 
  )

}
function mapStateToProps({ props }) {
    return {
      props,
    };
  }
export default connect(mapStateToProps, {
  

    getDataFromAPI,
    onChange_Createuser_Warehouse,
  
})(AddWarehouseContainer);
