import React, { useState } from "react";
import './componentWarehouse.css'
import search from "../../assests/search.svg";
import filter from "../../assests/filterIcon.svg";
import Table from "react-bootstrap/Table";
import Radio from "@mui/material/Radio";
import Form from "react-bootstrap/Form";
import { success } from "toastr";
import Sidebar from "../Navigation/Sidebar/Sidebar";
import InfiniteScroll from "react-infinite-scroll-component";

export const WarehouseComponent = ({data,handleWarehouse,fetchWarehouseListNext}) => {
  const [open, setOpen]= useState()
  const radioChange = ()=>{
    setOpen(!open)
  }
  console.log('data',data)
  const [selectedValue, setSelectedValue] = React.useState("a");
  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };
  const controlProps = (item) => ({
    checked: selectedValue === item,
    onChange: handleChange,
    value: item,
    name: "color-radio-button-demo",
    inputProps: { "aria-label": item },
  });
 
  return (
    <>
   
    <div className="cohortsec">
      <div >
        <div className="searchDivision">
          <input
            type="search"
            placeholder="Search by Warehouse Name/ Warehouse ID"
          />
          <img className="warehousecreatesearchIcon" src={search} alt="" />
        </div>
     
        <div
          style={{
           
            padding: "14px",
            borderRadius: "14px",
            width: "100%",
          }}
        >
           

               
          <Table  striped hover className="scrolldown">
          <thead>
              <tr>
                <th>Warehouse ID</th>
                <th>Warehouse Name</th>
                <th>Area Name</th>
              {console.log("mydata",)}
                
             
                <th> select</th>
              </tr>
            </thead>
            <tbody  style={{position:"relative"}}>
             
              
             { data && data &&
                data.length &&
                data.map((el) =>{
                return(<tr key={el.id} style={{textAlign:"left"}}>
                  
                  <td>{el.warehouseId}</td>
                  <td style={{textAlign:"left"}}>{el.warehouseName}</td>
                  <td style={{textAlign:"left"}}>{el.warehouseCity}</td>
                
                  
                  <td>
                  <input variant="success" style={{width:"20px", height:"20px"}} type="radio" onClick={(e)=>{handleWarehouse(e,el.warehouseId)}} name="radio-group"  />
                    
                  </td>
                </tr>)
                })
            }
              
            </tbody>
          </Table>
          
        </div>
    
      </div>
    </div>
    
    </>
    
  );
};