import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import CohortUpdateComponent from "./component";
import { useParams, useNavigate } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import UpdateMapChargesComponent from "./component";

const UpdateMapChargesContainer = (props) => {
  const { id,cohortId, franchiseeId } = useParams();
  const navigate = useNavigate(); // Import the useNavigate hook

  const [loading, setLoading] = useState(false);
  const [updateMapCharges, setUpdateMapCharges] = useState(null);
  const [selectedChargeIds, setSelectedChargeIds] = useState([]);
 
useEffect (()=>{
  handleUpdateGetFranchiseeCharges(franchiseeId)
},[franchiseeId, cohortId, id])

const handleUpdateGetFranchiseeCharges = (franchiseeId) => {
  props.getDataFromAPI(
    `/dashboard/api/v2/admin/platform/beneficiary/franchisee/${franchiseeId}/charge`,
    "GET",
    undefined,
    (response) => {
      setUpdateMapCharges(response);
    },
    (err) => {
      console.log("error---", err);
      toastr.error("Failed", "Unable to fetch franchisee charge details");
    }
  );
};
 

const handleCheckboxChange = (chargeId) => {
 
  if (selectedChargeIds.includes(chargeId)) {
    setSelectedChargeIds(selectedChargeIds.filter((id) => id !== chargeId));
  } else {
    setSelectedChargeIds([...selectedChargeIds, chargeId]);
  }
};

const handleUpdateMapCharges = () => {
  // Check if any charges are selected
  if (selectedChargeIds.length === 0) {
    toastr.error("Error", "No charges selected");
    return;
  }

  // API payload with selected charge IDs
  const payload = selectedChargeIds;

  props.getDataFromAPI(
    `/dashboard/api/v2/admin/platform/beneficiary/franchisee/${franchiseeId}/charge`,
    "DELETE",
    payload, // Send selected charge IDs in the payload
    (response) => {
      console.log("Update response", response);
      toastr.success("Success", "Charges removed successfully");
      navigate(-1); // Navigate back
    },
    (err) => {
      console.log("Update error", err);
      toastr.error("Failed", "Unable to remove charges");
    }
  );
};


 
  return (
    <UpdateMapChargesComponent
      loading={loading}
     updateMapCharges={updateMapCharges}
     selectedChargeIds={selectedChargeIds}
     handleCheckboxChange={handleCheckboxChange}
      handleUpdateMapCharges={handleUpdateMapCharges}
    />
  );
};

export default connect(null, {
  getDataFromAPI,
})(UpdateMapChargesContainer);
