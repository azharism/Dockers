import React, { Component, useEffect, useState, useRef } from "react";
import "./style.css";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import { Link, useNavigate, useHistory } from "react-router-dom";
import Table from "react-bootstrap/Table";
import refillEye from "../../../../assests/refillEye.svg";
import search from "../../../../assests/search.svg";
import emotions7 from "../../../../assests/emotions7.svg";
import Button from "@mui/material/Button";
import deleteIcon from "../../../../assests/deleteIcon.svg"
import LoadingSpinner from "../../../Loading/component";

const ManagePartnersComponent = (props) => {
  const [isTableExtended, setTableExtended] = useState(false);
  
  const handleEyeIconClick = () => {
    setTableExtended(!isTableExtended);
  };

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const goback = () => {
    navigate(-1);
  };
  
  const managePartnerDetails = (franchiseeId, cohortId, id) => {
    // Navigate to the managepartnersdetails page with the specific ID
    navigate(`/home/configuration/managepartnersdetails/${franchiseeId}/${cohortId}/${franchiseeId}`)
   
  };

  return (
    <>
       {props.loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
 <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Manage Partners 
          </h2>
        </div>
        <div style={{ display: "flex", justifyContent: "end" }}></div>
        <div className="vmsearchdiv" style={{display:"flex", flexDirection:"row", justifyContent:"space-between"}}>
              {/* <div className="input-container">
                <input
                  type="search"
                  placeholder="Search by Owner ID / Cohort ID"
                  value={props.searchValue}
                  onChange={props.handleSearchInputChange}
                  onKeyPress={props.handleKeyPress}
                />
                <button
                  className="search-icon"
                  onClick={props.handleSearchIconClick}
                >
                  <img  src={search} alt="" />
                </button>
              </div> */}
                <div className="input-container">
      <input
        type="search"
        placeholder="Search by Owner ID / Cohort ID"
        value={props.searchValue}
        onChange={props.handleSearchInputChange}
      />
      <button className="search-icon" onClick={props.handleFilterFranchisees}>
        <img src={search} alt="" />
      </button>
    </div>
            
          
            <div style={{marginTop:"20px"}} >
            <Button
              variant="contained"
              color="primary"
            
              onClick={props.handleAddNewEntery}
              style={{ width: "120px", color:"#fff" }}
            >
             + Add New
            </Button>

           
          </div>
         
            </div>
        <div className="vmtablebrand">
          
          <div
            ref={props.tableContainerRef}
            className="tableContainer"
            style={{
              height: "790px",
              overflow: "auto",
              margin: "auto",
              // padding: "20px",
              width: "100%",
            }}
          >
            <Table striped hover>
              <thead>
                <tr
                  style={{
                    borderTop: "1px solid #ccc",
                    position: "relative",
                    top: "-16px",
                  }}
                >
                  <th> ID</th>
                  <th> Name</th>
                  <th>Description</th>
                  <th>Type</th>
                  <th>Cohort ID</th>
                 <th>Owner ID</th>
                 <th></th>
                </tr>
              </thead>
              <tbody>
                {props.filteredFranchiseeList && props.filteredFranchiseeList.length > 0 ? (
                  
                  props.filteredFranchiseeList.map((item) => (
                    
                    <React.Fragment key={item.id}>
                      {console.log("filterdata---", props.filteredFranchiseeList)}
                      <tr className="rowColor">
                        <td>{item.id}</td>
                        <td>{item.name}</td>
                        <td>{item.description}</td>
                        <td>{item.type}</td>
                        <td>{item.cohortId}</td>
                        <td>
                         
                            {item.ownerId}
                        
                        </td>

                        <td className="eyeIcon1" >
                        <img
                  onClick={() => managePartnerDetails(item.id, item.cohortId)}
                  src={refillEye}
                  alt=""
                />
                         
                         {/* <img
                src={deleteIcon}
                alt=""
                style={{ marginLeft: "10px", cursor: "pointer" }}
                onClick={() => props.handleDeleteIconClick(item.id)}
              /> */}
                        </td>
                      </tr>

                        
                      
                    </React.Fragment>
                  ))
                ) : (
                  <>
                    <div className="noVMFound">
                      <div>
                        <img className="noOrderImg" src={emotions7} alt="" />
                        <p className="noOrderPara">No VM Found</p>
                      </div>
                    </div>
                  </>
                )}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
      )}
    </>
   
  );
};

export default ManagePartnersComponent;
