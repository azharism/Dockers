import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";
import ManagePartnersComponent from "./component";
import { useParams } from "react-router-dom";
import { Link, useNavigate } from "react-router-dom";

const ManagePartnersListContainer = (props) => {
  const { id } = useParams;
  const navigate = useNavigate();
  const [franchiseeList, setFranchiseeList] = useState([]);
  const [filteredFranchiseeList, setFilteredFranchiseeList] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [pageNumber, setPageNumber] = useState(undefined); 


  const handleSearchInputChange = (event) => {
    const inputValue = event.target.value;
    setSearchValue(inputValue);
  };

  const handleAddNewEntery=()=>{
    navigate("/home/createfranchies")
  }

  useEffect(() => {
    handleFilterFranchisees();
  }, [searchValue, franchiseeList]);

  const tableContainerRef = useRef(null);

  const handleScroll = () => {
    const container = tableContainerRef.current;
    if (container) {
      const { scrollTop, clientHeight, scrollHeight } = container;
      if (scrollTop + clientHeight >= scrollHeight) {
        
        setPageNumber((prevPageNumber) =>
          prevPageNumber === undefined ? 1 : prevPageNumber + 1
        );
      }
    }
  };

  useEffect(() => {
    const container = tableContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, []);

  const handleSearchIconClick = () => {};

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
    }
  };
const handleGetFranchiseeList = (pageNumber, searchValue) => {
  const queryParams = new URLSearchParams({
    pageSize: 100,
    pageNumber: pageNumber === undefined ? 0 : pageNumber,
    search: searchValue, // Include search parameter
  }).toString();

  props.getDataFromAPI(
    `/dashboard/api/v2/admin/franchisee?${queryParams}`,
    "GET",
    undefined,
    (response) => {
      if (pageNumber === undefined) {
        setFranchiseeList(response);
      } else {
        // Concatenate the new data with the existing list
        setFranchiseeList((prevList) => [...prevList, ...response]);
      }
      console.log("response---", response);
    },
    (err) => {
      console.log("error---", err);
      toastr.error("Failed", "Unable to fetch franchisee listing");
    }
  );
};


useEffect(() => {
  handleGetFranchiseeList(pageNumber);
}, [pageNumber]);

useEffect(() => {
  handleFilterFranchisees(); 
}, [franchiseeList, searchValue]);

const handleFilterFranchisees = () => {
  const filteredList = franchiseeList.filter((franchisee) => {
    const searchString = searchValue.toLowerCase();
    const ownerId = franchisee.ownerId.toString().toLowerCase();
    const cohortId = franchisee.cohortId.toString().toLowerCase();
    return ownerId.includes(searchString) || cohortId.includes(searchString);
  });
  setFilteredFranchiseeList(filteredList);
};



  // const deleteFranchiseeId = (franchiseeId) => {
  //   props.getDataFromAPI(
  //     `/dashboard/api/v2/admin/platform/beneficiary/franchisee/${franchiseeId}/charge`,
  //     "DELETE",
  //     undefined,
  //     (response) => {
  //       // Handle the successful delete response here, such as updating the list of franchisees.
  //       // For example:
  //       // const updatedFranchisees = franchisees.filter(item => item.id !== franchiseeId);
  //       // setFranchisees(updatedFranchisees);
  //       toastr.success("Success", "Franchisee deleted successfully");
  //     },
  //     (err) => {
  //       console.log("error---", err);
  //       toastr.error("Failed", "Unable to delete franchisee");
  //     }
  //   );
  // };

  // const handleDeleteIconClick = (franchiseeId) => {
  //   if (window.confirm("Are you sure you want to delete this franchisee?")) {
  //     deleteFranchiseeId(franchiseeId);
  //   }
  // };

  return (
    <>
      <ManagePartnersComponent
        filteredFranchiseeList={filteredFranchiseeList}
        tableContainerRef={tableContainerRef}
        handleSearchInputChange={handleSearchInputChange}
        handleSearchIconClick={handleSearchIconClick}
        handleFilterFranchisees={handleFilterFranchisees}
        handleKeyPress={handleKeyPress}
        handleAddNewEntery={handleAddNewEntery}
        // handleDeleteIconClick={handleDeleteIconClick}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(ManagePartnersListContainer);