
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { useParams } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import ManagePartnersDetailsComponent from "./component";

const ManagePartnersDetailsContainer = (props) => {
  const { id,cohortId, franchiseeId } = useParams();
  const [loading, setLoading] = useState(true)
  const [cohortDetails, setCohortDetails] = useState(null);
  const [franchiseeDetails, setFranchiseeDetails] = useState(null);
  const [franchiseeBankDetails, setFranchiseeBankDetails] = useState(null);
  const [franchiseeCharges, setFranchiseeCharges] = useState(null)


console.log("fetch bank account name", franchiseeBankDetails&&franchiseeBankDetails)

  useEffect(() => {
    handleGetCohortDetails(cohortId);
    handleGetFranchiseeDetails(franchiseeId);
    handleGetFranchiseeBankDetails(franchiseeId);
    handleGetFranchiseeCharges(franchiseeId)
  }, [cohortId, franchiseeId]);

  const handleGetCohortDetails = (cohortId) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts/${cohortId}`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        setCohortDetails(response); 
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch cohort details");
      }
    );
  };

  const handleGetFranchiseeDetails = (franchiseeId) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/franchisee/${franchiseeId}`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        setFranchiseeDetails(response); 
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch franchisee details");
      }
    );
  };

  const handleGetFranchiseeBankDetails = (franchiseeId) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/franchisee/${franchiseeId}/bank-detail`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        setFranchiseeBankDetails(response); 
        console.log("bank details",response)
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch franchisee bank details");
      }
    );
  };
  const handleGetFranchiseeCharges = (franchiseeId) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/platform/beneficiary/franchisee/${franchiseeId}/charge`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        setFranchiseeCharges(response); 
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch franchisee charge details");
      }
    );
  };
 



return (
    <>
      <ManagePartnersDetailsComponent
        cohortDetails={cohortDetails}
        franchiseeDetails={franchiseeDetails}
        franchiseeBankDetails={franchiseeBankDetails}
        franchiseeCharges={franchiseeCharges}
        loading={loading}
      />
    </>
  );
};

export default connect(null, {
  getDataFromAPI,
})(ManagePartnersDetailsContainer);
