import React, { useState, useEffect } from "react";
import "./style.css";
import { useParams } from "react-router-dom";
import LoadingSpinner from "../../../Loading/component";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import { useNavigate } from "react-router-dom";
import bankicon from "../../../../assests/bankicon.svg";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import chargemap from "../../../../assests/chargemap.svg";
import gprofile from "../../../../assests/gprofile.svg";
import Button from "@mui/material/Button";
import cohorts from "../../../../assests/cohorts.svg";
import uid from "../../../../assests/uid.svg";
import vmids from "../../../../assests/vmids.svg";

const ManagePartnersDetailsComponent = (props, cohortDetails) => {
  console.log("cohortDetails", cohortDetails);
 

 
  const [totalHeight, setTotalHeight] = useState(0);

  useEffect(() => {
    // Calculate the total height of the container based on card heights
    const cardHeights = 155 * 2; // Height of each individual card
    const extraSpace = 0; // Extra space for padding or margin
    setTotalHeight(cardHeights + extraSpace);
  }, []);
  const { id } = useParams(); // Access the ID from the route parameters
  const { cohortId, franchiseeId } = useParams();
 

  const navigate = useNavigate();
  const handleClick = () => {
    navigate(-1);
  };
  const goback = () => {
    navigate(-1);
  };

const editCohortDetails=(cohortId)=>{
  navigate(`/home/updatecohortdetails/${cohortId}`)
}
const editFranchiseeDetails= (franchiseeId)=>{
  navigate(`/home/updatefranchiseedetails/${franchiseeId}`)
}
const editBankDetails= (franchiseeId)=>{
  navigate(`/home/updatebankdetails/${franchiseeId}`)
}

const editMapCharges= (franchiseeId)=>{
  navigate(`/home/updatemapcharges/${franchiseeId}`)
}

  return (
    <>

    
    {props.loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
<div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Manage Partners
          </h2>
        </div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          {props && props && (
            <div
              style={{
                backgroundColor: "#FDFBEC",
                // height: `${totalHeight}px`, // Set the calculated total height
                width: "1320px",
                borderRadius: "18px",
              }}
            >
              <div className="manageCohortDetails">
                <div>
                  <img src={cohorts} alt="" /> Cohort Name :{" "}
                  {props.cohortDetails ? props.cohortDetails.name : "N/A"}
                </div>
                <div>
  <Button variant="outlined" onClick={() => editCohortDetails(cohortId)}>Edit</Button>
</div>

              </div>

              <div className="cardWrapper">
                <div
                  style={{
                    backgroundColor: "#fff",
                    width: "453px",
                    // height: `${totalHeight}px`, // Set the calculated total height
                    borderRadius: "15px",
                  }}
                >
               
 
                  <div
                    style={{
                      margin: "40px",
                      display: "flex",
                      flexDirection: "column",
                    }}
                  >
                    <div style={{ display: "flex", flexDirection: "column" }}>
                      <span style={{fontWeight:"bold"}}>
                        {" "}
                        {props.cohortDetails &&
                          props.cohortDetails.areaName}{" "}
                      </span>
                      <span>Area Name</span>
                    </div>

                    <div style={{ display: "flex", marginTop: "10px" }}>
                      <p>
                        Longitude :
                        {props.cohortDetails && props.cohortDetails.lat}{" "}
                      </p>
                      <p style={{ marginLeft: "40px" }}>
                        Latitude :{" "}
                        {props.cohortDetails && props.cohortDetails.lng}{" "}
                      </p>
                    </div>
                  </div>
                </div>
                <div
                  style={{
                    backgroundColor: "#fff",
                    width: "309px",
                    // height: `${totalHeight}px`, // Set the calculated total height
                    borderRadius: "15px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      margin: "12px",
                    
                    }}
                  >
                    <div style={{ display: "flex" }}>
                      {" "}
                      <img src={uid} alt="" />
                      <p style={{ margin: "10px" }}>
                        User ID :{" "}
                        {props.cohortDetails && props.cohortDetails.id}{" "}
                      </p>
                    </div>
                    <div style={{ display: "flex" }}>
                      {" "}
                      <img src={cohorts} alt="" />
                      <p style={{ margin: "10px" }}>
                        Cohort Type ID :{" "}
                        {props.cohortDetails &&
                          props.cohortDetails.cohortTypeId}{" "}
                      </p>
                    </div>

                    <div style={{ display: "flex", flexDirection: "row" }}>
                      <img src={vmids} alt="" />

                      <p style={{ margin: "10px", width: "250px", }}>
                        VM ID’s :
                        {props.cohortDetails &&
                          props.cohortDetails.machines.map((machine) => (
                            <span style={{ width: "150px" ,height: `${totalHeight}px`}} key={machine.id}>
                              {machine.id},{" "}
                            </span>
                          ))}
                      </p>
                    </div>
                  </div>
                </div>
                <div
                  style={{
                    backgroundColor: "#fff",
                    width: "430px",
                    height: "155px",
                    borderRadius: "15px",
                  }}
                >
                  <div style={{ width: "308px", margin: "20px" }}>
                    <p>Description : </p>
                    <span style={{ color: "#3D3D3DB2", fontSize: "14px" }}>
                      {" "}
                      {props.cohortDetails &&
                        props.cohortDetails.description}{" "}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div
            style={{
              width: "1320px",
              height: "299px",
              display: "flex",
              flexDirection: "row",
              marginTop: "20px",
              justifyContent: "space-between",
            }}
          >
            <div
              style={{
                width: "760px",
                backgroundColor: "#FDFBEC",
                borderRadius: "18px",
              }}
            >
              <div className="manageCohortDetails">
                <div>
                  <img src={gprofile} alt="" /> Franchise Name :{" "}
                  {props.franchiseeDetails && props.franchiseeDetails.name}
                </div>
                <div>
                  <Button variant="outlined" onClick={() => editFranchiseeDetails(franchiseeId)}>Edit</Button>
                </div>
              </div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-around",
                  margin: "30px",
                }}
              >
                <div
                  style={{
                    width: "245px",
                    height: "165px",
                    backgroundColor: "#fff",
                    borderRadius: "15px",
                  }}
                >
                  <div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        padding: "14px",
                      }}
                    >
                      <span style={{ fontWeight: "bold" }}>
                        {" "}
                        {props.franchiseeDetails &&
                          props.franchiseeDetails.type}{" "}
                      </span>
                      <span>Franchise Type</span>
                    </div>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        marginLeft: "10px",
                      }}
                    >
                      <div style={{ display: "flex" }}>
                        <img src={cohorts} alt="" />
                        <p style={{ margin: "10px" }}>
                          Owner ID:{" "}
                          {props.franchiseeDetails &&
                            props.franchiseeDetails.owner.id}
                        </p>
                      </div>
                      <div style={{ display: "flex" }}>
                        {" "}
                        <img src={uid} alt="" />
                        <p style={{ margin: "10px" }}>
                          Cohort id :{" "}
                          {props.franchiseeDetails &&
                            props.franchiseeDetails.cohortId}{" "}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  style={{
                    width: "429px",
                    height: "165px",
                    backgroundColor: "#fff",
                    borderRadius: "15px",
                  }}
                >
                  <div style={{ width: "308px", margin: "20px" }}>
                    <p>Description : </p>
                    <span style={{ color: "#3D3D3DB2", fontSize: "14px" }}>
                      {" "}
                      {props.franchiseeDetails &&
                        props.franchiseeDetails.description}{" "}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div
              style={{
                width: "520px",
                backgroundColor: "#FDFBEC",
                borderRadius: "18px",
              }}
            >
              <div className="manageCohortDetails">
                <div>
                  <img src={bankicon} alt="" /> Bank Details
                </div>
                <div>
                <Button variant="outlined" onClick={() => editBankDetails(franchiseeId)}>Edit</Button>
                </div>
              </div>
              <div
                style={{
                  backgroundColor: "#fff",
                  width: "470px",
                  height: "165px",
                  margin: "30px",
                  borderRadius: "15px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    margin: "12px",
                  }}
                >
                  <div style={{ display: "flex" }}>
                    <p style={{ margin: "10px" }}>
                      Account Name:{" "}
                      {props.franchiseeBankDetails &&
                        props.franchiseeBankDetails.accountName}
                    </p>
                  </div>
                  <div style={{ display: "flex" }}>
                    <p style={{ margin: "10px" }}>
                      Account ID:{" "}
                      {props.franchiseeBankDetails &&
                        props.franchiseeBankDetails.accountId}
                    </p>
                  </div>
                  <div style={{ display: "flex" }}>
                    <p style={{ margin: "10px" }}>
                      IFSC Code:{" "}
                      {props.franchiseeBankDetails &&
                        props.franchiseeBankDetails.ifsc}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            style={{
              width: "1322px",
              backgroundColor: "#FDFBEC",
              borderRadius: "18px",
              marginTop: "20px",
              marginBottom: "10px",
            }}
          >
            <div className="manageCohortDetails">
              <div>
                <img src={chargemap} alt="" /> Charges
              </div>
              <div>
              <Button variant="outlined" onClick={() => editMapCharges(franchiseeId)}>Edit</Button>
              </div>
            </div>
            <div style={{ overflow: "auto", height: "340px" }}>
              <div style={{ display: "flex", flexWrap: "wrap" }}>
                {props.franchiseeCharges &&
                  props.franchiseeCharges.map((charge, index) => (
                    <Card
                      key={index}
                      sx={{
                        width: "370px",
                        minHeight: "320px",
                        margin: "10px",
                        flex: "0 0 calc(33.33% - 20px)",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          borderBottom: "1px solid #ccc",
                        }}
                      >
                        <Typography
                          style={{
                            textAlign: "right",
                            marginRight: "222px",
                            fontWeight: 500,
                            height: "40px",
                            padding: "10px",
                          }}
                        >
                          Charge Name {index + 1}
                        </Typography>
                      </div>

                      <CardContent>
                        <ul>
                          <li>Id: {charge.id}</li>
                          <li>Name: {charge.name}</li>
                          <li>Description: {charge.description}</li>
                          <li>
                            Beneficiary Type Id: {charge.beneficiaryTypeId}
                          </li>
                          <li>Charge Type: {charge.chargeType}</li>
                          <li>Value Type: {charge.valueType}</li>
                          <li>Value: {charge.value}</li>
                          <li>Value Min: {charge.valueMin}</li>
                          <li>Value Max: {charge.valueMax}</li>
                        </ul>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

      )}
    </>
  );
};

export default ManagePartnersDetailsComponent;
