import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import CohortUpdateComponent from "./component";
import { useParams, useNavigate } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import UpdateBankDetailsComponent from "./component";

const UpdateBankDetailsContainer = (props) => {
  const { id,cohortId, franchiseeId } = useParams();
  const navigate = useNavigate(); 

  const [loading, setLoading] = useState(false);
  const [updateBankDetails, setUpdateBankDetails] = useState({});
  const [formDataBank, setFormDataBank] = useState({});

useEffect (()=>{
  handleGetFranchiseeBankDetails(franchiseeId)
},[franchiseeId, cohortId, id])

const handleGetFranchiseeBankDetails = (franchiseeId) => {
  props.getDataFromAPI(
    `/dashboard/api/v2/admin/franchisee/${franchiseeId}/bank-detail`,
    "GET",
    undefined,
    (response) => {
      setUpdateBankDetails(response)
     setFormDataBank(response)
    },
    (err) => {
      console.log("error---", err);
      toastr.error("Failed", "Unable to fetch franchisee bank details");
    }
  );
};
 

const handleChangeUpdateBankDetails = (event) => {
  const { name, value } = event.target;
  setFormDataBank((prevData) => ({
    ...prevData,
    [name]: value,
  }));
};

const handleUpdateBankDetails = () => {
  const payload = {
    accountName: formDataBank.accountName,
    accountId: formDataBank.accountId,
    ifsc: formDataBank.ifsc,
    vpaId: "" 
  };
  props.getDataFromAPI(
    `/dashboard/api/v2/admin/franchisee/${franchiseeId}/bank-detail`,
    "PUT",
    payload, 
    (response) => {
      console.log("Update response", response);
      toastr.success("Success", "bank details updated successfully");
      navigate(-1);
    },
    (err) => {
      console.log("Update error", err);
      toastr.error("Failed", "Unable to update bank details");
    }
  );
};

 
  return (
    <UpdateBankDetailsComponent
      loading={loading}
      formDataBank={formDataBank}
      handleChangeUpdateBankDetails={handleChangeUpdateBankDetails}
      handleUpdateBankDetails={handleUpdateBankDetails}
    />
  );
};

export default connect(null, {
  getDataFromAPI,
})(UpdateBankDetailsContainer);
