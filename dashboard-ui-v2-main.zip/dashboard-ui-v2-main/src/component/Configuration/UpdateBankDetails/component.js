import React from 'react'
import "./component.css"
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from "@mui/material/Button";
import Sidebar from '../../Navigation/Sidebar/Sidebar';
import { useParams, useNavigate } from "react-router-dom";


const UpdateBankDetailsComponent = (props) => {
 
  const navigate = useNavigate();
  const goback = () => {
    navigate(-1);
  };



  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div className="cohortsec1">
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex", flexDirection: "row" }}>
          <Box sx={{ width: 500, maxWidth: '100%', marginTop: '40px' }}>
      <TextField
        fullWidth
        label=" Account Name"
        name="accountName"
        value={props.formDataBank && props.formDataBank.accountName}
        onChange={props.handleChangeUpdateBankDetails}
        style={{ margin: '14px' }}
        InputLabelProps={{ shrink: props.formDataBank && !!props.formDataBank.accountName }}
      />
      <TextField
        fullWidth
        label="Account Number"
        name="accountId"
        value={props.formDataBank && props.formDataBank.accountId}
        onChange={props.handleChangeUpdateBankDetails}
        style={{ margin: '14px' }}
        InputLabelProps={{ shrink: props.formDataBank && !!props.formDataBank.accountId }}
      />
      <TextField
        fullWidth
        label="IFSC"
        name="ifsc"
        value={props.formDataBank && props.formDataBank.ifsc}
        onChange={props.handleChangeUpdateBankDetails}
        style={{ margin: '14px' }}
        InputLabelProps={{ shrink: props.formDataBank && !!props.formDataBank.ifsc }}
      />
    </Box>
          </div>

          <Box className="backbtnaddpage">
            <Button className="backbtnaddpage1" onClick={goback}>
              Back
            </Button>

            <Button
              className="backbtnaddpage1"
              onClick={props.handleUpdateBankDetails}
            >
              save
            </Button>
          </Box>
        </div>
      </div>
    </div>


  )
}

export default UpdateBankDetailsComponent;