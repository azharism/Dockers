import React, { useState, useEffect } from "react";
import "./style.css";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import { useNavigate } from "react-router-dom";
import leftArrow from "../../../../assests/leftArrow.svg";
import IconButton from "@mui/material/IconButton";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import Menu from "@mui/material/Menu";
import { useTheme } from "@mui/material/styles";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import Chip from "@mui/material/Chip";
import cancel from "../../../../assests/cancel.svg";
import CancelIcon from "@mui/icons-material/Cancel";

const VmCreateComponent = (props) => {
  const theme = useTheme();
  console.log("vmtypeeeeeeee:", props.vmTypeList.type);

  const navigate = useNavigate();
  const [showWarehouseList, setShowWarehouseList] = useState(false);
  const [showVMTypeList, setShowVMTypeList] = useState(false);
  const [showHardwareList, setShowHardwareList] = useState(false);
  const [showCorporateList, setShowCorporateList] = useState(false);

  const [showConsumerAppMenu, setShowConsumerAppMenu] = useState(false);
  const [showHealthAppMenu, setShowHealthAppMenu] = useState(false);
  const [anchorElConsumerApp, setAnchorElConsumerApp] = useState(null);
  const [anchorElHealthApp, setAnchorElHealthApp] = useState(null);
  const [showStateList, setShowStateList] = useState(false);
  const [showCityList, setShowCityList] = useState(false);
  const [showLocationType, setShowLocationTypeList] = useState(false);
  const [cohorts, setCohorts] = useState([]);
  const [selectedCohorts, setSelectedCohorts] = useState([]);
  const [showCohortList, setShowCohortList] = useState(false);

  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const handleConsumerAppClick = (event) => {
    setAnchorElConsumerApp(event.currentTarget);
  };

  const handleHealthAppClick = (event) => {
    setAnchorElHealthApp(event.currentTarget);
  };

  const handleConsumerAppSelect = (value) => {
    setAnchorElConsumerApp(null);
    props.handleInputChange("consumerAppEnabled", value);
  };

  const handleHealthAppSelect = (value) => {
    setAnchorElHealthApp(null);
    props.handleInputChange("healthAppEnabled", value);
  };

  const handleVMTypeChange = (selectedVMTypeId) => {
    props.handleInputChange("machine_type_id", selectedVMTypeId);
    setShowVMTypeList(false);
  };
  const handleStateNameChange = (stateName) => {
    props.handleInputChange("state", stateName);
    setShowStateList(false);
  };

  const handleCityNameChange = (selectedCity) => {
    props.handleInputChange("city", selectedCity);
    setShowCityList(false);
  };
  const handleLocationTypeChange = (selectedLocationType) => {
    props.handleInputChange("location_type_id", selectedLocationType);
    setShowLocationTypeList(false);
  };

  const goback = () => {
    navigate(-1);
  };
  const handleWarehouseChange = (selectedWarehouseId) => {
    props.handleInputChange("warehouse_id", selectedWarehouseId);
    setShowWarehouseList(false);
  };

  const handleCorporateChange = (selectedCorporateId) => {
    props.handleInputChange("corporate_id", selectedCorporateId);
    setShowCorporateList(false);
  };

  const handleHardwareChange = (selectedHardwareId) => {
    props.handleInputChange("hardware_type_id", selectedHardwareId);
    setShowHardwareList(false);
  };

  const deleteSelectedCohort = (cohortId) => {
    setCohorts((prevCohorts) => prevCohorts.filter((id) => id !== cohortId));
    const updatedCohorts = selectedCohorts.filter((id) => id !== cohortId);
    props.handleInputChange("cohort_ids", updatedCohorts);
  };

  const handleCohortChange = (selectedCohorts) => {
    props.handleInputChange("cohort_ids", selectedCohorts);
    setSelectedCohorts(selectedCohorts);
    setShowCohortList(false);
  };

  const handleDeleteChip = (event, cohortId) => {
    event.stopPropagation();
    const updatedCohorts = selectedCohorts.filter((id) => id !== cohortId);
    setSelectedCohorts(updatedCohorts);
    deleteSelectedCohort(cohortId);
  };

  const handlePaymentChange = (selectedPayments) => {
    props.handleInputChange("payment_config_ids", selectedPayments);
  };

  const handleDeletePaymentChip = (event, paymentId) => {
    event.stopPropagation();
    const updatedPayments = props.formData.payment_config_ids.filter(
      (id) => id !== paymentId
    );
    handlePaymentChange(updatedPayments);
  };

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>
      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px", display: "flex" }}>
          <img
            onClick={goback}
            style={{ width: "22px", cursor: "pointer", marginLeft: "14px" }}
            src={leftArrow}
            alt=""
          />
          <h2 style={{ marginLeft: "10px" }}>Create a VM</h2>
        </div>
        <div className="cohortsec1">
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                height: "650px",
                margin: "50px",
              }}
            >
              <Box
                sx={{
                  width: 350,
                  maxWidth: "100%",
                  marginTop: "40px",
                  border: "1px solid #ccc",
                  padding: "20px",
                  margin: "10px",
                  borderRadius: "16px",
                }}
              >
                <div
                  className="section-number"
                  style={{
                    border: "1px solid #ccc",
                    background: "#2196F3",
                    padding: "10px",
                    borderRadius: "50%",
                    height: "30px",
                    width: "30px",
                    position: "relative",
                    top: "-36px",
                    left: "140px",
                  }}
                >
                  <span
                    style={{
                      position: "absolute",
                      bottom: "0px",
                      color: "#ffffff",
                    }}
                  >
                    1
                  </span>
                </div>

                <div style={{ marginRight: "10px" }}>
                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="VM Name"
                    autoComplete="off"
                    value={props.formData.vmName}
                    onChange={(e) =>
                      props.handleInputChange("vmName", e.target.value)
                    }
                  />

                  <FormControl
                    style={{ width: "300px ", margin: "10px" }}
                    fullWidth
                  >
                    <InputLabel id="demo-simple-select-label">
                      VM Type
                    </InputLabel>
                    <Select
                      id="demo-simple-select"
                      label="VM Type"
                      select
                      value={props.formData.machine_type_id}
                      onClick={() => setShowVMTypeList(true)}
                      className="selectrole"
                    >
                      {props.vmTypeList.list &&
                        props.vmTypeList.list.map((el, index) => {
                          return (
                            <MenuItem
                              value={el.id}
                              onClick={() => handleVMTypeChange(el.id)}
                            >
                              {el.type}
                            </MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>
                  <FormControl
                    style={{ width: "300px ", margin: "10px" }}
                    fullWidth
                  >
                    <InputLabel id="demo-simple-select-label">
                      Hardware Type
                    </InputLabel>
                    <Select
                      id="demo-simple-select"
                      label="Hardware Type"
                      select
                      value={props.formData.hardware_type_id}
                      onClick={() => setShowHardwareList(true)}
                      className="selectrole"
                    >
                      {props.hardwareList &&
                        props.hardwareList.map((el, index) => {
                          return (
                            <MenuItem
                              value={el.id}
                              onClick={() => handleHardwareChange(el.id)}
                            >
                              {el.name}
                            </MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>
                  <FormControl
                    style={{ width: "300px ", margin: "10px" }}
                    fullWidth
                  >
                    <InputLabel id="demo-simple-select-label">
                      Warehouse
                    </InputLabel>
                    <Select
                      id="demo-simple-select"
                      label="warehouse"
                      select
                      value={props.formData.warehouse_id}
                      onClick={() => setShowWarehouseList(true)}
                      className="selectrole"
                    >
                      {props.warehouseList &&
                        props.warehouseList.map((el, index) => {
                          return (
                            <MenuItem
                              value={el.warehouseId}
                              onClick={() =>
                                handleWarehouseChange(el.warehouseId)
                              }
                            >
                              {el.warehouseName}
                            </MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>

                  <FormControl
                    style={{ width: "300px ", margin: "10px" }}
                    fullWidth
                  >
                    <InputLabel>Corporate</InputLabel>
                    <Select label="Corporate" className="selectrole">
                      {props.corporateList &&
                        props.corporateList.map((el, index) => {
                          return (
                            <MenuItem
                              value={el.id}
                              onClick={() => handleCorporateChange(el.id)}
                            >
                              {el.name}
                            </MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>

                  <FormControl
                    style={{ width: "300px ", margin: "10px" }}
                    fullWidth
                  >
                    <InputLabel id="consumer-app-label">
                      Consumer App Enabled
                    </InputLabel>
                    <Select
                      labelId="consumer-app-label"
                      id="consumer-app-select"
                      label="Consumer App Enabled"
                      value={props.formData.consumerAppEnabled}
                      onChange={(e) => handleConsumerAppSelect(e.target.value)}
                      onClick={handleConsumerAppClick}
                      MenuProps={{
                        PaperProps: {
                          style: {
                            maxHeight: 100,
                          },
                        },
                      }}
                    >
                      <MenuItem value={true}>Yes</MenuItem>
                      <MenuItem value={false}>No</MenuItem>
                    </Select>
                  </FormControl>
                  <FormControl
                    style={{ width: "300px ", margin: "10px" }}
                    fullWidth
                  >
                    <InputLabel id="consumer-app-label">
                      Health App Enabled
                    </InputLabel>
                    <Select
                      labelId="Health App Enabled"
                      id="Health App Enabled"
                      label=" Health App Enabled"
                      value={props.formData.healthAppEnabled}
                      onChange={(e) => handleHealthAppSelect(e.target.value)}
                      onClick={handleHealthAppClick}
                      MenuProps={{
                        PaperProps: {
                          style: {
                            maxHeight: 100,
                          },
                        },
                      }}
                    >
                      <MenuItem value={true}>Yes</MenuItem>
                      <MenuItem value={false}>No</MenuItem>
                    </Select>
                  </FormControl>
                </div>
              </Box>
              <Box
                sx={{
                  width: 350,
                  maxWidth: "100%",
                  marginTop: "40px",
                  border: "1px solid #ccc",
                  padding: "20px",
                  margin: "10px",
                  borderRadius: "16px",
                }}
              >
                <div
                  className="section-number"
                  style={{
                    border: "1px solid #ccc",
                    background: "#2196F3",
                    padding: "10px",
                    borderRadius: "50%",
                    height: "30px",
                    width: "30px",
                    position: "relative",
                    top: "-36px",
                    left: "140px",
                  }}
                >
                  <span
                    style={{
                      position: "absolute",
                      bottom: "0px",
                      color: "#ffffff",
                    }}
                  >
                    2
                  </span>
                </div>

                <div style={{ marginRight: "10px" }}>
                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="Share Percentage"
                    value={props.formData.share_percentage}
                    onChange={(e) =>
                      props.handleInputChange(
                        "share_percentage",
                        e.target.value
                      )
                    }
                  />

                  <FormControl
                    fullWidth
                    style={{ margin: "6px", width: "100%" }}
                    onClick={() => console.log("Clicked")}
                  >
                    <div style={{ display: "flex", flexDirection: "column" }}>
                      <InputLabel style={{ width: "300px" }}>
                        Cohorts
                      </InputLabel>
                      <Select
                        label="Cohorts"
                        multiple
                        value={selectedCohorts}
                        onChange={(event) =>
                          handleCohortChange(event.target.value)
                        }
                        style={{ width: "100%" }}
                        renderValue={(selected) => (
                          <div
                            style={{
                              display: "flex",
                              flexWrap: "wrap",
                              height: "60px",
                              overflowY: "auto",
                            }}
                          >
                            {selected.map((cohortId) => (
                              <Chip
                                key={cohortId}
                                label={
                                  props.cohortList.find(
                                    (el) => el.id === cohortId
                                  )?.name
                                }
                                onDelete={(event) =>
                                  handleDeleteChip(event, cohortId)
                                }
                                onMouseDown={(event) => {
                                  event.stopPropagation();
                                }}
                                color="default"
                                style={{
                                  margin: "2px",
                                  backgroundColor: "#f0f0f0",
                                }}
                              />
                            ))}
                          </div>
                        )}
                      >
                        {props.cohortList &&
                          props.cohortList.map((el) => (
                            <MenuItem key={el.id} value={el.id}>
                              {el.name}
                            </MenuItem>
                          ))}
                      </Select>
                    </div>
                  </FormControl>

                  <FormControl style={{ width: "100%", margin: "6px" }}>
                    <InputLabel id="demo-simple-select-label">
                      Payments
                    </InputLabel>
                    <Select
                      label="Payments"
                      multiple
                      value={
                        Array.isArray(props.formData.payment_config_ids)
                          ? props.formData.payment_config_ids
                          : []
                      }
                      onChange={(event) =>
                        handlePaymentChange(event.target.value)
                      }
                      className="selectrole"
                      renderValue={(selected) => (
                        <div
                          style={{
                            display: "flex",
                            flexWrap: "wrap",
                            maxHeight: "50px",
                            overflowY: "auto",
                          }}
                        >
                          {selected.map((paymentId) => (
                            <Chip
                              key={paymentId}
                              label={
                                props.paymentList.find(
                                  (el) => el.id === paymentId
                                )?.name
                              }
                              onDelete={(event) =>
                                handleDeletePaymentChip(event, paymentId)
                              }
                              onMouseDown={(event) => {
                                event.stopPropagation();
                              }}
                              color="default"
                              style={{
                                margin: "2px",
                                backgroundColor: "#f0f0f0",
                              }}
                            />
                          ))}
                        </div>
                      )}
                      onMouseDown={(event) => {
                        event.stopPropagation();
                      }}
                    >
                      {props.paymentList &&
                        props.paymentList.map((el) => (
                          <MenuItem key={el.id} value={el.id}>
                            {el.name}
                          </MenuItem>
                        ))}
                    </Select>
                  </FormControl>

                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="Serial Number"
                    value={props.formData.serial_number}
                    onChange={(e) =>
                      props.handleInputChange("serial_number", e.target.value)
                    }
                  />
                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="Slot ID"
                    type="number"
                    autoComplete="off"
                    value={props.formData.slotId}
                    onChange={(e) =>
                      props.handleInputChange("slot_id", e.target.value)
                    }
                  />
                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="MV ID"
                    type="number"
                    value={props.formData.mvId}
                    onChange={(e) =>
                      props.handleInputChange("mv_id", e.target.value)
                    }
                  />
                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="Capacity"
                    type="number"
                    value={props.formData.capacity}
                    onChange={(e) =>
                      props.handleInputChange("capacity", e.target.value)
                    }
                  />
                </div>
              </Box>

              <Box
                sx={{
                  width: 350,
                  maxWidth: "100%",
                  marginTop: "40px",
                  border: "1px solid #ccc",
                  padding: "20px",
                  margin: "10px",
                  borderRadius: "16px",
                }}
              >
                <div
                  className="section-number"
                  style={{
                    border: "1px solid #ccc",
                    background: "#2196F3",
                    padding: "10px",
                    borderRadius: "50%",
                    height: "30px",
                    width: "30px",
                    position: "relative",
                    top: "-36px",
                    left: "140px",
                  }}
                >
                  <span
                    style={{
                      position: "absolute",
                      bottom: "0px",
                      color: "#ffffff",
                    }}
                  >
                    3
                  </span>
                </div>

                <div style={{ marginRight: "10px" }}>
                  <FormControl style={{ width: "300px ", margin: "6px" }}>
                    <InputLabel id="demo-simple-select-label">
                      Location Type
                    </InputLabel>
                    <Select
                      id="demo-simple-select"
                      label=" Location Type"
                      select
                      value={props.formData.location_type_id}
                      onClick={() => setShowLocationTypeList(true)}
                      className="selectrole"
                    >
                      {props.locationType &&
                        props.locationType.map((el, index) => {
                          return (
                            <MenuItem
                              value={el.id}
                              onClick={() => handleLocationTypeChange(el.id)}
                            >
                              {el.name}
                            </MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>
                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="Location"
                    value={props.formData.location}
                    onChange={(e) =>
                      props.handleInputChange("location", e.target.value)
                    }
                  />

                  <FormControl
                    style={{ width: "300px", margin: "8px" }}
                    fullWidth
                  >
                    <InputLabel id="demo-simple-select-label">State</InputLabel>
                    <Select
                      labelId="demo-simple-select-label"
                      id="demo-simple-select"
                      label="State"
                      open={props.showStateList}
                      onClose={() => props.setShowStateList(false)}
                      onOpen={() => {
                        props.setShowStateList(true);
                        props.handleGetStateName();
                      }}
                      value={props.formData.state}
                      className="selectrole"
                    >
                      {props.stateName.list &&
                        props.stateName.list.map((el, index) => (
                          <MenuItem
                            key={index}
                            value={el.name}
                            onClick={() => {
                              props.handleInputChange("state", el.name);
                              props.setShowStateList(false);
                              props.handleGetCityName(el.id);
                            }}
                          >
                            {el.name}
                          </MenuItem>
                        ))}
                    </Select>
                  </FormControl>

                  <FormControl
                    style={{ width: "300px ", margin: "8px" }}
                    fullWidth
                  >
                    <InputLabel id="demo-simple-select-label">City</InputLabel>
                    <Select
                      id="demo-simple-select"
                      label="City"
                      select
                      value={props.formData.city}
                      onClick={() => props.setShowCityList(true)}
                      className="selectrole"
                    >
                      {props.cityName.list &&
                        props.cityName.list.map((el, index) => (
                          <MenuItem
                            key={index}
                            value={el.name}
                            onClick={() => {
                              props.handleInputChange("city", el.name);
                              props.setShowCityList(false); 
                            }}
                          >
                            {el.name}
                          </MenuItem>
                        ))}
                    </Select>
                  </FormControl>

                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="Latitude"
                    value={props.formData.latitude}
                    onChange={(e) =>
                      props.handleInputChange("latitude", e.target.value)
                    }
                  />
                  <TextField
                    style={{ margin: "10px" }}
                    fullWidth
                    label="Longitude"
                    value={props.formData.longitude}
                    onChange={(e) =>
                      props.handleInputChange("longitude", e.target.value)
                    }
                  />

                  {/* <div
                    style={{
                      marginLeft: "10px",
                      border: "1px solid #ccc",
                      borderRadius: "14px",
                      padding: "10px",
                      width: "292px",
                    }}
                  >
                    <input
                      accept="image/*"
                      style={{ display: "none" }}
                      id="uploadImage"
                      type="file"
                      onChange={props.handleFileChange}
                    />

                    <label htmlFor="uploadImage">
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <IconButton color="primary" component="span">
                          <CloudUploadIcon />
                        </IconButton>
                        <span style={{ marginLeft: "5px", color: "grey" }}>
                          {props.imagePreview
                            ? "Image Selected"
                            : "Click here to select an image"}
                        </span>
                      </div>
                    </label>

                    <Button
                      variant="outlined"
                      onClick={props.handleImageUpload}
                    >
                      Upload
                    </Button>
                  </div>
                  {props.imagePreview && (
                    <div style={{ marginTop: "10px" }}>
                      <img
                        src={props.imagePreview}
                        alt="Preview"
                        style={{ maxWidth: "100%", maxHeight: "100px" }}
                      />
                    </div>
                  )} */}

                  {/* <div
      style={{
        marginLeft: '10px',
        border: '1px solid #ccc',
        borderRadius: '14px',
        padding: '10px',
        width: '292px',
      }}
    >
      <input
        accept="image/*"
        style={{ display: 'none' }}
        id="uploadImage"
        type="file"
        onChange={props.handleFileChange}
      />

      <label htmlFor="uploadImage">
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <IconButton color="primary" component="span">
            <CloudUploadIcon />
          </IconButton>
          <span style={{ marginLeft: '5px', color: 'grey' }}>
            {props.imagePreview ? 'Change Image' : 'Click here to select an image'}
          </span>
        </div>
      </label>

      {props.imagePreview && (
        <div style={{ marginTop: '10px', display: 'flex', alignItems: 'center' }}>
          <img
            src={props.imagePreview}
            alt="Preview"
            style={{ maxWidth: '100%', maxHeight: '100px' }}
          />
          <IconButton onClick={props.handleCancel} color="primary">
            <CancelIcon />
          </IconButton>
        </div>
      )}

      <Button variant="outlined" onClick={props.handleImageUpload}>
        Upload
      </Button>
    </div> */}
                  <div
                    style={{
                      marginLeft: "10px",
                      border: "1px solid #ccc",
                      borderRadius: "14px",
                      padding: "10px",
                      width: "296px",
                      height: "134px",
                    }}
                  >
                    <input
                      accept="image/*"
                      style={{ display: "none" }}
                      id="uploadImage"
                      type="file"
                      onChange={props.handleFileChange}
                    />

                    <label htmlFor="uploadImage">
                      {props.imagePreview ? (
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            width: "240px",
                          }}
                        >
                          <img
                            src={props.imagePreview}
                            alt="Preview"
                            style={{ width: "100%", maxHeight: "80px" }}
                          />
                          <img
                            src={cancel}
                            alt="Cancel"
                            onClick={props.handleCancel}
                            style={{ cursor: "pointer", marginLeft: "5px" }}
                          />
                        </div>
                      ) : (
                        <div style={{ display: "flex", alignItems: "center" }}>
                          <IconButton color="primary" component="span">
                            <CloudUploadIcon />
                          </IconButton>
                          <span style={{ marginLeft: "5px", color: "grey" }}>
                            {props.imagePreview
                              ? "Image Selected"
                              : "Click here to select an image"}
                          </span>
                        </div>
                      )}
                    </label>

                    <Button
                      variant="outlined"
                      onClick={props.handleImageUpload}
                    >
                      Upload
                    </Button>

                    {props.isImageUploaded && <p>Image Uploaded</p>}
                  </div>
                </div>
              </Box>
            </div>
          </div>
        </div>

        <Button className="createVmBtn1" onClick={props.handleCreateVm}>
          Create Vending Machine
        </Button>
      </div>
    </div>
  );
};

export default VmCreateComponent;
