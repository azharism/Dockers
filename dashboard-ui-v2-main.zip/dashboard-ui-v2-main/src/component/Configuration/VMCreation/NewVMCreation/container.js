// import React, { useEffect, useState } from "react";
// import { connect } from "react-redux";
// import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
// import { toastr } from "react-redux-toastr";
// import { Link, useNavigate, useHistory } from "react-router-dom";
// import VmCreateComponent from "./component";


// const VmCreateContainer = (props) => {
 
//   const navigate = useNavigate();
//   const [ warehouseList,  setWarehouseList]= useState([])
//   const [ vmTypeList,  setVmTypeList]= useState([])
//   const [hardwareList, setHardwareList]= useState([])
//   const [corporateList, setCorporateList]= useState([])
//   const [stateName, setStateName] = useState([])
//   const [locationType, setLocationType] = useState ([])
//   const [selectedFile, setSelectedFile] = useState(null);
//   const [uploadStatus, setUploadStatus] = useState(null);
//   const [cityName, setCityName] = useState ([])
//   const [paymentList, setPaymentList] = useState([])
//   const [stateId, setStateId] = useState(undefined);
//   const [formData, setFormData] = useState({
//     // Section 1
//     vmName: '',
//     machine_type_id: '',
//     hardware_type_id: '',
//     warehouse_id: '',
//     corporate_id: '',
//     consumerAppEnabled: '',
//     healthAppEnabled: '',

//     // Section 2
//     share_percentage: '',
//     cohort_ids: '',
//     payment_config_ids: '',
//     serial_number: '',
//     slot_id: '',
//     mv_id: '',
//     capacity: '',

//     // Section 3
//     location_type_id: '',
//     location: '',
//     state: '',
//     city: '',
//     latitude: '',
//     longitude: '',
//     image_path: '',
//   });
//   const [imagePath, setImagePath] = useState(null);
//  const [isImageUploaded, setIsImageUploaded] = useState(false);

//   const [imagePreview, setImagePreview] = useState(null);
//   const [cohortList, setCohortList] = useState([])
 

//   const handleInputChange = (field, value, name) => {
//     setFormData((prevData) => ({
//       ...prevData,
//       [field]: value,
      
//     }));
//   };

 

//   const handleAddNewCorporate=()=>{
//     navigate("/home/configuration/vmcreation/newvmcreation")
//   }

  

//   const handleSelectChange = (selectedValue) => {
//     setFormData((prevUserLimit) => ({
//       ...prevUserLimit,
//       hardware_type_id: selectedValue,
//     }));
//   };
  

//   const handleImageUpload = () => {
//     if (!selectedFile) {
//       toastr.error('Error', 'Please select an image');
//       return;
//     }

//     const formData = new FormData();
//     formData.append('file', selectedFile);

//     props.getDataFromAPI(
//       '/partner/api/v2/s3upload/machine-image',
//       'POST',
//       formData,
//       (response) => {
//         toastr.success('Created', 'Image uploaded successfully');
//         setImagePreview(null);
//         setImagePath(response.image_path);
//         setIsImageUploaded(true)
        
//       },
//       (err) => {
//         toastr.error('Failed', 'Unable to upload image');
//       }
//     );
//   };

//   const handleFileChange = (event) => {
//     const file = event.target.files[0];

//     if (file) {
      
//       const reader = new FileReader();
//       reader.onloadend = () => {
//         setImagePreview(reader.result);
//       };
//       reader.readAsDataURL(file);

     
//       setSelectedFile(file);
//     } else {
     
//       setImagePreview(null);
//     }
//   };
  
//   // const handleFileChange = (e) => {
//   //   const file = e.target.files[0];
//   //   setSelectedFile(file);
//   //   setImagePath({
//   //     ...imagePath,
//   //     image_path: file,
//   //   });
//   // };
 
//   useEffect(() => {
//     getSeedDataList();
//   }, []);

// const getSeedDataList= ()=>{

//   props.getDataFromAPI(
//     "/partner/api/v2/machine/seed",
//     "GET",
//     undefined,
//     (response) => {
//       console.log("VMtype data:", response);
//       setHardwareList(response.hardware_types);
//       setCorporateList(response.corporates)
//       setLocationType(response.location_types)
//       setCohortList(response.cohorts)
//       setPaymentList(response.payment_configs)
//     },
//     (err) => {
//       console.log("error:", err);
//       toastr.error("Failed", "Unable to fetch Brand category listing");
//     }
//   );

// }

// useEffect(()=>{
//   handleGetStateName()
// }, [])

// const handleGetStateName = () => {
//   props.getDataFromAPI(
//     "/dashboard/api/v2/admin/vendingmachines/location/states",
//     "GET",
//     undefined,
//     (response) => {
//       console.log("state name data:", response);

//       const firstStateId =
//         response && response.list && response.list.length > 0
//           ? response.list[0].id
//           : undefined;

//       setStateName(response);
//       setStateId(firstStateId);
//       handleGetCityName(firstStateId);
//     },
//     (err) => {
//       console.log("error:", err);
//       toastr.error("Failed", "Unable to fetch state listing");
//     }
//   );
// };




// console.log("state id", stateId)
// useEffect(() => {
//   handleGetCityName(stateId ); 
// }, [stateId ]);


// const handleGetCityName = (stateId) => {
//   if (stateId) {
//     props.getDataFromAPI(
//       `/dashboard/api/v2/admin/vendingmachines/location/${stateId}/cities`,
//       "GET",
//       undefined,
//       (response) => {
//         console.log("city name data:", response);
//         setCityName(response);
//       },
//       (err) => {
//         console.log("error:", err);
//         toastr.error("Failed", "Unable to fetch city listing");
//       }
//     );
//   }
// };


//   useEffect(() => {
//     getVMTypeList();
//   }, []);

// const getVMTypeList= ()=>{

//   props.getDataFromAPI(
//     "/dashboard/api/v2/admin/vendingmachines/vmtypes",
//     "GET",
//     undefined,
//     (response) => {
//       console.log("VMtype data:", response);
//       setVmTypeList(response);
//     },
//     (err) => {
//       console.log("error:", err);
//       toastr.error("Failed", "Unable to fetch Brand category listing");
//     }
//   );

// }

//   useEffect(() => {
//     getWarehouseList();
//   }, []);

// const getWarehouseList= ()=>{

//   props.getDataFromAPI(
//     "/partner/api/v2/warehouse/list",
//     "GET",
//     undefined,
//     (response) => {
//       console.log("warehouseData:", response);
//       setWarehouseList(response);
//     },
//     (err) => {
//       console.log("error:", err);
//       toastr.error("Failed", "Unable to fetch Brand category listing");
//     }
//   );

// }


// const handleCreateVm = () => {
//   console.log("hhhh")
//   const cohortIds = Array.isArray(formData.cohort_ids)
//   ? formData.cohort_ids.map(Number)
//   : formData.cohort_ids ? [Number(formData.cohort_ids)] : [];

// const paymentConfigIds = Array.isArray(formData.payment_config_ids)
//   ? formData.payment_config_ids.map(Number)
//   : formData.payment_config_ids ? [Number(formData.payment_config_ids)] : [];

//     const requestData = {
//         name: formData.vmName,
//         hardware_type_id:formData.hardware_type_id,
//         machine_type_id: formData.machine_type_id,
//         health_report_enabled: formData.healthAppEnabled,
//         consumer_app_enabled: formData.consumerAppEnabled,
//         share_percentage: parseInt(formData.share_percentage),
//         warehouse_id: formData.warehouse_id,
//         corporate_id: formData.corporate_id,
//         cohort_ids:cohortIds, 
//         payment_config_ids: paymentConfigIds,
//         address: {
//           street: formData.location,
//           city: formData.city,
//           state: formData.state,
//           latitude: parseFloat(formData.latitude),
//           longitude: parseFloat(formData.longitude),
//           image_path: imagePath, 
//           location_type_id: parseInt(formData.location_type_id),
//         },
//         serial_number: formData.serial_number,
//         slots: [
//           {
//             slot_id: parseInt(formData.slot_id),
//             mv_id: parseInt(formData.mv_id),
//             capacity: parseInt(formData.capacity),
//           },
//         ],
//       };
//   props.getDataFromAPI(
//     `/partner/api/v2/machine`,
//     "POST",
//     requestData,
//     (response) => {
//      toastr.success("created", "VM created successfully")
//      navigate("/home/configuration/vmlist")
//     },
//     (err) => {
     
//       toastr.error("Failed", "Unable to create VM ");
//     }
//   );
// };

  
//  const handleCancel = () => {
//     setImagePreview(null); // Reset the image preview
//   };


//   return (
//     <>
//       <VmCreateComponent
//        handleCreateVm={handleCreateVm}
//        formData={formData}
//        handleInputChange={handleInputChange}
//        handleFileChange={handleFileChange}
//        warehouseList={warehouseList}
//        vmTypeList={vmTypeList}
//        hardwareList={hardwareList}
//        corporateList={corporateList}
//        handleImageUpload={handleImageUpload}
//        handleSelectChange={handleSelectChange}
//        stateName= {stateName}
//        locationType={locationType}
//        selectedFile={selectedFile}
//        uploadStatus={uploadStatus}
//        cityName={cityName}
//        stateId={stateId}
//        setStateId={setStateId}
//        cohortList={cohortList}
//        paymentList={paymentList}
//        imagePreview={imagePreview}
//        handleCancel={handleCancel}
//        isImageUploaded={isImageUploaded}
//       />
//     </>
//   );
// };

// function mapStateToProps(props) {
//   return {
//     props,
//   };
// }
// export default connect(mapStateToProps, {
//   getDataFromAPI,
// })(VmCreateContainer);

import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";
import { Link, useNavigate, useHistory } from "react-router-dom";
import VmCreateComponent from "./component";

const VmCreateContainer = (props) => {
 
  const navigate = useNavigate();
  const [ warehouseList,  setWarehouseList]= useState([])
  const [ vmTypeList,  setVmTypeList]= useState([])
  const [hardwareList, setHardwareList]= useState([])
  const [corporateList, setCorporateList]= useState([])
  
  const [locationType, setLocationType] = useState ([])
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [stateName, setStateName] = useState([])
  const [cityName, setCityName] = useState ([])
  
  const [stateId, setStateId] = useState(undefined);
  const [paymentList, setPaymentList] = useState([])
  const [formData, setFormData] = useState({
    // Section 1
    vmName: '',
    machine_type_id: '',
    hardware_type_id: '',
    warehouse_id: '',
    corporate_id: '',
    consumerAppEnabled: '',
    healthAppEnabled: '',

    // Section 2
    share_percentage: '',
    cohort_ids: '',
    payment_config_ids: '',
    serial_number: '',
    slot_id: '',
    mv_id: '',
    capacity: '',

    // Section 3
    location_type_id: '',
    location: '',
    state: '',
    city: '',
    latitude: '',
    longitude: '',
    image_path: '',
  });
  const [imagePath, setImagePath] = useState(null);
  const [isImageUploaded, setIsImageUploaded] = useState(false);

  const [imagePreview, setImagePreview] = useState(null);
  const [cohortList, setCohortList] = useState([])

  const [showStateList, setShowStateList] = useState(false);
  const [showCityList, setShowCityList] = useState(false);

  const handleInputChange = (field, value, name) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value,
    }));
  };

  const handleSelectChange = (selectedValue) => {
    setFormData((prevUserLimit) => ({
      ...prevUserLimit,
      hardware_type_id: selectedValue,
    }));
  };

  const handleImageUpload = () => {
    if (!selectedFile) {
      toastr.error('Error', 'Please select an image');
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);

    props.getDataFromAPI(
      '/partner/api/v2/s3upload/machine-image',
      'POST',
      formData,
      (response) => {
        toastr.success('Created', 'Image uploaded successfully');
        setImagePreview(null);
        setImagePath(response.image_path);
        setIsImageUploaded(true);
      },
      (err) => {
        toastr.error('Failed', 'Unable to upload image');
      }
    );
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);

      setSelectedFile(file);
    } else {
      setImagePreview(null);
    }
  };

  useEffect(() => {
    getSeedDataList();
  }, []);

  const getSeedDataList= () => {
    props.getDataFromAPI(
      "/partner/api/v2/machine/seed",
      "GET",
      undefined,
      (response) => {
        console.log("VMtype data:", response);
        setHardwareList(response.hardware_types);
        setCorporateList(response.corporates)
        setLocationType(response.location_types)
        setCohortList(response.cohorts)
        setPaymentList(response.payment_configs)
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch Brand category listing");
      }
    );
  };

  useEffect(() => {
    handleGetStateName()
  }, [])

  const handleGetStateName = () => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/vendingmachines/location/states",
      "GET",
      undefined,
      (response) => {
        console.log("state name data:", response);
        setStateName(response);
        setStateId(response[0]?.id);
        handleGetCityName(response[0]?.id);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch state listing");
      }
    );
  };

  useEffect(() => {
    handleGetCityName(stateId);
  }, [stateId]);

  const handleGetCityName = (stateId) => {
    if (stateId) {
      props.getDataFromAPI(
        `/dashboard/api/v2/admin/vendingmachines/location/${stateId}/cities`,
        "GET",
        undefined,
        (response) => {
          console.log("city name data:", response);
          setCityName(response);
        },
        (err) => {
          console.log("error:", err);
          toastr.error("Failed", "Unable to fetch city listing");
        }
      );
    }
  };

  useEffect(() => {
    getVMTypeList();
  }, []);

  const getVMTypeList = () => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/vendingmachines/vmtypes",
      "GET",
      undefined,
      (response) => {
        console.log("VMtype data:", response);
        setVmTypeList(response);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch Brand category listing");
      }
    );
  };

  useEffect(() => {
    getWarehouseList();
  }, []);

  const getWarehouseList = () => {
    props.getDataFromAPI(
      "/partner/api/v2/warehouse/list",
      "GET",
      undefined,
      (response) => {
        console.log("warehouseData:", response);
        setWarehouseList(response);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch Brand category listing");
      }
    );
  };

  const handleCreateVm = () => {
    const cohortIds = Array.isArray(formData.cohort_ids)
      ? formData.cohort_ids.map(Number)
      : formData.cohort_ids ? [Number(formData.cohort_ids)] : [];

    const paymentConfigIds = Array.isArray(formData.payment_config_ids)
      ? formData.payment_config_ids.map(Number)
      : formData.payment_config_ids ? [Number(formData.payment_config_ids)] : [];

    const requestData = {
      name: formData.vmName,
      hardware_type_id: formData.hardware_type_id,
      machine_type_id: formData.machine_type_id,
      health_report_enabled: formData.healthAppEnabled,
      consumer_app_enabled: formData.consumerAppEnabled,
      share_percentage: parseInt(formData.share_percentage),
      warehouse_id: formData.warehouse_id,
      corporate_id: formData.corporate_id,
      cohort_ids: cohortIds, 
      payment_config_ids: paymentConfigIds,
      address: {
        street: formData.location,
        city: formData.city,
        state: formData.state,
        latitude: parseFloat(formData.latitude),
        longitude: parseFloat(formData.longitude),
        image_path: imagePath, 
        location_type_id: parseInt(formData.location_type_id),
      },
      serial_number: formData.serial_number,
      slots: [
        {
          slot_id: parseInt(formData.slot_id),
          mv_id: parseInt(formData.mv_id),
          capacity: parseInt(formData.capacity),
        },
      ],
    };
    props.getDataFromAPI(
      `/partner/api/v2/machine`,
      "POST",
      requestData,
      (response) => {
        toastr.success("created", "VM created successfully");
        navigate("/home/configuration/vmlist");
      },
      (err) => {
          console.log(" create err vm api ", err.message);
          toastr.error(`${   "Error",err.status.message}`, {
            position: "top-right",
            autoClose: 1000,
          });
        }
    );
  };

  const handleCancel = () => {
    setImagePreview(null); // Reset the image preview
  };

  return (
    <>
      <VmCreateComponent
       handleCreateVm={handleCreateVm}
       formData={formData}
       handleInputChange={handleInputChange}
       handleFileChange={handleFileChange}
       warehouseList={warehouseList}
       vmTypeList={vmTypeList}
       hardwareList={hardwareList}
       corporateList={corporateList}
       handleImageUpload={handleImageUpload}
       handleSelectChange={handleSelectChange}
       stateName={stateName}
       locationType={locationType}
       selectedFile={selectedFile}
       uploadStatus={uploadStatus}
       cityName={cityName}
       stateId={stateId}
       setStateId={setStateId}
       cohortList={cohortList}
       paymentList={paymentList}
       imagePreview={imagePreview}
       handleCancel={handleCancel}
       isImageUploaded={isImageUploaded}
       setShowStateList={setShowStateList}
       setShowCityList={setShowCityList}
       showStateList={showStateList}
       showCityList={showCityList}
       handleGetCityName={handleGetCityName}
       handleGetStateName={handleGetStateName}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}

export default connect(mapStateToProps, {
  getDataFromAPI,
})(VmCreateContainer);
