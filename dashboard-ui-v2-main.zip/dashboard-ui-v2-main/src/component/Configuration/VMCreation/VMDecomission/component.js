import React, { useState, useEffect } from "react";
import "./style.css";
import { useParams } from "react-router-dom";
import avtar2 from "../../../../assests/emotions2.svg"
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import { useNavigate,Link } from "react-router-dom";

import { TextField, Dialog, DialogTitle, DialogContent, DialogActions , Button} from "@mui/material";


const VmDecomissionComponent = (props) => {
 
  const { id } = useParams(); 
  const { cohortId, franchiseeId } = useParams();
 
 

  const navigate = useNavigate();
  const handleClick = () => {
    navigate(-1);
  };
  const goback = () => {
    navigate(-1);
  };

  const editCohortDetails = (cohortId) => {
    navigate(`/home/updatecohortdetails/${cohortId}`);
  };
  const editFranchiseeDetails = (franchiseeId) => {
    navigate(`/home/updatefranchiseedetails/${franchiseeId}`);
  };
  const editBankDetails = (franchiseeId) => {
    navigate(`/home/updatebankdetails/${franchiseeId}`);
  };

  const editMapCharges = (franchiseeId) => {
    navigate(`/home/updatemapcharges/${franchiseeId}`);
  };

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Clone a Machine
          </h2>
        </div>
        <div
          className="vmsearchdiv"
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        ></div>
        <div className="vmtablebrand">
          <div
           
          >
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                width:"400px",
                margin:"auto",
                marginTop:"240px"
              }}
            >
              <TextField
                fullWidth
                label="Enter VM ID"
                autoComplete="off"
                value={props.vmId}
                onChange={props.handleVmIdChange}
              />
              <Button
                fullWidth
                variant="outlined"
                color="error"
                style={{
                  margin: "30px",
                  fontWeight: "600",
                  height: "70px",
                  borderRadius: "16px",
                  fontSize: "18px",
                }}
                onClick={props.handleClickpopup}
              >
                DECOMMISSION
              </Button>
              <p>To clone a machine <Link style={{ color:"#D54545"}}>Decomission</Link>   it first.</p>
            </div>
          </div>
        </div>
        <Dialog  open={props.openDialog} onClose={props.handleCloseDialog}>
          <DialogTitle style={{backgroundColor:"#DD7231"}}>
          <img className="img-avtar" src={avtar2} alt="" />
          </DialogTitle>
         
          <DialogTitle >
          Decomission
          </DialogTitle>
          <DialogContent>
            <p>Are you sure you want to delete VM ID: {id}?</p>
          </DialogContent>
          <DialogActions style={{display:"flex", justifyContent:"space-evenly"}} >
            <Button size="medium" variant="contained" color="error" style={{width:"120px"}} onClick={props.handleCloseDialog}>No</Button>
            <Button size="medium" variant="outlined" color="error" style={{width:"120px"}} onClick={props.handleDeleteVm}>Yes</Button>
          </DialogActions>
         
          
        </Dialog>
      </div>
    </div>
  );
};

export default VmDecomissionComponent;
