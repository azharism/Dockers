
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { useParams } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import VMDetailsComponent from "./component";
import { useNavigate } from "react-router-dom";


const VMDecomissionContainer = (props) => {
  const { id } = useParams();
  const [openDialog, setOpenDialog] = useState(false);

  const navigate = useNavigate();
  
  const [vmId, setVmId] = useState("");
  const handleClickpopup = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };
  const handleVmIdChange = (e) => {
    setVmId(e.target.value);
  };


  const handleDeleteVm = () => {
    
    console.log("Deleting VM with ID:", id);
  
    props.getDataFromAPI(
      `/partner/api/v2/machine/${id}`,
      "DELETE",
      undefined,
      (response) => {
        toastr.success("Vm successfully deleted")
        navigate(-1)
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to delete VM");
      }
    );
  };
  
  



return (
    <>
      <VMDetailsComponent
     handleDeleteVm={handleDeleteVm}
     vmId={vmId}
     handleVmIdChange={handleVmIdChange}
     openDialog={openDialog}
     handleClickpopup={handleClickpopup}
     handleCloseDialog={handleCloseDialog}
      />
    </>
  );
};

export default connect(null, {
  getDataFromAPI,
})(VMDecomissionContainer);
