import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { useParams } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import VMDetailsComponent from "./component";
import { useNavigate } from "react-router-dom";

const VMCloneContainer = (props) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [openDialog, setOpenDialog] = useState(false);
  const [stateName, setStateName] = useState([]);
  const [cityName, setCityName] = useState([]);
  const [stateId, setStateId] = useState(undefined);
  const [vmId, setVmId] = useState("");
  const [imagePath, setImagePath] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    street: "",
    city: "",
    state: "",
    latitude: "",
    longitude: "",
    image_path: "",
    serial_number: "",
  });

  const handleClickpopup = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };
  

  const handleInputChange = (field, value) => {
    if (field === "state") {
      setStateId(value);

      setFormData((prevData) => ({
        ...prevData,
        state: value,
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [field]: value,
      }));
    }
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);

      setSelectedFile(file);
    } else {
      setImagePreview(null);
    }
  };

  const handleImageUpload = () => {
    if (!selectedFile) {
      toastr.error("Error", "Please select an image");
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);

    props.getDataFromAPI(
      "/partner/api/v2/s3upload/machine-image",
      "POST",
      formData,
      (response) => {
        toastr.success("Created", "Image uploaded successfully");
        setImagePreview(null);
        setImagePath(response.image_path);
      },
      (err) => {
        toastr.error("Failed", "Unable to upload image");
      }
    );
  };

  const handleCloneVm = () => {
    console.log("clone VM with ID:", id);

    const payload = {
      name: formData.name,
      address: {
       
        street: formData.street,
        city: formData.city,
        state: formData.state, 
        latitude: parseFloat(formData.latitude),
        longitude: parseFloat(formData.longitude),
        image_path: imagePath,
      },
      keys: {
        serial_number: formData.serial_number,
      },
    };

    props.getDataFromAPI(
      `/partner/api/v2/machine/${id}`,
      "POST",
      payload,
      (response) => {
        toastr.success("Success", "Clone Created Successfully")
        navigate(-1);
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to clone VM");
      }
    );
  };

  useEffect(() => {
    handleGetStateName();
  }, []);

  const handleGetStateName = () => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/vendingmachines/location/states",
      "GET",
      undefined,
      (response) => {
        console.log("state name data:", response);

        const firstStateId =
          response && response.list && response.list.length > 0
            ? response.list[0].id
            : undefined;

        setStateName(response);
        setStateId(firstStateId);
        handleGetCityName(firstStateId);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch state listing");
      }
    );
  };

  console.log("state id", stateId);
  useEffect(() => {
    handleGetCityName(stateId);
  }, [stateId]);

  const handleGetCityName = (stateId) => {
    if (stateId) {
      props.getDataFromAPI(
        `/dashboard/api/v2/admin/vendingmachines/location/${stateId}/cities`,
        "GET",
        undefined,
        (response) => {
          console.log("city name data:", response);
          setCityName(response);
        },
        (err) => {
          console.log("error:", err);
          toastr.error("Failed", "Unable to fetch city listing");
        }
      );
    }
  };

  return (
    <>
      <VMDetailsComponent
        handleCloneVm={handleCloneVm}
        vmId={vmId}
        formData={formData}
        //  handleVmIdChange={handleVmIdChange}
        openDialog={openDialog}
        handleClickpopup={handleClickpopup}
        handleCloseDialog={handleCloseDialog}
        handleInputChange={handleInputChange}
        cityName={cityName}
        stateId={stateId}
        setStateId={setStateId}
        stateName={stateName}
        handleFileChange={handleFileChange}
        imagePreview={imagePreview}
        handleImageUpload={handleImageUpload}
        uploadStatus={uploadStatus}
      />
    </>
  );
};

export default connect(null, {
  getDataFromAPI,
})(VMCloneContainer);
