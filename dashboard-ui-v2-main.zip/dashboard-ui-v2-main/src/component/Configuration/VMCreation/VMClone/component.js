import React, { useState, useEffect } from "react";
import "./style.css";
import { useParams } from "react-router-dom";
import avtar2 from "../../../../assests/emotions2.svg";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import { useNavigate, Link } from "react-router-dom";
import IconButton from "@mui/material/IconButton";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import cancel from "../../../../assests/cancel.svg";

import {
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
} from "@mui/material";

const VmCloneComponent = (props) => {
  const { id } = useParams();
  const { cohortId, franchiseeId } = useParams();
  const [showStateList, setShowStateList] = useState(false);
  const [showCityList, setShowCityList] = useState(false);

  const navigate = useNavigate();
  const handleClick = () => {
    navigate(-1);
  };
  const goback = () => {
    navigate(-1);
  };
  const handleStateNameChange = (stateId, stateName) => {
    props.handleInputChange("state", stateName);
    props.setStateId(stateId);
    setShowStateList(false);
  };
  const handleCityNameChange = (selectedCity) => {
    props.handleInputChange("city", selectedCity);
    setShowCityList(false);
  };
  const editCohortDetails = (cohortId) => {
    navigate(`/home/updatecohortdetails/${cohortId}`);
  };
  const editFranchiseeDetails = (franchiseeId) => {
    navigate(`/home/updatefranchiseedetails/${franchiseeId}`);
  };
  const editBankDetails = (franchiseeId) => {
    navigate(`/home/updatebankdetails/${franchiseeId}`);
  };

  const editMapCharges = (franchiseeId) => {
    navigate(`/home/updatemapcharges/${franchiseeId}`);
  };

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Clone a Machine
          </h2>
        </div>
        {/* <div
          className="vmsearchdiv"
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        ></div> */}
        <div className="vmtablebrand1">
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <div></div>
            <Box
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                width: "400px",
                margin: "auto",
                marginTop: "120px",
              }}
            >
              <TextField
                style={{ margin: "14px" }}
                fullWidth
                label="Name"
                autoComplete="off"
                value={props.formData.name}
                onChange={(e) =>
                  props.handleInputChange("name", e.target.value)
                }
              />
              <TextField
                style={{ margin: "14px" }}
                fullWidth
                label="Street"
                autoComplete="off"
                value={props.formData.street}
                onChange={(e) =>
                  props.handleInputChange("street", e.target.value)
                }
              />{" "}
              <FormControl style={{ width: "400px", margin: "8px" }} fullWidth>
                <InputLabel id="demo-simple-select-label">State</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  label="State"
                  open={showStateList}
                  onClose={() => setShowStateList(false)}
                  onOpen={() => setShowStateList(true)}
                  value={props.formData.state}
                  className="selectrole"
                >
                  {props.stateName.list &&
                    props.stateName.list.map((el, index) => (
                      <MenuItem
                        key={index}
                        value={el.name}
                        onClick={() => handleStateNameChange(el.id, el.name)}
                      >
                        {el.name}
                      </MenuItem>
                    ))}
                </Select>
              </FormControl>
              <FormControl style={{ width: "400px ", margin: "8px" }} fullWidth>
                <InputLabel id="demo-simple-select-label">City</InputLabel>
                <Select
                  id="demo-simple-select"
                  label="City"
                  select
                  value={props.formData.city}
                  onClick={() => setShowCityList(true)}
                  className="selectrole"
                >
                  {props.cityName.list &&
                    props.cityName.list.map((el, index) => (
                      <MenuItem
                        key={index}
                        value={el.name}
                        onClick={() => handleCityNameChange(el.name)}
                      >
                        {el.name}
                      </MenuItem>
                    ))}
                </Select>
              </FormControl>
            </Box>
            <Box
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                width: "400px",
                margin: "auto",
                marginTop: "120px",
              }}
            >
              <TextField
                style={{ margin: "14px" }}
                fullWidth
                label="Latitude"
                autoComplete="off"
                value={props.formData.latitude}
                onChange={(e) =>
                  props.handleInputChange("latitude", e.target.value)
                }
              />
              <TextField
                style={{ margin: "14px" }}
                fullWidth
                label="Longitude"
                autoComplete="off"
                value={props.formData.longitude}
                onChange={(e) =>
                  props.handleInputChange("longitude", e.target.value)
                }
              />
              <TextField
                style={{ margin: "14px" }}
                fullWidth
                label="Serial Number"
                autoComplete="off"
                value={props.formData.serial_number}
                onChange={(e) =>
                  props.handleInputChange("serial_number", e.target.value)
                }
              />
               <div
  style={{
    marginLeft: "10px",
    border: "1px solid #ccc",
    borderRadius: "14px",
    padding: "10px",
    width: "400px",
    height: "134px",
  }}
>
  <input
    accept="image/*"
    style={{ display: "none" }}
    id="uploadImage"
    type="file"
    onChange={props.handleFileChange}
  />

  <label htmlFor="uploadImage">
    {props.imagePreview ? (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          width: "240px",
        }}
      >
        <img
          src={props.imagePreview}
          alt="Preview"
          style={{ width: "100%", maxHeight: "80px" }}
        />
        <img
          src={cancel}
          alt="Cancel"
          onClick={props.handleCancel}
          style={{ cursor: "pointer", marginLeft: "5px" }}
        />
      </div>
    ) : (
      <div style={{ display: "flex", alignItems: "center" }}>
        <IconButton color="primary" component="span">
          <CloudUploadIcon />
        </IconButton>
        <span style={{ marginLeft: "5px", color: "grey" }}>
          {props.imagePreview
            ? "Image Selected"
            : "Click here to select an image"}
        </span>
      </div>
    )}
  </label>

  <Button  variant="outlined" onClick={props.handleImageUpload}>
    Upload
  </Button>

  {props.isImageUploaded && <p>Image Uploaded</p>}
</div>
              {/* <div
                style={{
                  marginLeft: "10px",
                  border: "1px solid #ccc",
                  borderRadius: "14px",
                  padding: "10px",
                  width: "400px",
                }}
              >
                <input
                  accept="image/*"
                  style={{ display: "none" }}
                  id="uploadImage"
                  type="file"
                  onChange={props.handleFileChange}
                />

                <label htmlFor="uploadImage">
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <IconButton
                      color="primary"
                      component="span"
                      style={{ display: "flex", alignItems: "end " }}
                    >
                      <CloudUploadIcon />
                    </IconButton>
                    <span style={{ marginLeft: "5px", color: "grey" }}>
                      {props.imagePreview
                        ? "Image Selected"
                        : "Click here to select an image"}
                    </span>
                  </div>
                </label>

                <Button variant="outlined" onClick={props.handleImageUpload}>
                  Upload
                </Button>
              </div>
              {props.imagePreview && (
                <div style={{ marginTop: "10px" }}>
                  <img
                    src={props.imagePreview}
                    alt="Preview"
                    style={{ maxWidth: "100%", maxHeight: "100px" }}
                  />
                </div>
              )} */}
            </Box>
          </div>
          <Box
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              width: "400px",
              margin: "auto",
              marginTop: "40px",
            }}
          >
            <Button
              fullWidth
              variant="outlined"
              color="success"
              style={{
                margin: "30px",
                fontWeight: "600",
                height: "70px",
                borderRadius: "16px",
                fontSize: "18px",
              }}
              onClick={props.handleCloneVm}
            >
              Clone a machine
            </Button>
          </Box>
        </div>
        {/* <Dialog  open={props.openDialog} onClose={props.handleCloseDialog}>
          <DialogTitle style={{backgroundColor:"#DD7231"}}>
          <img className="img-avtar" src={avtar2} alt="" />
          </DialogTitle>
         
          <DialogTitle >
          Decomission
          </DialogTitle>
          <DialogContent>
            <p>Are you sure you want to delete VM ID: {id}?</p>
          </DialogContent>
          <DialogActions style={{display:"flex", justifyContent:"space-evenly"}} >
            <Button size="medium" variant="contained" color="error" style={{width:"120px"}} onClick={props.handleCloseDialog}>No</Button>
            <Button size="medium" variant="outlined" color="error" style={{width:"120px"}} onClick={props.handleDeleteVm}>Yes</Button>
          </DialogActions>
         
          
        </Dialog> */}
      </div>
    </div>
  );
};

export default VmCloneComponent;
