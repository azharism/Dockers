
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { useParams } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import ManagePartnersDetailsComponent from "./component";
import VMDetailsComponent from "./component";

const VMDetailsContainer = (props) => {
  const { id,cohortId, franchiseeId } = useParams();

  const [vmDetails, setVmDetails] = useState(null);
  const [franchiseeDetails, setFranchiseeDetails] = useState(null);
  const [franchiseeBankDetails, setFranchiseeBankDetails] = useState(null);
  const [franchiseeCharges, setFranchiseeCharges] = useState(null)


console.log("fetch bank account name", franchiseeBankDetails&&franchiseeBankDetails)

  useEffect(() => {
    handleGetVmDetails(id);
    
  }, []);
 
  const handleGetVmDetails = (id) => {
    props.getDataFromAPI(
      `/partner/api/v2/machine/${id}`,
      "GET",
      undefined,
      (response) => {
        setVmDetails(response); 
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch Vm details");
      }
    );
  };

  const handleGetFranchiseeDetails = (franchiseeId) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/franchisee/${franchiseeId}`,
      "GET",
      undefined,
      (response) => {
        setFranchiseeDetails(response); // Assuming your API response is stored in 'response.data'
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch franchisee details");
      }
    );
  };

  const handleGetFranchiseeBankDetails = (franchiseeId) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/franchisee/${franchiseeId}/bank-detail`,
      "GET",
      undefined,
      (response) => {
        setFranchiseeBankDetails(response); 
        console.log("bank details",response)
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch franchisee bank details");
      }
    );
  };
  const handleGetFranchiseeCharges = (franchiseeId) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/platform/beneficiary/franchisee/${franchiseeId}/charge`,
      "GET",
      undefined,
      (response) => {
        setFranchiseeCharges(response); // Assuming your API response is stored in 'response.data'
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch franchisee charge details");
      }
    );
  };
 



return (
    <>
      <VMDetailsComponent
        vmDetails={vmDetails}
        franchiseeDetails={franchiseeDetails}
        franchiseeBankDetails={franchiseeBankDetails}
        franchiseeCharges={franchiseeCharges}
      />
    </>
  );
};

export default connect(null, {
  getDataFromAPI,
})(VMDetailsContainer);
