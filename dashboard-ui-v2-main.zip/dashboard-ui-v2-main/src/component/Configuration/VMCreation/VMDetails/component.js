import React, { useState, useEffect } from "react";
import "./style.css";
import { useParams } from "react-router-dom";

import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import { useNavigate } from "react-router-dom";
import bankicon from "../../../../assests/bankicon.svg";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import chargemap from "../../../../assests/chargemap.svg";
import gprofile from "../../../../assests/gprofile.svg";
import Button from "@mui/material/Button";
import cohorts from "../../../../assests/cohorts.svg";
import uid from "../../../../assests/uid.svg";
import vmids from "../../../../assests/vmids.svg";

const VMDetailsComponent = (props, cohortDetails) => {
  console.log("cohortDetails", cohortDetails);
 

 
  const [totalHeight, setTotalHeight] = useState(0);

  useEffect(() => {
    // Calculate the total height of the container based on card heights
    const cardHeights = 155 * 2; // Height of each individual card
    const extraSpace = 0; // Extra space for padding or margin
    setTotalHeight(cardHeights + extraSpace);
  }, []);
  const { id } = useParams(); 
  const { cohortId, franchiseeId } = useParams();
 
const handleDecommtionVm = ()=>{
  navigate(`/home/configuration/vmdecomission/${id}`)
}
const handleCloneVm = ()=>{
  navigate(`/home/configuration/vmclone/${id}`)
}
  const navigate = useNavigate();
  const handleClick = () => {
    navigate(-1);
  };
  const goback = () => {
    navigate(-1);
  };

const editCohortDetails=(cohortId)=>{
  navigate(`/home/updatecohortdetails/${cohortId}`)
}
const editFranchiseeDetails= (franchiseeId)=>{
  navigate(`/home/updatefranchiseedetails/${franchiseeId}`)
}
const editBankDetails= (franchiseeId)=>{
  navigate(`/home/updatebankdetails/${franchiseeId}`)
}

const editMapCharges= (franchiseeId)=>{
  navigate(`/home/updatemapcharges/${franchiseeId}`)
}

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
           VM Details
          </h2>
        </div>
        <div style={{margin:"auto", width:"100%", display:"flex", justifyContent:"space-around"}}>
          <Button variant="outlined" color="error" onClick={handleDecommtionVm}>Decomission</Button>
          <Button variant="outlined"  onClick={handleCloneVm}>Clone</Button>
        </div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          
           
      </div>
    </div>
    </div>
  );
};

export default VMDetailsComponent;
