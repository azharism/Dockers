import React, { useState } from "react";
import "./style.css";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../../assests/leftArrow.svg";
import Table from "react-bootstrap/Table";
import eyeTag from "../../../../assests/eyeTag.svg";
import search from "../../../../assests/search.svg";
import emotions7 from "../../../../assests/emotions7.svg";
import Button from "@mui/material/Button";
import { useNavigate, useParams } from "react-router-dom";
import Stack from "@mui/material/Stack";
import AddIcon from "@mui/icons-material/Add";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import InputLabel from "@mui/material/InputLabel";
import OutlinedInput from "@mui/material/OutlinedInput";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import editsvg from "../../../../assests/edit.svg";
import LoadingSpinner from "../../../Loading/component";


const VmListComponent = (props) => {
  const { id } = useParams();
  console.log("vmid", id);
  const [showStatusList, setShowStatusList] = useState(false);
  const handleStatusClick = (id) => {
    setShowStatusList(!showStatusList);
  };
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };
  const handleVMCreation = ()=>{
    navigate(`/home/configuration/vmcreation/newvmcreation`)
  }
  const goback = () => {
    console.log("goback");
    navigate(-1);
  };
  const handleVmDetails = (id) => {
    navigate(`/home/configuration/vmdetails/${id}`);
  };

  const handleVMEdit = (id) => {
    navigate(`/home/configuration/vmeditdetails/${id}`);
  };

  const getStatusColorClass = (status) => {
    switch (status) {
      case "Active":
        return "activeStatus";
      case "Inactive":
        return "inactiveStatus";
      case "Active-Virtual":
        return "activeVirtualStatus";
      case "Test":
        return "testStatus";
      default:
        return "";
    }
  };

  return (
    <>
{props.loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
<div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            VM Management
          </h2>
        </div>
        <div style={{ display: "flex", justifyContent: "end" }}></div>
        <div
          className="vmsearchdiv"
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <div className="input-container">
            <input
              type="search"
              placeholder="Search by VM ID / VM name"
              value={props.searchValue}
              onKeyPress={props.handleKeyPress}
              onChange={props.handleSearchInputChange}
            />

            <button
              className="search-icon"
              onClick={props.handleSearchClick}
            >
              <img src={search} alt="" />
            </button>
          </div>

          <div style={{ marginTop: "20px" }}>
            <Stack direction="row" spacing={2}>
              {/* <Button
                variant="contained"
                // onClick={() => handleVmDetails(vmId)}
                startIcon={<EditIcon />}
              >
                Edit VM
              </Button> */}
              <Button
                variant="contained"
                onClick={handleVMCreation}
                startIcon={<AddIcon />}
              >
                Add VM
              </Button>
            </Stack>
          </div>
        </div>
        <div className="vmtablebrand">
          <div
            ref={props.tableContainerRef}
            className="tableContainer"
            style={{
              height: "790px",
              overflow: "auto",
              margin: "auto",
              width: "100%",
            }}
          >
            <Table striped hover>
              <thead>
                <tr
                  style={{
                    border: "1px solid #ccc",
                    position: "relative",
                    top: "-16px",
                  }}
                >
                  {/* <th> Sr.no</th> */}
                  <th> VM. ID</th>
                  <th>VM Name</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {props.filteredVmList && props.filteredVmList.length > 0 ? (
                  props.filteredVmList.map((item, index) => (
                    <React.Fragment key={item.index}>
                      <tr className="rowColor1">
                        {/* <td>{index + 1}</td> */}
                        <td>{item.id}</td>
                        <td>{item.name}</td>
                        <td > <div style={{width:"48%",  textAlign:"center", borderRadius:"16px", margin:"auto", padding:"6px"}} className={getStatusColorClass(item.operational_status)}>{item.operational_status}</div>  </td>

                        <td className="eyeIcon1">
                          <span
                            style={{
                              marginRight: "6px",
                              color: "#0080FF",
                              fontWeight: "500",
                              fontSize: "14px",
                            }}
                            onClick={() => props.handleOpenStatusModal(item.id)}
                          >
                            Change Status
                          </span>
                          <Dialog
                            open={props.showStatusModal === item.id}
                            onClose={() =>
                              props.handleCloseStatusModal(item.id)
                            }
                          >
                            <DialogTitle>Change Status</DialogTitle>
                            <DialogContent>
                              <FormControl variant="outlined" fullWidth>
                                <InputLabel
                                  id="status-label"
                                  style={{ width: "200px", marginTop: "4px" }}
                                >
                                  Status
                                </InputLabel>
                                <Select
                                  style={{ width: "200px" }}
                                  labelId="status-label"
                                  id="status-select"
                                  value={
                                    props.updateStatus.operational_status_id
                                  }
                                  onChange={(e) =>
                                    props.setUpdateStatus({
                                      operational_status_id: e.target.value,
                                    })
                                  }
                                  label="Status"
                                >
                                    {console.log("Status:", item.operational_status)}
{console.log("Color Class:", getStatusColorClass(item.operational_status))}

                                  {props.statusList.map((status) => (
                                    <MenuItem key={status.id} value={status.id}>
                                      {status.name}
                                    </MenuItem>
                                  ))}
                                </Select>
                              </FormControl>
                            </DialogContent>
                            <DialogActions>
                              <Button
                                onClick={() =>
                                  props.handleCloseStatusModal(item.id)
                                }
                                color="primary"
                              >
                                Cancel
                              </Button>
                              <Button
                                onClick={() => {
                                  props.handleUpdateVmStatus(item.id);
                                  props.handleCloseStatusModal(item.id);
                                }}
                                color="primary"
                              >
                                Update
                              </Button>
                            </DialogActions>
                          </Dialog>
                          {console.log}
                          <img
                            src={eyeTag}
                            onClick={() => handleVmDetails(item.id)}
                            alt=""
                          />

                          <img
                            onClick={() => handleVMEdit(item.id)}
                            src={editsvg}
                            alt=""
                            style={{
                              marginLeft: "10px",
                              cursor: "pointer",
                            }}
                          />
                        </td>
                      </tr>
                    </React.Fragment>
                  ))
                ) : (
                  <>
                    <div className="noVMFound">
                      <div>
                        <img className="noOrderImg" src={emotions7} alt="" />
                        <p className="noOrderPara">No VM Found</p>
                      </div>
                    </div>
                  </>
                )}
              </tbody>
           
            </Table>
          </div>
        </div>
      </div>
    </div>
      )}
    </>
    
  );
};

export default VmListComponent;
