
// import React, { useEffect, useState, useRef } from "react";
// import { connect } from "react-redux";
// import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
// import { toastr } from "react-redux-toastr";

// import { useParams } from "react-router-dom";
// import { useNavigate } from "react-router-dom";
// import _ from "lodash";

// import VmListComponent from "./component";

// const VmListContainer = (props) => {
//   const { id } = useParams();
//   const navigate = useNavigate();
//   const [vmList, setVmList] = useState([]);
//   const [filteredVmList, setFilteredVmList] = useState([]);
//   const [searchValue, setSearchValue] = useState("");
//   const [pageNumber, setPageNumber] = useState(0);
//   const [showDropdown, setShowDropdown] = useState(false);
//   const [vmId, setVmId] = useState();
//   const [statusList, setStatusList] = useState([]);
//   const [showStatusModal, setShowStatusModal] = useState(null);
//   const [updateStatus, setUpdateStatus] = useState({
//     operational_status_id: "",
//   });
// const [loading, setLoading] = useState(true)

//  const handleSearchInputChange = (event) => {
//   const { value } = event.target;
//   setSearchValue(value);
//   handleSearchVMList(value); 
// };


//   useEffect(() => {
//     handleFilterVmList(id);
//   }, [searchValue, vmList]);

//   useEffect(() => {
//     handleFilterVmList();
//   }, [vmList, searchValue]);

//   const tableContainerRef = useRef(null);

//   const handleScroll = () => {
//     const container = tableContainerRef.current;
//     if (container) {
//       const { scrollTop, clientHeight, scrollHeight } = container;
//       if (scrollTop + clientHeight >= scrollHeight) {
//         setPageNumber((prevPageNumber) =>
//           prevPageNumber === undefined ? 1 : prevPageNumber + 1
//         );
//       }
//     }
//   };

//   useEffect(() => {
//     const container = tableContainerRef.current;
//     if (container) {
//       container.addEventListener("scroll", handleScroll);
//     }

//     return () => {
//       if (container) {
//         container.removeEventListener("scroll", handleScroll);
//       }
//     };
//   }, []);

//   const handleKeyPress = (e) => {
//     if (e.key === "Enter") {
//       handleSearchVMList();
//     }
//   };

//   useEffect(() => {
//     handleGetVmList(pageNumber);
//   }, [pageNumber]);

//   useEffect(() => {
//     getSeedDataList();
//   }, []);

//   const handleGetVmList = async (pageNumber, pageSize, searchQuery) => {
//     const queryParams = new URLSearchParams({
//       pageSize: pageSize || 100,
//       pageNumber: pageNumber === undefined ? 0 : pageNumber,
//       search: searchQuery || "",
//     }).toString();

//     props.getDataFromAPI(
//       `/partner/api/v2/machine?${queryParams}`,
//       "GET",
//       undefined,

//       (response) => {
//         setLoading(false)
//         console.log("vmlistfetch---", vmList)
//         if (pageNumber === 0) {
//           setVmList(response);
         
//         } else {
//           setVmList((prevList) => [...prevList, ...response]);
//         }
//       },
//       (err) => {
//         toastr.error("Failed", "Unable to fetch VM list");
//       }
//     );
//   };

//   const handleFilterVmList = () => {
//     if (searchValue.trim() === "") {
     
//       setFilteredVmList(vmList);
//     } else {
      
//       const filteredList = vmList.filter((vmSeriesList) => {
//         const searchString = searchValue.toLowerCase();
//         const vmId = (vmSeriesList.id || "").toString().toLowerCase();
//         const vmName = (vmSeriesList.name || "").toString().toLowerCase();
//         return vmId.includes(searchString) || vmName.includes(searchString);
//       });
//       setFilteredVmList(filteredList);
//     }
//   };

//   const handleUpdateVmStatus = (vmId) => {
//     const payload = {
//       operational_status_id: updateStatus.operational_status_id,
//     };

//     props.getDataFromAPI(
//       `/partner/api/v2/machine/${vmId}`,
//       "PATCH",
//       payload,
//       (response) => {
//         toastr.success("Updated", "VM status updated successfully");
//         setShowDropdown(false);

//         setVmList((prevVmList) =>
//           prevVmList.map((vm) =>
//             vm.id === vmId
//               ? { ...vm, operational_status: response.operational_status }
//               : vm
//           )
//         );
//       },
//       (err) => {
//         toastr.error("Failed", "Unable to update VM status");
//       }
//     );
//   };

//   const getSeedDataList = () => {
//     props.getDataFromAPI(
//       "/partner/api/v2/machine/seed",
//       "GET",
//       undefined,
//       (response) => {
//         console.log("VMtype data:", response);
//         setStatusList(response.operational_status);
//       },
//       (err) => {
//         console.log("error:", err);
//         toastr.error("Failed", "Unable to fetch seeds listing");
//       }
//     );
//   };

//   const handleOpenStatusModal = (itemId) => {
//     setShowStatusModal(itemId);
//   };

//   const handleCloseStatusModal = () => {
//     setShowStatusModal(null);
//   };

//   const handleSearchClick = () => {
//     handleSearchVMList();
//   };

//   const handleSearchVMList = () => {
//     props.getDataFromAPI(
//       `/partner/api/v2/machine/search?value=${searchValue}`,
//       "GET",
//       undefined,
//       (response) => {
//         console.log("Search results:", response);
//         setVmList(response);
//         handleFilterVmList();
//       },
//       (err) => {
//         console.log("Error:", err);
//         toastr.error("Failed", "Unable to fetch search list");
//       }
//     );
//   };

//   return (
//     <>
//       <VmListComponent
//         filteredVmList={filteredVmList}
//         tableContainerRef={tableContainerRef}
//         handleSearchInputChange={handleSearchInputChange}
//         handleFilterVmList={handleFilterVmList}
//         handleKeyPress={handleKeyPress}
//         // handleAddNewCorporate={handleAddNewCorporate}
//         searchValue={searchValue}
//         handleUpdateVmStatus={handleUpdateVmStatus}
//         showDropdown={showDropdown}
//         setShowDropdown={setShowDropdown}
//         updateStatus={updateStatus}
//         statusList={statusList}
//         showStatusModal={showStatusModal}
//         handleOpenStatusModal={handleOpenStatusModal}
//         handleCloseStatusModal={handleCloseStatusModal}
//         setUpdateStatus={setUpdateStatus}
//         handleSearchClick={handleSearchClick}
//         loading={loading}
//       />
//     </>
//   );
// };

// function mapStateToProps(props) {
//   return {
//     props,
//   };
// }
// export default connect(mapStateToProps, {
//   getDataFromAPI,
// })(VmListContainer);


import React, { useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";

import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import _ from "lodash";

import VmListComponent from "./component";

const VmListContainer = (props) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [vmList, setVmList] = useState([]);
  const [filteredVmList, setFilteredVmList] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [pageNumber, setPageNumber] = useState(0);
  const [showDropdown, setShowDropdown] = useState(false);
  const [vmId, setVmId] = useState();
  const [statusList, setStatusList] = useState([]);
  const [showStatusModal, setShowStatusModal] = useState(null);
  const [updateStatus, setUpdateStatus] = useState({
    operational_status_id: "",
  });
 
 const handleSearchInputChange = (event) => {
  const { value } = event.target;
  setSearchValue(value);
  handleSearchVMList(value); 
};


  useEffect(() => {
    handleFilterVmList(id);
  }, [searchValue, vmList]);

  useEffect(() => {
    handleFilterVmList();
  }, [vmList, searchValue]);

  const tableContainerRef = useRef(null);

  const handleScroll = () => {
    const container = tableContainerRef.current;
    if (container) {
      const { scrollTop, clientHeight, scrollHeight } = container;
      if (scrollTop + clientHeight >= scrollHeight) {
        setPageNumber((prevPageNumber) =>
          prevPageNumber === undefined ? 1 : prevPageNumber + 1
        );
      }
    }
  };

  useEffect(() => {
    const container = tableContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, []);

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSearchVMList();
    }
  };

  useEffect(() => {
    handleGetVmList(pageNumber);
  }, [pageNumber]);

  useEffect(() => {
    getSeedDataList();
  }, []);

  const handleGetVmList = async (pageNumber, pageSize, searchQuery) => {
    const queryParams = new URLSearchParams({
      pageSize: pageSize || 100,
      pageNumber: pageNumber === undefined ? 0 : pageNumber,
      search: searchQuery || "",
    }).toString();

    props.getDataFromAPI(
      `/partner/api/v2/machine?${queryParams}`,
      "GET",
      undefined,

      (response) => {
        
        if (pageNumber === 0) {
          setVmList(response);
         
        } else {
          setVmList((prevList) => [...prevList, ...response]);
        }
      },
      (err) => {
        toastr.error("Failed", "Unable to fetch VM list");
      }
    );
  };

  const handleFilterVmList = () => {
    if (searchValue.trim() === "") {
     
      setFilteredVmList(vmList);
    } else {
      
      const filteredList = vmList.filter((vmSeriesList) => {
        const searchString = searchValue.toLowerCase();
        const vmId = (vmSeriesList.id || "").toString().toLowerCase();
        const vmName = (vmSeriesList.name || "").toString().toLowerCase();
        return vmId.includes(searchString) || vmName.includes(searchString);
      });
      setFilteredVmList(filteredList);
    }
  };

  const handleUpdateVmStatus = (vmId) => {
    const payload = {
      operational_status_id: updateStatus.operational_status_id,
    };

    props.getDataFromAPI(
      `/partner/api/v2/machine/${vmId}`,
      "PATCH",
      payload,
      (response) => {
        toastr.success("Updated", "VM status updated successfully");
        setShowDropdown(false);

        setVmList((prevVmList) =>
          prevVmList.map((vm) =>
            vm.id === vmId
              ? { ...vm, operational_status: response.operational_status }
              : vm
          )
        );
      },
      (err) => {
        toastr.error("Failed", "Unable to update VM status");
      }
    );
  };

  const getSeedDataList = () => {
    props.getDataFromAPI(
      "/partner/api/v2/machine/seed",
      "GET",
      undefined,
      (response) => {
        console.log("VMtype data:", response);
        setStatusList(response.operational_status);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch seeds listing");
      }
    );
  };

  const handleOpenStatusModal = (itemId) => {
    setShowStatusModal(itemId);
  };

  const handleCloseStatusModal = () => {
    setShowStatusModal(null);
  };

  const handleSearchClick = () => {
    handleSearchVMList();
  };

  const handleSearchVMList = () => {
    props.getDataFromAPI(
      `/partner/api/v2/machine/search?value=${searchValue}`,
      "GET",
      undefined,
      (response) => {
        console.log("Search results:", response);
        setVmList(response);
        handleFilterVmList();
      },
      (err) => {
        console.log("Error:", err);
        toastr.error("Failed", "Unable to fetch search list");
      }
    );
  };

  return (
    <>
      <VmListComponent
        filteredVmList={filteredVmList}
        tableContainerRef={tableContainerRef}
        handleSearchInputChange={handleSearchInputChange}
        handleFilterVmList={handleFilterVmList}
        handleKeyPress={handleKeyPress}
        // handleAddNewCorporate={handleAddNewCorporate}
        searchValue={searchValue}
        handleUpdateVmStatus={handleUpdateVmStatus}
        showDropdown={showDropdown}
        setShowDropdown={setShowDropdown}
        updateStatus={updateStatus}
        statusList={statusList}
        showStatusModal={showStatusModal}
        handleOpenStatusModal={handleOpenStatusModal}
        handleCloseStatusModal={handleCloseStatusModal}
        setUpdateStatus={setUpdateStatus}
        handleSearchClick={handleSearchClick}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(VmListContainer);