import React, { useState, useEffect } from "react";
import "./style.css";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Sidebar from "../../../Navigation/Sidebar/Sidebar";
import { useNavigate, useParams } from "react-router-dom";
import leftArrow from "../../../../assests/leftArrow.svg";
import IconButton from "@mui/material/IconButton";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import Menu from "@mui/material/Menu";
import { useTheme } from "@mui/material/styles";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import Chip from "@mui/material/Chip";
import cancel from "../../../../assests/cancel.svg";
import LoadingSpinner from "../../../Loading/component";
// import { EditVMCohortComp } from "../VMEditCohorts/component";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import Table from "react-bootstrap/Table";
import Dropdown from "react-bootstrap/Dropdown";
import filter from "../../../../assests/filterIcon.svg";
import search from "../../../../assests/search.svg";
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 1390,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

const VmEditComponent = (props) => {
  console.log("khan formdata machine city: ", props.formData.address.city);
  const theme = useTheme();
  console.log("vmtypeeeeeeee:", props.vmTypeList.type);
const { id } = useParams();
  const navigate = useNavigate();
  const [showWarehouseList, setShowWarehouseList] = useState(false);
  const [showVMTypeList, setShowVMTypeList] = useState(false);
  const [showHardwareList, setShowHardwareList] = useState(false);
  const [showCorporateList, setShowCorporateList] = useState(false);
  const [anchorElConsumerApp, setAnchorElConsumerApp] = useState(null);
  const [anchorElHealthApp, setAnchorElHealthApp] = useState(null);
  const [showStateList, setShowStateList] = useState(false);
  const [showCityList, setShowCityList] = useState(false);
  const [showLocationType, setShowLocationTypeList] = useState(false);
const [isStateSelected, setIsStateSelected] = useState(false);

  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

 const cohortBack = () => {
   navigate(-1);
 };
  const handleConsumerAppClick = (event) => {
    setAnchorElConsumerApp(event.currentTarget);
  };

  const handleConsumerAppSelect = (value) => {
    setAnchorElConsumerApp(null);

    const isEnabled = value === 1;

    props.handleInputChange("consumer_app_enabled", isEnabled);
  };

  const handleHealthAppClick = (event) => {
    setAnchorElHealthApp(event.currentTarget);
  };

  const handleHealthAppSelect = (value) => {
    setAnchorElHealthApp(null);
    props.handleInputChange("health_report_enabled", value);
  };

  const handleVMTypeChange = (selectedVMType) => {
    props.handleInputChange("machine_type_id", selectedVMType);
    setShowVMTypeList(false);
  };

  const handleStateNameChange = (stateId) => {
    props.setStateId(stateId);
    props.handleInputChange("state", stateId);
    setShowStateList(false);

   
    props.handleGetCityName(stateId);
  };

  const handleCityNameChange = (selectedCity) => {
    props.handleInputChange("city", selectedCity);
    setShowCityList(false);
  };

  const handleLocationTypeChange = (selectedLocationType) => {
    props.setFormData((prevFormData) => ({
      ...prevFormData,
      address: {
        ...prevFormData.address,
        location_type_id: selectedLocationType,
      },
    }));
    setShowLocationTypeList(false);
  };

  const goback = () => {
    navigate(-1);
  };
  const handleWarehouseChange = ( selectedWarehouseId) => {
    const selectedWarehouse = props.warehouseList.find(
      (el)=> el.warehouseId === selectedWarehouseId
    );
    if(selectedWarehouse){
    const  updateWarehouse={
        id : selectedWarehouse.warehouseId,
        name : selectedWarehouse.warehouseName
      }
    

    
    props.handleInputChange("warehouse", updateWarehouse);
    setShowWarehouseList(false);
  }
  };
  useEffect(() => {
    console.log("City value changed:", props.formData.address.city);
  }, [props.formData.address.city]);

  const handleCorporateChange = (selectedCorporateId) => {
    const selectedCorporate = props.corporateList.find(
      (el) => el.id === selectedCorporateId
    );

    if (selectedCorporate) {
      const updatedCorporate = {
        id: selectedCorporate.id,
        name: selectedCorporate.name,
      };

      props.handleInputChange("corporate", updatedCorporate);
      setShowCorporateList(false);
    }
  };

  const handleHardwareChange = (name, selectedHardwareId) => {
    console.log(" handleHardwareChange", selectedHardwareId);
    props.handleInputChange(name, selectedHardwareId);
    setShowHardwareList(false);
  };


 const handleCheckboxChange = (e, cohortId) => {
   const checked = e.target.checked;

   console.log("Checkbox checked:", checked);
   console.log("Cohort ID:", cohortId);

   if (checked) {
     props.addCohorthandleClick(cohortId);
   } else {
     props.removedCohort(cohortId);
   }
 };

 
 
  return (
    <>
      {props.loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
        <div className="main-div">
          <div>
            <Sidebar />
          </div>
          <div>
            <div
              style={{ marginLeft: "42px", marginTop: "20px", display: "flex" }}
            >
              <img
                onClick={goback}
                style={{ width: "22px", cursor: "pointer", marginLeft: "14px" }}
                src={leftArrow}
                alt=""
              />
              <h2 style={{ marginLeft: "10px" }}>Edit Vending Machine</h2>
            </div>
            <div className="cohortsec1">
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    height: "640px",
                    margin: "50px",
                  }}
                >
                  <Box
                    sx={{
                      width: 350,
                      maxWidth: "100%",
                      marginTop: "40px",
                      border: "1px solid #ccc",
                      padding: "20px",
                      margin: "10px",
                      borderRadius: "16px",
                    }}
                  >
                    <div
                      className="section-number"
                      style={{
                        border: "1px solid #ccc",
                        background: "#2196F3",
                        padding: "10px",
                        borderRadius: "50%",
                        height: "30px",
                        width: "30px",
                        position: "relative",
                        top: "-36px",
                        left: "140px",
                      }}
                    >
                      <span
                        style={{
                          position: "absolute",
                          bottom: "0px",
                          color: "#ffffff",
                        }}
                      >
                        1
                      </span>
                    </div>

                    <div style={{ marginRight: "10px" }}>
                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="VM Name"
                        value={props.formData.name || ""}
                        onChange={(e) =>
                          props.handleInputChange("name", e.target.value)
                        }
                      />
                      {console.log("name:", props.formData.name)}
                      <FormControl
                        style={{ width: "300px", margin: "10px" }}
                        fullWidth
                      >
                        <InputLabel id="demo-simple-select-label">
                          VM Type
                        </InputLabel>
                        <Select
                          labelId="demo-simple-select-label"
                          id="demo-simple-select"
                          label="VM Type"
                          // value={
                          //   props.vmTypeList.list &&
                          //   props.vmTypeList.list.findIndex(
                          //     (el) => el.id === props.formData.machine_type_id
                          //   )
                          // }
                          value={props.formData.machine_type_id || " "}
                          // onChange={(e) =>
                          //   props.vmTypeList &&
                          //   handleVMTypeChange(props.vmTypeList[e.target.value].id)
                          // }
                          onChange={(e) =>
                            props.vmTypeList &&
                            handleVMTypeChange(e.target.value)
                          }
                          className="selectrole"
                        >
                          {props.vmTypeList &&
                            props.vmTypeList.map((el, index) => (
                              <MenuItem key={index} value={el.id}>
                                {el.name}
                              </MenuItem>
                            ))}
                        </Select>
                      </FormControl>

                      <FormControl
                        style={{ width: "300px", margin: "10px" }}
                        fullWidth
                      >
                        {console.log(
                          "khan props.hardwareList:",
                          props.formData.hardware_type_id
                        )}
                        <InputLabel id="demo-simple-select-label">
                          Hardware Type
                        </InputLabel>
                        <Select
                          id="demo-simple-select"
                          label="hardware_type_id"
                          value={props.formData.hardware_type_id}
                          onChange={(e) =>
                            handleHardwareChange(
                              "hardware_type_id",
                              e.target.value
                            )
                          }
                          className="selectrole"
                        >
                          {props.hardwareList &&
                            props.hardwareList.map((el, index) => (
                              <MenuItem value={el.id} key={index}>
                                {console.log(
                                  "khan props.hardwareList---",
                                  el.name
                                )}
                                {el.name}
                              </MenuItem>
                            ))}
                        </Select>
                      </FormControl>

                      <FormControl
                        style={{ width: "300px ", margin: "10px" }}
                        fullWidth
                      >
                        <InputLabel id="demo-simple-select-label">
                          Warehouse
                        </InputLabel>
                        <Select
                          id="demo-simple-select"
                          label="warehouse"
                          select
                          value={
                            (props.formData && props.formData.warehouse.id) ||
                            ""
                          }
                          onClick={() => setShowWarehouseList(true)}
                          className="selectrole"
                          onChange={(e) =>
                            handleWarehouseChange(e.target.value)
                          }
                        >
                          {props.warehouseList &&
                            props.warehouseList.map((el, index) => {
                              return (
                                <MenuItem value={el.warehouseId} key={index}>
                                  {el.warehouseName}
                                </MenuItem>
                              );
                            })}
                        </Select>
                      </FormControl>

                      <FormControl
                        style={{ width: "300px", margin: "10px" }}
                        fullWidth
                      >
                        <InputLabel>Corporate</InputLabel>
                        <Select
                          label="corporate"
                          className="selectrole"
                          value={props.formData.corporate.id || ""}
                          onChange={(e) =>
                            handleCorporateChange(e.target.value)
                          }
                        >
                          {props.corporateList &&
                            props.corporateList.map((el, index) => {
                              return (
                                <MenuItem value={el.id} key={index}>
                                  {el.name}
                                </MenuItem>
                              );
                            })}
                        </Select>
                      </FormControl>

                      <FormControl
                        style={{ width: "300px", margin: "10px" }}
                        fullWidth
                      >
                        <InputLabel id="consumer-app-label">
                          Consumer App Enabled
                        </InputLabel>
                        <Select
                          labelId="consumer-app-label"
                          id="consumer-app-select"
                          label="Consumer App Enabled"
                          value={props.formData.consumer_app_enabled ? 1 : 0}
                          onChange={(e) =>
                            handleConsumerAppSelect(e.target.value)
                          }
                          onClick={handleConsumerAppClick}
                          MenuProps={{
                            PaperProps: {
                              style: {
                                maxHeight: 100,
                              },
                            },
                          }}
                        >
                          {[
                            { id: 0, name: "NO" },
                            { id: 1, name: "YES" },
                          ].map((el, index) => (
                            <MenuItem value={el.id} key={index}>
                              {el.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                      <FormControl
                        style={{ width: "300px ", margin: "10px" }}
                        fullWidth
                      >
                        <InputLabel id="consumer-app-label">
                          Health App Enabled
                        </InputLabel>
                        <Select
                          labelId="Health App Enabled"
                          id="Health App Enabled"
                          label=" Health App Enabled"
                          value={
                            props.formData.health_report_enabled == false
                              ? 0
                              : 1 || ""
                          }
                          onChange={(e) =>
                            handleHealthAppSelect(e.target.value)
                          }
                          onClick={handleHealthAppClick}
                          MenuProps={{
                            PaperProps: {
                              style: {
                                maxHeight: 100,
                              },
                            },
                          }}
                        >
                          {[
                            { id: 0, name: "NO" },
                            { id: 1, name: "YES" },
                          ].map((el, index) => {
                            return (
                              <MenuItem
                                value={el.id}
                                // onClick={() =>
                                //     handleWarehouseChange(el.warehouseId)
                                //   }
                              >
                                {el.name}
                              </MenuItem>
                            );
                          })}
                        </Select>
                      </FormControl>
                    </div>
                  </Box>
                  <Box
                    sx={{
                      width: 350,
                      maxWidth: "100%",
                      marginTop: "40px",
                      border: "1px solid #ccc",
                      padding: "20px",
                      margin: "10px",
                      borderRadius: "16px",
                    }}
                  >
                    <div
                      className="section-number"
                      style={{
                        border: "1px solid #ccc",
                        background: "#2196F3",
                        padding: "10px",
                        borderRadius: "50%",
                        height: "30px",
                        width: "30px",
                        position: "relative",
                        top: "-36px",
                        left: "140px",
                      }}
                    >
                      <span
                        style={{
                          position: "absolute",
                          bottom: "0px",
                          color: "#ffffff",
                        }}
                      >
                        2
                      </span>
                    </div>

                    <div style={{ marginRight: "10px" }}>
                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="Share Percentage"
                        value={props.formData.share_percentage || ""}
                        onChange={(e) =>
                          props.handleInputChange(
                            "share_percentage",
                            e.target.value
                          )
                        }
                      />
                      {console.log("cohorts:", props.cohorts)}
                      <div
                        style={{
                          width: "310px",
                          height: "60px",
                          border: "1px solid #ccc",
                          borderRadius: "16px",
                          margin: "6px",
                        }}
                      >
                        <span
                          style={{
                            position: "relative",
                            top: "-10px",
                            left: "20px",
                            fontWeight: "400",
                          }}
                        >
                          Cohorts
                        </span>
                        <div
                          style={{
                            width: "300px",
                            display: "flex",
                            justifyContent: "space-evenly",
                            alignItems: "center",
                          }}
                        >
                          <p
                            style={{
                              fontWeight: "400",
                              fontSize: "12px",
                              lineHeight: "20px",
                              marginRight: "10px",
                              color: "#949494",
                            }}
                          >
                            Click here to view & select cohort
                          </p>
                          <Button
                            variant="outlined"
                            // onClick={props.handleEditVMCohorts}
                            onClick={handleOpen}
                          >
                            Cohorts
                          </Button>
                        </div>
                      </div>
                      <div>
                        <Modal
                          open={open}
                          onClose={handleClose}
                          aria-labelledby="modal-modal-title"
                          aria-describedby="modal-modal-description"
                        >
                          <Box sx={style}>
                            <div>
                              <div
                                style={{
                                  marginLeft: "42px",
                                  marginTop: "20px",
                                  display: "flex",
                                }}
                              >
                                <img
                                  onClick={goback}
                                  style={{
                                    width: "22px",
                                    cursor: "pointer",
                                    marginLeft: "14px",
                                  }}
                                  src={leftArrow}
                                  alt=""
                                />
                                <h2 style={{ marginLeft: "10px" }}>
                                  Edit Vending Machine
                                </h2>
                              </div>
                              <div className="cohortsec">
                                <div style={{ width: "100%" }}>
                                  <div className="searchDivision">
                                    <input
                                      type="search"
                                      placeholder="Search by Cohort Name/ Cohort ID"
                                      onChange={(e) => {
                                        props.Search(e.target.value);
                                      }}
                                    />
                                    <img
                                      className="cohortupdatesearchIcon1"
                                      src={search}
                                      alt=""
                                    />
                                  </div>

                                  <div
                                    style={{
                                      // backgroundColor: "#ffffff",
                                      padding: "14px",
                                      borderRadius: "14px",
                                    }}
                                  >
                                    <Table striped className="scrolldown">
                                      <thead>
                                        <tr style={{ border: "none" }}>
                                          <th>Cohort ID</th>
                                          <th>Cohort Name</th>

                                          <th>Area Name</th>

                                          <th>
                                            <Dropdown
                                              className="cohort-type1"
                                              style={{
                                                border: "none !important",
                                              }}
                                            >
                                              <Dropdown.Toggle
                                                variant="none"
                                                className="dropdown-toggle"
                                                id="dropdown-basic"
                                              >
                                                <img
                                                  style={{
                                                    marginLeft: "48px",
                                                    border: "none",
                                                  }}
                                                  src={filter}
                                                  alt=""
                                                />{" "}
                                                <span
                                                  style={{
                                                    marginBottom: "-30px ",
                                                    position: "absolute",
                                                    left: "90px",
                                                    bottom: "30px",
                                                    color: "black",
                                                    fontSize: "17px",
                                                  }}
                                                >
                                                  Cohort Type
                                                </span>
                                              </Dropdown.Toggle>
                                              <Dropdown.Menu>
                                                {props.stagecohortsTypes &&
                                                  props.stagecohortsTypes.map(
                                                    (item) => (
                                                      <Dropdown.Item
                                                        key={item.id}
                                                        id={item.id}
                                                        active={
                                                          props.activeCohortType ===
                                                          item.id
                                                        }
                                                        onClick={() => {
                                                          console.log(
                                                            "Clicked on cohort type:",
                                                            item.id
                                                          );
                                                          props.handleCohortTypeClick(
                                                            item.id,
                                                            item.type
                                                          );
                                                        }}
                                                      >
                                                        {item.name}
                                                      </Dropdown.Item>
                                                    )
                                                  )}
                                              </Dropdown.Menu>
                                            </Dropdown>
                                          </th>

                                          <th></th>
                                        </tr>
                                      </thead>

                                      <tbody>
                                        {props.FilterCohortData &&
                                          props.FilterCohortData.length > 0 &&
                                          props.FilterCohortData.sort(
                                            (a, b) => {
                                              const aChecked =
                                                props.userdetailsCohort?.find(
                                                  (dt) => dt.id === a.id
                                                );
                                              const bChecked =
                                                props.userdetailsCohort?.find(
                                                  (dt) => dt.id === b.id
                                                );

                                              if (aChecked && !bChecked)
                                                return -1;
                                              if (!aChecked && bChecked)
                                                return 1;

                                              return 0;
                                            }
                                          ).map((el, index, cohort) => (
                                            <tr key={el.id}>
                                              <td style={{ textAlign: "left" }}>
                                                {el.id}
                                              </td>
                                              <td style={{ textAlign: "" }}>
                                                {el.name}
                                              </td>
                                              <td style={{ textAlign: "left" }}>
                                                {el.area_name}
                                              </td>
                                              <td
                                                style={{ textAlign: "left" }}
                                                className="ctypes"
                                              >
                                                {el.type}
                                              </td>
                                              <td>
                                                <input
                                                  id={el.id}
                                                  style={{
                                                    height: "18px",
                                                    width: "30px",
                                                    marginLeft: "20px",
                                                  }}
                                                  type="checkbox"
                                                  onChange={(e) => {
                                                    if (
                                                      props.userdetailsCohort?.find(
                                                        (dt) => dt.id === el.id
                                                      )
                                                    ) {
                                                      props.removedCohort(
                                                        e,
                                                        el.id
                                                      );
                                                    } else {
                                                      props.addCohorthandleClick(
                                                        e
                                                      );
                                                    }
                                                  }}
                                                  checked={props.userdetailsCohort?.find(
                                                    (dt) =>
                                                      dt.id === el.id
                                                        ? true
                                                        : false
                                                  )}
                                                />
                                                {/* Your other elements here */}
                                              </td>
                                            </tr>
                                          ))}
                                      </tbody>
                                    </Table>
                                  </div>
                                </div>
                                <Box className="usersrolebtnCohort">
                                  <Button
                                    className="backbtncohort"
                                    style={{ color: "black !important" }}
                                    onClick={cohortBack}
                                  >
                                    Back
                                  </Button>

                                  <Button
                                    className="savebtnupdate"
                                    onClick={handleClose}
                                  >
                                    save
                                  </Button>
                                </Box>
                              </div>
                            </div>
                          </Box>
                        </Modal>
                      </div>

                      <FormControl style={{ width: "300px", margin: "6px" }}>
                        <InputLabel id="demo-simple-select-label">
                          Payments
                        </InputLabel>
                        <Select
                          label="Payments"
                          multiple
                          value={props.selectedPayments}
                          onChange={(event) =>
                            props.handlePaymentChange1(event.target.value)
                          }
                          className="selectrole"
                          renderValue={(selected) => {
                            const validSelected = selected.filter(
                              (paymentId) => paymentId
                            );
                            return (
                              <div
                                style={{
                                  display: "flex",
                                  flexWrap: "wrap",
                                  height: "50px",
                                  overflowY: "auto",
                                }}
                              >
                                {validSelected.map((payment) => (
                                  <Chip
                                    key={payment.id}
                                    label={payment.name}
                                    onDelete={(event) =>
                                      props.handleDeletePaymentChip(
                                        event,
                                        payment
                                      )
                                    }
                                    onMouseDown={(event) => {
                                      event.stopPropagation();
                                    }}
                                    color="default"
                                    style={{
                                      margin: "2px",
                                      backgroundColor: "#f0f0f0",
                                    }}
                                  />
                                ))}
                              </div>
                            );
                          }}
                          onMouseDown={(event) => {
                            event.stopPropagation();
                          }}
                        >
                          {props.paymentList
                            .filter(
                              (payment) =>
                                !props.initialPaymentIds.includes(payment.id)
                            )
                            .map((el) => (
                              <MenuItem key={el.id} value={el}>
                                {el.name}
                              </MenuItem>
                            ))}
                        </Select>
                      </FormControl>

                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="Serial Number"
                        value={props.serialNumber}
                        onChange={(e) =>
                          props.handleInputChange(
                            "serial_number",
                            e.target.value
                          )
                        }
                      />
                      {console.log(
                        "Serial Number:",
                        props.formData.keys.serial_number
                      )}

                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="Slot ID"
                        value={
                          props.formData.slots
                            .map((slot) => slot.slot_id)
                            .join(", ") || ""
                        }
                        onChange={(e) =>
                          props.handleInputChange("slots", {
                            ...props.formData.slots,
                            slot_id: e.target.value.split(", ").map(Number),
                          })
                        }
                        disabled
                      />

                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="MV ID"
                        value={
                          props.formData.slots
                            .map((slot) => slot.mv_id)
                            .join(", ") || ""
                        }
                        onChange={(e) =>
                          props.handleInputChange("slots", {
                            ...props.formData.slots,
                            mv_id: e.target.value.split(", ").map(Number),
                          })
                        }
                        disabled
                      />

                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="Capacity"
                        value={
                          props.formData.slots
                            .map((slot) => slot.capacity)
                            .join(", ") || ""
                        }
                        onChange={(e) =>
                          props.handleInputChange("slots", {
                            ...props.formData.slots,
                            capacity: e.target.value.split(", ").map(Number),
                          })
                        }
                        disabled
                      />
                    </div>
                  </Box>

                  <Box
                    sx={{
                      width: 350,
                      maxWidth: "100%",
                      marginTop: "40px",
                      border: "1px solid #ccc",
                      padding: "20px",
                      margin: "10px",
                      borderRadius: "16px",
                    }}
                  >
                    <div
                      className="section-number"
                      style={{
                        border: "1px solid #ccc",
                        background: "#2196F3",
                        padding: "10px",
                        borderRadius: "50%",
                        height: "30px",
                        width: "30px",
                        position: "relative",
                        top: "-36px",
                        left: "140px",
                      }}
                    >
                      <span
                        style={{
                          position: "absolute",
                          bottom: "0px",
                          color: "#ffffff",
                        }}
                      >
                        3
                      </span>
                    </div>

                    <div style={{ marginRight: "10px" }}>
                      <FormControl style={{ width: "300px", margin: "6px" }}>
                        <InputLabel id="demo-simple-select-label">
                          Location Type
                        </InputLabel>
                        <Select
                          id="demo-simple-select"
                          label="Location Type"
                          value={props.formData.address.location_type_id || ""}
                          onChange={(e) =>
                            handleLocationTypeChange(e.target.value)
                          }
                          className="selectrole"
                        >
                          {props.locationType &&
                            props.locationType.map((el, index) => (
                              <MenuItem key={el.id} value={el.id}>
                                {el.name}
                              </MenuItem>
                            ))}
                        </Select>
                      </FormControl>

                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="Location"
                        value={props.formData.address.street}
                        onChange={(e) =>
                          props.handleInputChange("address", {
                            ...(props.formData.address &&
                              props.formData.address),
                            street: e.target.value,
                          })
                        }
                      />

                      {/* <FormControl
                        style={{ width: "300px", margin: "8px" }}
                        fullWidth
                      >
                        <InputLabel id="demo-simple-select-label">
                          State
                        </InputLabel>
                        <Select
                          labelId="demo-simple-select-label"
                          id="demo-simple-select"
                          label="State"
                          open={props.showStateList}
                          onClose={() => props.setShowStateList(false)}
                          onOpen={() => {
                            props.setShowStateList(true);
                            props.handleGetStateName();
                          }}
                          value={props.formData.address.state || ""}
                          className="selectrole"
                        >
                          {props.stateName.list.map((el, index) => (
                            <MenuItem
                              key={index}
                              value={el.name}
                              onClick={() => {
                                props.handleInputChange("state", el.name);
                                props.setShowStateList(false);
                                props.handleGetCityName(el.id);
                              }}
                            >
                              {el.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>

                      <FormControl
                        style={{ width: "300px ", margin: "8px" }}
                        fullWidth
                      >
                        <InputLabel id="demo-simple-select-label">
                          City
                        </InputLabel>
                        {console.log(
                          "formdata machine city",
                          props.formData.address.city
                        )}

                        <Select
                          select
                          id="demo-simple-select"
                          label="City"
                          value={props.formData.address.city || " "}
                          onChange={(event) =>
                            props.handleInputChange("city", event.target.value)
                          }
                          className="selectrole"
                          disabled={!props.isEditPage} 
                        >
                          {props.cityName &&
                            props.cityName.map((el, index) => (
                              <MenuItem
                                key={index}
                                value={el.name}
                                onChange={() =>
                                  props.handleInputChange("city", el.name)
                                }
                              >
                                {el.name}
                              </MenuItem>
                            ))}
                        </Select>
                      </FormControl> */}

                      <FormControl
                        style={{ width: "300px", margin: "8px" }}
                        fullWidth
                        onFocus={() => setIsStateSelected(true)}
                      >
                        <InputLabel id="demo-simple-select-label">
                          State
                        </InputLabel>
                        <Select
                          labelId="demo-simple-select-label"
                          id="demo-simple-select"
                          label="State"
                          open={props.showStateList}
                          onClose={() => {
                            props.setShowStateList(false);
                            setIsStateSelected(false);
                          }}
                          onOpen={() => {
                            props.setShowStateList(true);
                            props.handleGetStateName();
                          }}
                          value={props.formData.address.state || ""}
                          className="selectrole"
                        >
                          {props.stateName.list.map((el, index) => (
                            <MenuItem
                              key={index}
                              value={el.name}
                              onClick={() => {
                                props.handleInputChange("state", el.name);
                                props.setShowStateList(false);
                                props.handleGetCityName(el.id);
                              }}
                            >
                              {el.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>

                      <FormControl
                        style={{ width: "300px ", margin: "8px" }}
                        fullWidth
                      >
                        <InputLabel id="demo-simple-select-label">
                          {isStateSelected ? "City" : "Please select a state*"}
                        </InputLabel>
                        <Select
                          select
                          id="demo-simple-select"
                          label={
                            isStateSelected ? "City" : "Plz select a state"
                          }
                          value={props.formData.address.city || " "}
                          onChange={(event) =>
                            props.handleInputChange("city", event.target.value)
                          }
                          className="selectrole"
                          disabled={!isStateSelected}
                        >
                          {props.cityName &&
                            props.cityName.map((el, index) => (
                              <MenuItem
                                key={index}
                                value={el.name}
                                onChange={() =>
                                  props.handleInputChange("city", el.name)
                                }
                              >
                                {el.name}
                              </MenuItem>
                            ))}
                        </Select>
                      </FormControl>

                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="Latitude"
                        value={props.formData.address.latitude || ""}
                        onChange={(e) =>
                          props.handleInputChange("latitude", e.target.value)
                        }
                      />
                      <TextField
                        style={{ margin: "10px" }}
                        fullWidth
                        label="Longitude"
                        value={props.formData.address.longitude || ""}
                        onChange={(e) =>
                          props.handleInputChange("longitude", e.target.value)
                        }
                      />

                      <div
                        style={{
                          marginLeft: "10px",
                          border: "1px solid #ccc",
                          borderRadius: "14px",
                          padding: "10px",
                          width: "296px",
                          height: "124px",
                        }}
                      >
                        <input
                          accept="image/*"
                          style={{ display: "none" }}
                          id="uploadImage"
                          type="file"
                          onChange={props.handleFileChange}
                        />

                        <label htmlFor="uploadImage">
                          {props.imagePreview ? (
                            <div
                              style={{
                                display: "flex",
                                alignItems: "center",
                                width: "240px",
                              }}
                            >
                              <img
                                src={props.imagePreview}
                                alt="Preview"
                                style={{ width: "100%", maxHeight: "72px" }}
                              />
                              <img
                                src={cancel}
                                alt="Cancel"
                                onClick={props.handleCancel}
                                style={{ cursor: "pointer", marginLeft: "5px" }}
                              />
                            </div>
                          ) : (
                            <div
                              style={{ display: "flex", alignItems: "center" }}
                            >
                              <IconButton color="primary" component="span">
                                <CloudUploadIcon />
                              </IconButton>
                              <span
                                style={{ marginLeft: "5px", color: "grey" }}
                              >
                                {props.imagePreview
                                  ? "Image Selected"
                                  : "Click here to select an image"}
                              </span>
                            </div>
                          )}
                        </label>

                        <Button
                          variant="outlined"
                          onClick={props.handleImageUpload}
                        >
                          Upload
                        </Button>
                      </div>
                    </div>
                  </Box>
                </div>
              </div>
            </div>

            <Button
              className="createVmBtn1"
              onClick={props.handleUpdateVMDetails}
            >
              Update Vending Machine
            </Button>
          </div>
        </div>
      )}
    </>
  );
};

export default VmEditComponent;
