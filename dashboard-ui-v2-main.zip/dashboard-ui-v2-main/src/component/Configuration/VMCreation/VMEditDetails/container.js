import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../../HandleAPICalls/actions";
import { toastr } from "react-redux-toastr";
import { Link, useNavigate, useHistory } from "react-router-dom";
import VmCreateComponent from "./component";
import { useParams } from "react-router-dom";

const VmEditContainer = (props) => {
  const { vmId, id } = useParams();

  const navigate = useNavigate();
  const [warehouseList, setWarehouseList] = useState([]);
  const [vmTypeList, setVmTypeList] = useState([]);
  const [hardwareList, setHardwareList] = useState([]);
  const [corporateList, setCorporateList] = useState([]);
  const [stateName, setStateName] = useState([]);
  const [locationType, setLocationType] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [cityName, setCityName] = useState([]);
  const [paymentList, setPaymentList] = useState([]);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    name: "",
    operational_status: "",
    hardware_type_id: "",
    machine_type_id: "",
    health_report_enabled: "",
    consumer_app_enabled: "",
    share_percentage: "",
    app_version: "",
    warehouse: { id: "", name: "" },
    corporate: { id: "", name: "" },
    cohorts: [],
    payment_configs: [],
    address: {
      street: "",
      city: "",
      state: "",
      latitude: "",
      longitude: "",
      image_path: "",
      location_type_id: "",
      location_name: "",
    },
    serial_number: "",
    keys: {
      board_id: "",
      bluetooth_id: "",
      com_id: "",
      device_id: "",
    },
    slots: [],
  });
  const [serialNumber, setSerialNumber] = useState(
    formData.keys.serial_number || ""
  );
  const [imagePath, setImagePath] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [cohortList, setCohortList] = useState([]);
  const [vmDetailsData, setVmDetailsData] = useState([]);
  const [cohorts, setCohorts] = useState([]);
  const [payments, setPayments] = useState([]);

  const [selectedPayments, setSelectedPayments] = useState([]);
  const [addedPaymentIds, setAddedPaymentIds] = useState([]);
  const [removedPaymentIds, setRemovedPaymentIds] = useState([]);
  const [initialPaymentIds, setInitialPaymentIds] = useState([]);
  const [showStateList, setShowStateList] = useState(false);
  const [showCityList, setShowCityList] = useState(false);
  const [isStateSelected, setIsStateSelected] = useState(false);

  const [stateId, setStateId] = useState(formData.address.state);

  const [data, setData] = useState([]);

  const [searchCohortList, setSearchCohortList] = useState([]);
  const [searchCohortValue, setSearchCohortValue] = useState([]);
  const [searchCohortData, setSearchCohortData] = useState(null);
  const [filterCohortType, setFilterCohortType] = useState(null);
  
  const [cohortVMTypeData, setCohortVMTypesData] = useState([]);
  const [filterCohortData, setFilterCohortData] = useState([]);
  const [activeCohortType, setActiveCohortType] = useState("");

  const [checkedCohorts, setCheckedCohorts] = useState([]);
 
  useEffect(() => {
    setSerialNumber(formData.keys.serial_number || "");
  }, [formData.keys.serial_number]);

  const handleAddNewCorporate = () => {
    navigate("/home/configuration/vmcreation/newvmcreation");
  };

  // const handleEditVMCohorts = () => {
  //   navigate(`/home/configuration/vmeditcohortsdetails/${vmId}`);
  // };
  useEffect(() => {
    getSeedDataList();
    getWarehouseList();
    handleGetStateName();
  }, [stateId]);
  useEffect(() => {
    if (formData.address.state) {
      setIsStateSelected(true);
    } else {
      setIsStateSelected(false);
    }
  }, [formData.address.state]);

  const handleInputChange = (field, value) => {
    console.log(`Field: ${field}, Value: ${value}`);

    if (field === "cohorts") {
      const updatedCohorts = Array.isArray(value) ? value : [value];
      setCohorts(updatedCohorts);
    }

    if (field === "payment_configs") {
      const updatedPayments = Array.isArray(value) ? value : [value];
      setPayment(updatedPayments);
    }

    if (field === "serial_number") {
      setSerialNumber(value);
    } else if (
      field === "state" ||
      field === "city" ||
      field === "latitude" ||
      field === "longitude"
    ) {
      setFormData((prevData) => ({
        ...prevData,
        address: {
          ...prevData.address,
          [field]: value,
        },
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [field]: value,
      }));
    }
  };

  const handleImageUpload = () => {
    if (!selectedFile) {
      toastr.error("Error", "Please select an image");
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);

    props.getDataFromAPI(
      "/partner/api/v2/s3upload/machine-image",
      "POST",
      formData,
      (response) => {
        toastr.success("Created", "Image uploaded successfully");
        setImagePreview(null);
        setImagePath(response.image_path);
      },
      (err) => {
        toastr.error("Failed", "Unable to upload image");
      }
    );
  };
  console.log("Initial State:", stateId);
  const handleFileChange = (event) => {
    const file = event.target.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);

      setSelectedFile(file);
    } else {
      setImagePreview(null);
    }
  };

  useEffect(() => {
    getSeedDataList();
  }, []);

  const getSeedDataList = () => {
    props.getDataFromAPI(
      "/partner/api/v2/machine/seed",
      "GET",
      undefined,
      (response) => {
        console.log("VMtype data:", response);
        setHardwareList(response.hardware_types);
        setCorporateList(response.corporates);
        setLocationType(response.location_types);
        setCohortList(response.cohorts);
        setPaymentList(response.payment_configs);
        setVmTypeList(response.machine_types);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch seeds listing");
      }
    );
  };
  console.log("vmtypes", hardwareList);
  const handleGetStateName = () => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/vendingmachines/location/states",
      "GET",
      undefined,
      (response) => {
        console.log("state name data:", response);
        setStateName(response);

        if (isStateSelected) {
          handleGetCityName(formData.address.state.id);
        }
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch state listing");
      }
    );
  };

  const handleGetCityName = (stateId) => {
    if (stateId) {
      props.getDataFromAPI(
        `/dashboard/api/v2/admin/vendingmachines/location/${stateId}/cities`,
        "GET",
        undefined,
        (response) => {
          console.log("city name data:", response.list || []);
          setCityName(response.list);
        },
        (err) => {
          console.log("error:", err);
          toastr.error("Failed", "Unable to fetch city listing");
        }
      );
    }
  };

  useEffect(() => {
    handleGetStateName();
  }, [formData]);

  useEffect(() => {
    handleGetCityName(stateId);
  }, [stateId, formData]);

  useEffect(() => {
    getWarehouseList();
  }, []);

  const getWarehouseList = () => {
    props.getDataFromAPI(
      "/partner/api/v2/warehouse/list",
      "GET",
      undefined,
      (response) => {
        console.log("warehouseData:", response);
        setWarehouseList(response);
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch warehouse listing");
      }
    );
  };

  useEffect(() => {
    getVMdetailsList(vmId);
  }, [vmId]);

  const getVMdetailsList = (id) => {
    props.getDataFromAPI(
      `/partner/api/v2/machine/${id}`,
      "GET",
      undefined,
      (response) => {
        console.log("API Response for Cohorts:", response.address.state.name);
        setLoading(false);
        setVmDetailsData(response.cohorts);
        setFormData({
          name: response.name,
          hardware_type_id: response.hardware_type_id,
          machine_type_id: response.machine_type_id,
          health_report_enabled: response.health_report_enabled,
          consumer_app_enabled: response.consumer_app_enabled,
          share_percentage: response.share_percentage,

          warehouse: response.warehouse || { id: "", name: "" },
          corporate: response.corporate || { id: "", name: "" },
          cohorts: response.cohorts,
          payment_configs: response.payment_configs,

          address: {
            street: response.address.street,
            city: response.address.city,
            state: response.address.state,
            latitude: parseFloat(response.address.latitude),
            longitude: parseFloat(response.address.longitude),
            location_type_id: response.address.location_type_id,
            image_path: imagePath,
          },

          keys: {
            board_id: response.keys.board_id,
            bluetooth_id: response.keys.bluetooth_id,
            com_id: response.keys.com_id,
            device_id: response.keys.device_id,
            serial_number: response.keys.serial_number,
          },

          slots: response.slots.map((slot) => ({
            slot_id: slot.slot_id,
            mv_id: slot.mv_id,
            capacity: slot.capacity,
          })),
        });
      },
      (err) => {
        console.log("error:", err);
        toastr.error("Failed", "Unable to fetch machine details");
      }
    );
  };

  
  const [payment, setPayment] = useState([]);


  useEffect(() => {
    const initialAddedPaymentIds = formData?.added_payment_config_ids || [];
    const initialRemovedPaymentIds = formData?.removed_payment_config_ids || [];

    setAddedPaymentIds(initialAddedPaymentIds);
    setRemovedPaymentIds(initialRemovedPaymentIds);

    setSelectedPayments(formData?.payment_configs || []);

    setInitialPaymentIds(
      formData?.payment_configs.map((payment) => payment.id) || []
    );
  }, [
    formData?.payment_configs,
    formData?.added_payment_config_ids,
    formData?.removed_payment_config_ids,
  ]);

  const handlePaymentChange1 = (selectedPayments) => {
    setSelectedPayments(selectedPayments);

    const selectedPaymentIds = selectedPayments.map((payment) => payment.id);
    const newAddedPaymentIds = selectedPaymentIds.filter(
      (id) => !initialPaymentIds.includes(id)
    );
    const newRemovedPaymentIds = initialPaymentIds.filter(
      (id) => !selectedPaymentIds.includes(id)
    );

    setAddedPaymentIds((prevIds) => [
      ...new Set([...prevIds, ...newAddedPaymentIds]),
    ]);
    setRemovedPaymentIds((prevIds) => [
      ...new Set([...prevIds, ...newRemovedPaymentIds]),
    ]);
  };

  const handleDeletePaymentChip = (event, payment) => {
    event.stopPropagation();

    setRemovedPaymentIds((prevIds) => [...new Set([...prevIds, payment.id])]);

    setAddedPaymentIds((prevIds) => prevIds.filter((id) => id !== payment.id));

    setSelectedPayments((prevPayments) =>
      prevPayments.filter(
        (selectedPayment) => selectedPayment.id !== payment.id
      )
    );
  };

  const handleUpdateVMDetails = () => {
    const payload = {
      name: formData.name,
      operational_status: formData.operational_status,
      hardware_type_id: formData.hardware_type_id,
      machine_type_id: formData.machine_type_id,
      health_report_enabled: formData.health_report_enabled,
      consumer_app_enabled: formData.consumer_app_enabled,
      warehouse_id: (formData.warehouse || {}).id || null ,
      corporate_id: (formData.corporate || {}).id || null,
      share_percentage: formData.share_percentage,
      app_version: formData.app_version,
      added_cohort_ids: addedVmCohortIds,
      removed_cohort_ids: removedVmCohortIds,
      added_payment_config_ids: addedPaymentIds,
      removed_payment_config_ids: removedPaymentIds,

      address: {
        street: formData.address.street,
        city: formData.address.city,
        state: formData.address.state,
        latitude: parseFloat(formData.address.latitude),
        longitude: parseFloat(formData.address.longitude),
        image_path: imagePath,
        location_type_id: formData.address.location_type_id,
        location_name: formData.address.location_name,
      },
      serial_number: serialNumber,
      keys: {
        board_id: formData.keys.board_id,
        bluetooth_id: formData.keys.bluetooth_id,
        com_id: formData.keys.com_id,
        device_id: formData.keys.device_id,
      },
      slots: formData.slots.map((slot) => ({
        slot_id: slot.slot_id,
        mv_id: slot.mv_id,
        capacity: slot.capacity,
      })),
    };
    console.log("Cohorts:", cohorts);
    console.log("Update VM Payload:", payload);
    console.log("Serial Number updated:", formData.keys.serial_number);

    props.getDataFromAPI(
      `/partner/api/v2/machine/${vmId}`,
      "PATCH",
      payload,
      (response) => {
        toastr.success("Updated", "VM details updated successfully");
        navigate("/home/configuration/vmlist");
      },
      (err) => {
        toastr.error("Failed", "Unable to update VM details");
      }
    );
  };
  const stagecohortsTypes = [
    {
      id: 1,
      name: "mobility",
    },
    {
      id: 2,
      name: "franchisee_payouts",
    },
    {
      id: 3,
      name: "meals",
    },
    {
      id: 4,
      name: "city_payouts",
    },
    {
      id: 5,
      name: "df_access",
    },
  ];
 
  const [removedVmCohortIds, setRemovedVmCohortIds] = useState([]);

 
 useEffect(() => {
   getVMdetailsListCohort(vmId);
 }, [vmId]);

 const getVMdetailsListCohort = (id) => {
   props.getDataFromAPI(
     `/partner/api/v2/machine/${id}`,
     "GET",
     undefined,
     (response) => {
       console.log("API Response for Cohorts:", response.address.state.name);
       setLoading(false);
       setUserdetailsCohort(response.cohorts);
      
       
     },
     (err) => {
       console.log("error:", err);
       toastr.error("Failed", "Unable to fetch machine details");
     }
   );
 };

  useEffect(() => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/vendingmachines/vm-cohorts",
      "GET",
      undefined,
      (response) => {
        console.log("update  cohorts length", response.list.length);
        setData(response.list);
        //console.log("dataaaa",data)
        if (response.list.success) {
          navigate("/");
        }
      },
      (err) => {
        console.log("errrororororooro", err);
        toastr.error(
          "Failed",
          "Unable to fetch vending machine cohort  listing"
        );
      }
    );
  }, []);

  const onCohortSearch = (e) => {
    const searchName = e.target.value;
    console.log("search name", searchName);
    setSearchCohortValue(searchName);
    searchCohort(searchName);
  };

  const searchCohort = (searchCohortValue) => {
    setSearchCohortData(searchCohortValue);
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts?search_query=${searchCohortValue}`,
      "GET",
      undefined,
      (response) => {
        console.log("Ankit get response", response.list);
        setSearchCohortList(response);
        console.log("SEARCH RES----->", response.list);
      },
      (err) => {}
    );
  };

  const handleCohortTypeClick = (id) => {
    console.log("Clicked on cohort type with ID:", id);

    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts?associated_user_id=${id}` +
        (id ? `&cohort_type_id=${id}` : ""),
      "GET",
      undefined,
      (response) => {
        console.log("Response from API:", response.list);

        setData(response.list);

        let filteredData = response.list;
        if (id) {
          filteredData = filteredData.filter((cohort) => cohort.type === id);
          console.log("filteredData12", filteredData);
        }

        if (filteredData.length > 0) {
          setFilterCohortData(filteredData);
          setActiveCohortType(id);
        }
      },
      (err) => {
        console.error(err);
      }
    );
  };


const [addedVmCohortIds, setIsCheck] = useState([]);
const [userdetailsCohort, setUserdetailsCohort] = useState([]);

  console.log("searchCohortData:", userdetailsCohort);

  const FilterCohortData = data
    .filter(
      (vmlist) =>
        !searchCohortData ||
        vmlist.name.toLowerCase().includes(searchCohortData.toLowerCase()) ||
        vmlist.id.toString().includes(searchCohortData)
    )
    .filter((cohort) => !activeCohortType || cohort.type === activeCohortType);

 const addCohorthandleClick = React.useCallback(
   (e) => {
     console.log("removedVmCohortIds addddd");
     const { id, checked } = e.target;

     if (checked) {
       const updatedAddedVmCohortIds = [...addedVmCohortIds, parseInt(id)];
       setIsCheck(updatedAddedVmCohortIds);

       const updatedUserdetailsCohort = [
         ...userdetailsCohort,
         { id: parseInt(id) },
       ];
       setUserdetailsCohort(updatedUserdetailsCohort);
     } else {
     }
   },
   [addedVmCohortIds, userdetailsCohort]
 );
 console.log("user details", userdetailsCohort);
 const removedCohort = (e, id) => {
   const updatedAddedVmCohortIds = addedVmCohortIds.filter(
     (dataId) => dataId !== parseInt(id)
   );
   setIsCheck(updatedAddedVmCohortIds);

   const updatedUserdetailsCohort = userdetailsCohort.filter(
     (data) => data.id !== parseInt(id)
   );
   setUserdetailsCohort(updatedUserdetailsCohort);

   const updatedRemovedVmCohortIds = [...removedVmCohortIds, parseInt(id)];
   setRemovedVmCohortIds(updatedRemovedVmCohortIds);
 };

  return (
    <>
      <VmCreateComponent
        formData={formData}
        handleInputChange={handleInputChange}
        handleFileChange={handleFileChange}
        warehouseList={warehouseList}
        vmTypeList={vmTypeList}
        hardwareList={hardwareList}
        corporateList={corporateList}
        handleImageUpload={handleImageUpload}
        stateName={stateName}
        locationType={locationType}
        selectedFile={selectedFile}
        uploadStatus={uploadStatus}
        cityName={cityName}
        stateId={stateId}
        setStateId={setStateId}
        cohortList={cohortList}
        paymentList={paymentList}
        imagePreview={imagePreview}
        handleUpdateVMDetails={handleUpdateVMDetails}
        setFormData={setFormData}
       
        handleDeletePaymentChip={handleDeletePaymentChip}
        handlePaymentChange1={handlePaymentChange1}
        payments={payments}
        selectedPayments={selectedPayments}
        removedPaymentIds={removedPaymentIds}
        addedPaymentIds={addedPaymentIds}
        initialPaymentIds={initialPaymentIds}
        serialNumber={serialNumber}
        handleGetCityName={handleGetCityName}
        loading={loading}
        handleGetStateName={handleGetStateName}
        showCityList={showCityList}
        showStateList={showStateList}
        setShowCityList={setShowCityList}
        setShowStateList={setShowStateList}
        isEditPage={false}
        // handleEditVMCohorts={handleEditVMCohorts}
        getVMdetailsList={getVMdetailsList}
        stagecohortsTypes={stagecohortsTypes}
        Search={searchCohort}
      
        FilterCohortData={FilterCohortData}
       
        data={data}
       
        filterCohortType={filterCohortType}
        cohortVMTypeData={cohortVMTypeData}
        
        handleCohortTypeClick={handleCohortTypeClick}
        activeCohortType={activeCohortType}
        //  setActiveCohortType={setActiveCohortType}
        addCohorthandleClick={addCohorthandleClick}
        removedCohort={removedCohort}
        checkedCohorts={checkedCohorts}
        // isCheck={isCheck}
        userdetailsCohort={userdetailsCohort}
        vmDetailsData={vmDetailsData}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(VmEditContainer);
