import React from "react";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import Button from "@mui/material/Button";
import { useParams, useNavigate } from "react-router-dom";

const FranchiseeUpdateComponent = (props) => {
  const { cohortId } = useParams();
  const cohortIdNumber = parseInt(cohortId);
  const navigate = useNavigate();

  const goback = () => {
    navigate(-1);
   
  };

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>

      <div className="cohortsec1">
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex", flexDirection: "row" }}>
            <Box sx={{ width: 500, maxWidth: "100%", marginTop: "40px" }}>
              <TextField
                fullWidth
                label="Name"
                name="name"
                value={
                  (props.formDataFranchisee && props.formDataFranchisee.name) ||
                  ""
                }
                onChange={props.handleUpdateFranchisee}
                style={{ margin: "14px" }}
              />
              <TextField
                fullWidth
                label="Description"
                name="description"
                value={
                  (props.formDataFranchisee &&
                    props.formDataFranchisee.description) ||
                  ""
                }
                onChange={props.handleUpdateFranchisee}
                style={{ margin: "14px" }}
              />
              <TextField
                fullWidth
                label="Type"
                name="type"
                value={
                  (props.formDataFranchisee && props.formDataFranchisee.type) ||
                  ""
                }
                onChange={props.handleUpdateFranchisee}
                style={{ margin: "14px" }}
              />
              {/* <TextField
  fullWidth
  label="Cohort ID"
  name="cohortId"
  value={props.formDataFranchisee.cohortId}
  onChange={props.handleChangeFranchisee}
  style={{ margin: '14px' }}
/> */}
              <TextField
                fullWidth
                label="Cohort ID"
                name="cohortId"
                value={props.formDataFranchisee.cohortId}
                onChange={props.handleUpdateFranchisee}
                style={{ margin: "14px" }}
                InputLabelProps={{ shrink: true }}
              />

              <TextField
                fullWidth
                label="Owner ID"
                name="ownerId"
                value={
                  Number(
                    props.formDataFranchisee && props.formDataFranchisee.ownerId
                  ) || ""
                }
                onChange={props.handleUpdateFranchisee}
                style={{ margin: "14px" }}
              />
            </Box>
          </div>

          <Box className="backbtnaddpage">
            <Button className="backbtnaddpage1" onClick={goback}>
              Back
            </Button>

            <Button
              className="backbtnaddpage1"
              onClick={props.handleApicallToUpdate}
            >
              save
            </Button>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default FranchiseeUpdateComponent;
