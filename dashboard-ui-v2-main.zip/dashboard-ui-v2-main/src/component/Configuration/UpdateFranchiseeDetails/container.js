import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { useParams, useNavigate } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import FranchiseeUpdateComponent from "./component";

const UpdateFranchiseeDetailsContainer = (props) => {
  const { franchiseeId, id, cohortId } = useParams();
  const navigate = useNavigate();
  const [updateFranchisee, setUpdateFranchisee] = useState({});
  const [loading, setLoading] = useState(false);
  const [formDataFranchisee, setFormDataFranchisee] = useState({});

  useEffect(() => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/franchisee/${franchiseeId}`,
      "GET",
      undefined,
      (response) => {
        const formDataWithNumbers = {
          ...response,
          cohortId: parseInt(response.cohortId),
          ownerId: Number(response.ownerId),
        };
        setUpdateFranchisee(updateFranchisee);
        setFormDataFranchisee(formDataWithNumbers);
        setLoading(true);
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch franchisee details");
      }
    );
  }, [franchiseeId, id, cohortId]);

  const handleUpdateFranchisee = (event) => {
    const { name, value } = event.target;
    setFormDataFranchisee((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleApicallToUpdate = () => {
    handleChangeUpdateFranchisee();
    navigate(-1);
    toastr.success("Success", "Franchisee updated successfully");
  };

  const handleChangeUpdateFranchisee = async () => {
    const formDataToSend = {
      ...formDataFranchisee,
      ownerId: Number(formDataFranchisee.ownerId),
    };

    try {
      const response = await props.getDataFromAPI(
        `/dashboard/api/v2/admin/franchisee/${franchiseeId}`,
        "PATCH",
        formDataToSend,
        formDataToSend
      );

      console.log("Update response franchisee-------", response);

     
    } catch (error) {
      console.error("Error updating franchisee:", error);
      toastr.error("Failed", "Unable to update franchisee");
    }
  };

  return (
    <FranchiseeUpdateComponent
      loading={loading}
      formDataFranchisee={formDataFranchisee}
      handleUpdateFranchisee={handleUpdateFranchisee}
      handleApicallToUpdate={handleApicallToUpdate}
    />
  );
};

export default connect(null, {
  getDataFromAPI,
})(UpdateFranchiseeDetailsContainer);
