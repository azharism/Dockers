import React from "react";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import Button from "@mui/material/Button";
import { useParams, useNavigate } from "react-router-dom";
import leftArrow from "../../../assests/leftArrow.svg";

const CohortUpdateComponent = (props) => {
  console.log(
    "Type of props.formData.machines:",
    typeof props.formData && props.formData.machines
  );

  const navigate = useNavigate();
  const goback1 = () => {
    navigate(-1);
  };

  return (
    <div className="main-div">
      <div>
        <Sidebar />
      </div>
      <div>
        <div style={{ marginLeft: "42px", marginTop: "40px" }}>
          <h2>
            <img
              onClick={goback1}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Edit Cohort
          </h2>
        </div>
        <div className="cohortsec">
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <div style={{ display: "flex", flexDirection: "row", marginTop:"128px" }}>
              <Box
                sx={{
                  width: 500,
                  maxWidth: "100%",
                  marginTop:"80px"
                }}
                style={{ marginTop: "20px", marginRight: "20px" }}
              >
                <TextField
                  fullWidth
                  label="Add VMID"
                  name="newNameAttribute"
                  value={props.newNameAttribute}
                  onChange={props.handleInputChange}
                  style={{ margin: "14px" }}
                  error={props.inputError}
                />

                <Button
                  style={{
                    width: "500px",
                backgroundColor: "#14AE78",
                color: "#ffffff",
                height:"58px",
                borderRadius:"15px",
                marginLeft:"14px",
                marginTop:"20px"
                  }}
                  onClick={props.vmAdded}
                >
                  ADD
                </Button>
              </Box>
            </div>

            <div style={{ display: "flex", flexDirection: "row" }}></div>
          </div>

          <Box
            sx={{
              width: 500,
              maxWidth: "100%",
            }}
            style={{ marginTop: "90px", marginLeft: "30px" }}
          >
            <div
              style={{
                display: "inline-block",
                boxShadow: "0px 7px 9px rgba(0, 0, 0, 0.1)",
                padding: "16px",
                borderRadius: "4px",
                backgroundColor: "#FDFAEC",
                marginLeft:"10px"
              }}
            >
              <p style={{ margin: 0 }}>VMIDs: {props.vmIdList.join(", ")}</p>
            </div>

            <TextField
              fullWidth
              label="Remove VMID"
              name="machines"
              value={props.removeVmid}
              onChange={props.handleChangeRemoveVmid}
              style={{  marginTop:"30px"}}
            />
            <Button
              style={{
                width: "500px",
                backgroundColor: "#14AE78",
                color: "#ffffff",
                height:"58px",
                borderRadius:"15px",
               
                marginTop:"20px"

              }}
              onClick={props.vmDeleted}
            >
              Remove
            </Button>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default CohortUpdateComponent;
