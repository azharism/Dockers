import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import CohortUpdateComponent from "./component";
import { useParams, useNavigate } from "react-router-dom";
import { toastr } from "react-redux-toastr";

const UpdateCohortDetailsContainer = (props) => {
  const { id, cohortId, franchiseeId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [updateCohort, setUpdateCohort] = useState({});
  const [formData, setFormData] = useState({
    name: "",
    areaName: "",
    description: "",
    lat: "",
    lng: "",
    cohortTypeId: "",
    vmIDs: [],
    userID: "",
  });
  const [vmIdList, setVmIdList] = useState([]);
  const [addingVM, setAddingVM] = useState(false);

  const [newNameAttribute, setNewNameAttribute] = useState("");
  const [removeVmid, setRemoveVmid] = useState("");

  useEffect(() => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts/${cohortId}`,
      "GET",
      undefined,
      (response) => {
        console.log("Cohort details response", response);
        const vmIds = response.machines.map((machine) => machine.id);
        setVmIdList(vmIds);
        setUpdateCohort(response);
        setFormData({
          name: response.name || "",
          areaName: response.areaName || "",
          description: response.description || "",
          cohortTypeId: response.cohortTypeId || "",
          userID: response.users[0]?.id || "",
          machines: response.machines || [],
          lat: response.lat || "",
          lng: response.lng || "",
        });

        setLoading(true);
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch cohort details");
      }
    );
  }, [cohortId, id, franchiseeId]);

  const handleChangeUpdateCohort = (event) => {
    const { name, value } = event.target;

    if (name === "machines") {
      const machineIds = value.split(",").map((id) => ({ id }));
      setFormData((prevData) => ({
        ...prevData,
        vmIDs: machineIds,
      }));
    } else if (name === "userID") {
      setFormData((prevData) => ({
        ...prevData,
        userID: value,
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };

  const handleUpdateCohortApi = async () => {
    await handleUpdateCohort();
    navigate(-1);
    toastr.success("Success", "Cohort updated successfully");
  };

  const handleUpdateCohort = async () => {
    const formDataToSend = {
      ...formData,
      cohortTypeId: Number(formData.cohortTypeId),
      userID: Number(formData.userID),
    };

    try {
      const response = await props.getDataFromAPI(
        `/dashboard/api/v2/admin/vendingmachines/vm-cohorts/${cohortId}`,
        "PATCH",
        formDataToSend
      );

      console.log("Update response Cohort-------", response);
    } catch (error) {
      console.error("Error updating franchisee:", error);
      toastr.error("Failed", "Unable to update Cohort");
    }
  };

  const handleMachineToCohort = () => {
    if (!newNameAttribute) {
      toastr.error("Validation Error", "Please enter VM IDs to add");
      return;
    }

    const machineIds = newNameAttribute.split(",").map(Number);
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts/${cohortId}/machines`,
      "POST",
      machineIds,
      (response) => {
        console.log("API success response:", response);
        setNewNameAttribute("");

        navigate(-1);
        toastr.success("Success", "Machines added to cohort successfully");
      },
      (err) => {
        toastr.error("error", err.message);
      }
    );
  };

  const vmAdded = async () => {
    if (!newNameAttribute) {
      toastr.error("Validation Error", "Please enter VM IDs to add");
      return;
    }
    await handleMachineToCohort();
  };

  const handleInputChange = (event) => {
    const { value } = event.target;
    setNewNameAttribute(value);
  };

  const handleRemoveButtonClick = async () => {
    if (!removeVmid) {
      toastr.error("Validation Error", "Please enter VM IDs to remove");
      return;
    }

    const inputVmIds = removeVmid.split(",").map((vmId) => vmId.trim());

    for (const vmId of inputVmIds) {
      await handleDeleteCohortApi(vmId);
    }
  };

  const handleDeleteCohortApi = async (vmIdToDelete) => {
    try {
      const response = await props.getDataFromAPI(
        `/dashboard/api/v2/admin/vendingmachines/vm-cohorts/${cohortId}/vendingmachines/${vmIdToDelete}`,
        "DELETE"
      );

      if (response.status === 204) {
        console.log(`VMID ${vmIdToDelete} deleted successfully`);
        setRemoveVmid("");
        toastr.success("success", "VM id deleted");
      } else {
        console.error(
          `Error deleting VMID ${vmIdToDelete}:`,
          response.data.error
        );
      }
    } catch (error) {
      console.error(`Error deleting VMID ${vmIdToDelete}:`, error);
    }
  };

  const vmDeleted = () => {
    if (!removeVmid) {
      toastr.error("Validation Error", "Please enter VM IDs to remove");
      return;
    }
    toastr.success("succes", "remove successfully ");
    handleRemoveButtonClick();
    navigate(-1);
  };
// ankit
  const handleChangeRemoveVmid = (event) => {
    setRemoveVmid(event.target.value);
  };

  
  return (
    <CohortUpdateComponent
      loading={loading}
      formData={formData}
      handleChangeUpdateCohort={handleChangeUpdateCohort}
      handleUpdateCohortApi={handleUpdateCohortApi}
      handleMachineToCohort={handleMachineToCohort}
      handleInputChange={handleInputChange}
      handleRemoveButtonClick={handleRemoveButtonClick}
      newNameAttribute={newNameAttribute}
      handleChangeRemoveVmid={handleChangeRemoveVmid}
      removeVmid={removeVmid}
      vmDeleted={vmDeleted}
      vmIdList={vmIdList}
      onChangeRemoveVmid={handleChangeRemoveVmid}
      vmAdded={vmAdded}
      addingVM={addingVM}
    />
  );
};

export default connect(null, {
  getDataFromAPI,
})(UpdateCohortDetailsContainer);
