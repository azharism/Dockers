import React from 'react'
import "./component.css"
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';


const BankDetailsComponent = (props) => {
  return (
    <div className="cohortsec1">
<div style={{ marginLeft:"40px" }}>
  
  <Box
            sx={{
              width: 500,
              maxWidth: '100%',
            }}
            style={{ marginTop: '90px', marginRight: "20px" }}
          >
        
            <TextField fullWidth label=" Account Name" name="accountName" value={props.formDataBank&&props.formDataBank.accountName} onChange={props.handleChangeBankDetails} style={{ margin: '14px' }} />
            <TextField fullWidth label="Account Number" name="accountId" value={props.formDataBank&&props.formDataBank.accountId} onChange={props.handleChangeBankDetails} style={{ margin: '14px' }} />
            <TextField fullWidth label="IFSC" name="ifsc" value={props.formDataBank&&props.formDataBank.ifsc} onChange={props.handleChangeBankDetails} style={{ margin: '14px' }} />
           
          </Box>
  </div>

  
  
</div>

  )
}

export default BankDetailsComponent;