// import {
//     CREATE_FRANCHIES_SUCCESS,
//     CREATE_COHORT_SUCCESS,
  
//   } from "./constant.js";
  
//   export const createFranchiesSuccess = (payload) => ({
//     type: CREATE_FRANCHIES_SUCCESS,
//     payload,
//   });
  
//   export const createCohortSuccess = (payload) => ({
//     type: CREATE_COHORT_SUCCESS,
//     payload,
//   });
  
//   // ... Define other action creators here
import { CREATE_COHORT_SUCCESS, CREATE_FRANCHISEE_SUCCESS } from './constant.js';

export const onChange_CreateCohortSuccess = (payload) => ({
  
  type: CREATE_COHORT_SUCCESS,
  payload,
});
export const onChange_CreateFranchiseeSuccess = (payload) => ({
  type: CREATE_FRANCHISEE_SUCCESS,
  payload,
});
