// import React, { Component, useEffect, useState, useRef } from "react";
// import { connect } from "react-redux";
// import { getDataFromAPI } from "../../../HandleAPICalls/actions";
// import { Link, useNavigate, useHistory } from "react-router-dom";
// import { toastr } from "react-redux-toastr";
// import CohortCreateComponent from "./CohortCreate/component";
// import ConfigurepayoutComponent from "./component";
// import { onChange_CreateCohortSuccess } from "./action";
// import { onChange_CreateFranchiseeSuccess } from "./action";
// import { ToastContainer, toast } from "react-toastify";

// import "react-toastify/dist/ReactToastify.css";
// export const steps = ["Create a Cohort", "Create a Franchise", "Map Charges", "Add Franchise Bank Details"];

// const ConfigurepayoutContainer = (props) => {
//   const [activeStep, setActiveStep] = useState(0);
//   const [stepCompleted, setStepCompleted] = useState(
//     Array(steps.length).fill(false)
//   );
//   const [createCohortCalled, setCreateCohortCalled] = useState(false);
//   const navigate = useNavigate();
//   const [errors, setErrors] = useState();
//   const [createFranchiseeCharges, setCreateFranchiseeCharges] = useState(null);
//   const [franchiseeId, setFranchiseeId] = useState(null);
//   const [cohortId, setCohortId] = useState(null); // Ad
//   const [createFranchiseeCalled, setCreateFranchiseeCalled] = useState(false)
//   const [selectedChargeIds, setSelectedChargeIds] = useState([]);
//   const [formData, setFormData] = useState({
//     name: "",
//     areaName: "",
//     description: "",
//     latitude: "",
//     longitude: "",
//     cohortTypeId: "",
//     vmIDs: "",
//     userID: "",
//     machines: [],
//   });
//   const [formDataFranchisee, setFormDataFranchisee] = useState({
//     name: "",
//     description: "",
//     type: "",
//     cohortId: "",
//     ownerId: "",
//   });

//   const [formDataBank, setFormDataBank] = useState({
//     accountName:"",
//     accountId:"",
//     ifsc:"",
//     vpaId:"",
//   })

//   console.log("franchiseeCharges", createFranchiseeCharges);

//   const handleNext = async () => {
//     let isValid = true;

//     if (activeStep === 0) {
//       isValid = validateCohortFields();
//       if (!isValid) {
//         toastr.error("Error", "Please Enter All Required Fields to Create a Cohort");
//         return;
//       }
//     } else if (activeStep === 1) {
//       isValid = validateFranchiseeFields();
//       if (!isValid) {
//         toastr.error("Error", "Please Enter All Required Fields to Create a Franchisee");
//         return;
//       }
//     } else if (activeStep === 3) {
//       isValid = validateBankDetailsFields();
//       if (!isValid) {
//         toastr.error("Error", "Please Enter All Required Fields to Create a Bank details");
//         return;
//       }
//     }

//     if (activeStep === 2) {
//       await handleAssignCharges();
//     }

//     setActiveStep((prevStep) => prevStep + 1);

//     if (activeStep === 0) {
//       await handleCreateCohort();
//     } else if (activeStep === 1) {
//       await handleCreateFranchisee();
//     } else if (activeStep === 3) {
//       await handleBankDetails();
//     }
//   };

//   const validateCohortFields = () => {
//     const requiredFields = ["name", "areaName", "description", "cohortTypeId", "longitude","latitude","vmIDs","userID"];
//     let isValid = true;

//     const newErrors = { ...errors };

//     requiredFields.forEach((field) => {
//       if (formData[field].trim() === "") {
//         newErrors[field] = `${
//           field.charAt(0).toUpperCase() + field.slice(1)
//         } is required`;
//         isValid = false;
//       } else {
//         newErrors[field] = "";
//       }
//     });

//     setErrors(newErrors);
//     return isValid;
//   };

//   const validateFranchiseeFields = () => {
//     const requiredFranchiseeFields = ["name", "description", "ownerId", "type"];
//     let isValid = true;

//     const newErrors = {};

//     requiredFranchiseeFields.forEach((field) => {
//       if (!formDataFranchisee[field]) {
//         newErrors[field] = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
//         isValid = false;
//       } else {
//         newErrors[field] = "";
//       }
//     });

//     setErrors(newErrors);
//     return isValid;
//   };

//   const validateBankDetailsFields = () => {
//     const requiredFields = ["accountName", "accountId", "ifsc"];
//     let isValid = true;

//     const newErrors = { ...errors };

//     requiredFields.forEach((field) => {
//       if (formDataBank[field].trim() === "") {
//         newErrors[field] = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
//         isValid = false;
//       } else {
//         newErrors[field] = "";
//       }
//     });

//     setErrors(newErrors);
//     return isValid;
//   };

//   const handleClose = () => {
//     setActiveStep((prevStep) => prevStep - 1);
//   };

//   const handleChangeCohort = (event) => {
//     const { name, value } = event.target;
//     setFormData((prevData) => ({ ...prevData, [name]: value }));
//   };

//   const handleChangeFranchisee = (event) => {
//     const { name, value } = event.target;
//     setFormDataFranchisee((prevData) => ({ ...prevData, [name]: value }));
//   };

//   const handleCreateCohort = () => {
//     validateCohortFields();
//     console.log("handleCreateCohort function called");
//     const cohortTypeId = parseInt(formData.cohortTypeId);
//     const latitude = parseFloat(formData.latitude);
//     const longitude = parseFloat(formData.longitude);
//     const userID = formData.userID.split(",").map(Number);

//     const vmIDsArray = formData.vmIDs.split('').map(Number);

//     const payload = {
//       name: formData.name,
//       areaName: formData.areaName,
//       description: formData.description,
//       lat: isNaN(latitude) ? null : latitude,
//       lng: isNaN(longitude) ? null : longitude,
//       cohortTypeId: isNaN(cohortTypeId) ? null : cohortTypeId,
//       vmCollection: vmIDsArray,

//       userIdCollection: userID.filter((id) => !isNaN(id)),
//     };

//     props.getDataFromAPI(
//       `/dashboard/api/v2/admin/vendingmachines/vm-cohorts`,
//       "POST",
//       payload,
//       (response) => {
//         console.log("API success response:", response);

//         if (response.cohortId !== undefined) {
//           console.log("Cohort success:", response);
//           props.onChange_CreateCohortSuccess(response);
//           toastr.success("Success", "Cohort created successfully");

//           setCohortId(response.cohortId);
//         } else {
//           console.log("Cohort creation failed:", response);
//           toastr.error("Failed", "Unable to create cohort");
//         }
//       }
//     );
//   };

//   const handleCreateFranchisee = () => {
//     validateFranchiseeFields();
//     console.log("Creating franchisee...");
//     const cohortIdValue =
//       formDataFranchisee.cohortId !== ""
//         ? parseInt(formDataFranchisee.cohortId)
//         : cohortId;

//     const payload = {
//       name: formDataFranchisee.name,
//       description: formDataFranchisee.description,
//       type: formDataFranchisee.type,
//       cohortId: cohortIdValue,
//       ownerId: parseInt(formDataFranchisee.ownerId),
//     };

//     props.getDataFromAPI(
//       `/dashboard/api/v2/admin/franchisee`,
//       "POST",
//       payload,
//       (response) => {
//         console.log("Franchisee creation response:", response);

//         const franchiseeId = response.id;
//         console.log("Franchisee ID inside createFranchisee:", franchiseeId);
//         setFranchiseeId(franchiseeId);
//         handleGetMapCharges();

//       },
//       (err) => {
//         console.log("Error creating franchisee:", err);
//         toastr.error(`${err.message}`, {
//           position: toast.POSITION.TOP_RIGHT,
//           autoClose: 1000,
//         });
//       }
//     );
//   };

//   const handleGetMapCharges = () => {
//     const queryParams = new URLSearchParams({
//       pageSize: 50,
//       pageNumber: 0,
//       beneficiaryTypeId: 1,
//     });

//     const url = `/dashboard/api/v2/admin/platform/charge?${queryParams.toString()}`;

//     props.getDataFromAPI(
//       url,
//       "GET",
//       undefined,
//       (response) => {
//         console.log("Franchisee charges response:", response);
//         setCreateFranchiseeCharges(response);

//       },
//       (err) => {
//         console.log("error---", err);
//         toastr.error("Failed", "Unable to fetch franchisee details");
//       }
//     );
//   };

//   const handleCheckboxChange = (chargeId) => {
//     const updatedChargeIds = [...selectedChargeIds];

//     if (updatedChargeIds.includes(chargeId)) {

//       updatedChargeIds.splice(updatedChargeIds.indexOf(chargeId), 1);
//     } else {

//       updatedChargeIds.push(chargeId);
//     }

//     setSelectedChargeIds(updatedChargeIds);
//   };

// useEffect(() => {
//   if (activeStep === 2 && !createFranchiseeCharges) {
//     handleGetMapCharges();
//   }

//   if (activeStep === 2 && createFranchiseeCharges) {
//     const allChargeIds = createFranchiseeCharges.map((charge) => charge.id);
//     setSelectedChargeIds(allChargeIds);
//   }
// }, [activeStep, createFranchiseeCharges]);

// const handleAssignCharges = async () => {

//   if (!franchiseeId) {
//     console.log("Franchisee ID is undefined");
//     return;
//   }

//   const payload = selectedChargeIds;

//   try {
//     const response = await props.getDataFromAPI(
//       `/dashboard/api/v2/admin/platform/beneficiary/franchisee/${franchiseeId}/charge`,
//       "POST",
//       payload
//     );

//     console.log("Assign charges response:", response);

//     setFranchiseeId(franchiseeId);

//     setActiveStep((prevStep) => prevStep + 1);
//   } catch (err) {
//     console.log("Error assigning charges:", err);

//   }
// };

//   const handleBankDetails = async () => {
//     if (!validateBankDetailsFields()) {
//       return;
//     }

//     try {
//       const payload = {
//         accountName: formDataBank.accountName,
//         accountId: formDataBank.accountId,
//         ifsc: formDataBank.ifsc,
//       };

//       const response = await props.getDataFromAPI(
//         `/dashboard/api/v2/admin/franchisee/${franchiseeId}/bank-detail`,
//         "PUT",
//         payload
//       );

//       console.log("bank details creation response:", response);
//       setFranchiseeId(response.id);
//       navigate("/home/configuration/managepartners");
//     } catch (err) {
//       console.log("err ankit", err);
//       toastr.error(`${err.message}`, {
//         position: toast.POSITION.TOP_RIGHT,
//         autoClose: 1000,
//       });
//     }
//   };

//   const handleChangeBankDetails = (event) => {
//     const { name, value } = event.target;
//     setFormDataBank((prevData) => ({ ...prevData, [name]: value }));
//   };

//   return (
//     <>
//       <ConfigurepayoutComponent
//         activeStep={activeStep}
//         handleNext={handleNext}
//         handleClose={handleClose}
//         handleCreateCohort={handleCreateCohort}
//         formData={formData}
//         handleChangeCohort={handleChangeCohort}
//         setFormData={setFormData}
//         handleCreateFranchisee={handleCreateFranchisee}
//         setFormDataFranchisee={setFormDataFranchisee}
//         handleChangeFranchisee={handleChangeFranchisee}
//         errors={errors}
//         createFranchiseeCharges={createFranchiseeCharges}
//         createCohortCalled={createCohortCalled}
//         handleAssignCharges={handleAssignCharges}
//         handleBankDetails={handleBankDetails}
//         cohortId={cohortId}
//         handleChangeBankDetails={handleChangeBankDetails}
//         formDataBank={formDataBank}
//         // handleAssignChargesClick={handleAssignChargesClick}
//         handleCheckboxChange={handleCheckboxChange}
//         selectedChargeIds={selectedChargeIds}
//         franchiseeId={franchiseeId}
//        stepCompleted={stepCompleted}
//       //  handleSaveButtonClick={handleSaveButtonClick}

//       />
//     </>
//   );
// };

// function mapStateToProps(props) {
//   return {
//     props,
//   };
// }
// export default connect(mapStateToProps, {
//   getDataFromAPI,
//   onChange_CreateCohortSuccess,
//   onChange_CreateFranchiseeSuccess,
// })(ConfigurepayoutContainer);

import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../../HandleAPICalls/actions";
import { Link, useNavigate, useHistory } from "react-router-dom";
import { toastr } from "react-redux-toastr";
import CohortCreateComponent from "./CohortCreate/component";
import ConfigurepayoutComponent from "./component";
import { onChange_CreateCohortSuccess } from "./action";
import { onChange_CreateFranchiseeSuccess } from "./action";
import { ToastContainer, toast } from "react-toastify";

import "react-toastify/dist/ReactToastify.css";

export const steps = [
  "Create a Cohort",
  "Create a Franchise",
  "Map Charges",
  "Add Franchise Bank Details",
];

const ConfigurepayoutContainer = (props) => {
  const [activeStep, setActiveStep] = useState(0);
  const [stepCompleted, setStepCompleted] = useState(
    Array(steps.length).fill(false)
  );
  const [createCohortCalled, setCreateCohortCalled] = useState(false);
  const navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const [createFranchiseeCharges, setCreateFranchiseeCharges] = useState(null);
  const [franchiseeId, setFranchiseeId] = useState(null);
  const [cohortId, setCohortId] = useState(null);
  const [createFranchiseeCalled, setCreateFranchiseeCalled] = useState(false);
  const [selectedChargeIds, setSelectedChargeIds] = useState([]);

  const [formData, setFormData] = useState({
    name: "",
    areaName: "",
    description: "",
    latitude: "",
    longitude: "",
    cohortTypeId: "",
    vmIDs: "",
    userID: "",
    machines: [],
  });
  const [formDataFranchisee, setFormDataFranchisee] = useState({
    name: "",
    description: "",
    type: "",
    cohortId: "",
    ownerId: "",
  });

  const [formDataBank, setFormDataBank] = useState({
    accountName: "",
    accountId: "",
    ifsc: "",
    vpaId: "",
  });

  console.log("franchiseeCharges", createFranchiseeCharges);

  const handleNext = async () => {
    let isValid = true;

    if (activeStep === 0) {
      isValid = validateCohortFields();
      if (!isValid) {
        toastr.error(
          "Error",
          "Please Enter All Required Fields to Create a Cohort"
        );
        return;
      }
    } else if (activeStep === 1) {
      isValid = validateFranchiseeFields();
      if (!isValid) {
        toastr.error(
          "Error",
          "Please Enter All Required Fields to Create a Franchisee"
        );
        return;
      }
    } else if (activeStep === 2) {
      if (selectedChargeIds.length === 0) {
        toastr.error("Error", "Please Select at least one Charge to Proceed");
        return;
      }
    } else if (activeStep === 3) {
      isValid = validateBankDetailsFields();
      if (!isValid) {
        toastr.error(
          "Error",
          "Please Enter All Required Fields to Create a Bank details"
        );
        return;
      }
    }

    if (activeStep === 2) {
      await handleAssignCharges();
    }

    if (activeStep === 0) {
      await handleCreateCohort();
    } else if (activeStep === 1) {
      await handleCreateFranchisee();
    } else if (activeStep === 3) {
      await handleBankDetails();
    }

    setActiveStep((prevStep) => prevStep + 1);
  };

  const validateCohortFields = () => {
    const requiredFields = [
      "name",
      "areaName",
      "description",
      "cohortTypeId",
      "longitude",
      "latitude",
      "vmIDs",
      "userID",
    ];
    let isValid = true;

    const newErrors = { ...errors };

    requiredFields.forEach((field) => {
      if (formData[field].trim() === "") {
        newErrors[field] = `${
          field.charAt(0).toUpperCase() + field.slice(1)
        } is required`;
        isValid = false;
      } else {
        newErrors[field] = "";
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  const validateFranchiseeFields = () => {
    const requiredFranchiseeFields = ["name", "description", "ownerId", "type"];
    let isValid = true;

    const newErrors = {};

    requiredFranchiseeFields.forEach((field) => {
      if (!formDataFranchisee[field]) {
        newErrors[field] = `${
          field.charAt(0).toUpperCase() + field.slice(1)
        } is required`;
        isValid = false;
      } else {
        newErrors[field] = "";
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  const validateBankDetailsFields = () => {
    const requiredFields = ["accountName", "accountId", "ifsc"];
    let isValid = true;

    const newErrors = { ...errors };

    requiredFields.forEach((field) => {
      if (formDataBank[field].trim() === "") {
        newErrors[field] = `${
          field.charAt(0).toUpperCase() + field.slice(1)
        } is required`;
        isValid = false;
      } else {
        newErrors[field] = "";
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  const handleClose = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleChangeCohort = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleChangeFranchisee = (event) => {
    const { name, value } = event.target;
    setFormDataFranchisee((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleCreateCohort = () => {
    validateCohortFields();
    console.log("handleCreateCohort function called");
    const cohortTypeId = parseInt(formData.cohortTypeId);
    const latitude = parseFloat(formData.latitude);
    const longitude = parseFloat(formData.longitude);
    const userID = formData.userID.split(",").map(Number);

    const vmIDsArray = formData.vmIDs
      .split(",")
      .map((item) => parseInt(item.trim(), 10))
      .filter((item) => !isNaN(item));

    const payload = {
      name: formData.name,
      areaName: formData.areaName,
      description: formData.description,
      lat: isNaN(latitude) ? null : latitude,
      lng: isNaN(longitude) ? null : longitude,
      cohortTypeId: isNaN(cohortTypeId) ? null : cohortTypeId,
      vmCollection: vmIDsArray,
      userIdCollection: userID.filter((id) => !isNaN(id)),
    };

    props.getDataFromAPI(
      `/dashboard/api/v2/admin/vendingmachines/vm-cohorts`,
      "POST",
      payload,
      (response) => {
        console.log("API success response:", response);

        if (response.cohortId !== undefined) {
          console.log("Cohort success:", response);
          props.onChange_CreateCohortSuccess(response);
          toastr.success("Success", "Cohort created successfully");

          setCohortId(response.cohortId);
        } else {
          console.log("Cohort creation failed:", response);
          toastr.error("Failed", "Unable to create cohort");
        }
      }
    );
  };

  const handleCreateFranchisee = () => {
    validateFranchiseeFields();
    console.log("Creating franchisee...");
    const cohortIdValue =
      formDataFranchisee.cohortId !== ""
        ? parseInt(formDataFranchisee.cohortId)
        : cohortId;

    const payload = {
      name: formDataFranchisee.name,
      description: formDataFranchisee.description,
      type: formDataFranchisee.type,
      cohortId: cohortIdValue,
      ownerId: parseInt(formDataFranchisee.ownerId),
    };

    props.getDataFromAPI(
      `/dashboard/api/v2/admin/franchisee`,
      "POST",
      payload,
      (response) => {
        console.log("Franchisee creation response:", response);

        const franchiseeId = response.id;
        console.log("Franchisee ID inside createFranchisee:", franchiseeId);
        setFranchiseeId(franchiseeId);
        handleGetMapCharges();
      },
      (err) => {
        console.log("Error creating franchisee:", err);
        toastr.error(`${err.message}`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
        });
      }
    );
  };

  const handleGetMapCharges = () => {
    const queryParams = new URLSearchParams({
      pageSize: 50,
      pageNumber: 0,
      beneficiaryTypeId: 1,
    });

    const url = `/dashboard/api/v2/admin/platform/charge?${queryParams.toString()}`;

    props.getDataFromAPI(
      url,
      "GET",
      undefined,
      (response) => {
        console.log("Franchisee charges response:", response);
        setCreateFranchiseeCharges(response);
      },
      (err) => {
        console.log("error---", err);
        toastr.error("Failed", "Unable to fetch franchisee details");
      }
    );
  };

  const handleCheckboxChange = (chargeId) => {
    if (selectedChargeIds.includes(chargeId)) {
      setSelectedChargeIds(selectedChargeIds.filter((id) => id !== chargeId));
    } else {
      setSelectedChargeIds([...selectedChargeIds, chargeId]);
    }
  };

  useEffect(() => {
    if (activeStep === 2 && !createFranchiseeCharges) {
      handleGetMapCharges();
    }

    if (activeStep === 2 && createFranchiseeCharges) {
      setSelectedChargeIds([]);
    }
  }, [activeStep, createFranchiseeCharges]);



  
  const handleAssignCharges = async () => {
    if (!franchiseeId) {
      return;
    }

    

    const payload = selectedChargeIds;

    try {
      const response = await props.getDataFromAPI(
        `/dashboard/api/v2/admin/platform/beneficiary/franchisee/${franchiseeId}/charge`,
        "POST",
        payload,
        (response) => {
          console.log("handleAssignCharges API response:", response);

          setFranchiseeId(franchiseeId);
          toastr.success("Charges Apply");
        },
        (err) => {
          setActiveStep((prevStep) => prevStep - 1);
          console.log(" handleAssignCharges err refund api ", err.message);
          toastr.error(`${err.message}`, {
            position: toast.POSITION.TOP_RIGHT,
            autoClose: 1000,
          });
        }
      );
    } catch (err) {
      console.log("Error assigning charges:", err);
    }
  };

  const handleBankDetails = async () => {
    if (!validateBankDetailsFields()) {
      return;
    }

    try {
      const payload = {
        accountName: formDataBank.accountName,
        accountId: formDataBank.accountId,
        ifsc: formDataBank.ifsc,
      };

      const response = await props.getDataFromAPI(
        `/dashboard/api/v2/admin/franchisee/${franchiseeId}/bank-detail`,
        "PUT",
        payload
      );

      console.log("bank details creation response:", response);
      setFranchiseeId(response.id);
      navigate("/home/configuration/managepartners");
    } catch (err) {
      console.log("err ankit", err);
      toastr.error(`${err.message}`, {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 1000,
      });
    }
  };

  const handleChangeBankDetails = (event) => {
    const { name, value } = event.target;
    setFormDataBank((prevData) => ({ ...prevData, [name]: value }));
  };

  return (
    <>
      <ConfigurepayoutComponent
        activeStep={activeStep}
        handleNext={handleNext}
        handleClose={handleClose}
        handleCreateCohort={handleCreateCohort}
        formData={formData}
        handleChangeCohort={handleChangeCohort}
        setFormData={setFormData}
        handleCreateFranchisee={handleCreateFranchisee}
        setFormDataFranchisee={setFormDataFranchisee}
        handleChangeFranchisee={handleChangeFranchisee}
        errors={errors}
        createFranchiseeCharges={createFranchiseeCharges}
        createCohortCalled={createCohortCalled}
        handleAssignCharges={handleAssignCharges}
        handleBankDetails={handleBankDetails}
        cohortId={cohortId}
        handleChangeBankDetails={handleChangeBankDetails}
        formDataBank={formDataBank}
        handleCheckboxChange={handleCheckboxChange}
        selectedChargeIds={selectedChargeIds}
        franchiseeId={franchiseeId}
        stepCompleted={stepCompleted}
      />
    </>
  );
};

function mapStateToProps(props) {
  return {
    props,
  };
}

export default connect(mapStateToProps, {
  getDataFromAPI,
  onChange_CreateCohortSuccess,
  onChange_CreateFranchiseeSuccess,
})(ConfigurepayoutContainer);
