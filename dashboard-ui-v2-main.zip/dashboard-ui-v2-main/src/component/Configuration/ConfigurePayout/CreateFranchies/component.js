import React from 'react'
import "./component.css"
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';

const CreateFranchiesComponent = (props) => {
  return (
    <div className="cohortsec1">
<div >
  <div  style={{display:"block", marginLeft:"40px"}}>
    <Box
      sx={{
        width: 500,
        maxWidth: '100%',
      }}
      style={{ marginTop: '40px'  }}
    >
      <TextField fullWidth label="Name" name='name' value={props.formDataFranchisee&&props.formDataFranchisee.name} onChange={props.handleChangeFranchisee}  style={{ margin: '14px' }} />
      <TextField fullWidth label="Description" name='description' value={props.formDataFranchisee&&props.formDataFranchisee.description} onChange={props.handleChangeFranchisee} style={{ margin: '14px' }} />
      <TextField fullWidth label="Type" name='type' value={props.formDataFranchisee&&props.formDataFranchisee.type} onChange={props.handleChangeFranchisee} style={{ margin: '14px' }} />
      {/* <TextField
        fullWidth
        label={props.cohortId ? '' : 'Cohort id'}
        id="cohortId"
        name="cohortId"
        value={props.cohortId}
        onChange={props.handleChangeFranchisee}
        style={{ margin: '14px', color:"#1c1c1" }}
        disabled={true}
      /> */}


 <TextField
            fullWidth
            label="Cohort id"
            id="cohortId"
            name="cohortId"
            value={props.cohortId}
            onChange={props.handleChangeFranchisee}
            InputProps={{
                readOnly: true,
                style: {
                    marginTop: '2px', // Adjust as needed for proper alignment
                    color: '#1c1c1c', // Text color
                },
            }}
            InputLabelProps={{
                shrink: true, // Ensures label stays up when text is present
            }}
            disabled={true}
            style={{ margin: '14px', color:"#1c1c1" }}
        />

      <TextField fullWidth label="Owner ID" name='ownerId' value={props.formDataFranchisee&&props.formDataFranchisee.ownerId} onChange={props.handleChangeFranchisee} style={{ margin: '14px' }} />
      
    </Box>
  </div>

  
</div>




  </div>
  )
}

export default CreateFranchiesComponent;