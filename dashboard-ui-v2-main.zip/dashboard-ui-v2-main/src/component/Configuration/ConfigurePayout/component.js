import React from "react";
import "./component.css";
import Sidebar from "../../Navigation/Sidebar/Sidebar";
import leftArrow from "../../../assests/leftArrow.svg";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Button from "@mui/material/Button";
import CohortCreateComponent from "./CohortCreate/component";
import CreateFranchiesComponent from "./CreateFranchies/component";
import MapToChargeComponent from "./MapToCharge/component";
import BankDetailsComponent from "./BankDetails/component";
import { Link, useNavigate, useHistory } from "react-router-dom";

const ConfigurepayoutComponent = (props) => {
  const steps = [
    "Create a Cohort",
    "Create a Franchise",
    "Map Charges",
    "Add Franchise Bank Details",
  ];

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };

  const handleSaveButtonClick = async () => {
    if( props.activeStep === steps.length - 0 ){
     props.handleBankDetails()
    }else{
     props.handleNext()
    }
    
   };

  return (
    <div className="main-div">
      {/* Sidebar */}
      <Sidebar />

      <div>
        <div style={{ marginLeft: "42px", marginTop: "20px" }}>
          <h2>
            <img
              onClick={handleClick}
              style={{ width: "22px", cursor: "pointer" }}
              src={leftArrow}
              alt=""
            />{" "}
            Create a Franchise
          </h2>
        </div>
        <div style={{ marginLeft: "20px", width: "100%" }}>
          <div style={{ width: "694px", margin: "30px" }}>
            <Box sx={{ width: "100%" }}>
            <Stepper activeStep={props.activeStep}>
              {steps.map((label, index) => {
                const stepProps = {};
                const labelProps = {};
              
                return (
                  <Step key={label} {...stepProps}>
                    <StepLabel {...labelProps}>{label} </StepLabel>
                  </Step>
                );
              })}
            </Stepper>
            </Box>
          </div>
          <div>
  <React.Fragment>
    {props.activeStep === 0 ? (
      <>
        <CohortCreateComponent
          formData={props.formData}
          setFormData={props.setFormData}
          handleChangeCohort={props.handleChangeCohort}
          handleCreateCohort={props.handleCreateCohort}
        />
      </>
    ) : props.activeStep === 1 ? (
      <>
        <CreateFranchiesComponent
          formDataFranchisee={props.formDataFranchisee}
          setFormDataFranchisee={props.setFormDataFranchisee}
          handleChangeFranchisee={props.handleChangeFranchisee}
          handleCreateFranchisee={props.handleCreateFranchisee}
          cohortId={props.cohortId}
          errors={props.errors}
        />
      </>
    ) : props.activeStep === 2 ? (
      <>
      <MapToChargeComponent
  createFranchiseeCharges={props.createFranchiseeCharges}
  selectedChargeIds={props.selectedChargeIds}
  handleCheckboxChange={props.handleCheckboxChange}
/>

        {/* <MapToChargeComponent
          createFranchiseeCharges={props.createFranchiseeCharges}
          handleGetMapCharges={props.handleGetMapCharges}
          handleAssignCharges={props.handleAssignCharges}
          handleCheckboxChange={props.handleCheckboxChange}
          selectedChargeIds={props.selectedChargeIds}
          franchiseeId={props.franchiseeId}


        /> */}
      </>
    ) : (
      <>
        <BankDetailsComponent
          handleChangeBankDetails={props.handleChangeBankDetails}
          formDataBank={props.formDataBank}
          handleBankDetails={props.handleBankDetails}
          franchiseeId={props.franchiseeId}
          handleSaveButtonClick={props.handleSaveButtonClick}
        />
      </>
    )}
  </React.Fragment>
</div>

<Box className="backbtnaddpage">
  <Button
    className="backbtnaddpage1"
    disabled={props.activeStep === 0}
    onClick={props.handleClose}
  >
    Back
  </Button>
  
  {props.activeStep === steps.length - 0 ? (
    <Button
      className="saveandcontinue"
      onClick={handleSaveButtonClick}
    >
      Save
    </Button>
  ) : (
    <Button className="saveandcontinue" onClick={props.handleNext}>
      Save and Continue
    </Button>
  )}
</Box>

        </div>
      </div>
    </div>
  );
};

export default ConfigurepayoutComponent;
