import React from 'react'
import "./component.css"
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';


const CohortCreateComponent = (props) => {
  return (
    <div className="cohortsec">
<div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
  <div style={{ display: 'flex', flexDirection: 'row' }}>
  <Box
            sx={{
              width: 500,
              maxWidth: '100%',
            }}
            style={{ marginTop: '90px', marginRight: "20px" }}
          >
         
            <TextField fullWidth label="Name" name="name" value={props.formData.name} onChange={props.handleChangeCohort} style={{ margin: '14px' }} />
            {/* {props.errors&&props.errors.name && <p>{props.errors&&props.errors.name}</p>} */}
            <TextField fullWidth label="Area Name" name="areaName" value={props.formData.areaName} onChange={props.handleChangeCohort} style={{ margin: '14px' }} />
            <TextField fullWidth label="Description" name="description" value={props.formData.description} onChange={props.handleChangeCohort} style={{ margin: '14px' }} />
            <TextField fullWidth label="Latitude" name="latitude" value={props.formData.latitude} onChange={props.handleChangeCohort} style={{ margin: '14px' }} />
          </Box>
  </div>

  <div style={{ display: 'flex', flexDirection: 'row' }}>
 
  </div>
</div>

<Box
            sx={{
              width: 500,
              maxWidth: '100%',
            }}
            style={{ marginTop: '90px', marginLeft: "30px" }}
          >
            <TextField fullWidth label="Longitude" name="longitude" value={props.formData.longitude} onChange={props.handleChangeCohort} style={{ margin: '14px' }} />
            <TextField fullWidth label="Cohort Type ID" name="cohortTypeId" value={props.formData.cohortTypeId} onChange={props.handleChangeCohort} style={{ margin: '14px' }} />
            <TextField fullWidth label="VM ID’s" name="vmIDs" value={props.formData.vmIDs} onChange={props.handleChangeCohort} style={{ margin: '14px' }} />
            <TextField fullWidth label="User ID" name="userID" value={props.formData.userID} onChange={props.handleChangeCohort} style={{ margin: '14px' }} />
          </Box>


  </div>
  )
}

export default CohortCreateComponent;