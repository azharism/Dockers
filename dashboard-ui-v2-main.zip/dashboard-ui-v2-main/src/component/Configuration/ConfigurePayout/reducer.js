
// import { CREATE_FRANCHIES_SUCCESS, CREATE_COHORT_SUCCESS, /* ... */ } from "./constant.js";

// const initialState = {
//   franchies: null,
//   cohort: '',
//   // ... Initialize other state properties here
// };

// export default (state = initialState, action) => {
//   switch (action.type) {
//     case CREATE_FRANCHIES_SUCCESS:
//       return {
//         ...state,
//         franchies: action.payload,
//       };
//     case CREATE_COHORT_SUCCESS:
//       return {
//         ...state,
//         cohort: action.payload,
//       };
//     // Add cases for other steps or features here
//     default:
//       return state;
//   }
// };
import { CREATE_COHORT_SUCCESS } from './constant.js';
import {CREATE_FRANCHISEE_SUCCESS} from "./constant.js"

const initialState = {
  cohort: null,
  franchisee: null,
  // ... other state properties
};

export default (state = initialState, action) => {
  switch (action.type) {
    case CREATE_COHORT_SUCCESS:
      return {
        ...state,
        cohort: action.payload,
      };
      case CREATE_FRANCHISEE_SUCCESS:
        return{
          ...state,
          franchisee:action.payload
        };
    // ... other cases
    default:
      return state;
  }
};
