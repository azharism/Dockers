// import React, {useState} from "react";
// import "./component.css";
// import Box from "@mui/material/Box";
// import TextField from "@mui/material/TextField";
// import Card from "@mui/material/Card";
// import CardActions from "@mui/material/CardActions";
// import CardContent from "@mui/material/CardContent";
// import Button from "@mui/material/Button";
// import Typography from "@mui/material/Typography";
// import { IconButton } from "@mui/material";
// import add from "../../../../assests/add.svg"
// import remove from "../../../../assests/remove.svg"
// import chargemap from "../../../../assests/chargemap.svg"

// const MapToChargeComponent = (props) => {
//  console.log("chargemap", props.franchiseeCharges)
//   return (
//     <div className="maptocharge-div">
//     <div style={{ overflow: "auto", height: "940px" }}>
//       <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between" }}>
//         {props.createFranchiseeCharges &&
//           props.createFranchiseeCharges.map((charge, index) => (
//             <Card
//               key={charge.id}
//               sx={{
//                 width: "370px",
//                 minHeight: "320px",
//                 margin: "10px",
//               }}
//             >
//                 <div
//                   style={{
//                     display: "flex",
//                     justifyContent: "space-between",
//                     alignItems: "center",
//                     borderBottom: "1px solid #ccc",
//                   }}
//                 >
//                   <Typography
//                     style={{
//                       textAlign: "right",
//                       marginRight: "216px",
//                       fontWeight: 500,
//                       height: "40px",
//                       padding: "10px",
//                       width:"264px"
//                     }}
//                   >
//                     Charge Name {index+1}
//                   </Typography>
//                   <div  >
//                   <input
//                  style={{padding:"15px",width:"20px", marginLeft:"-28px", height:"20px"}}
//   key={charge.id}
//   type="checkbox"
//   checked={props.selectedChargeIds.includes(charge.id)}
//   onChange={() => props.handleCheckboxChange(charge.id)}
// />


//                   </div>
//                 </div>

//                 <CardContent>
//                   <ul>
//                     <li>Id: {charge.id}</li>
//                     <li>Name: {charge.name}</li>
//                     <li>Description: {charge.description}</li>
//                     <li>Beneficiary Type Id: {charge.beneficiaryTypeId}</li>
//                     <li>Charge Type: {charge.chargeType}</li>
//                     <li>Value Type: {charge.valueType}</li>
//                     <li>Value: {charge.value}</li>
//                     <li>Value Min: {charge.valueMin}</li>
//                     <li>Value Max: {charge.valueMax}</li>
//                   </ul>
//                 </CardContent>
//               </Card>
//             ))}
//             </div>
//           </div>
//         </div>
//   );
// };

// export default MapToChargeComponent;

import React from "react";
import "./component.css";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";

const MapToChargeComponent = (props) => {
  console.log("chargemap", props.createFranchiseeCharges);

  return (
    <div className="maptocharge-div">
      <div style={{ overflow: "auto", height: "716px", position:"relative" }}>
        <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between" }}>
          {props.createFranchiseeCharges &&
            props.createFranchiseeCharges.map((charge, index) => (
              <Card
                key={charge.id}
                sx={{
                  width: "370px",
                  minHeight: "320px",
                  margin: "10px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    borderBottom: "1px solid #ccc",
                  }}
                >
                  <Typography
                    style={{
                      textAlign: "right",
                      marginRight: "216px",
                      fontWeight: 500,
                      height: "40px",
                      padding: "10px",
                      width: "264px",
                    }}
                  >
                    Charge Name {index + 1}
                  </Typography>
                  <div>
                   
                  <input
  style={{ padding: "15px", width: "20px", marginLeft: "-28px", height: "20px" }}
  key={charge.id}
  type="checkbox"
  checked={props.selectedChargeIds.includes(charge.id)} 
  onChange={() => props.handleCheckboxChange(charge.id)}
/>






                  </div>
                </div>

                <CardContent>
                  <ul>
                    <li>Id: {charge.id}</li>
                    <li>Name: {charge.name}</li>
                    <li>Description: {charge.description}</li>
                    <li>Beneficiary Type Id: {charge.beneficiaryTypeId}</li>
                   <li>Deduction Type Id: {charge.deductionTypeId}</li>
                    
                    <li>Charge Type: {charge.chargeType}</li>
                    <li>Value Type: {charge.valueType}</li>
                    <li>Value: {charge.value}</li>
                    <li>Value Min: {charge.valueMin}</li>
                    <li>Value Max: {charge.valueMax}</li>
                  </ul>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    </div>
  );
};

export default MapToChargeComponent;

