import React, { useState } from "react";
import "./style.css";
import Sidebar from "../Navigation/Sidebar/Sidebar";
import { Link, useNavigate } from "react-router-dom";
import leftArrow from "../../assests/leftArrow.svg";
import Table from "react-bootstrap/Table";
import search from "../../assests/search.svg";
import eyeIcon from "../../assests/eyeIcon.svg";
import filterIcon from "../../assests/filterIcon.svg";
// import moment from "moment";
import LoadingSpinner from "../Loading/component";
import dayjs from "dayjs";
import AlarmIcon from "@mui/icons-material/Alarm";
import SnoozeIcon from "@mui/icons-material/Snooze";
import TextField from "@mui/material/TextField";
import ClockIcon from "@mui/icons-material/AccessTime";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { MobileDateTimePicker } from "@mui/x-date-pickers/MobileDateTimePicker";
// import moment from "moment-timezone";
import InfiniteScroll from "react-infinite-scroll-component";
import { success } from "toastr";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import SendIcon from "@mui/icons-material/Send";
import Stack from "@mui/material/Stack";
import retryicon from "../../assests/retryicon.svg";
import PhotoCamera from "@mui/icons-material/PhotoCamera";

import PropTypes from "prop-types";
import unableImage from "../../assests/unableImage.svg";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Typography from "@mui/material/Typography";
import { useParams } from "react-router-dom";
import { CompressOutlined } from "@mui/icons-material";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";
import emotions7 from "../../assests/emotions7.svg";
import moment from 'moment-timezone';


const ScreensaversComp = ({
  filteredOrderList,
  orderSearch,
  onSearchInputChange,
  loading,
  fetchUsersListNext,
  data,
  morescroll,
  handleDateChange,

  pickDate,
  rowColors,
  handleDrag,
  handleDrop,

  onButtonClick,

  inputRef,
  imageDropped,

  previewImage,

  handleClickImg,
  handleCloseD,
  handleChangeImage,
  orderFound,
  handleRetry,
  handleClickOpen,
  showFileInput,
  open,
  isFocused,
  handleFocus,
  handleBlur,
  onSearchClick,
  onSearchInputKeyDown,
  searchOrderValue,
  isLoading,
  searchOption,
  tableContainerRef
}) => {
  const { orderid } = useParams();
  console.log("orderid", orderid)
  console.log("order data", filteredOrderList);
  const [showDatePicker, setShowDatePicker] = useState(false);
 
  const [dateWithNoInitialValue, setDateWithNoInitialValue] =
    React.useState(null);
  const [dateWithInitialValue, setDateWithInitialValue] = React.useState(
    dayjs("00-00-00T00:00")
  );

  const [date, setDate] = useState("");
  const [time, setTime] = useState("");

  const [orderDetails, setOrderDetails] = useState(null);
  const [imagePath, setImagePath] = useState("");

  const handleRowClick = (e,orderid) => {
   
    navigate(`/home/ordersview/${orderid}`)
    };

  function handleTimeChange(event) {
    setTime(event.target.value);
  }

  function handleFilterClick() {
    setShowDatePicker(!showDatePicker);
  }


  function handleApplyFilter() {
    console.log(`Selected date: ${date} Selected time: ${time}`);
    // Your code to apply the filter goes here
  }
  const navigate = useNavigate();

  const arrowClick = () => {
    navigate("/");
  };
  const handleCancel = () => {
    setShowDatePicker(!showDatePicker);
  };

  const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    "& .MuiDialogContent-root": {
      padding: theme.spacing(2),
    },
    "& .MuiDialogActions-root": {
      padding: theme.spacing(1),
    },
  }));

  function BootstrapDialogTitle(props) {
    const { children, onClose, ...other } = props;

    return (
      <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
        {children}
        {onClose ? (
          <IconButton
            aria-label="close"
            onClick={onClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>
        ) : null}
      </DialogTitle>
    );
  }

  BootstrapDialogTitle.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
  };

  return (
    <>
      {isLoading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
        <div className="main-div">
          <div>
            <Sidebar />
          </div>

          <div style={{ margin: "auto" }}>
            <div className="ordersHeading">
              <img
                onClick={arrowClick}
                style={{ width: "22px", cursor: "pointer" }}
                src={leftArrow}
                alt=""
              />
              <p className="ordersText1">Screensavers</p>
            </div>
            {isLoading && (
              <div>
                {" "}
                <Box sx={{ display: "flex", color: "yellow" }}>
                  {/* <CircularProgress /> */}
                  <LoadingSpinner />
                </Box>
              </div>
            )}

            <div
              style={{
                display: "flex",
                flexDirection: " row",
                justifyContent: "space-between",
                width: "100%",
              }}
            >
              {/* <div>
                <div className="order-searchbar">
                  <input
                    className="inputfirlf"
                    type="text"
                    placeholder={
                      searchOption === "phone" ? "Search " : "Search Screensavers"
                    }
                    onFocus={handleFocus}
                    onBlur={handleBlur}
                    value={searchOrderValue}
                    onChange={onSearchInputChange}
                    onKeyDown={onSearchInputKeyDown}
                  />
                  <img
                    style={{ marginLeft: "10px" }}
                    className="search-icon"
                    src={search}
                    alt=""
                    // onClick={onSearchClick}
                  />
                </div>
              </div> */}

              {/* <div
                style={{ position: "relative", top: "80px", right: "10px" }}
                className="uploadimg"
              >
                <Stack direction="row" spacing={2}>
                  <Button onClick={handleClickOpen}>
                    <img
                      src={uploadsvg}
                      alt=""
                      style={{ marginRight: "10px" }}
                    />
                    <span className="uploadtext" style={{ color: "#fff" }}>
                      Upload Screenshot
                    </span>
                  </Button>
                </Stack>
              </div> */}
            </div>

            <div>
              <BootstrapDialog
                onClose={handleCloseD}
                aria-labelledby="customized-dialog-title"
                open={open}
              >
                <BootstrapDialogTitle
                  id="customized-dialog-title"
                  onClose={handleCloseD}
                >
                  <div style={{ padding: "24px" }}>
                    <p className="uploadHead">Upload Screenshot</p>
                    <Typography>
                      Upload the screenshot of payment transaction
                    </Typography>
                  </div>
                </BootstrapDialogTitle>
                <DialogContent id="form-file-upload">
                  {orderFound ? (
                    <div>
                      <div
                        className="dragDropBox"
                        onDrop={handleDrop}
                        onDragEnter={handleDrag}
                        onDragOver={handleDrag}
                        onDragLeave={handleDrag}
                        onClick={(e) => onButtonClick(e, "box")}
                      >
                        {previewImage ? (
                          <div
                            style={{
                              height: "350px ",
                              margin: "10px",
                              width: "100%",
                            }}
                          >
                            <img
                              src={previewImage}
                              alt="Preview"
                              style={{ maxWidth: "100%", maxHeight: "100%" }}
                            />
                          </div>
                        ) : (
                          <div
                            style={{
                              margin: "auto",
                              textAlign: "center",
                              alignItems: "center",
                            }}
                          >
                            <p className="boxheading">
                              Drop screenshot here, or{" "}
                              <a
                                onClick={(e) => onButtonClick(e, "button")}
                                href=""
                                style={{
                                  textDecoration: "none",
                                  marginLeft: "4px",
                                }}
                              >
                                {" "}
                                Browse{" "}
                              </a>
                            </p>
                          </div>
                        )}
                        <div
                          style={{
                            position: "fixed",
                            margin: "auto",
                            width: "711px",
                          }}
                        >
                          {imageDropped && (
                            <div style={{ marginTop: "20px" }}>
                              <Button
                                onClick={(e) => onButtonClick(e, "button")}
                                className="changeimage-button"
                              >
                                change image
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>

                      {previewImage ? (
                        <div style={{ marginTop: "50px" }}>
                          <Button
                            onClick={handleClickImg}
                            type="submit"
                            loading={loading}
                            variant="contained"
                            color="success"
                            size="large"
                            style={{ marginLeft: "0px", width: "100%" }}
                          >
                            Submit
                          </Button>
                        </div>
                      ) : (
                        <div style={{ marginTop: "50px" }}>
                          <Button
                            //  onClick={handleClickImg}
                            type="submit"
                            disabled={true}
                            variant="secondary"
                            color="success"
                            size="large"
                            style={{
                              marginLeft: "0px",
                              width: "710px",
                              display: "none",
                            }}
                          >
                            Submit
                          </Button>
                        </div>
                      )}

                      <div
                        style={{ display: showFileInput ? "block" : "none" }}
                      >
                        <input
                          ref={inputRef}
                          // id="input-file-upload"
                          id="myFileInput"
                          multiple={true}
                          type="file"
                          onChange={handleChangeImage}
                          style={{ display: "none" }}
                        />
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div>
                        <img src={unableImage} alt="" />
                        <h4 style={{ textTransform: "capitalize" }}>
                          Unable to find order id
                        </h4>
                      </div>
                      <a
                        href="#"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRetry(orderFound);
                        }}
                      >
                        Retry <img src={retryicon} alt="" />
                      </a>

                      {showFileInput && (
                        <div>
                          <input
                            ref={inputRef}
                            id="myFileInput"
                            multiple={true}
                            type="file"
                            onChange={handleChangeImage}
                            style={{ display: "none" }}
                          />
                        </div>
                      )}
                    </div>
                  )}
                </DialogContent>
              </BootstrapDialog>
            </div>

            <div className="order-main-sec">
              <div>
                <h2> Coming soon</h2>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ScreensaversComp;
