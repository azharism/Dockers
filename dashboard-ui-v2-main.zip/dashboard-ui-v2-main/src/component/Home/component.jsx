import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet'; 
import { useEffect } from 'react';
import "./style.css";
import {Link} from "react-router-dom"
import logo  from "../../assests/Daalchini-logo.svg"
//import JunkFood from "../../assests/JunkFood.svg";
import phone from "../../assests/phone.svg";
import lock from "../../assests/lock.svg";
import { Navigate } from 'react-router-dom';
import dashboard from "../../assests/dashboard.svg"
import Avtar from "../../assests/Avatar.png";
import SideBar from "../Navigation/Sidebar/component"

import Dropdown from "react-bootstrap/Dropdown";
import { LandingPage } from '../Auth/Grettingpage/component';
import LoadingSpinner from '../Loading/component';
// import Sider from 'antd/es/layout/Sider';

const Home = ({
  mobile,
  password,
  disabled,
  loading,
  onSubmit,
  onChanegOfMobile,
  onChangeOfPassword,
}) => 

{

const inputStyle= {
  borderRadius: "18px",
  padding: "12px 48px 14px",
  fontSize: "20px",
  background: "#FFFFFF"
 
}
const inputStylePassword={
  borderRadius: "18px",
  padding: "12px 52px 14px ",
  fontSize: "20px",
  background: "#FFFFFF"
 
}
const forgotPasswordStyle={
  marginTop: "-31px",
  color: "#BDBDBD",
  textDecoration: "none",
}
const signinStyle={
  borderRadius: "18px",
  padding: "12px 32px 14px",
  fontSize: "20px",
  textTransform:'uppercase'
}

  const navigate=useNavigate();

  useEffect(() => {
    
  
  },[])
 
  

  return (
    
   
   <>
   {/* <section className="mainSec">
        <div className="side-div">
          <div className="side-div1">
            <div className="logo-div">
              <img src={logo} alt="" />
            </div>
            <div className="profileDiv">
              <img src={Avtar} alt="" />
              <div className="designation">
                <p>name</p>
                <span>developer</span>
              </div>
            </div>
            <hr style={{ color: "grey", padding: "24px" }} />
           
            </div>
            
        </div>
      </section> */}
      <div>
        {loading ? <><LoadingSpinner/></>:  <div><div>
        <SideBar/>
        </div>
        <div>
<LandingPage/>
        </div>
        
      </div>}
     
     </div>

   </>
  );
};

export default Home;
