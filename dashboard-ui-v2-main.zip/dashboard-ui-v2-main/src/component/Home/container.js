import React, { Component, useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import Home from "../Home/component";
import { LandingPage } from "../Auth/Grettingpage/component";
import LoadingSpinner from "../Loading/component";


const HomeContainer = (props) => {
  const [auth, setAuth] = useState(localStorage.getItem("data"));
  const [loading, setLoading]= useState(true)
  const history = createBrowserHistory();

  useEffect(() => {}, [auth]);

  return <LandingPage />;
};
function mapStateToProps({ props }) {
  return {
    
    props,
   
  };
}
export default connect(mapStateToProps, {
  
 
  getDataFromAPI,
})(HomeContainer);
