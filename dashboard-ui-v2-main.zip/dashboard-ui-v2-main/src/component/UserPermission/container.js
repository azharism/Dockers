import React, { Component, useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { getDataFromAPI } from "../../HandleAPICalls/actions";
import { createBrowserHistory } from "history";
import { UsersroleList } from "./component";
import { toastr } from "react-redux-toastr";
import { useParams } from "react-router-dom";
import _ from "lodash";

const UserPermissionContainer = (props) => {
  // console.log("ankit sharma", props.match)
  const [userList, setUserList] = useState([]);
  const [searchList, setSearchList] = useState();
  const [searchValue, setSearchValue] = useState();
  const [searchData, setSearchData] = useState(null);
  const [start, setStart] = useState(0);
  const [to_timestamp, setTo_timestamp] = useState();
  const [from_timestamp, setFrom_timestamp] = useState();
  const [morescroll, setMorescroll] = useState(true);
  // const [FilteredUserListTable, setFilteredUserListTable]=useState()
  const [roleList, setRoleList] = useState([]);
  const [role, setRole] = useState();
  const [filteredUserList, setFilteredUserList] = useState([]);
  const [selectedUserRole, setSelectedUserRole] = useState();
  const [isActive, setIsActive] = useState([]);
  const { role_id } = useParams();
  const { isActiveParam } = useParams();
  const {getUserRole, setUserRole} = useState([])
 const [loading , setLoading] = useState (true)

console.log("getuserrole",getUserRole)
  useEffect(() => {
    props.getDataFromAPI(
      "/dashboard/api/v2/admin/users/roles/all",
      "GET",
      undefined,
      (response) => {
        console.log(
          "roleList---container  user role responseer",
          response.list.id
        );
        setRoleList(response.list);
      }
    );
  }, []);

  const handleFilterUserListRole = (role_id) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/roles/all/?role_id=${role_id}`,
      "GET",
      undefined,
      (response) => {
        console.log("filtered user list response", response.list.id);
        setFilteredUserList(response.list);
      },
      (error) => {
        console.log("filtered user list error", error);
      }
    );
  };

  const handleUpdateUserRole = (e, id) => {
    console.log("user role id", id);
    setSelectedUserRole(id);
    handleFilterUserList(id);
   
    // window.removeEventListener('scroll', handleScroll);
  };




  const handleFilterUserList = (role_id) => {
    const filteredUserList = userList.filter(
      (user) => user.role_id === role_id
    );
    setFilteredUserList(filteredUserList);
  };

  const handleActiveUserList = (isActiveParam) => {
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/list?is_active=${isActiveParam}`,
      "GET",
      undefined,
      (response) => {
        let filteredUsers = response.list;

        // Apply filter conditionally only if props.filteredUserListTable is defined
        if (props.filteredUserListTable) {
          filteredUsers = filteredUsers.filter((user) => {
            if (isActiveParam === "1") {
              return (
                user.status === "active" &&
                props.filteredUserListTable.includes(user)
              );
            } else if (isActiveParam === "0") {
              return (
                user.status === "deleted" &&
                props.filteredUserListTable.includes(user)
              );
            }
            return true;
          });
        } else {
          if (isActiveParam === "1") {
            filteredUsers = filteredUsers.filter(
              (user) => user.status === "active"
            );
          } else if (isActiveParam === "0") {
            filteredUsers = filteredUsers.filter(
              (user) => user.status === "deleted"
            );
          }
        }

        const formattedUsers = filteredUsers.map((user) => ({
          ...user,
          status: user.status === "active" ? "Active" : "deleted",
        }));
        setIsActive(formattedUsers);
      },
      (err) => {},
      true
    );
  };

  const handleInactiveClick = () => {
    setIsActive(false);
  };
  const handleActiveClick = () => {
    setIsActive(true);
  };

  const onSearchInputChange = (e) => {
    const searchName = e.target.value;
    console.log("searchName", searchName);
    setSearchValue(searchValue);
  };

  const Search = (searchdata) => {
    setSearchData(searchdata);

    props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/search?search=${searchdata}`,
      "GET",
      undefined,
      (response) => {
        console.log("Get response ", response);
        setSearchList(response);
        console.log("SEARCH RES----->", response);
      },
      (err) => {}
    );
  };

  const LoadUserlist = (match) => {
    return props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/list?limit=50&offset=0`,
      "GET",
      undefined,
      (response) => {
        setUserList(response.list);
        console.log("response--------->", response);
      },
      (err) => {},
      true
    );
  };

  // const fetchUsersList = () => {
  //   setStart(start + 1)
  //   props.getDataFromAPI(
  //     `/dashboard/api/v2/admin/users/list?limit=50&offset=0&pageSize=${start}&pageNumber=100`,
  //     'GET',
  //     undefined,
  //     (response) => {
  //       if (response) {
  //         setUserList([...userList, ...response.list]);
  //         console.log("onchange userlist", response.list)
  //       }
  //       if (!response) {
  //         setMorescroll(false);
  //       }
  //     },
  //     (err) => {
  //       // handle error
  //     }
  //   );
  // };

  const fetchUsersList = (offset) => {
    const pageSize = 50;
    const nextOffset = offset + pageSize;
    props.getDataFromAPI(
      `/dashboard/api/v2/admin/users/list?limit=${pageSize}&offset=${offset}&pageNumber=100`,
      "GET",
      undefined,
      (response) => {
        setLoading(false)
        if (response) {
          setUserList([...userList, ...response.list]);
       
          setStart(nextOffset);
          setMorescroll(true);
          // After fetching and updating the user list, scroll to the top of the table
          const container = tableContainerRef.current;
          if (container) {
            container.scrollTo({ behavior: "smooth" });
          }
          console.log("onchange userlist", response.list);
        } else {
          setMorescroll(false);
          console.log("No more data to fetch");
        }
        
      },
      (err) => {
        setMorescroll(false);
        return toastr.warning("Error fetching data:", err);
        console.log("Error fetching data:", err);
      }
    );
  };

  useEffect(() => {
    fetchUsersList(0);
  }, []);
  const tableContainerRef = useRef(null);

  useEffect(() => {
    fetchUsersList(0);
  }, []);

  useEffect(() => {
    const handleScroll = _.throttle(() => {
      const container = tableContainerRef.current;
      if (container) {
        const { scrollTop, clientHeight, scrollHeight } = container;

        if (scrollTop + clientHeight >= scrollHeight) {
          fetchUsersList(start);
        }
      }
    }, 200);

    const container = tableContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, [start]);

  const filteredUserListTable =
    !searchData && filteredUserList.length > 0
      ? filteredUserList.filter((user) => {
          console.log("filter 1 working");

          if (isActive && user.status === "active") {
            return true;
          } else if (!isActive && user.status === "deleted") {
            return true;
          } else {
            return false;
          }
        })
      : !searchData && userList
      ? userList.filter((user) => {
          console.log("filter 1 working");

          if (isActive && user.status === "active") {
            return true;
          } else if (!isActive && user.status === "deleted") {
            return true;
          } else {
            return false;
          }
        })
      : searchList && searchData
      ? searchList.filter((user) => {
          console.log("filter 2 working");

          if (isActive && user.status === "active") {
            return true;
          } else if (!isActive && user.status === "deleted") {
            return true;
          } else {
            return false;
          }
        })
      : userList;

  return (
    <UsersroleList
      filteredUserListTable={filteredUserListTable}
      // fetchNextUserslist={fetchUsersList}
      Search={Search}
      morescroll={morescroll}
      userList={userList}
      handleUpdateUserRole={handleUpdateUserRole}
      roleList={roleList}
      handleFilterUserListRole={handleFilterUserListRole}
      // handleActiveUserList={handleActiveUserList}
      handleActiveClick={handleActiveClick}
      isActive={isActive}
      handleInactiveClick={handleInactiveClick}
      selectedUserRole={selectedUserRole}
      // handleInactiveUserList={handleInactiveUserList}
      // formattedUsers={formattedUsers}
loading={loading}
      tableContainerRef={tableContainerRef}
    />
  );
};
function mapStateToProps({ props }) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  getDataFromAPI,
})(UserPermissionContainer);
