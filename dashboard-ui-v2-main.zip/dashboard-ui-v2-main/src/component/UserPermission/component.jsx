import React, { useState } from "react";
import Dropdown from "react-bootstrap/Dropdown";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import eyeIcon from "../../assests/eyeIcon.svg";
import search from "../../assests/search.svg";
import leftArrow from "../../assests/leftArrow.svg";
import filter from "../../assests/filterIcon.svg";
import { Link, useNavigate } from "react-router-dom";
import "./userPermission.css";
import Sidebar from "../Navigation/Sidebar/Sidebar";
import { Spinner } from "react-bootstrap-v5";
import InfiniteScroll from "react-infinite-scroll-component";
import { useParams } from "react-router-dom";
import emotions7 from "../../assests/emotions7.svg";
import LoadingSpinner from "../Loading/component";

export const UsersroleList = (props) => {
  // console.log("props.props.filteredUserList", props.filteredUserList);
  const [isFocused, setIsFocused] = useState(false);

  const navigate = useNavigate();
  const clickIcon = () => {
    navigate("/userdetails");
  };
  const addUser = () => {
    navigate("/createuser");
  };
  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };
  const arrowClick = () => {
    navigate("/");
  };
  return (
    <>
    {props.loading ? (
        <>
          <LoadingSpinner />
        </>
      ) : (
<div className="main-div">
        <div>
          <Sidebar />
        </div>
        <div style={{ width: "1328px", margin: "auto" }}>
          <div>
            <div style={{ display: "flex" }}>
              <img
                style={{ cursor: "pointer" }}
                onClick={arrowClick}
                src={leftArrow}
                alt=""
              />
              <h2 style={{ marginLeft: "20px" }} className="userHeading">
                Users & Roles
              </h2>
            </div>
            <div className="searchbar-sec">
              <div className="searchbaritem">
                <input
                  type="search"
                  style={{ color: "black" }}
                  placeholder="Search by Full Name / Mobile Number"
                  onFocus={handleFocus}
                  onBlur={handleBlur}
                  onChange={(e) => {
                    props.Search(e.target.value);
                  }}
                />
                <img
                  src={search}
                  alt=""
                  style={{
                    display: isFocused ? "none" : "block",
                    marginTop: "-14px",
                    marginLeft: "-0px",
                  }}
                />
              </div>
              <div>
                <Button
                  onClick={addUser}
                  style={{ fontSize: "14px" }}
                  variant="primary"
                  size="lg"
                >
                  + Add User
                </Button>
              </div>
            </div>
          </div>

          <div>
            <div
              style={{
                backgroundColor: "#ffffff",
                padding: "12px",
                borderRadius: "14px",
                width: "100%",
                marginTop: "10px",
                overflow: "auto",
                height:"720px"
              }}
              className="scrolldown"
              ref={props.tableContainerRef}
            >
              <Table striped style={{ overflowY: "scroll" }}>
                <thead>
                  <tr  style={{
                    borderTop: "1px solid #ccc",
                    position: "relative",
                    top: "-22px",
                    height:"80px",
                   
                  }}>
                    <th>Sr. No</th>
                    <th>Full Name</th>
                    <th>User ID</th>
                    <th>Mobile Number</th>
                    <th>
                      <Dropdown
                        style={{
                          justifyContent: "start",
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "end",
                          position: "absolute",

                          marginLeft: "40px",
                          marginTop: "-33px",
                        }}
                      >
                        <Dropdown.Toggle
                          variant="secondary"
                          style={{
                            display: "flex",
                            alignItems: "left",
                            backgroundColor: "#fff",
                            border: "none !important",
                            justifyContent: "start",
                            width: "94px",
                          }}
                          id="dropdown-basic"
                        >
                          <img src={filter} alt="" />
                        </Dropdown.Toggle>
                        <span
                          style={{
                            marginBottom: "-30px ",
                            position: "absolute",
                            left: "44px",
                            bottom: "24px",
                          }}
                        >
                          Role
                        </span>

                        <Dropdown.Menu
                          style={{ height: "300px", overflow: "auto" }}
                        >
                          {props.roleList &&
                            props.roleList.map((el, index) => {
                              return (
                                <Dropdown.Item
                                  value={index}
                                  id={el}
                                  size="small"
                                  onClick={(e) => {
                                    props.handleUpdateUserRole(e, el.id); 
                                  }}
                                  active={false}
                                >
                                  {el.name}
                                </Dropdown.Item>
                              );
                            })}
                        </Dropdown.Menu>
                      </Dropdown>
                    </th>
                    <th>
                      <Dropdown
                        style={{
                          justifyContent: "start",
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "start",
                          position: "absolute",

                          marginLeft: "76px",
                          marginTop: "-33px",
                        }}
                      >
                        <Dropdown.Toggle
                          variant="secondary"
                          style={{
                            display: "flex",
                            alignItems: "left",
                            backgroundColor: "#fff",
                            border: "none",
                            justifyContent: "start",
                            width: "94px",
                          }}
                          id="dropdown-basic"
                        >
                          <img src={filter} alt="" />
                        </Dropdown.Toggle>
                        <span
                          style={{
                            marginBottom: "-30px ",
                            position: "absolute",
                            left: "44px",
                            bottom: "24px",
                          }}
                        >
                          Status
                        </span>
                        <Dropdown.Menu>
                          <Dropdown.Item
                            onClick={() => props.handleActiveClick()}
                          >
                            Active
                          </Dropdown.Item>
                          <Dropdown.Item
                            onClick={() => props.handleInactiveClick()}
                          >
                            Inactive
                          </Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    </th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {props.filteredUserListTable &&
                  props.filteredUserListTable.length > 0 ? (
                    props.filteredUserListTable.map((item, index) => (
                      <tr className="rowColor" key={item.id}>
                        <td>{index + 1}</td>
                        <td>{item.full_name}</td>
                        <td
                          style={{ textAlign: "center", paddingLeft: "30px" }}
                        >
                          {item.id}
                        </td>
                        <td style={{ textAlign: "center" }}>{item.mobile}</td>
                        <td
                          style={{ textAlign: "right  " }}
                          className="userrole1"
                        >
                          {item.user_role}
                        </td>
                        <td
                          style={{ textAlign: "center" }}
                          className="userstatus1"
                        >
                          <span className="itemstatus1">
                            {item.status === "active" ? "Active" : "Deleted"}
                          </span>
                        </td>
                        <td className="eyeicon1">
                          <Link to={`/users/userlist/${item.id}`}>
                            <img src={eyeIcon} alt="" />
                          </Link>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <div className="noOrderFound">
                      <div>
                        <img className="noOrderImg" src={emotions7} alt="" />
                        <p className="noOrderPara">No User Found</p>
                      </div>
                    </div>
                  )}
                </tbody>
              </Table>
            </div>
          </div>
        </div>
      </div>
      )}
      
    </>
  );
};
