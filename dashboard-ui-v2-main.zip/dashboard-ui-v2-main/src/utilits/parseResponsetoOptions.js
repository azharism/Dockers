export default (options) => {
    if (!options && options.length) {
      return { key: 0, text: 'All', value: 'all' };
    }
    const parsed = options.map(el => ({ key: el.id, text: el.name, value: el.id }));
    return [...parsed];
  };