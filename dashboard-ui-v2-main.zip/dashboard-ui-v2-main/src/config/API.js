export const S3_BASE_URL = 'https://s3.ap-south-1.amazonaws.com/daalchini/dcprod';
// URL for development

/** PROD URL */
  // export const BASE_URL = 'https://api-stage.daalchini.co.in';
  export const BASE_URL = 'https://api-prod.daalchini.co.in';

// export const BASE_URL = 'https://api-prod.daalchini.co.in/dashboard/api/v2/admin';
// export const BASE_URL_PARTNER = 'https://api-prod.daalchini.co.in/partner/api/v1';

/** STAGING URL */
// export const BASE_URL = 'https:/api-stage.daalchini.co.in/';
// export const BASE_URL_PARTNER = 'https://api-prod.daalchini.co.in/';
