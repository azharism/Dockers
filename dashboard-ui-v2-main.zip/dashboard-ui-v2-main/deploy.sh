#!/bin/bash

# build and deployment config
kill_wait=10
application_port=7300
log_dir_base=$LOG_BASE_DIR
application_name='dashboard-ui-v2-stage'

log_dir=$log_dir_base/$application_name

# build
export NODE_ENV=production
npm ci
npm run build

# deployment
echo "Stopping instance..."
service_pid=$(cat process.id)
count=1
while
    kill -0 "$service_pid" >/dev/null 2>&1
do
    kill -SIGTERM "$service_pid"
    if [ $count -gt $kill_wait ]; then
        kill -SIGKILL "$service_pid"
        break
    fi
    sleep 1
    ((count = count + 1))
done

echo "Starting instance..."
nohup serve -l $application_port -s build/ >> "$log_dir/$application_name.log" &
echo $! >process.id


