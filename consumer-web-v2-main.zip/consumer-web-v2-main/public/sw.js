/* let cacheData = "Daalchini";

self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(cacheData).then((cache) => {
            // Add URLs to cache using cache.addAll()
            return cache.addAll([
                "/static/js/bundle.js"
                // Specify URLs to cache here, e.g., ['/index.html', '/styles.css', '/script.js']
            ]);
        })
    );
});
 */
const cacheData = "Daalchini";

self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(cacheData).then((cache) => {
            // Add URLs to cache using cache.addAll()
            return cache.addAll([
               
                
                
                // Add more URLs to cache as needed
            ]);
        })
    );
});

self.addEventListener("fetch", (event) => {
/*     event.respondWith(
        caches.match(event.request).then((result) => {
            // Cache hit - return cached response
            if (result) {
                return result;
            }

            // Clone the request to make a fetch request
            const fetchRequest = event.request.clone();

            return fetch(fetchRequest).then((response) => {
                // Check if we received a valid response
                if (!response || response.status !== 200 || response.type !== "basic") {
                    return response;
                }

                // Clone the response to cache it
                const responseToCache = response.clone();

                caches.open(cacheData).then((cache) => {
                    cache.put(event.request, responseToCache);
                });

                return response;
            });
        }).catch((error) => {
            console.error("Error fetching and caching:", error);
            // Fallback to a fallback page or handle error gracefully
        })
    ); */
});
