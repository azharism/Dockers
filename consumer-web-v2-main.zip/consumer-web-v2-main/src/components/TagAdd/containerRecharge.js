import TagAdd from "./component"
import {fetchSearchTokenRequest,fetchSecretKeyLinkRequest,fetchSecretKeyActiveRequest} from "./action"
import { connect } from "react-redux";
import {  toast } from 'react-toastify';
import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
const TagDirRechargeContainer=(props)=>{
  const navigator=useNavigate()
    const [tokenNumber,setTokenNumber]=useState([])
 const [pageCount,setPageCount]=useState(1)
 const [secretkey,setSecretkey]=useState("")
 const [taguid,setTaguid]=useState("")
 const[loader,setLoader]=useState(false)
 const [tagActive,setTagActive]=useState(false)
 const [askLink,setAskLink]=useState(false)
    useEffect(()=>{
       
    },[])


    const handleResponseSearchToken=(response)=>{

      console.log("Get response SearchToken",response.data.response);
      setTaguid(response.data.response.uid)
      setTagActive(response.data.response.active)
      localStorage.setItem("TagUUID",response.data.response.uid)
      if(response.data.response.active==true){
      
        navigator(`/taghistory/${response.data.response.uid}`)
      }
      else{
        toast.error(`TAG NOT ACTIVE`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 1000,
      });
      //setPageCount(pageCount+1)
      }
      setLoader(false)

    
    }
    
    const handleErrorSearchToken=(err)=>{

      setLoader(false)
      console.log("SearchToken ERROR",err.response.data.statusMessage);
      toast.error(`${err.response.data.statusMessage}`, {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 1000,
    });
    
    }
    
    
    const SearchToken = () => {
     
      const UserJWTAuth = localStorage.getItem('UserJWTAuth');
      console.log("UserJWTAuth",UserJWTAuth)
      setLoader(true)
      console.log("inventory...container")
    
      props.fetchSearchTokenRequest({
        url: `/auth/tag/search?qrData=${tokenNumber}`,
        method:  "GET",
        headers: {
          Authorization: `Bearer ${UserJWTAuth}`,
            "x-app-platform": "web",
          "x-app-version": "v1.0.1",
           //HEADER ERROR
          "x-device-id":localStorage.getItem("uuid")
    
        },
        
    
    
        handleErrorSearchToken,
        handleResponseSearchToken,
      });
    };
    
   
    
    const handleResponseSecretKeyLink=(response)=>{

      setLoader(false)
            console.log("Get response SearchToken",response.data.response);
           
            setPageCount(pageCount+1)
            navigator("/taglist")
    
    }
    
    const handleErrorSecretKeyLink=(err)=>{

      setLoader(false)
      navigator("/taglist")
      console.log("SearchToken ERROR",err.response.data.statusMessage);
      toast.error(`${err.response.data.statusMessage}`, {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 1000,
    });
    
    }
    
    
    const SubmitSecretKeyLink = () => {
     
      const UserJWTAuth = localStorage.getItem('UserJWTAuth');
      console.log("UserJWTAuth",UserJWTAuth)
      setLoader(true)
      console.log("inventory...container")
    
      props.fetchSecretKeyLinkRequest({
        url: `/auth/tag/${taguid}/link`,
        method:  "POST",
        headers: {
          Authorization: `Bearer ${UserJWTAuth}`,
            "x-app-platform": "web",
          "x-app-version": "v1.0.1",
           //HEADER ERROR
          "x-device-id":localStorage.getItem("uuid"),
          "x-tag-secret": `${secretkey}`
    
        },
        request:{request:{"replaceCurrentAccount":false}},
          
        
    
    
        handleErrorSecretKeyLink,
        handleResponseSecretKeyLink,
      });
    };
    

////////////////////////////////////////////////////////////////////

const handleResponseSecretKeyActive=(response)=>{

  setLoader(false)

  console.log("Get response SearchToken",response.data.response);
 
  setPageCount(pageCount+1)
  SubmitSecretKeyLink()


 setTimeout(() => {
  navigator("/taglist")
 }, 1000);
  

}

const handleErrorSecretKeyActive=(err)=>{
  setLoader(false)
  navigator("/taglist")
  console.log("SearchToken ERROR",err.response.data.statusMessage);
  toast.error(`${err.response.data.statusMessage}`, {
    position: toast.POSITION.TOP_RIGHT,
    autoClose: 1000,
});

}


const SubmitSecretKeyActive = () => {
 
  const UserJWTAuth = localStorage.getItem('UserJWTAuth');
  console.log("UserJWTAuth",UserJWTAuth)
  setLoader(true)
  console.log("inventory...container")

  props.fetchSecretKeyActiveRequest({
    url:  `/auth/tag/${taguid}/active`,
    method:  "POST",
    headers: {
      Authorization: `Bearer ${UserJWTAuth}`,
        "x-app-platform": "web",
      "x-app-version": "v1.0.1",
       //HEADER ERROR
      "x-device-id":localStorage.getItem("uuid"),
      "x-tag-secret": `${secretkey}`

    },
    request:{"replaceCurrentAccount":false},
      
    


    handleErrorSecretKeyActive,
    handleResponseSecretKeyActive,
  });
};




   
    const handleChangeRfIDToken=(e)=>{
      console.log("handleChangeRfIDToken",e.target.value)
      setTokenNumber(e.target.value)
    }
    const handleChangeSecretkey=(secretkey)=>{
      console.log("handleChangeSecretkey",secretkey)
      setSecretkey(secretkey)
    }


    return(
        <TagAdd
      
        handleChangeRfIDToken={handleChangeRfIDToken}
        SearchToken={SearchToken}
        pageCount={pageCount}
        SubmitSecretKey={SubmitSecretKeyActive}
        handleChangeSecretkey={handleChangeSecretkey}
        secretkey={secretkey}
        loader={loader}
        askLink={askLink}
        setTokenNumber={setTokenNumber}
        tokenNumber={tokenNumber}
        />


    )
}
function mapStateToProps({ props }) {
    return {
      props,
    };
  }
  export default connect(mapStateToProps, {
    
    fetchSecretKeyActiveRequest,
    fetchSecretKeyLinkRequest,
    fetchSearchTokenRequest,
  
  })(TagDirRechargeContainer);

