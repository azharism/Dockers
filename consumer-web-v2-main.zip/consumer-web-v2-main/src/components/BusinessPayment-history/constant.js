export const FETCH_TAG_LIST = '@Tag/FETCH_TAG_LIST';
