import React, { useState } from 'react';
import ButtonPrimary from '../Buttons/ButtonPrimary';

const PopupModal = () => {

  return (
    <div>
  
     
        <div className="fixed top-0 left-0 right-0 bottom-0 flex items-center justify-center bg-black bg-opacity-50 z-30">
          <div className="relative bg-white  rounded-3xl shadow p-6 text-center dark:bg-gray-700 max-w-screen-md mx-4">
         
            <div className="p-6 text-center">
              <h3 className="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">
                Are you sure you want to delete this stageuct?
              </h3>
           
           <ButtonPrimary text={"share"}/>
            </div>
          </div>
        </div>
      
    </div>
  );
};

export default PopupModal;
