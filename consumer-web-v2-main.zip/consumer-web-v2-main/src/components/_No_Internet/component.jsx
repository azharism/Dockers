import React from "react";
const NoIneterPage=()=>{
    return(<>
    <h1>no internet</h1>
    </>)
}
export default NoIneterPage;