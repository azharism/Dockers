import { useEffect, useState } from "react";
import { connect } from "react-redux";
import ActiveOrdersBar from "./component";
import { fetchBanner } from "./action";
import { mpClick } from "../../Mixpanel";
const Banner = (props) => {
const [activeOrdersList,setActiveOrdersList]=useState([])

const[total_itemBook,setTotal_itemBook]=useState([])
const [count,setCount]=useState(0);
useEffect(()=>{
  banners() 
  
},[])





const banners=()=>{
  const UserJWTAuth = localStorage.getItem('UserJWTAuth');
  console.log("UserJWTAuth",UserJWTAuth)
  console.log("inventory...container")
return props.fetchBanner(
  "POST",
  "/order/fetch/banners",
  { "headers": {
    'Authorization':`Bearer ${UserJWTAuth}`,
    //'x-app-platform':'web',
    
  }
},
  
  {
    "request": {
    "vendingMachineId": 9
    }
    },
    response => {
      console.log("Get response banners",response.data.response.banners);
   
      setActiveOrdersList(response.data.response.banners);
     
    },
    err => {
     // this.props.setLoading(false);
      //toastr.error('ERROR', err);
      //console.log(err);
    }
  )
  

} 
return(
  <ActiveOrdersBar
  activeOrdersList={activeOrdersList}/>
)

}




function mapStateToProps({ props }) {
    return {
      props,
    };
  }
  export default connect(mapStateToProps, {
    fetchBanner
    
  })(Banner);