import React, { useState,useEffect } from "react";
import LocationPage from "./LocationPage/component";
import TopNavbar from "../header";
import RecentVms from "./RecentVm's/component";
import Banner_Container from "../Banners/container";
import IconButton from '@mui/material/IconButton';
import ClearIcon from '@mui/icons-material/Clear';
import tagpay from '../../assets/Rejected.png'
import { useNavigate } from "react-router-dom";
import BottomNavBar from "../BottomNav1/component";
import ActiveOrdersFab from "../_ActiveOrderFab/component";
import Procced from "../_ProccedFab/component";
import QRCodeScanner from "../QrScanner/component";
import { toast } from "react-toastify";
import Webcam from "react-webcam";
import QrReader from "react-web-qr-reader";
import HeaderSecondary from "../Header/HeaderSecondary";
import VmImgnotfound from '../../assets/vmImgnotfound.png'
import {
  AppBar, Box, Button,CardMedia,Skeleton, Card,CardContent, Typography, CssBaseline, CircularProgress,TextField,InputAdornment
} from '@mui/material';

import { Search, Tune } from "@mui/icons-material";
const VmList=(props)=>{
  const [cameraError, setCameraError] = useState(false);
//carttotalAmount={carttotalAmount}
console.log("activeOrderData",props&&props.activeOrderData)
const [result, setResult] = useState('');
const [cameraFacingMode, setCameraFacingMode] = useState('environment'); // 'user' for front camera, 'environment' for rear camera
const [showScanner, setShowScanner] = useState(true);

const handleScan = (data) => {
  if (data) {
    setResult(data);
  }
};


const resetScanner = () => {
  setResult('');
};
const videoConstraints = {
  facingMode: 'environment',  // This sets the camera to use the back camera
};



const ShowQRFun = () => {
  console.log();
  props&&props.setShow_Qr_Modal_VmList(true);
  props&&props.setShow_vmList_flag(false);
  
  props&&props.setShow_location_flag(false);
};
  


  const navigate=useNavigate()
  const [searchText,setSearchText]=useState('')

  const globalSearchflag = (e) => {
    e.preventDefault();

    navigate("/globalsearch");
  };

const VmsClick=(e,id, name, address,source)=>{

  console.log("VmsClick")
//mpClick({EventName:"vm_page_opened",data:{source:"source",vmid:id}})
  navigate(`items?machineId=${id}`)
  localStorage.setItem("vmName", name);
  localStorage.setItem("vmAddress", address);
  

}
const handleError = (error) => {
  console.log("Camera Error", error);
  toast.error(`${error}`, {
    position: toast.POSITION.TOP_RIGHT,
    autoClose: 1000,
  });
  setCameraError(true);
  ///props.setShow_Qr_Modal(true);
};


const handleClear=()=>{
  setSearchText('')
}
const shareLocation=()=>{
  props.getLocation4Modal()
}
function TruncatedText({ text, limit,color,size }) {
  if (text.length <= limit) {
    return <span style={{ fontSize: size?size:"", color:color?color:"" }}>{text}</span>;
  }
  return (
    <span style={{ fontSize:size?size:"", color:color?color:"" }}>{`${text&&text.substring(
      0,
      limit
    )}`}{" "}...</span>
  );
}

    return(<>
  
    <>
    {props.show_Qr_Modal_VmList && (
        <div>

        <HeaderSecondary onClick={props&&props.HideQrModalFunforVmlistPage} /> 
          {!cameraError ? (
            <div>
              <div className="mt-[60px] h-full w-full backdrop-blur-md absolute top-0 left-0"></div>

               <Webcam  videoConstraints={videoConstraints}  className="object-cover h-screen w-screen" />  
              <div className="mt-[80px] w-[200px] h-[200px] border-4 border-[var(--color-primary)] rounded-md flex justify-center items-center absolute top-1/4 left-1/4  ">
                {showScanner && (
                      <QrReader
                      delay={50}
                      onError={handleError}
                      onScan={handleScan}
                      facingMode={cameraFacingMode}
                      style={{width:"100%",border:"none!important"}}
                      //className="object-cover rounded-md w-full h-full"
                               />
                )}
              </div> 
            </div>
          ) : (
            <>
              {" "}
              <p style={{ textAlign: "center", paddingTop: "50%" }}>
                {" "}
                No Camra Permission Reset Your Setting
              </p>
            </>
          )}
        </div>
      )}
      {props&&props.show_vmList_flag&&<>
    {(props&&props.cartCount>0)&&<Procced totalamount={props&&props.carttotalAmount} cartCount={props&&props.cartCount} bottom={"39px"}/>}
    {props&&props.activeOrderData&&props.activeOrderData[0]&&<ActiveOrdersFab
        
        itemname={props && props.activeOrderData&&props.activeOrderData[0]&&props.activeOrderData[0].lineItems[0].productName}
        itemlength={props &&props.activeOrderData&& props.activeOrderData[0]&&props.activeOrderData[0].lineItems.length}
        orderLength={props && props.activeOrderData&&props.activeOrderData.length}
        Top={props&&props.activeOrderData&&props.activeOrderData[0]?props.preCardItems&&props.preCardItems[0]?"122px" : "65px":"65px"}
        orderID={props &&props.activeOrderData&& props.activeOrderData[0]&&props.activeOrderData[props.activeOrderData.length-1].orderId}
        orderMachineId={props &&props.activeOrderData&& props.activeOrderData[0]&&props.activeOrderData[props.activeOrderData.length-1].vendingMachineId}
        />}
    <BottomNavBar/>

  {props&&props.show_location_flag&&!(localStorage.getItem("lat"))&&<LocationPage getFirstLocation={props&&props.getLocation}/>}
  
  <TopNavbar LoctionPinHeader={true} QrMarkHeader={true} shareLocation={shareLocation} ShowQRFun={ShowQRFun} />
  <Box>



<Box    sx={{display:{xs:"block",md:"",sm:"block"},
        //backgroundImage: ' linear-gradient(to bottom, #ffffff, #f4fcff)',
        background: "radial-gradient(circle, rgba(245, 233, 233, 0.408) 0%, rgba(185, 245, 247, 0.34) 100%)",
        minHeight: '100vh',
        padding: "12px",

        color: '#fff', // Set text color to white
    }}
>

  <Box display={"none"}><Banner_Container vmid={0} /></Box>

     {(props&&props.vmListSkeleton)?<Skeleton
    variant="rectangular"
    width="100%"
    height={40}
   
    sx={{ borderRadius:"10px", objectFit: 'scale-down', padding: '2%' ,marginBottom:"5px",marginTop:"5%"}}
  />:
  <TextField
      onClick={(e) => globalSearchflag(e)}
      sx={{
        background: "white",
        borderRadius: "10px",
        border: "none",
        '& .MuiOutlinedInput-root': {
          '& fieldset': {
            borderColor: 'your-border-color', // customize border color
          },
          '& input': {
            fontSize: '15px', // customize font size
            color: 'background: rgba(56, 79, 111, 1)', // customize font color
          },
        },
      }}
      variant="outlined"
      fullWidth
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <Search/>
          </InputAdornment>
        ),
        endAdornment: (
          <InputAdornment position="end">
            {searchText && (
              <IconButton
                edge="end"
                onClick={handleClear}
              >
                <ClearIcon />
              </IconButton>
            )}
          </InputAdornment>
        ),
      }}
      InputLabelProps={{
        shrink: true,
      }}
      placeholder="Find items or machine"
      value={searchText}
      onChange={(e) => setSearchText(e.target.value)}
    />}
 {props&&props.recentMachines&&props.recentMachines[0]&&<RecentVms recentMachines={props&&props.recentMachines} VmsClick={VmsClick} vmListSkeleton={props&&props.vmListSkeleton} />}
 <Box marginTop={"20px"}>
 <Typography color={"rgba(113, 129, 152, 1)"}  marginTop={"5%"}>Nearby by Vending Machine</Typography>
    {(props&&props.vmListSkeleton)?
    <Box marginTop={"14px"}>
      {[...Array(10)].map((_, index) => (
        <Card key={index} sx={{ width: '100%', borderRadius: '16px', marginBottom: '16px' ,boxShadow:"0px 2px 21px 0px rgba(0, 0, 0, 0.08) " }}>
          <div >
            <div style={{display:"flex"}}>
            <div style={{ width:"30%",padding:"2%",    }}>
            <Skeleton
              variant="rectangular"
              width="100%"
              height={80}
             
              sx={{ borderRadius:"10px", objectFit: 'scale-down', padding: '2%' }}
            />
            </div>
            
         
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '5%' }}>
              <Box>
                <Skeleton variant="text" width={150} height={20} marginBottom={2} />
                <Skeleton variant="text" width={100} height={20} />
              </Box>
            </Box>
          </div>
          </div> 
        </Card>
      ))}
    </Box>:<Box marginTop={"3%"}  marginBottom={props&&props.activeOrderData&&props.activeOrderData[0]&&props&&props.carttotalAmount?"53%":props&&props.carttotalAmount?"37%":props&&props.activeOrderData&&props.activeOrderData[0]?"37%":"60px"}>
    {props&&props.nearbyMachines.map((data, index) => (
        <Card key={index} sx={{ width: '100%', borderRadius: '16px', marginBottom: '10px',boxShadow:"0px 2px 21px 0px rgba(0, 0, 0, 0.08) " }}  onClick={(e)=>VmsClick(e,data.id,data.name,data.address,"nearbyMachines_Section")}>
          <Box sx={{ display: 'flex' }}>
          
        <object
               /*  className="profile-img" */
                data={`https://daalchini.s3.ap-south-1.amazonaws.com/dcprod/${data.machineImagePath}`}
                type="image/png"
                style={{backgroundColor:"none",padding:"5%",width:"30%",objectFit:"fill",height:"80px",borderRadius:"27px"}}
              >
                <img /* className="cover"  */src={VmImgnotfound} alt="Product Img" style={{width:"100%",padding:"0px",height:"50px",objectFit:"contain",borderRadius:"6px"}} />{" "}
              </object>
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '5%',paddingLeft:"0px" }}>
              <Box>
                <Typography fontWeight={600} fontSize={"14px"} color={"rgba(56, 79, 111, 1)"}></Typography><TruncatedText text={data.name} limit={25}/>
                <Typography color={"rgba(148, 163, 184, 1)"} fontWeight={400} fontSize={"12px"}><TruncatedText text={data.address } limit={33}/></Typography>
              </Box>
            </Box>
          </Box>
        </Card>
      ))}
        </Box>}
    </Box>
  </Box>
  
  </Box>
  </>}
   
    </></>)
}

export default VmList 