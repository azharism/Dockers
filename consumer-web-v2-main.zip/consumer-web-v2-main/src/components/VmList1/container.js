import React, { useEffect, useState } from "react";
import VmList from "./component";
import { useNavigate } from "react-router-dom";
import {fetchVmListRequest,fetchPreCardRequest,fetchActiveOrdersRequest} from './action'
import { connect } from "react-redux";
import { toast } from "react-toastify";
const Vmlist_Container = (props) => {
const navigate=useNavigate()
const [loader,setLoader]=useState(false)
const [location_Btn_disable,setLocation_Btn_disable]=useState(false)
const [show_location_flag, setShow_location_flag] = useState(true);
const [show_vmList_flag,setShow_vmList_flag]=useState(false)
const [vmListSkeleton,setVmListSkeleton]=useState(true)
const [nearbyMachines,setNearbyMachines]=useState([])
const [recentMachines,setRecentMachines]=useState([])
const [preCardItems,setPreCardItems]=useState()
const [cartCount,setCartCount]=useState(null)
const [carttotalAmount,setCarttotalAmount]=useState(null)
const [activeOrderData,setActiveOrderData]=useState(null)
const [show_Qr_Modal_VmList,setShow_Qr_Modal_VmList]=useState(false)
let totalitemcount=0,totalAmount=0
useEffect(()=>{
  if(navigator.onLine){
    if (localStorage.getItem("lat") && localStorage.getItem("lng")) {
        setShow_vmList_flag(true); // SHOW VM LIST PAGE AND
        setShow_location_flag(false); // HIDE LOCATION PAGE
        fetchVmList(localStorage.getItem("lat"), localStorage.getItem("lng"));
        fetchPreCard()
        fetchActiveOrder()
      }
      else{
        setShow_vmList_flag(false); // HIDE VM LIST PAGE AND

        setShow_location_flag(true);
      }
    }
    else{
      setLoader(false)
    }
},[])

function getLocation() {

    console.log("mpClick getLocation")
       
      setLocation_Btn_disable(true);// untill location not get till ...disable Location Page Btn
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
      } else {
        console.log("Geolocation is not supported by this browser.");
      }
      function showPosition(position) {
        setLoader(true);
        console.log(
          "Latitude: " +
            position.coords.latitude +
            " Longitude: " +
            position.coords.longitude
        );
        localStorage.setItem("lat", position.coords.latitude);
        localStorage.setItem("lng", position.coords.longitude);
        setShow_location_flag(false);// HIDE VM LIST PAGE AND
        setShow_vmList_flag(true);//// SHOW LOCATION PAGE
  
        fetchVmList(position.coords.latitude, position.coords.longitude);
  
       
      }
  
      // if any problem to access  location  than 
      function showError(error) {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setLocation_Btn_disable(false);
            console.log("User denied the request for Geolocation.");
            toast.error(`User denied the request for Geolocation`, {
              position: toast.POSITION.TOP_RIGHT,
              autoClose: 1000,
            });
  
            break;
          case error.POSITION_UNAVAILABLE:
            setLocation_Btn_disable(true);
            console.log("Location information is unavailable.");
            toast.error(`Location information is unavailable.`, {
              position: toast.POSITION.TOP_RIGHT,
              autoClose: 1000,
            });
            break;
          case error.TIMEOUT:
            setLocation_Btn_disable(true);
            console.log("The request to get user location timed out.");
            toast.error(`The request to get user location timed out.`, {
              position: toast.POSITION.TOP_RIGHT,
              autoClose: 1000,
            });
            break;
          case error.UNKNOWN_ERROR:
            setLocation_Btn_disable(true);
            console.log("An unknown error occurred.");
            toast.error(`An unknown error occurred.`, {
              position: toast.POSITION.TOP_RIGHT,
              autoClose: 1000,
            });
            break;
        }
      }
    }
function getLocation4Modal() {
   
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
      console.log("Geolocation is not supported by this browser.");
    }
    function showPosition(position) {
      setLoader(true);
      console.log(
        "Latitude: " +
          position.coords.latitude +
          " Longitude: " +
          position.coords.longitude
      );
      localStorage.setItem("lat", position.coords.latitude);
      localStorage.setItem("lng", position.coords.longitude);
      setShow_location_flag(false);// HIDE VM LIST PAGE AND
      setShow_vmList_flag(true);//// SHOW LOCATION PAGE

      fetchVmList(position.coords.latitude, position.coords.longitude);
    }

    // if any problem to access  location  than 
    function showError(error) {
      switch (error.code) {
        case error.PERMISSION_DENIED:
          setLocation_Btn_disable(false);
          console.log("User denied the request for Geolocation.");
          toast.error(`User denied the request for Geolocation`, {
            position: toast.POSITION.TOP_RIGHT,
            autoClose: 1000,
          });

          break;
        case error.POSITION_UNAVAILABLE:
          setLocation_Btn_disable(true);
          console.log("Location information is unavailable.");
          toast.error(`Location information is unavailable.`, {
            position: toast.POSITION.TOP_RIGHT,
            autoClose: 1000,
          });
          break;
        case error.TIMEOUT:
          setLocation_Btn_disable(true);
          console.log("The request to get user location timed out.");
          toast.error(`The request to get user location timed out.`, {
            position: toast.POSITION.TOP_RIGHT,
            autoClose: 1000,
          });
          break;
        case error.UNKNOWN_ERROR:
          setLocation_Btn_disable(true);
          console.log("An unknown error occurred.");
          toast.error(`An unknown error occurred.`, {
            position: toast.POSITION.TOP_RIGHT,
            autoClose: 1000,
          });
          break;
      }
    }
  }

  function HideQrModalFunforVmlistPage(){



    setShow_vmList_flag(true); // HIDE VM LIST PAGE AND
  
    setShow_location_flag(false); // HINDE LOCATION PAGE
  
    setShow_Qr_Modal_VmList(false);// Show Qr Modal
  
  }


    const fetchVmList = (lat, lng) => {
      console.log("fetchVmList")
        setLoader(true)
        const UserJWTAuth = localStorage.getItem("UserJWTAuth");
        setLoader(true)
        props.fetchVmListRequest({
          url: `/consumerbe/api/v2/outlet/search?nearbyLimit=50&recentLimit=6&lat=${lat}&lng=${lng}`,
          method: "GET",
          headers: {
            Authorization: `Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzUxMiJ9.eyJqdGkiOiI2ZWZhMjI4Yy01ZTBjLTRiZGQtYWRmOS1mZTg1YTk1ZjQzYWYiLCJzdWIiOiIxMjE1NiIsImlhdCI6MTcwNzczMTQ2Miwicm9sZSI6IlVTRVIiLCJwZXJtaXNzaW9ucyI6WyJ1c2VyIl19.AKEPvHwvaAiz3rCReVBO03vBS7UU_XT-Fkwjp4bKp4ntleOoSnXppCUhpO50xxMo4PmWaaPPuQv4pZJLNhRBpu6xAKK07Y4KEUWkPD-4m3UgTQB68vBC7b-QYZoMXAo3zQSE0sTcxLdxWFXUVy_6L-Pu-2d4I552NGtqXRcivddv-Fbd`,
            "x-app-platform": "web",
            "x-app-version": "v1.0.1",
            //HEADER ERROR
          "x-device-id":localStorage.getItem("uuid")
            
          },
          handleErrorVmList,
          handleResponseVmList,
        });
      };
      const handleResponseVmList = (res) => {
        setShow_location_flag(false);

        setVmListSkeleton(false)
      
         console.log("handleResponse", res.data.data.nearbyMachines);
         setNearbyMachines(res.data.data.nearbyMachines)
         setRecentMachines(res.data.data.recentMachines)
        setLoader(false)
       };
     
       const handleErrorVmList = (error) => {
    /*      console.log("handleErrorVmList", error&&error.response.status==401);
         setLoader(false)
         if(error&&error.response.status==401|| error&&error.response.status==403){
           console.log(error&&error.response.data.status.code);
           //LOGOUT
           localStorage.removeItem("UserJWTAuth")
           navigate("/login");
       } */
       };
     
       useEffect(()=>{
        console.log("tahzeeb preCardItems",preCardItems)
        preCardItems&&preCardItems[0]&&preCardItems.forEach(item => {
          console.log("tahzeeb preCardItems",item)
          const count = item.count;
          const amount = item.amount;
          const itemTotal = count * amount;
          totalitemcount+=item.count
          totalAmount += itemTotal;
        });
        setCartCount(totalitemcount)
        setCarttotalAmount(totalAmount)
      
       
    
      },[preCardItems])


       const fetchPreCard = () => {
        const Guest_clientId=localStorage.getItem("Guest_clientId")
        const UserJWTAuth = localStorage.getItem("UserJWTAuth");
    
        if(!Guest_clientId){
        props.fetchPreCardRequest({
          url: `/consumerbe/api/v2/cart`,
          method: "GET",
          headers: {
            Authorization: `Bearer ${UserJWTAuth}`,
            "x-app-platform": "web",
            "x-app-version": "v1.0.1",
             //HEADER ERROR
          "x-device-id":localStorage.getItem("uuid")
          },
          handleErrorPreCard ,
          handleResponsePreCard ,
        });
      }
      };

      const handleErrorPreCard = (error) => {
   
        setLoader(false)
       
        if(error.response.status==401|| error.response.status==403){
          console.log("handleErrorPreCard", error.response.data.status.code);
           //LOGOUT
        localStorage.removeItem("UserJWTAuth")
        navigate("/login");
      }
      };

      const handleResponsePreCard = (res) => {
        console.log("handleResponsePreCard", res.data.data.items);
       setPreCardItems(res.data.data.items)
    
        
       
      };
    
      const fetchActiveOrder = () => {
        const UserJWTAuth = localStorage.getItem("UserJWTAuth");
        const Guest_clientId=localStorage.getItem("Guest_clientId")
      if(!Guest_clientId){
        props.fetchActiveOrdersRequest({
          url: `/consumerbe/api/v2/order/active`,
          method: "GET",
          headers: {
            Authorization: `Bearer ${UserJWTAuth}`,
            "x-app-platform": "web",
            "x-app-version": "v1.0.1",
             //HEADER ERROR
            "x-device-id":localStorage.getItem("uuid")
          },
          handleErrorActiveOrders ,
          handleResponseActiveOrders ,
        });
      }
      };

      const handleErrorActiveOrders = (error) => {
        setLoader(false)
        console.log("KHAN handleErrorActiveOrders ", error);
        if(error.response.status==401|| error.response.status==403){
    
          console.log("handleErrorActiveOrders", error.response.data.status.code);
          //Logout
          localStorage.removeItem("UserJWTAuth")
            navigate("/login");
      }
      };

      const handleResponseActiveOrders=(res)=>{

        console.log("handleResponseActiveOrders", res.data.data);
        setActiveOrderData(res.data.data)
    
      }

      useEffect(()=>{},activeOrderData)

return(<>
<VmList 
getLocation4Modal={getLocation4Modal}
show_location_flag={show_location_flag}
show_vmList_flag={show_vmList_flag}
setShow_vmList_flag={setShow_vmList_flag}
getLocation={getLocation}
vmListSkeleton={vmListSkeleton}
nearbyMachines={nearbyMachines}
recentMachines={recentMachines}
carttotalAmount={carttotalAmount}
cartCount={cartCount}
activeOrderData={activeOrderData}
preCardItems={preCardItems}
setShow_Qr_Modal_VmList={setShow_Qr_Modal_VmList}
HideQrModalFunforVmlistPage={HideQrModalFunforVmlistPage}
show_Qr_Modal_VmList={show_Qr_Modal_VmList}
setShow_location_flag={setShow_location_flag}
/>
</>)


}

const mapStateToProps = (props) => {
    return props;
  };
  
  const mapDispatchToProps = {
    fetchVmListRequest,
    fetchPreCardRequest,
    fetchActiveOrdersRequest
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(Vmlist_Container);
  