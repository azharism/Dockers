import { call, put, takeLatest } from "redux-saga/effects";
import axios from "axios";
import { FETCH_ORDER_DETAILS_REQUEST, fetchOrderDetailsFailure, fetchOrderDetailsSuccess } from "./action";
///////////////////////////////////// API CALL ONLY ///////////////////////////////////////////
const callApi = async (mydata) => {
    console.log("callApi", mydata.data);
  
    const url = `https://api-prod.daalchini.co.in${mydata.data.url}`;
    try {
      const response = await axios({
        method: mydata.data.method,
        url: url,
        headers: mydata.data.headers,
        data: mydata.data.request
        
      });
  
      return response;
    } catch (error) {
      throw error;
    }
  };
  
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  





  /////////////////////////////////// ACTIVE ORDER DATA////////////////////////////////////////////////////

function* fetcheOrderDetails(action) {
    console.log("fetchPreCard saga", action);
    try {
      const response = yield call(callApi, action);
  
      yield put(fetchOrderDetailsSuccess(response));
  
      action.data.handleResponseOrderDetails(response);
    } catch (error) {
      console.log("fetchPreCard error", error.message);
      yield put(fetchOrderDetailsFailure(error.message));
      action.data.handleErrorOrderDetails(error)    }
  }

  function* OrderDetailsSaga() {
    yield takeLatest(FETCH_ORDER_DETAILS_REQUEST, fetcheOrderDetails);
    
  }
  
  export default OrderDetailsSaga;