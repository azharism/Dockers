import React from 'react'
import DalchiniLogo from '../../assets/dalchini_logo.png'

const Header = () => {
  return (
    <div className='h-[56px] flex items-center m-3 '>
        <img src={DalchiniLogo} alt='dalchini logo' />
    </div>
  )
}

export default Header