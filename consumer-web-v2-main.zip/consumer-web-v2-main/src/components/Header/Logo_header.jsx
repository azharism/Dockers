import Daalchini_Logo from "../../assets/dalchini_logo.png";
import locat from '../../assets/locat.png';
import QrHeader from '../../assets/qrmark.png'

export const Header_with_Qr = ({ShowLocationModal,ShowQRFun}) => {
  return (
    <>
      <header className="daalchini-header-color daalchini-header-height fixed  w-full z-20">
        <div className=" inset-x-0 top-0 bg-white rounded-t-lg"></div>
        <div className="flex items-center  justify-between w-full">
          <img src={Daalchini_Logo} alt="Logo" className="p-4 w-28 " />
          <div className="flex">
          <img src={locat} alt="Logo" onClick={ShowLocationModal} style={{width:"60px",height:"66px"}} className="p-4" />
          <img src={QrHeader} alt="Logo" onClick={ShowQRFun}style={{width:"65px",height:"65px"}} className="p-4 w-10" />
          </div>
        </div>
      </header>
    </>
  );
};

export const Logo_header = () => {
  return (
    <>
      <header className="daalchini-header-color daalchini-header-height fixed  w-full z-20">
        <div className=" inset-x-0 top-0 bg-white rounded-t-lg"></div>
        <div className="flex items-center  justify-between w-full">
          <img src={Daalchini_Logo} alt="Logo" className="p-4 w-28 " />
        
        </div>
      </header>
    </>
  );
};