import React, { useState } from 'react';

import { Button, Typography, Grid } from '@material-ui/core';
import Webcam from "react-webcam";
import QrReader from "react-web-qr-reader";
const QRCodeScanner = () => {
  const [result, setResult] = useState('');
  const [cameraFacingMode, setCameraFacingMode] = useState('environment'); // 'user' for front camera, 'environment' for rear camera


  const handleScan = (data) => {
    if (data) {
      setResult(data);
    }
  };

  const handleError = (err) => {
    console.error(err);
  };

  const resetScanner = () => {
    setResult('');
  };
  const videoConstraints = {
    facingMode: 'environment',  // This sets the camera to use the back camera
  };



  return (
    <div>
    <div className="mt-[60px] h-full w-full backdrop-blur-md absolute top-0 left-0"></div>

     <Webcam  videoConstraints={videoConstraints}  className="object-cover h-screen w-screen" />  
    <div className="mt-[80px] w-[200px] h-[200px] border-4 border-[var(--color-primary)] rounded-md flex justify-center items-center absolute top-1/4 left-1/4  ">
      {true && (
            <QrReader
            delay={50}
            onError={handleError}
            onScan={handleScan}
            facingMode={cameraFacingMode}
            style={{width:"100%",border:"none!important"}}
            //className="object-cover rounded-md w-full h-full"
                     />
      )}
    </div> 
  </div>
  );
};

export default QRCodeScanner;
