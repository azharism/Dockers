import { FETCH_INVENTORY } from "./constant";
import { ADD_TO_CART } from "./constant";
import { REMOVE_TO_CART } from "./constant";
export function fetchInventory(
    method,
    url,
    headers,
    body,
    handleSuccess,
    //handleError,
    //showToast,

) {
    console.log('method---',method,url,body)
    
    return {
      type:FETCH_INVENTORY,
      method,
      url,
      headers,
      body,  
      handleSuccess,
      //handleError,
      //showToast,
    };
  }


  export function addtocart(
    method,
    url,
    headers,
    body,
    handleSuccess,
    //handleError,
    //showToast,

) {
    console.log('method---',method,url,body)
    
    return {
      type:ADD_TO_CART,
      method,
      url,
      headers,
      body,  
      handleSuccess,
      //handleError,
      //showToast,
    };
  }

  export function removetocart(
    method,
    url,
    headers,
    body,
    handleSuccess,
    //handleError,
    //showToast,

) {
    console.log('method---',method,url,body)
    
    return {
      type:REMOVE_TO_CART,
      method,

      url,
      headers,
      body,  
      handleSuccess,
      //handleError,
      //showToast,
    };
  }