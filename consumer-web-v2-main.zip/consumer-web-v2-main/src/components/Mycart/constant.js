export const FETCH_INVENTORY = '@Inventory/FETCH_INVENTORY';
export const ADD_TO_CART = '@Cart/ADD_TO_CART';
export const REMOVE_TO_CART = '@Cart/REMOVE_TO_CART';
export const INITIATED_PAYMENT_API = '@Cart/INITIATED_PAYMENT_API';
export const APPLY_COUPON='@Cart/APPLY_COUPON';