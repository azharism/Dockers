import { call, put, takeLatest } from "redux-saga/effects";
import axios from "axios";
import { FETCH_FAQ_TOPIC_REQUEST,fetchFaqTopicSuccess,fetchFaqTopicFailure, FETCH_ORDER_HISTORY_LIST_FAQ_REQUEST, fetchOrdersHistoryFailure, fetchOrdersHistorySuccess} from "./action";
///////////////////////////////////// API CALL ONLY ///////////////////////////////////////////
const callApi = async (mydata) => {
    console.log("callApi", mydata.data);
  
    const url = `https://api-prod.daalchini.co.in${mydata.data.url}`;
    try {
      const response = await axios({
        method: mydata.data.method,
        url: url,
        headers: mydata.data.headers,
        data: mydata.data.request
        
      });
  
      return response;
    } catch (error) {
      throw error;
    }
  };
  
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  





  /////////////////////////////////// ACTIVE ORDER DATA////////////////////////////////////////////////////

 function* fetcheOrderHistory(action) {
    console.log("fetchPreCard saga", action);
    try {
      const response = yield call(callApi, action);
  
      yield put(fetchOrdersHistorySuccess(response));
  
      action.data.handleResponseOrderHistory(response);
    } catch (error) {
      console.log("fetchPreCard error", error.message);

      yield put(fetchOrdersHistoryFailure(error.message));
      action.data.handleErrorOrderHistory(error);
     
    }
  } 



function* fetcheFaqTopics(action) {
  console.log("fetchPreCard saga", action);
  try {
    const response = yield call(callApi, action);

    yield put(fetchFaqTopicSuccess(response));

    action.data.handleResponseFaqTopic(response);
  } catch (error) {
    console.log("fetchPreCard error", error.message);
   
    yield put(fetchFaqTopicFailure(error.message));
    action.data.handleErrorFaqTopic(error);
  }
}

  function* FaqTopicsSaga() {
    yield takeLatest(FETCH_FAQ_TOPIC_REQUEST, fetcheFaqTopics);
    yield takeLatest(FETCH_ORDER_HISTORY_LIST_FAQ_REQUEST,fetcheOrderHistory)
    
  }
  
  export default FaqTopicsSaga;