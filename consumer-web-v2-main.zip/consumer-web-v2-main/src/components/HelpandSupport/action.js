export const FETCH_ORDER_SEARCH_IMAGE_REQUEST="FETCH_ORDER_SEARCH_IMAGE_REQUEST"
export const FETCH_ORDER_SEARCH_IMAGE_SUCCESS="FETCH_ORDER_SEARCH_IMAGE_SUCCESS"
export const FETCH_ORDER_SEARCH_IMAGE_FAILURE="FETCH_ORDER_SEARCH_IMAGE_FAILURE"


export const  fetchOrderSearchImageRequest=(myurldata)=>{
    console.log("etchPreCardRequest myurldata---->",myurldata)
    return{
        type:FETCH_ORDER_SEARCH_IMAGE_REQUEST,
        data:myurldata
    }

    
   
}

export const fetchOrderSearchImageSuccess=(OrderHistory)=>{
return{
    type:FETCH_ORDER_SEARCH_IMAGE_SUCCESS,
    OrderHistory:OrderHistory
}
}

export const fetchOrderSearchImageFailure=(error)=>{
    return{
    type:FETCH_ORDER_SEARCH_IMAGE_FAILURE,
    error:error
    }
}