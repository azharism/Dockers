import { call, put, takeLatest } from "redux-saga/effects";
import axios from "axios";
import { FETCH_ORDER_SEARCH_REQUEST, fetchOrderSearchImageFailure, fetchOrderSearchImageSuccess } from "./action";
import { fetchOrderSearchFailure } from "./action";
import { fetchOrderSearchSuccess } from "./action";
///////////////////////////////////// API CALL ONLY ///////////////////////////////////////////
const callApi = async (mydata) => {
    console.log("callApi", mydata.data);
  
    const url = `https://api-prod.daalchini.co.in${mydata.data.url}`;
    try {
      const response = await axios({
        method: mydata.data.method,
        url: url,
        headers: mydata.data.headers,
        data: mydata.data.request
        
      });
  
      return response;
    } catch (error) {
      throw error;
    }
  };
  
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  





  /////////////////////////////////// ACTIVE ORDER DATA////////////////////////////////////////////////////

function* fetcheOrderSearch(action) {
    console.log("fetchPreCard saga", action);
    try {
      const response = yield call(callApi, action);
  
      yield put(fetchOrderSearchSuccess(response));
  
      action.data.handleResponseFindOrder(response);
    } catch (error) {
      console.log("fetchPreCard error", error.message);
      action.data.handleErrorFindOrder(error)
      yield put(fetchOrderSearchFailure(error.message));
    }
  }

  function* OrderSearchSaga() {
    yield takeLatest(FETCH_ORDER_SEARCH_REQUEST, fetcheOrderSearch);
    
  }
  
  export default OrderSearchSaga;