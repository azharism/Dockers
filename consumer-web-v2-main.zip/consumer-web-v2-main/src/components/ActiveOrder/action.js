import { CANCLE_ORDER } from "./constant";

export function CancleOrder(
    method,
    url,
    headers,
    body,
    handleSuccess,
    handleError,
    //showToast,

) {
    console.log('method---',method,url,body)
    
    return {
      type:CANCLE_ORDER,
      method,
      url,
      headers,
      body,  
      handleSuccess,
      handleError,
      //showToast,
    };
  }
