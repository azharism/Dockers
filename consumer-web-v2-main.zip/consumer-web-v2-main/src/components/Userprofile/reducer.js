import { FETCH_USER_DETAILS_FAILURE, FETCH_USER_DETAILS_REQUEST, FETCH_USER_DETAILS_SUCCESS } from "./action";


const initialState = {
    //////////////VM LIST VARIABLES///////////////
      UserDetailsData: [],
      loading_User_History:false,
      error_User_History:null
     
}    



const OrderHistoryReducer = (state = initialState, action) => {
    console.log("OrderHistoryReducer",action&&action.OrderHistory&&action.OrderHistory.data&&action.OrderHistory.data.response)
    switch (action.type) {
//////////////////////SWITCH CASES FOR ACTIVE ORDERS //////////////////////////////////////
case FETCH_USER_DETAILS_REQUEST:
    return {
      ...state,
      
      loading_User_History:false,
      error_User_History:null
    };

  case FETCH_USER_DETAILS_SUCCESS: 
    return {
      ...state,
      
      UserDetailsData: action&&action.OrderHistory&&action.OrderHistory.data&&action.OrderHistory.data.response,
      loading_User_History:false,
      error_User_History:null
    
    
    };

  case FETCH_USER_DETAILS_FAILURE: 
  return {
    ...state,
 
      loading_User_History:false,
      error_User_History:action.error
   
  }
  
  
  
  
  
  
    default:
      return state;

  }
};

export default OrderHistoryReducer;
