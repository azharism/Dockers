export const POST_GIFT_CARD_REQUEST="POST_GIFT_CARD_REQUEST"



export const sendGiftRequest=(myurldata)=>{
    console.log("etchPreCardRequest myurldata---->",myurldata)
    return{
        type:POST_GIFT_CARD_REQUEST,
        data:myurldata
    }

    
   
}













