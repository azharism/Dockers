import { Box } from "@material-ui/core";
import React, { useEffect, useRef, useState } from "react";
import gift from '../../assets/giftlogo.svg'
import Gift1 from '../../assets/GIFT3.png'
import giftwrap from '../../assets/giftwrap.png'
import giftWork from '../../assets/giftworks.png'
import '../../components/GiftCard/gift.css'
import aa from '../../assets/aa.gif'
import giftcardbg from '../../assets/bg2.svg'

import Cross from '../../assets/cross1.png'

import axios from "axios";
import Hand from '../../assets/Hand.png';
import HandW from '../../assets/Handw.png';
import Vector from '../../assets/Vector.png';
import Cel from '../../assets/cel.gif'
import jump from '../../assets/jump.gif'
import { sendGiftRequest } from "./action";
import { toast } from 'react-toastify';
import { connect } from "react-redux";
import Tick from '../../assets/tick.png'
import backArrow from '../../assets/backArrow.png'
import { Link } from "react-router-dom";
const GiftCard = (props) => {

  const inputRef = useRef(null);
  const [flag, setFlag] = useState(false)
  const [flag2, setFlag2] = useState(false)
  const [giftCode, setGiftCode] = useState(null)
  const [wrapFlag, setwrapFlag] = useState(true)
  useEffect(() => {
    //GiftCardCall()
    
  }, [])

  useEffect(() => {
    if (flag) {
      inputRef.current.focus(); // Focus on input when modal opens
    }
  }, [flag]);

  const GiftCardInput = (e) => {
    setGiftCode(e.target.value)

  }


  const GiftCardCall = () => {
    console.log("GiftCardCall")
    GiftCardApi()


  }

  const close2 = () => {
    window.location.reload()
  }

  const close = () => {
    setGiftCode(null)
    setFlag(false)
    document.body.style.overflow = '';


  }

  const handleResponseGiftCardApi = (res) => {
    setFlag(false)
    setFlag2(true)

    setTimeout(() => {
      setwrapFlag(false)
    }, 500);

  }

  const handleErrorGiftCardApi = (error) => {

    console.log("error", error && error.response && error.response.data && error.response.data.status.message)

    toast.error(`${error.response.data.status.message}`, {
      position: toast.POSITION.TOP_RIGHT,
      autoClose: 1000,
    })


  }

  const GiftCardApi = () => {
    localStorage.setItem("defaultPgName", "WALLET_LOYALTY")
    localStorage.setItem("defaultPgId", 9)
    const UserJWTAuth = localStorage.getItem("UserJWTAuth")
    props.sendGiftRequest({
      url: `/consumerbe/api/v2/voucher/apply`,
      method: "POST",
      headers: {
        Authorization: `Bearer ${UserJWTAuth}`,

        "x-app-platform": "web",
        "x-app-version": "v1.0.1",
      },
      "request": {



        "code": giftCode







      },
      handleErrorGiftCardApi,
      handleResponseGiftCardApi: (res) => handleResponseGiftCardApi(res),
    });
  };
const openModal=(e)=>{
  document.body.style.overflow = 'hidden';
  setFlag(true)
}




  useEffect(() => {
    console.log("useEffect--->")

  }, [flag, flag2])

  return (
    <div>
     
      {flag2 && <> <div className="giftmodal" style={{ display: "flex", justifyContent: "center" }}>
        {false && <div className="innergiftmodal">
          <img src={aa} />
        </div>}
        <div>
          <div style={{
            position: "absolute",
            right: "20px", top: "20px"
          }}><img src={Cross} onClick={(e) => { close2(e) }} style={{ width: "30px" }} /></div>
          {true &&
            <div style={{ width: "143px", height: "147px", border: "1px solid rgba(56, 79, 111, 0.44)", borderRadius: "41px", margin: "3%", marginTop: "47%", background: "white" }}>
              {wrapFlag && <img style={{
                "border-top-right-radius": "33px",
                "border-top-left-radius": "33px"
              }} src={giftwrap} />}
              <div style={{ display: "flex", justifyContent: "center", alignItems: "center", width: "143px", height: "147px" }}>
                <div style={{ height: "143px" }}>

                  {!wrapFlag && <>
                    <img src={Cel} />

                    <div style={{ display: "flex", justifyContent: "center" }}><img src={Tick} style={{ width: "50px", marginTop: "11px" }} /></div>
                    <div style={{
                      display: "flex",
                      justifyContent: "center",

                      marginTop: "-60px"
                    }}>
                      <img src={jump} />
                    </div>
                  </>}
                </div>
              </div>





            </div>}
          {false && <h1 style={{ fontSize: "20px", color: "white", fontWeight: "600", textAlign: "center" }}>Tap to Claim</h1>}
          {<h1 style={{
            fontSize: "20px", color: "white", fontWeight: "600", textAlign: "center", position: "absolute",
            width: "100%",
            left: "0"
          }}>Gift Card from a friend enjoy!</h1>}




        </div>

        <div className="gift-modal-content " style={{ "border-top-right-radius": "30px", "border-top-left-radius": "30px" }}>
          <div style={{ padding: "7%", }}>
            <h1 style={{ color: "rgba(56, 79, 111, 1)", fontSize: "14px", fontWeight: "500" }}>Points To Note:</h1>
            <li style={{ color: "rgba(113, 129, 152, 1)", fontSize: "12px", fontWeight: "400" }}>hello i m tahzeeb khan </li>
          </div>


        </div>
      </div></>}
      {flag && <> <div className="giftmodal" style={{ display: "flex", justifyContent: "center" }}>

        <div>
          <div style={{ marginTop: "49px" }}><img src={Cross} onClick={(e) => { close() }} style={{ width: "40px" }} /></div>




        </div>

        <div className="gift-modal-content " style={{ borderTopRightRadius: "30px",borderTopLeftRadius: "30px"  }}>

          <div style={{ padding: "5%" }}>
            <div style={{ display: "flex" }}><h1 style={{ fontSize: "16px", fontWeight: "500" }}>Claim Gift Card Here &nbsp;</h1><img style={{ width: "20px" }} src={Hand} />
           
            </div>
            <div className="tahzeebhello" style={{
              position: "absolute",
              top: "26px", width: "90%", marginTop: "8%",
              "box-shadow": "none",
            }}>
              <div className="tahzeebhello" style={{ borderRadius:"18px",fontSize:"13px",borderRadius: "20px", display: "flex", "box-shadow": "0px 1px 41.2px 0px rgba(0, 0, 0, 0.08)" }}>
              <input
                  ref={inputRef}
                  className="tahzeebhello"
                  value={giftCode || ''}
                  onChange={GiftCardInput}
                  type="text"
                  placeholder="Enter 6 Digit Gift Card Code"
                  style={{ "box-shadow": "none",}}
                />
                {giftCode && <div style={{ display: "flex", justifyContent: "center", alignItems: "center", background: "green", position: "absolute", top: "6%", right: "5%", height: "35px", width: "35px", borderRadius: "40px" }} onClick={e => { GiftCardCall(e) }}><div><img style={{ width: "12px", height: "12px" }} src={Vector} /></div></div>}

              </div>
              <div style={{ marginTop: "10%" }}>
                <h1 style={{ fontSize: "14px", fontWeight: "500", color: "rgba(56, 79, 111, 1)",marginBottom:"10px" }}>Points To Note:</h1>
                <li style={{ color: "rgba(113, 129, 152, 1)", fontSize: "12px", fontWeight: "400" }}>Yorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                <li style={{ color: "rgba(113, 129, 152, 1)", fontSize: "12px", fontWeight: "400" }}>Yorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                <li style={{ color: "rgba(113, 129, 152, 1)", fontSize: "12px", fontWeight: "400" }}>Yorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                <li style={{ color: "rgba(113, 129, 152, 1)", fontSize: "12px", fontWeight: "400" }}>Yorem ipsum dolor sit amet, consectetur adipiscing elit.</li>

              </div>

            </div>
          </div></div>
      </div></>}


      <Box  style={{
  backgroundImage: `url(${giftcardbg})`,
  backgroundSize: 'cover',
  backgroundRepeat: 'no-repeat',
  backgroundPosition: 'center center',
  width: '100%',
  height: '100vh',  // Adjust as needed
}}>

      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"5%"}}><Link to="/profile"><img src={backArrow} style={{width:"22px",height:"22px"}}/></Link>
      <h1 style={{color:"rgba(88, 60, 67, 1)",fontSize:"14px"}}></h1></div>
        
        <div style={{ display: "flex", justifyContent: "center" ,marginTop:"-60px"}}>
          <img src={gift} />

        </div>
        <div style={{ display: "flex", "justify-content": "center", position: "relative", "bottom": "73px" }}>
          <div style={{ width: "100%" }} >
            <div style={{ display: "flex", justifyContent: "center" }}><div style={{ width: "190px", height: "50px", background: "rgba(56, 79, 111, 1)", color: "white", borderRadius: "18px", display: "flex", justifyContent: "center" }} >
            <div style={{display:"flex",padding: "5%",}}>  <h1 style={{ fontSize: "14px", fontWeight: "500", textAlign: "center",marginRight:"5px" }}>Claim Gift Card Here </h1><img style={{ width: "20px",height:"20px" }} src={HandW} /></div>
            </div>
            </div>
            <div style={{ display: "flex", justifyContent: "center" }}>
              <div onClick={(e) => {openModal(e)}} className="hello" style={{
                position: "absolute",
                top: "26px", width: "90%"
              }}>
                <input className="hello" value={""} type="text" placeholder="Enter 6 Digit Gift Card Code" />

              </div>
            </div>
          </div>

        </div>

        <div style={{ display: "flex", justifyContent: "center", marginTop: "-16px" }}>
          <div style={{ width: "90%" }}>
            <div style={{ borderRadius: "18px", "box-shadow": "0px 4px 35.4px 0px rgba(0, 0, 0, 0.1)", padding: "5%", background: "white" }}>
              <div style={{ display: "flex", objectFit: "contain" }}>
                <div>
                  <h1 style={{ fontWeight: "500", fontSize: "16px" }}>How it works?</h1>


                  <p style={{ fontWeight: "400", fontSize: "12px" }}>
                    Claim your Daalchini gift card above and Buy your favorite snacks at any vending machine.
                  </p>
                </div>
                <img style={{ width: "100px" }} src={giftWork} />
              </div>
            </div>
          </div>
        </div>
        <div style={{ display: "flex", justifyContent: "center", marginTop: "6%" }}>
          <div style={{ padding: "5%", visibility: "hidden" }}>
            <div style={{ borderTopLeftRadius: "18px", borderTopRightRadius: "18px", "box-shadow": "0px 4px 35.4px 0px rgba(0, 0, 0, 0.1)", background: "white" }}>
              <h1 stmyCartyle={{ fontSize: "16px", fontWeight: "500", padding: "5%" }} >Your Gift Cards (8)</h1>
              <div style={{ display: "flex", "flex-wrap": "wrap", "justify-content": "space-between" }}>

                {
                  [1, 2,].map(() => (
                    <div style={{ visibility: "hidden" }}>
                      <>
                        {false && <div style={{ width: "143px", height: "147px", border: "1px solid rgba(56, 79, 111, 0.44)", borderRadius: "41px", margin: "3%" }}>
                          <img style={{
                            "mix-blend-mode": "multiply",
                            "border-top-right-radius": "33px",
                            "border-top-left-radius": "33px"
                          }} src={Gift1} />
                          <div style={{ background: "rgba(250, 225, 75, 1)", "border-top-left-radius": "7px", "border-bottom-left-radius": "7px", position: "absolute", "margin-top": "-59px", "margin-left": "85px" }}><h1 style={{ color: "rgba(240, 129, 69, 1)", fontWeight: "500" }}>11d left</h1></div>

                          <div style={{ padding: "5%" }}>
                            <h1 tyle={{ fontWeight: "600", fontSize: "14px" }}>₹100.00</h1>
                            <p style={{ fontWeight: "400", fontSize: "8px" }}>Gift Card from a friend
                              Enjoy!</p>
                          </div>
                        </div>}
                        {false && <div style={{ width: "143px", height: "147px", border: "1px solid rgba(56, 79, 111, 0.44)", borderRadius: "41px", margin: "3%" }}>
                          <img style={{
                            "mix-blend-mode": "multiply",
                            "border-top-right-radius": "33px",
                            "border-top-left-radius": "33px"
                          }} src={giftwrap} />


                        </div>}
                        {true && <div style={{ width: "143px", height: "147px", border: "1px solid rgba(56, 79, 111, 0.44)", borderRadius: "41px", margin: "3%" }}>
                          <img style={{
                            "mix-blend-mode": "multiply",
                            "border-top-right-radius": "33px",
                            "border-top-left-radius": "33px"
                          }} src={Gift1} />
                          <div style={{ background: "rgba(250, 225, 75, 1)", "border-top-left-radius": "7px", "border-bottom-left-radius": "7px", position: "absolute", "margin-top": "-24px", width: "140px" }}><h1 style={{ color: "rgba(240, 129, 69, 1)", fontWeight: "500", textAlign: "center" }}>Redeemed</h1></div>

                          <div style={{ padding: "5%" }}>
                            <h1 tyle={{ fontWeight: "600", fontSize: "14px" }}>₹100.00</h1>
                            <p style={{ fontWeight: "400", fontSize: "8px" }}>Gift Card from a friend
                              Enjoy!</p>
                          </div>
                        </div>}
                      </>
                    </div>
                  ))}


              </div>
            </div>
          </div>
        </div>
      </Box>

    </div>)
}



function mapStateToProps(props) {
  return {
    props,
  };
}
export default connect(mapStateToProps, {
  sendGiftRequest
})(GiftCard);


