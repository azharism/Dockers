import React, { useEffect } from 'react'

const  ButtonPrimary = ({text, onClick,color}) => {
  useEffect(()=>{

  },[text])
  return (
    <div>
        <button className='w-[302px] bg-[var(--color-button-primary)] rounded-lg text-white p-3 flex mx-auto justify-center text-sm font-body' onClick={onClick} style={{background:color}}>{text}</button>
    </div>
    
  )
}

export default ButtonPrimary