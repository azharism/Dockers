# CHANGELOG

### Ticketing
Deliver notifications to consumer app users

### Delivery
Orders can be delivered to user

### Mobility
Mobile vending machines

### Attendance
DF attendance

### General
General issues and quality of life changes

---

[Bugfix - Attendance](#attendance)

__Date: 2020-08-12__  
_BugFix: fixed response entries_

1. changed warehouseAddress to  warehourse_address_id
1. changed vendingMachineCohortId to vending_machine_cohort_id

[Feature - Mobility](#mobility)

__Date: 2020-07-23__  
_BugFix: notification sending issue_

1. fixed data format for notification
1. reduced logging clutter
1. added enum for machine type
    - exit when vm type is not mobility

_BugFix: removed extra fields from response_

1. removed dashboardUsers, orders from vending machine entity
1. VM id migration to Long

__Date: 2020-07-22__  
_BugFix: completed API changes_

1. simplified order complete api
1. better error handling
1. some housekeeping

__Date: 2020-07-21__  
_BugFix: exposing more APIs_

1. removed auth from all attendance APIs
1. removed auth form all ticketing APIs

__Date: 2020-07-20__  
_BugFix: fixing issues found in RC_

1. removed auth from attendance APIs
1. fixed the jwt token check for dashboard token
1. fixed user - role relationship
1. added created/updated timestamp for tokens

__Date: 2020-07-18__  
_New API for order complete_

1. added new api for order complete `order/complete`
    - moved line item details inside line item
1. removed auth from delivery completed `order/delivery/completed`
1. simplified authentication mechanism

__Date: 2020-07-17__  
_FCM token create/update API_

1. added fcm create / update logic
1. improvements to exception handler
1. better error messages in logs
1. fixed duplicate token creation on update
1. added firebase admin sdk for partner app
1. populating and sending order complete data in  notification

__Date: 2020-07-16__  
_Changes to auth layer_

1. dto for user details and granted authorities
1. moved around some service classes
1. added fcm token update controller 

__Date: 2020-07-11__  
_Added authentication layer_

1. added authentication layer skeleton
1. changes to dashboard user <==> permission mapping

__Date: 2020-07-08__  
_Multicast notification and config enhancements_

1. multicast support for notifications
1. logging improvements
1. consolidated application properties

__Date: 2020-07-07__  
_Fixed stack overflow issue, firebase config_

1. added error handler for activemq
1. added entity repositories
1. added @JsonIgnore and toString() to avoid infinite loop
1. firebase initializer bean
1. firebase config, segregated

__Date: 2020-07-06__  
_Database layer and FCM sdk_

1. added sdk for firebase
1. added required entities
1. some housekeeping

__Date: 2020-07-04__  
_Data format conversion on retrieval_

1. simplified dynamic config for activemq
1. OrderStateChange for message encapsulation
1. file logging for dev profile

__Date: 2020-07-03__  
_Groundwork for activemq subscriber_

1. added basic code to consume activemq messages
1. dynamic activemq config
1. general housekeeping

[Feature - Delivery](#delivery)
__Date: 2020-06-30__  
_Vend/Fulfil implementation_

1. Entity for getting order from database
1. Added user token generation support for kiosk 
1. Implementation for Vend order
1. Implementation for Fulfil order
1. Generalized api properties by using env vars

__Date: 2020-06-29__  
_Delivery APIs_

1. Wrapper for vend / fulfilment api
1. Changed the name from to dc-partner

[Feature](#ticketing)
__Date: 2020-05-20__  
_Ticket feature implementation_

1. Ticketing feature

[General](#general)
__Date: 2020-05-20__  
_Added changelog_

1. changelog
