package in.co.daalchini.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.co.daalchini.models.*;
import in.co.daalchini.repository.EntityAttributesRepository;
import in.co.daalchini.repository.LocationCaptureActivityRepository;
import in.co.daalchini.repository.VendingMachineAddressRepository;
import in.co.daalchini.repository.VendingMachineRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Slf4j
@AutoConfigureMockMvc
@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
public class WarehouseControllerIT {
    @Autowired
    LocationCaptureActivityRepository locationCaptureActivityRepository;
    @Autowired
    VendingMachineRepository vendingMachineRepository;
    @Autowired
    EntityAttributesRepository entityAttributesRepository;
    @Autowired
    VendingMachineAddressRepository vendingMachineAddressRepository;

    @Autowired
    private WebApplicationContext wac;
    private MockMvc mockMvc;
    private ObjectMapper objectMapper;
    Map responseMap=new HashMap();

    @BeforeAll
    public void setup () {
        mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
        objectMapper=new ObjectMapper();

    }

    @Test
    public void get_All_Warehouses_Fails_On_Null_Values () throws Exception {

        String content=mockMvc.perform(get("/api/v1/attendence/warehouse/2/null/null")

        ).andDo(print()).andExpect(status().isBadRequest()).andReturn().getResponse().getContentAsString();

        responseMap=objectMapper.readValue(content,Map.class);
        assertThat(responseMap.get("status")).isNotNull().isEqualTo("Failure");
        assertThat(responseMap.get("message")).isNotNull().isEqualTo("Bad Request");

    }

    @Test
    public void get_All_Manufactures_Fails_On_Null_Values () throws Exception {
        String content=mockMvc.perform(get("/api/v1/attendence/manufactures/50/null/null")

        ).andDo(print()).andExpect(status().isBadRequest()).andReturn().getResponse().getContentAsString();

        responseMap=objectMapper.readValue(content,Map.class);
        assertThat(responseMap.get("status")).isNotNull().isEqualTo("Failure");
        assertThat(responseMap.get("message")).isNotNull().isEqualTo("Bad Request");
    }

    @Test
    public void get_All_Vending_Machines_Fails_On_Null_Values () throws Exception {
       String content= mockMvc.perform(get("/api/v1/attendence/vendingmachine/5/null/null")

       ).andDo(print()).andExpect(status().isBadRequest()).andReturn().getResponse().getContentAsString();

        responseMap=objectMapper.readValue(content,Map.class);
        assertThat(responseMap.get("status")).isNotNull().isEqualTo("Failure");
        assertThat(responseMap.get("message")).isNotNull().isEqualTo("Bad Request");
    }

    @Test
    public void get_User_Last_Check_in_Status_Fails_On_Dashboard_User_Id_Not_Found () throws Exception {
      String content=  mockMvc.perform(get("/api/v1/attendence/user/last-checkin/564")

      ).andDo(print()).andExpect(status().isNotFound()).andReturn().getResponse().getContentAsString();

      responseMap=objectMapper.readValue(content,Map.class);
      assertThat(responseMap.get("status")).isNotNull().isEqualTo("Failure");
      assertThat(responseMap.get("message")).isNotNull().isEqualTo("User not found");

    }

    @Test
    public void get_User_Activities_Fails_On_Dashboard_User_Id_Not_Found () throws Exception {
        String content =mockMvc.perform(get("/api/v1/attendence/user/activities/560")

        ).andDo(print()).andExpect(status().isNotFound()).andReturn().getResponse().getContentAsString();

        responseMap=objectMapper.readValue(content,Map.class);
        assertThat(responseMap.get("status")).isNotNull().isEqualTo("Failure");
        assertThat(responseMap.get("message")).isNotNull().isEqualTo("User not found");
    }

    @Test
    public void location_Details_Vm_Fails_On_Vm_lat_And_lng_as_null () throws Exception {
        locationCaptureActivityRepository.save(
            DummyLocationCaptureActivityModel.builder().build().toActual());
        VendingMachineAddress vendingMachineAddress =
            vendingMachineAddressRepository.save(DummyVendingMachineAddress.builder().build().toActual());
        vendingMachineRepository.save(
            DummyVendingMachine.builder().address(vendingMachineAddress).build().toActual());
        entityAttributesRepository.save(
            DummyEntityAttributeModel.builder().build().toActual());

        String content = mockMvc
            .perform(
                post("/api/v1/attendence/location-details-vm/1")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(
                        "{\"dashboard_user_id\":1,\"location_type\":1,\"condition_value\":20,\"df_lat\":28.5843,\"df_lng\":77.3185}")
                    )
            .andDo(print())
            .andExpect(status().isNotFound())
            .andReturn()
            .getResponse()
            .getContentAsString();

        responseMap = objectMapper.readValue(content, Map.class);
        assertThat(responseMap.get("status")).isNotNull().isEqualTo("Failure");
        assertThat(responseMap.get("message")).isNotNull().isEqualTo("data missing");

    }


}
