package in.co.daalchini.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@Configuration
@EnableAsync
public class AsyncConfig {

    @Bean(name = "fulfilOrder")
    public Executor fulfilOrder () {
        return Executors.newCachedThreadPool();
    }

    @Bean(name = "fulfilPartnerOrder")
    public Executor fulfilPartnerOrder () {
        return Executors.newCachedThreadPool();
    }

    @Bean(name = "initiatePayment")
    public Executor initiatePayment () {
        return Executors.newCachedThreadPool();
    }

    @Bean(name = "performRefill")
    public Executor performRefill () {
        return Executors.newCachedThreadPool();
    }
}
