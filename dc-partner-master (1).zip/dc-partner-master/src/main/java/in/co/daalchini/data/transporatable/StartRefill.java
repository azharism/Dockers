package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

public final class StartRefill {

    @Data
    @Builder
    public static final class Request {
        private Long vmId;
        @Default private Long kitId = null;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Response {
        public Long kitId;
        public Long kitRefillId;
    }
}
