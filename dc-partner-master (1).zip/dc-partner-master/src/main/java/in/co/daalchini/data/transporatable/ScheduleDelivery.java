package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class ScheduleDelivery {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Request {

        @Positive(message = "Invalid userAddressId")
        @NotEmpty(message = "Address id missing")
        private Long userAddressId;

        @NotEmpty(message = "Delivery date cannot be empty")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime deliveryDateEnd;
    }

}
