package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum VmImagePlatform {
    ConsumerApp("consumerApp"),
    Kiosk("kiosk");

    private final @JsonValue String value;

    VmImagePlatform (String value) {this.value = value;}

    @JsonCreator(mode = Mode.DELEGATING)
    public static VmImagePlatform of (String value) {
        return Arrays.stream(VmImagePlatform.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }
}
