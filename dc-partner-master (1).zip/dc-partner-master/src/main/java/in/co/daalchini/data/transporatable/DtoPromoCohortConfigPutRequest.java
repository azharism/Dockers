package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

@Data
@JsonIncludeProperties({"initial_delay_sec", "refresh_interval_sec", "default_promo_duration_sec"})
public class DtoPromoCohortConfigPutRequest {

    @NotNull
    @Positive
    @JsonProperty("initial_delay_sec")
    private String initialDelaySec;

    @NotNull
    @Positive
    @JsonProperty("refresh_interval_sec")
    private String refreshIntervalSec;

    @Positive
    @JsonProperty("default_promo_duration_sec")
    private String defaultPromoDurationSec;
}
