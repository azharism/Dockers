package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApproveUnlink {
    private String ucmId;

    @JsonIgnore
    private Long createdBy;

    private Long updateAt;


}
