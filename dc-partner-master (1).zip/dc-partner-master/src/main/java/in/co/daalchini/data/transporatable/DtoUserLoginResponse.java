package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.service.jwt.JwtService;
import lombok.Builder;
import lombok.Data;

import java.util.Collection;

@Data
@Builder
@JsonIncludeProperties({"user_id", "access_token", "role_id", "role_name", "permissions"})
public final class DtoUserLoginResponse {

    @JsonProperty("user_id")
    private Long userId;

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("role_id")
    private Integer roleId;

    @JsonProperty("role_name")
    private String roleName;

    @JsonProperty("permissions")
    private Collection<String> permissions;

    public static DtoUserLoginResponse of(JwtService.JwTokenData tokenData) {
        return DtoUserLoginResponse
                .builder()
                .accessToken(tokenData.token())
                .userId(tokenData.userId())
                .roleId(tokenData.roleId())
                .roleName(tokenData.roleName())
                .permissions(tokenData.permissions())
                .build();
    }
}
