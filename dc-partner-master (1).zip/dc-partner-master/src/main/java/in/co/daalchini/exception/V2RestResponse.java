package in.co.daalchini.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class V2RestResponse<T> {
    private Status status;
    private T data;

    public static <T> V2RestResponse<T> ofSuccess (T body) {
        return new V2RestResponse<T>(Status.ofSuccess("Success"), body);
    }

    public static <T> V2RestResponse<T> ofSuccess (T body, String message) {
        return new V2RestResponse<T>(Status.ofSuccess(message), body);
    }

    public static <T> V2RestResponse<T> ofFailure (String code, String message) {
        return new V2RestResponse<T>(Status.ofFailure(code, message), null);
    }

    public static <T> V2RestResponse<T> ofFailure (String code, String message, T body) {
        return new V2RestResponse<T>(Status.ofFailure(code, message), body);
    }
}
