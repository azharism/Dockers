package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.models.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.data.domain.Page;

import java.util.*;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface MachineMapper {

    @Mapping(target = "operationalStatus", source = "operationalStatus.name")
    DtoMachineSummary toSummary(VendingMachine machine);

    List<DtoMachineSummary> toSummary(Page<VendingMachine> machines);

    List<DtoMachineSummary> toSummary(List<VendingMachine> machines);

    @Mapping(target = "operationalStatus", source = "operationalStatus.name")
    @Mapping(target = "keys", source = "machineKey")
    @Mapping(target = "slots", source = "items")
    @Mapping(target = "cohorts", source = "cohorts")
    @Mapping(target = "hardwareType", source = "hardwareType.name")
    @Mapping(target = "machineType", source = "machineType.type")
    @Mapping(target = "appVersion", source = "machineStatus.appVersion")
    @Mapping(target = "address.latitude", source = "address.lat")
    @Mapping(target = "address.longitude", source = "address.lng")
    @Mapping(target = "address.imagePath", source = "address.imageId")
    @Mapping(target = "address.locationName", source = "address.locationType.name")
    @Mapping(target = "corporate.id", source = "corporateMachine.corporateDetails.id")
    @Mapping(target = "corporate.name", source = "corporateMachine.corporateDetails.name")
    @Mapping(target = "cartLimit", source = "machineCartLimit.cartLimit")
    DtoMachineDetails toDetails(VendingMachine machine);

    default List<DtoCohort> mapCohorts(Set<MachineCohort> cohorts) {
        return cohorts
                .stream()
                .map(this::toDto)
                .sorted(Comparator.comparingInt(DtoCohort::getId))
                .collect(Collectors.toList());
    }

    default List<DtoMachineSlot> mapSlots(Set<MachineAvailableItem> items) {
        return items
                .stream()
                .map(this::toDto)
                .filter(DtoMachineSlot::isActive)
                .sorted(Comparator.comparingLong(DtoMachineSlot::getSlotId))
                .collect(Collectors.toList());
    }

    @Mapping(target = "id", source = "vendingMachine.id")
    @Mapping(target = "name", source = "vendingMachine.name")
    @Mapping(target = "sharePercentage", source = "vendingMachine.sharePercentage")
    @Mapping(target = "operationalStatus", constant = "Draft")
    @Mapping(target = "hardwareType", source = "hardwareType.name")
    @Mapping(target = "machineType", source = "machineType.type")
    @Mapping(target = "address", source = "machineAddress")
    @Mapping(target = "paymentConfigs", source = "paymentConfigs")
    @Mapping(target = "warehouse", source = "warehouse")
    @Mapping(target = "cohorts", source = "cohorts")
    @Mapping(target = "keys", source = "newMachineKey")
    @Mapping(target = "cartLimit", source = "newCartLimit.cartLimit")
    @Mapping(target = "slots", source = "machineSlots")
    @Mapping(target = "corporate.id", source = "corporateMachine.corporateDetails.id")
    @Mapping(target = "corporate.name", source = "corporateMachine.corporateDetails.name")
    DtoMachineDetails toDetails(
            VendingMachine vendingMachine,
            VendingMachineAddress machineAddress,
            Warehouse warehouse,
            CorporateMachine corporateMachine,
            MachineHardwareType hardwareType,
            MachineType machineType,
            MachineKey newMachineKey,
            MachineCartLimit newCartLimit, Collection<MachineCohort> cohorts,
            Collection<MachinePaymentConfig> paymentConfigs,
            Collection<DtoMachineSlot> machineSlots);

    @Mapping(target = "imagePath", source = "imageId")
    @Mapping(target = "latitude", source = "lat")
    @Mapping(target = "longitude", source = "lng")
    DtoMachineAddress toDto(VendingMachineAddress address);

    @Mapping(target = "boardId", source = "remoteBoardId")
    @Mapping(target = "bluetoothId", source = "remoteBluetoothId")
    @Mapping(target = "comId", source = "remoteComId")
    @Mapping(target = "deviceId", source = "remoteDeviceId")
    DtoMachineKeys toDto(MachineKey key);

    @Mapping(target = "type", source = "cohortType.name")
    DtoCohort toDto(MachineCohort cohort);

    @Mapping(target = "id", source = "configId")
    DtoPaymentConfig toDto(MachinePaymentConfig paymentConfig);

    DtoMachineSlot toDto(MachineAvailableItem item);

    Set<DtoMachineSlot> toDto(Collection<MachineAvailableItem> items);

    DtoWarehouse toDto(Warehouse warehouse);

    @Mapping(target = "slotId", source = "slotIdentifier")
    @Mapping(target = "capacity", source = "slotCapacity")
    @Mapping(target = "mvId", source = "manufacturerVariantId")
    DtoMachineSlot toDto(MachineManufacturerVariant variant);

    @Mapping(target = "address", ignore = true)
    @Mapping(target = "operationalStatusId", constant = "-1")
    VendingMachine toMachine(DtoMachineCreateRequest request, Long addressId);

    @Mapping(target = "createdBy", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "vendingMachineHealthDetailsId", ignore = true)
    @Mapping(target = "vmType", ignore = true)
    @Mapping(target = "address", ignore = true)
    @Mapping(target = "warehouse", ignore = true)
    @Mapping(target = "hardwareType", ignore = true)
    @Mapping(target = "machineType", ignore = true)
    @Mapping(target = "operationalStatus", ignore = true)
    @Mapping(target = "dashboardUsers", ignore = true)
    @Mapping(target = "cohorts", ignore = true)
    @Mapping(target = "orders", ignore = true)
    @Mapping(target = "paymentConfigs", ignore = true)
    @Mapping(target = "machineKey", ignore = true)
    @Mapping(target = "machineStatus", ignore = true)
    @Mapping(target = "items", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "operationalStatusId", constant = "-1")
    @Mapping(target = "name", source = "request.name")
    @Mapping(target = "addressId", source = "addressId")
    VendingMachine toMachine(DtoMachineCloneRequest request, VendingMachine sourceMachine, Long addressId);

    @Mapping(target = "imageId", source = "imagePath")
    @Mapping(target = "lat", source = "latitude")
    @Mapping(target = "lng", source = "longitude")
    VendingMachineAddress toAddress(DtoMachineAddress address);

    @Mapping(target = "activeQuantity", constant = "0")
    @Mapping(target = "holdQuantity", constant = "0")
    @Mapping(target = "slotIdentifier", source = "slot.slotId")
    @Mapping(target = "slotCapacity", source = "slot.capacity")
    @Mapping(target = "manufacturerVariantId", source = "slot.mvId")
    @Mapping(target = "vendingMachineId", source = "machineId")
    MachineManufacturerVariant toMachineMv(DtoMachineSlot slot, Long machineId);

    @Mapping(target = "activeCount", constant = "0L")
    @Mapping(target = "holdCount", constant = "0L")
    @Mapping(target = "expiryCount", constant = "0L")
    @Mapping(target = "isActive", constant = "true")
    @Mapping(target = "skuGroupId", source = "mvId")
    @Mapping(target = "machineManufacturerVariantId", source = "machineMvId")
    MachineManufacturerVariantSkuGroup toMachineMvSku(Long mvId, Long machineMvId);

    List<DtoMachineSlot> toDtoMachineSlots(List<MachineAvailableItem> item);

    Collection<DtoMachineSlot> toMachineSlots(Set<MachineAvailableItem> items);

    default Collection<DtoMachineTray> toMachineTrays(Set<MachineAvailableItem> items) {
        var machineSlots = toMachineSlots(items);
        var slotTrayMap = machineSlots.stream().sorted().collect(Collectors.groupingBy(x -> x.getSlotId() / 100));
        var maxLevel = slotTrayMap.keySet().stream().mapToLong(x -> x).max().orElse(0L);

        var machineTrays = new TreeSet<DtoMachineTray>();
        for (var i = 1L; i <= maxLevel; i++) {
            var slots = slotTrayMap.getOrDefault(i, Collections.emptyList());
            machineTrays.add(DtoMachineTray
                    .builder()
                    .level(i)
                    .slots(slotTrayMap.getOrDefault(i, Collections.emptyList()))
                    .build());
        }

        return machineTrays;
    }
}
