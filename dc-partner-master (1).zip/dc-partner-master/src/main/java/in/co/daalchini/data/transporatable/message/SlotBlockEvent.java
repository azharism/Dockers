package in.co.daalchini.data.transporatable.message;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SlotBlockEvent {
    private static final ObjectMapper mapper = new ObjectMapper();

    private final Long slotId;
    private final Long vmId;
    private final String productName;
    private final String imageId;
    private final Boolean isBlocked;

    @Builder
    @JsonCreator
    public SlotBlockEvent(
            @JsonProperty("slotId") final Long slotId,
            @JsonProperty("vmId") final Long vmId,
            @JsonProperty("productName") final String productName,
            @JsonProperty("imageId") final String imageId,
            @JsonProperty("isBlocked") final Boolean isBlocked)
    {
        this.slotId = slotId;
        this.vmId = vmId;
        this.productName=productName;
        this.imageId=imageId;
        this.isBlocked = isBlocked;
    }

    public String json () {
        String jsonString;
        try {
            jsonString = mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            jsonString = String.format(
                    "{\"slotId\":\"%s\",\"vmId\":\"%s\",\"isBlocked\":\"%s\",\"productName\":\"%s\",\"imageId\":%.2f}",
                    this.slotId,
                    this.vmId,
                    this.isBlocked,
                    this.productName,
                    this.imageId
            );
        }
        return jsonString;
    }
}
