package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.TagContext;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.TagInfo.Request;
import in.co.daalchini.data.transporatable.TagInfo.Response;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.http.RfidCardService;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Collection;
import java.util.Set;

@Log4j2
@Validated
@RestController
public class TagRoute {

    private final RfidCardService rfidCardService;

    public TagRoute(RfidCardService rfidCardService) {
        this.rfidCardService = rfidCardService;
    }

    @PreAuthorize("hasAnyAuthority('view_tag','tag:read','tag:modify','tag:all')")
    @GetMapping(TagContext.TAG_SEARCH)
    public TagSearch.Response searchTag(
            @RequestParam("qrData") String token
    ) {
        log.info("[searchTag] request, qrData = {}", token);
        TagSearch.Response response;
        try {
            response = rfidCardService.searchTagByToken(token);
        } catch (RuntimeException e) {
            log.warn("[searchTag] error", e);
            throw e;
        }

        log.info("[searchTag] response = {}", response);
        return response;
    }

    @PreAuthorize("hasAnyAuthority('view_tag','tag:read','tag:modify','tag:all')")
    @GetMapping(TagContext.TAG_WITH_ID)
    public Response fetchTagInfo(
            @PathVariable String tagId
    ) {
        log.info("[fetchTagInfo] request, tagId = {}", tagId);
        Response response;
        try {
            response = rfidCardService.fetchTagInfo(tagId);
        } catch (RuntimeException e) {
            log.warn("[fetchTagInfo] error", e);
            throw e;
        }

        log.info("[fetchTagInfo] response = {}", response);
        return response;
    }

    @PreAuthorize("hasAnyAuthority('activate_tag','tag:modify','tag:all')")
    @PatchMapping(TagContext.TAG_WITH_ID)
    public Response updateTagInfo(
            @PathVariable String tagId,
            @RequestBody Request request
    ) {
        log.info("[updateTagInfo] request, tagId = {}, request = {}", tagId, request);
        Response response;
        try {
            response = rfidCardService.updateTagInfo(tagId, request);
        } catch (RuntimeException e) {
            log.warn("[updateTagInfo] error", e);
            throw e;
        }

        log.info("[updateTagInfo] response = {}", response);
        return response;
    }

    @PreAuthorize("hasAnyAuthority('tag:read','tag:modify','tag:all')")
    @GetMapping(TagContext.TAG_SERIES)
    public RestResponseV2<Collection<CorporateTagSeries.Corporate>> fetchUserTagSeries(
            @AuthenticationPrincipal AuthUserDetails userDetails
    ) {
        var userId = userDetails.getUserId();
        var isAdmin = userDetails.hasPermission("tag:all");
        log.info("[fetchUserCorporates] userId={}, isAdmin={}", userId, isAdmin);
        try {
            Collection<CorporateTagSeries.Corporate> responses = rfidCardService.fetchCorporateCardSeries(userId, isAdmin);
            log.info("[fetchUserTagSeries] response :{}", responses);
            return RestResponseV2.ofSuccess(responses);
        } catch (Exception e) {
            log.warn("[fetchUserTagSeries] Error: ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAnyAuthority('tag:all')")
    @PostMapping(TagContext.TAG_SERIES)
    public RestResponseV2<CorporateTagSeries.CorporateSeriesSummary> createUserTagSeries(
            @Valid @RequestBody CreateTagSeriesRequest request
    ) {
        log.info("[createUserTagSeries] request={}", request);
        try {
            var response = rfidCardService.createCorporateCardSeries(request);
            log.info("[createUserTagSeries] response :{}", response);
            return RestResponseV2.ofSuccess(response);
        } catch (Exception e) {
            log.warn("[createUserTagSeries] Error: ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAnyAuthority('tag:modify','tag:all')")
    @PatchMapping(TagContext.TAG_SERIES_ID)
    public RestResponseV2<CorporateTagSeries.CorporateSeriesSummary> updateUserTagSeries(
            @Valid @RequestBody UpdateTagSeriesRequest request,
            @PathVariable Long seriesId
    ) {
        log.info("[updateUserTagSeries] seriesId={}, request={}", seriesId, request);
        try {
            var response = rfidCardService.updateCorporateCardSeries(seriesId, request);
            log.info("[updateUserTagSeries] response :{}", response);
            return RestResponseV2.ofSuccess(response);
        } catch (Exception e) {
            log.warn("[updateUserTagSeries] Error: ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAnyAuthority('tag:read','tag:modify','tag:all')")
    @GetMapping(TagContext.TAG_SERIES_ID_TAG)
    public RestResponseV2<Collection<CorporateTag.Summary>> fetchSeriesTags(
            @PathVariable Long seriesId
    ) {
        log.info("[fetchSeriesTags] seriesId={}", seriesId);
        try {
            var response = rfidCardService.fetchSeriesTags(seriesId);
            log.info("[fetchSeriesTags] response :{}", response);
            return RestResponseV2.ofSuccess(response);
        } catch (Exception e) {
            log.warn("[fetchSeriesTags] Error: ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAnyAuthority('tag:all')")
    @PostMapping(TagContext.TAG_SERIES_ID_TAG_BULK)
    public RestResponseV2<Collection<CorporateTag.Summary>> createSeriesTagBulk(
            @PathVariable(value = "seriesId") Long seriesId,
            @RequestBody @Size(min = 1, max = 50, message = "request size must be between 1 and 50")
            Collection<@Valid CreateTagRequest> requests
    ) {
        log.info("[createSeriesTagBulk] seriesId={}, requests={}", seriesId, requests);
        try {
            var response = rfidCardService.createSeriesTagBulk(seriesId, requests);
            log.info("[createSeriesTagBulk] response :{}", response);
            return RestResponseV2.ofSuccess(response);
        } catch (Exception e) {
            log.warn("[createSeriesTagBulk] Error: ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAnyAuthority('tag:modify','tag:all')")
    @PutMapping(TagContext.TAG_SERIES_ID_TAG_BULK)
    public RestResponseV2<Collection<CorporateTag.Summary>> activateSeriesTagBulk(
            @PathVariable(value = "seriesId") Long seriesId,
            @RequestBody
            @Size(min = 1, max = 50, message = "request size must be between 1 and 50")
            Set<@Pattern(regexp = "^[0-9]{10}$", message = "invalid uid") String> uids
    ) {
        log.info("[activateSeriesTagBulk] seriesId={}, uids={}", seriesId, uids);
        try {
            var response = rfidCardService.activateSeriesTagBulk(seriesId, uids);
            log.info("[activateSeriesTagBulk] response :{}", response);
            return RestResponseV2.ofSuccess(response);
        } catch (Exception e) {
            log.warn("[activateSeriesTagBulk] Error: ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAnyAuthority('tag:modify','tag:all')")
    @PostMapping(TagContext.TAG_SERIES_ID_TAG_BULK_RECHARGE)
    public RestResponseV2<Collection<CorporateTag.Summary>> rechargeSeriesTagBulk(
            @PathVariable(value = "seriesId") Long seriesId,
            @Valid @RequestBody RechargeTagRequest request
    ) {
        log.info("[rechargeSeriesTagBulk] seriesId={}, request={}", seriesId, request);
        try {
            var response = rfidCardService.rechargeSeriesTagBulk(seriesId, request);
            log.info("[rechargeSeriesTagBulk] response :{}", response);
            return RestResponseV2.ofSuccess(response);
        } catch (Exception e) {
            log.warn("[rechargeSeriesTagBulk] Error: ", e);
            throw e;
        }
    }


}
