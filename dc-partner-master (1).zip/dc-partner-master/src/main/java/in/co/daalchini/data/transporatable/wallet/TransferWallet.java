package in.co.daalchini.data.transporatable.wallet;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.constants.enums.TransactionType;
import lombok.*;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public final class TransferWallet {

    @Getter
    @Setter
    @Builder
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Request {

        @NotNull(message = "sourceWallet is missing")
        private SourceWallet sourceWallet;

        @NotNull(message = "transferOrder is missing")
        private TransferOrder transferOrder;

        @Size(min = 3, max = 250, message = "reason must be between 3 and 250 characters")
        private String reason;

        private String transactionType;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Response {
        private String orderId;
        private Long transactionId;
        private Double balance;
    }

}
