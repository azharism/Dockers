package in.co.daalchini.data.untransportable;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum VMType {
    Food(1L),
    Stationary(2L),
    Mobility(3L),
    FoodResidence(4L),
    Test(5L),
    eDaalchini(6L),
    WastageExpiry(7L),
    Warehouse(8L);

    private final @JsonValue Long value;

    VMType (Long value) {
        this.value = value;
    }

    @JsonCreator
    public static VMType of (Long value) {
        return Stream.of(VMType.values())
                     .filter(x -> x.value.equals(value))
                     .findFirst()
                     .orElse(null);
    }

    public static VMType of (String value) {
        return Stream.of(VMType.values())
                     .filter(x -> x.name().equals(value))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return this.name();
    }
}
