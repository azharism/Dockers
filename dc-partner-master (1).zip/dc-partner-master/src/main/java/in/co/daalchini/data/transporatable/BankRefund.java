package in.co.daalchini.data.transporatable;

import in.co.daalchini.data.constants.enums.OperationType;
import in.co.daalchini.data.untransportable.PaymentGatewayType;
import lombok.*;
import javax.validation.constraints.*;
import java.util.List;

public class BankRefund {

    @Data
    @Builder
    public static final class Request {
        @NotNull(message = "cannot be null ")
        private PaymentGatewayType pgName;
        @NotNull(message = "orderId cannot be null")
        private String orderId;
        @Min(value = 1, message = "Partial Refund under Rupee 1 is not allowed")
        @NotNull(message = "cannot be null ")
        private Double refundAmount;
        private String reason;
    }

    @Data
    @Builder
    public static final class Response {
        private PaymentGatewayType pgName;
        private OperationType operationType;
        private String orderId;
        private Double refundAmount;
        private String transactionId;
        private String reason;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static final class RefundStatusResponse {
    private String orderId;
    private PaymentGatewayType pgName;
    private List<RefundDetailInfo> refundDetailInfoList;
    private String refundAmount;
    private String resultStatus;
    private String resultCode;
    private String resultMsg;
    private String refundStatus;

    }
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public static class RefundDetailInfo {
    private String refundType;
    private String payMethod;
    private String userCreditExpectedDate;
    private String refundAmount;
}
}
