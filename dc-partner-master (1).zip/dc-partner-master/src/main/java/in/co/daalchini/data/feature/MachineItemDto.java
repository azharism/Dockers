package in.co.daalchini.data.feature;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Tuple;
import javax.validation.Valid;
import javax.validation.constraints.*;
import java.math.BigInteger;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;

public class MachineItemDto {

    public record ItemPlacement(
            Long machineId,
            String machineName,
            Integer activeCount,
            Collection<ItemPlacementSlot> slots
    ) {

        public static ItemPlacement of(Long machineId, String machineName) {
            return new ItemPlacement(machineId, machineName, 0, new ArrayList<>());
        }

        public ItemPlacement addSlot(ItemPlacementSlot slot) {
            if (null != slot.slotId && slot.slotId() > 0) slots.add(slot);

            return new ItemPlacement(machineId, machineName, activeCount + slot.activeCount(), slots);
        }
    }

    public record ItemPlacementSlot(
            Integer slotId,
            Integer activeCount
    ) {
    }

    public record MachineItemSlotInfo(
            Long machineId,
            Integer slotId,
            Integer activeCount
    ) {
        public static MachineItemSlotInfo of(Tuple t) {
            return new MachineItemSlotInfo(
                    t.get("machine_id", BigInteger.class).longValue(),
                    t.get("slot_id", BigInteger.class).intValue(),
                    t.get("active_count", BigInteger.class).intValue()
            );
        }
    }

    @JsonIncludeProperties({"expire_at", "machines"})
    public record MvExpireRequest(

            @NotNull
            @JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Kolkata")
            @JsonProperty("expire_at")
            Instant expireAt,

            @NotNull
            @NotEmpty
            @JsonProperty("machines")
            Collection<@Valid ExpireMvMachine> machines
    ) {
    }

    @JsonIncludeProperties({"machine_id", "slot_ids"})
    public record ExpireMvMachine(

            @NotNull
            @Positive
            @JsonProperty("machine_id")
            Long machineId,

            @NotNull
            @JsonProperty("slot_ids")
            Collection<@Valid @Min(100) @Max(999) Integer> slotIds
    ) {
        public String slotIdStrArr() {
            return slotIds.stream().map(String::valueOf).collect(Collectors.joining(","));
        }
    }


    @JsonIncludeProperties({"id", "user_id", "mv_id", "machine_id", "slot_ids"})
    public record MvExpireEvent(

            @JsonProperty("id")
            Long id,

            @JsonProperty("user_id")
            Long userId,

            @JsonProperty("mv_id")
            Long mvId,

            @JsonProperty("machine_id")
            Long machineId,

            @JsonProperty("slot_ids")
            Collection<Integer> slotIds
    ) {
    }
}
