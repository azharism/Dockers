package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum RfidCardType {

    User("user"),
    Corporate("corporate");

    private final @JsonValue String value;

    RfidCardType (String value) {
        this.value = value;
    }

    @JsonCreator
    public static RfidCardType of (String value) {
        return Stream.of(RfidCardType.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }
}
