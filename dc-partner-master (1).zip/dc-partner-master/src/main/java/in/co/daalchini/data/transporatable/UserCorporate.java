package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

public class UserCorporate {

    @Data
    @Builder
    public static final class Response{
        private Long corporateId;
        private String corporateName;
    }
}
