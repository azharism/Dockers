package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vm_cohort_promo_configurations")
@EntityListeners(AuditingEntityListener.class)
public class PromoCohortConfig {

    @Id
    @Column(name = "cohort_id")
    private Long id;

    @MapsId
    @OneToOne
    @JoinColumn(name = "cohort_id")
    private MachineCohort cohort;

    @Column(name = "initial_delay_sec")
    private Integer initialDelaySec;

    @Column(name = "refresh_interval_sec")
    private Integer refreshIntervalSec;

    @Column(name = "default_promo_duration_sec")
    private Integer defaultPromoDurationSec;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public PromoCohortConfig withCohort(MachineCohort cohort) {
        this.cohort = cohort;
        cohort.setPromoCohortConfig(this);

        return this;
    }
}
