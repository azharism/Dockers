package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum RefillSuggestionSortBy {
    OccupancyRatio("occupancy_ratio"),
    EmptySlots("empty_slots"),
    Sales("sales"),
    LastRefill("last_refill");

    public final @JsonValue String value;

    RefillSuggestionSortBy(String value){this.value = value;}

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static RefillSuggestionSortBy of (String value) {
        return Arrays.stream(RefillSuggestionSortBy.values())
                .filter(x -> x.value.equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }
}
