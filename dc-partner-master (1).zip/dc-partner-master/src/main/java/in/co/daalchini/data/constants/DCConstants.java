package in.co.daalchini.data.constants;

import java.util.regex.Pattern;

public class DCConstants {
	
	public static final String API_SUCCESS="SUCCESS";
	public static final String API_SUCCESS_CODE="SS_0001";
	public static final String API_SUCCESS_MESSAGE="API Returned Successful Result";
	public static final String API_SUCCESS_NULL_RESPONSE_MESSAGE="API Returned NULL Result";

	public static final String API_FAILURE="FAILURE";
	public static final String API_FAILURE_CODE_NULL_REQUEST="F_0004A";
	public static final String API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST="F_0004B";//for example giving month = 15;
	public static final String API_FAILURE_CODE_OTHER="F_0004";
	public static final String API_FAILURE_AUTHORIZATION_MESSAGE="Token Authorization FAILURE";
	public static final String API_FAILURE_JWT_AUTHORIZATION_MESSAGE="JWT DECODE FAILURE : Invalid oauthToken";
	public static final String API_FAILURE_AUTHORIZATION_CODE="401";

	public static final String OAUTH_TOKEN ="x-auth-token";
	public static final String VM_TOKEN ="token";
	public static final String USER_KEY ="userKey";

	public static final String X_TRACE_ID = "x-amzn-trace-id";
	
	public static final String KEYSTORE_FILE_LOC = "/home/sanji/work";
	public static final String DC_HEADER_USER_KEY="USER";
	public static final String VM_ID ="vmId";
	public static final String VM_KEY ="vmKey"; 
	public static final String VENDING_MACHINE_ID ="VENDING_MACHINE_ID";	
	public static final String USER ="USER";
	
	public static final String SECRET_KEY = "alongrandomsecret007001890";
	public static final Integer DC_CODE_LENGTH = 4;
	public static final long RECHARGE_MV_SKG_ID = -1L;

	public static final String WALLET_SUB_OWNER_PARTNER = "partner";
	public static final String DASHBOARD_AUTH_TOKEN = "x-auth-token";

	public static final String UPLOAD_FILE_NAME = "file";
	public static final Integer UPLOAD_FILE_COLUMN_NOS = 6;
	public static final String DEFAULT_UPLOAD_STATUS = "0";
	public static final Pattern VALID_EMAIL_ADDRESS_REGEX =
			Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
}
