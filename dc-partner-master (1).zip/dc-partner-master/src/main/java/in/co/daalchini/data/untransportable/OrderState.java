package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum OrderState {

    CREATED("created"),
    PLACED("placed"),
    COMPLETED("completed"),
    CANCELLED("cancelled"),
    PRE_PLACED("PRE_PLACED"),
    FAILED("FAILED"),
    PARTIALLY_COMPLETED("partially_completed"),
    REFUND_INITIATED("refund_initiated"),
    REFUNDED_BACK("refunded_back");

    private final @JsonValue String status;

    OrderState (String status) {
        this.status = status;
    }

    @JsonCreator
    public static OrderState of (final String statusStr) {
        return Stream.of(OrderState.values())
                     .filter(x -> x.status.equalsIgnoreCase(statusStr))
                     .findFirst()
                     .orElseThrow(IllegalArgumentException::new);
    }

    @Override
    public String toString () {
        return status;
    }
}
