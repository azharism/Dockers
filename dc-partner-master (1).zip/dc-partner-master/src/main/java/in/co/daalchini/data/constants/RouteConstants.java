package in.co.daalchini.data.constants;

public class RouteConstants {
    private static final String ROOT = "/api/v1";
    public static final String ROOT_V2 = "/api/v2";
    public static final String ROOT_V3 = "/api/v3";

    public static final class ContextFilters {
        public static final String[] UNGUARDED_PATTERNS = {
                "/error",
                GeneralContext.PING,
                GeneralContext.WS_ENDPOINT,
                GeneralContext.USER_LOGIN,
                TicketContext.BASE,
                AttendanceContext.BASE,
                OrderContext.DELIVERY_COMPLETE,
                SlotUtilizationContext.BASE,
                ProductPlacementContext.BASE,
                RefillContext.BASE,
                SkuGroupStockContext.BASE,
                VMHealthStatusContext.BASE,
                SkuGroupStockFetchAllContext.BASE,
        };
    }

    public static final String MACHINE_ITEM_BASE = ROOT_V2 + "/machine-item";

    public static final class GeneralContext {
        public static final String PING = "/ping";
        public static final String ROOT = "/";
        public static final String WS_ENDPOINT = "/ws/endpoint";
        public static final String USER_LOGIN = ROOT_V3 + "/login";
    }

    public static final class AttendanceContext {
        public static final String BASE = ROOT + "/attendence";
    }

    public static final class UserContext {
        private static final String BASE = ROOT + "/partner";
        public static final String UPDATE_FCM_TOKEN = BASE + "/token/fcm";
        public static final String PROFILE_ADDRESS = BASE + "/profile/address";
        public static final String SAVE_PROFILE_ADDRESS = PROFILE_ADDRESS + "/save";
        public static final String MACHINE_LIST = BASE + "/machine/list";
        public static final String CURRENT_INVENTORY = BASE + "/inventory/current";
        public static final String MACHINE_INVENTORY_RESTOCK = BASE + "/machine/{vmId}/restock";
        public static final String DRIVER_CHECK_IN = BASE + "/driver/checkin";
        public static final String CHECK_BALANCE_PARTNER = BASE + "/checkBalance";
        public static final String MOBILITY_ORDER_HISTORY = BASE + "/mobility/order/history";
        public static final String DRIVER_CURRENT_MACHINE = BASE + "/driver/current/machine";
        public static final String USER_CHECK_IN_DETAILS = BASE + "/{warehouseId}/timesheet/details";
        public static final String ATTENDANCE_APPROVE = BASE + "/timesheet/approve";
        public static final String USER_TRIP_LOCATIONS = ROOT_V2 + "/user/trips/locations";
        public static final String USER_MMI_DEVICE = ROOT_V2 + "/user/mmi-device-id";
    }
public static  final class VariantContext{
    public static final String VARIANT_SEARCH =ROOT_V2 +"/productSearch/variant";
    public static final String MFID_SEARCH =ROOT_V2 +"/productSearch/variant/{variantId}";
    public static final String CREATE_MFID =ROOT_V2 +"/productSearch/create/mfid";
    public static final String UPDATE_MFID =ROOT_V2 +"/productSearch/update/mfid";
    public static final String CREATE_VENDOR =ROOT_V2 +"/productSearch/create/vendor";
}

    public static final class OrderContext {
        private static final String BASE = ROOT + "/order";
        public static final String DELIVERY_COMPLETE = BASE + "/delivery/completed";
        public static final String ORDER_COMPLETE = BASE + "/complete";
        public static final String ORDER_FULFIL = BASE + "/{orderId}/fulfil";
        public static final String ORDER_PAYMENT = BASE + "/{orderId}/payment";
        public static final String ORDER_SCHEDULE_DELIVERY = BASE + "/{orderId}/schedule/delivery";
        public static final String ORDER_SCHEDULE_PICKUP = BASE + "/{orderId}/schedule/pickup";
        public static final String ORDER_HISTORY = BASE + "/history";
        public static final String ORDER_FETCH_SCHEDULED = BASE + "/scheduled/pickup";
        public static final String FETCH_ORDER_DETAIL = BASE + "/{orderId}";
    }

    public static final class OutletContext {
        private static final String BASE = ROOT + "/outlet";
        public static final String OUTLET_SEARCH = BASE + "/search";
        public static final String OUTLET_INVENTORY = BASE + "/{vmId}/inventory";
        public static final String OUTLET_ORDER_PLACE = BASE + "/{vmId}/order";
    }

    public static final class PaymentContext {
        private static final String BASE = ROOT + "/payment";
        public static final String PAYMENT_HISTORY = BASE + "/{pgId}/history";
        public static final String PAYMENT_RECHARGE = BASE + "/{pgId}/recharge";
        public static final String PAYMENT_RECHARGE_BULK = BASE + "/{pgId}/recharge/bulk";
        public static final String PAYMENT_ONBOARD_BULK = BASE + "/{pgId}/onboard/bulk";
        public static final String PAYMENT_OPTION = BASE + "/option";
    }

    public static final class TicketContext {
        private static final String BASE = ROOT + "/tickets";
        public static final String TYPE = BASE + "/type";
        public static final String SUB_TYPE = BASE + "/sub-type";
        public static final String SUB_SUB_TYPE = BASE + "/sub-sub-type";
    }

    public static final class TagContext {
        private static final String BASE = ROOT + "/tag";
        private static final String SERIES_BASE = ROOT_V2 + "/tag/series";
        public static final String TAG_WITH_ID = BASE + "/{tagId}";
        public static final String TAG_SEARCH = BASE + "/search";
        public static final String TAG_SERIES = SERIES_BASE;
        public static final String TAG_SERIES_ID = SERIES_BASE + "/{seriesId}";
        public static final String TAG_SERIES_ID_TAG = SERIES_BASE + "/{seriesId}/tag";
        public static final String TAG_SERIES_ID_TAG_BULK = SERIES_BASE + "/{seriesId}/tag/bulk";
        public static final String TAG_SERIES_ID_TAG_BULK_RECHARGE = SERIES_BASE + "/{seriesId}/tag/bulk/recharge";
    }

    public static final class CorporateContext {
        private static final String BASE = ROOT_V2 + "/corporate";
        public static final String CORPORATE = BASE;
        public static final String CORPORATE_ID = BASE + "/{corporateId}";
        public static final String CORPORATE_LIMIT_TYPE = BASE + "/limit-type";
        public static final String CORPORATE_ID_LIMIT = BASE + "/{corporateId}/limit";
        public static final String CORPORATE_ID_PLAN = BASE + "/{corporateId}/plan";
        public static final String CORPORATE_ID_PLAN_ID = BASE + "/{corporateId}/plan/{planId}";
    }

    public static final class MachineContext {
        private static final String BASE_MACHINE = ROOT_V2 + "/machine";
        private static final String BASE_HW_ISSUE = ROOT_V2 + "/hardware-issue";
        public static final String MACHINE = BASE_MACHINE;
        public static final String MACHINE_SEED = BASE_MACHINE + "/seed";
        public static final String MACHINE_W_ID = BASE_MACHINE + "/{machineId}";
        public static final String MACHINE_SEARCH = BASE_MACHINE + "/search";
        public static final String MACHINE_WISE_SALE = BASE_MACHINE + "/{machineId}/sale";
        public static final String HOURLY_MACHINE_WISE_SALE = BASE_MACHINE + "/todayHourly/sale";
        public static final String HW_ISSUE_REASON = BASE_HW_ISSUE + "/reason";
        public static final String HW_ISSUE_W_MACHINE_ID = BASE_HW_ISSUE + "/{machineId}";
        public static final String MACHINE_W_ID_TRAY = BASE_MACHINE + "/{machineId}/tray";
        public static final String MACHINE_SLOT_MERGE = BASE_MACHINE + "/{machineId}/slot/{slot}/merge/{mergedSlot}";
        public static final String MACHINE_SLOT_MERGE_DELETE_ALL = BASE_MACHINE + "/{machineId}/slot/merge";
    }

    public static final class BrandContext {
        private static final String BASE = ROOT_V2 + "/brand";
        public static final String WARHOUSE_BRAND = BASE + "/warehouse/{warehouseId}";
        public static final String ALL_BRAND = BASE + "/";
    }

    public static final class S3UploadContext {
        private static final String BASE = ROOT_V2 + "/s3upload";
        public static final String MACHINE_IMAGE = BASE + "/machine-image";
    }

    public static final class SlotUtilizationContext {
        public static final String BASE = ROOT + "/vm/slotutilization";
    }

    public static final class ProductPlacementContext {
        public static final String BASE = ROOT + "/product/placement/activecount";
    }

    public static final class RefillContext {
        public static final String BASE = ROOT + "/refill/save";
        public static final String LAST_REFILL_DETAILS = ROOT + "/previous/refill/details";
        public static final String REFILL_SUGGESTION = ROOT + "/refill/suggestion";

    }

    public static final class SkuGroupStockContext {
        public static final String BASE = ROOT + "/sgstockin/save";
    }

    public static final class VMHealthStatusContext {
        public static final String BASE = ROOT + "/vm/healthstatus";
        public static final String PING_FAILURE = ROOT + "/vm/ping-failure/report";
        public static final String HEALTH_STATUS = ROOT + "/vm/healthStatus/report";
    }

    public static final class SkuGroupStockFetchAllContext {
        public static final String BASE = ROOT + "/sgstockin/fetchall";
    }

    public static final class SlotUtilizationContextV2Context {
        public static final String SLOT_UTILIZATION = "/api/v2/vm/slotutilization";
    }
    public static final class SlotBlockContext {
        public static final String SLOT_BLOCK = "/api/v2/vm/slotBlock";
    }

    public static final class UserCohortsContext {
        public static final String USER_COHORTS = ROOT + "/vm/cohorts";
    }

    public static final class SendNotification {
        public static final String BASE = ROOT + "/notification/notification-user";
        public static final String SEND_NOTIFICATION = BASE + "/send-notification";
        public static final String NOTIFICATION_USER_CSV_UPLOAD = BASE + "/csv-upload";
    }

    public static final class UnblockSlotContext {
        public static final String UNBLOCK_SLOT = ROOT + "/unblock/slot";
        public static final String SLOT_BLOCK_REPORT = ROOT + "/slots/blocked/reports";
        public static final String SLOT_ISSUE_REPORTED = ROOT + "/slot/check/reported";
        public static final String UNBLOCK_ALL_SLOTS = ROOT + "/unblock/slot/all";
        public static final String SLOT_BLOCK_REPORT_V2 = "/api/v2/slots/report/{warehouseId}";


    }

    public static final class WarehouseContext {
        public static final String MAP_WAREHOUSE_VM = ROOT + "/map/vm/warehouse/{warehouseId}";

        private static final String BASE_WAREHOUSE = ROOT_V2 + "/warehouse";
        public static final String WAREHOUSE_WITH_ID = BASE_WAREHOUSE + "/{warehouseId}";
        public static final String WAREHOUSE_LIST_ALL = BASE_WAREHOUSE + "/list";
        public static final String WAREHOUSE_MAPPED = BASE_WAREHOUSE + "/mapped";
        public static final String USER_WORKING_DETAILS = WAREHOUSE_WITH_ID + "/user/details";
        public static final String DUMP_WAREHOUSE_INVENTORY = WAREHOUSE_WITH_ID + "/dump";
        public static final String DUMP_WAREHOUSE_ITEM_COUNT_INIT = WAREHOUSE_WITH_ID + "/init/dump";
        public static final String DUMP_WAREHOUSE_CLOSING_INVENTORY = WAREHOUSE_WITH_ID + "/init/dump/closing/inventory";
    }

    public static final class BpUserContext {
        public static final String BUSINESS_PROFILE = ROOT + "/business-profile/{id}";
        public static final String BUSINESS_PROFILE_APPROVE = ROOT + "/business-profile/approve/{ucmId}";
        public static final String ACTIVATE = BUSINESS_PROFILE + "/activate";
        public static final String USER_CORPORATE = ROOT + "/corporate";
    }

    public static final class CouponContext {
        private static final String BASE = ROOT + "/coupon";
        public static final String CREATE_DRAFT = BASE + "/create/draft";
        public static final String CREATE_COUPON = BASE + "/create/{draftId}";
        public static final String VIEW_COUPONS = BASE + "/fetchAll";
        public static final String FETCH_COUPON = BASE + "/fetchCoupon/{couponId}";
        public static final String FETCH_DRAFT= BASE + "/fetchDraft/{draftId}";
        public static final String RETRIEVE_COUPON = BASE + "/retrieve";
    }

    public static final class RefundRevokeRoute {
        public static final String REFUND_REVOKE = ROOT + "/wallet/operations";
    }

    public static final class BankRefundContext {
        public static final String BANK_REFUND = ROOT + "/wallet/bankrefund";
        public static final String BANK_REFUND_STATUS = ROOT_V2 + "/bankRefund/status/{orderId}/payment/{paymentId}";
    }

    public static final class HsnContext {
        public static final String BASE = ROOT + "/hsn";
        public static final String HSN_CODES = BASE + "/codes";
        public static final String HSN_CHAPTER = BASE + "/chapters";
        public static final String HSN_HEADINGS = BASE + "/headings";
        public static final String HSN_SUB_HEADINGS = BASE + "/subHeadings";
    }

    public static final class KitInvoiceContext {
        private static final String BASE_WAREHOUSE = ROOT_V2 + "/warehouse";
        public static final String WAREHOUSE_WITH_ID = BASE_WAREHOUSE + "/{warehouseId}";
        public static final String WAREHOUSE_SEZ_LOCATION = BASE_WAREHOUSE + "/{warehouseId}/sez-location";
        public static final String WAREHOUSE_SEZ_LOCATION_ID = WAREHOUSE_SEZ_LOCATION + "/{locationId}";
        public static final String WAREHOUSE_INVOICE_KIT = WAREHOUSE_WITH_ID + "/invoice/{kitId}";
    }

    public static final class AdminRouteContext {
        private static final String BASE = ROOT + "/admin";
        public static final String FETCH_ORDERS = BASE + "/orders";
        public static final String FETCH_ORDER_DETAIL = BASE + "/orders/{orderId}";
    }

    public static final class UserFuelContext {
        private static final String BASE_FUEL_WAREHOUSE = ROOT_V2 + "/fuel/warehouse";
        public static final String FUEL_WAREHOUSE_ASSOCIATED = BASE_FUEL_WAREHOUSE + "/associated";
        public static final String FUEL_WAREHOUSE_WITH_ID = BASE_FUEL_WAREHOUSE + "/{warehouseId}";
        public static final String FUEL_WAREHOUSE_USERS = FUEL_WAREHOUSE_WITH_ID + "/user";
    }

    public static final class PromoContext {
        private static final String BASE_PROMO = ROOT_V2 + "/promo";
        public static final String PROMO_IMAGE = BASE_PROMO + "/image";
        public static final String PROMO_COHORT = BASE_PROMO + "/cohort";
        public static final String PROMO_IMAGE_WITH_ID = BASE_PROMO + "/image/{imageId}";
        public static final String PROMO_COHORT_WITH_ID_CONFIG = BASE_PROMO + "/cohort/{cohortId}/config";
        public static final String PROMO_COHORT_WITH_ID_IMAGE = BASE_PROMO + "/cohort/{cohortId}/image";
        public static final String PROMO_COHORT_WITH_ID_OVERRIDE = BASE_PROMO + "/cohort/{cohortId}/override";
        public static final String PROMO_COHORT_WITH_ID_OVERRIDE_ID = BASE_PROMO + "/cohort/{cohortId}/override/{overrideId}";
    }

    public static final class ComboContext {
        private static final String BASE_PROMO = ROOT_V2 + "/combo";
        public static final String COMBO_CREATE = BASE_PROMO + "/create";
        public static final String COMBO_UPDATE = BASE_PROMO + "/{comboId}/update";
        public static final String COMBO_FETCH = BASE_PROMO + "/{comboId}";
        public static final String COMBO_COHORT = BASE_PROMO + "/{comboId}/cohort/{cohortId}";
        public static final String COMBO_COHORT_ALL = BASE_PROMO + "/cohort/{cohortId}/all";
        public static final String COMBO_TYPE_COHORT = BASE_PROMO + "/cohort";



    }

}
