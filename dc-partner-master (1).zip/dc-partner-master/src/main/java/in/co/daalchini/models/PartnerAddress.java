package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "partner_addresses")
public class PartnerAddress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private DashboardUser partner;

    @Column(name = "street")
    private String street;

    @Column(name = "house_number")
    private String houseNumber;

    @Column(name = "landmark")
    private String landmark;

    @Column(name = "save_as")
    private String saveAs;

    @Column(name = "locationUrl")
    private String locationUrl;


    @Column(name = "active")
    private Boolean active;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public PartnerAddress (Long id) {
        this.id = id;
    }

    public static PartnerAddress of (Long id) {
        return new PartnerAddress(id);
    }

    @PrePersist
    void createTimestamp () {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp () {
        this.updatedAt = DateTimeHelper.now();
    }

    @Override
    public String toString () {
        return new StringJoiner(", ", PartnerAddress.class.getSimpleName() + "[", "]")
                .add("id='" + id + "'")
                .add("street='" + street + "'")
                .add("houseNumber=" + houseNumber)
                .add("landmark=" + landmark)
                .add("saveAs=" + saveAs)
                .add("locationUrl=" + locationUrl)
                .add("active=" + active)
                .add("createdAt=" + createdAt)
                .add("updatedAt=" + updatedAt)
                .toString();
    }
}
