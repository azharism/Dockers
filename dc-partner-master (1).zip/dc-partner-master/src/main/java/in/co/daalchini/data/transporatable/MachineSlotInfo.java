package in.co.daalchini.data.transporatable;

import org.springframework.beans.factory.annotation.Value;

public interface MachineSlotInfo {

    @Value("#{target.id}")
    Long getId();

    @Value("#{target.vm_mv_id}")
    Long getVmMvId();

    @Value("#{target.slot_id}")
    Integer getSlotId();

}
