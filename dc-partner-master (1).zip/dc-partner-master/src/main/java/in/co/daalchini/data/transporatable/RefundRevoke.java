package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.constants.enums.OperationType;
import lombok.Data;

import javax.validation.constraints.NotNull;

public class RefundRevoke {

    @Data
    public static final class Request {

        @JsonProperty("operation_type")
        @NotNull(message = "operation_type cannot be null")
        private OperationType operationType;
        @JsonProperty("order_id")
        @NotNull(message = "order_id cannot be null")
        private String orderId;
        @JsonProperty("amount")
        @NotNull(message = "amount cannot be null")
        private Double amount;
    }
}
