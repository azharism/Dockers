
package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.data.untransportable.PaymentGatewayType;
import in.co.daalchini.data.untransportable.PaymentStatus;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "amount")
    private Double amount;

    @Column(name = "payment_gateway_id")
    private PaymentGatewayType pgType;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    private Order order;

    @Column(name = "status")
    private PaymentStatus status;

    @Column(name = "gateway_response")
    private String gatewayResponse;

    @Column(name = "transaction_id")
    private String transactionId;

    @Column(name = "webhook_response")
    private String webhookResponse;

    @Column(name = "is_deleted")
    private Boolean isDeleted;

    @Column(name = "reason")
    private String reason;

    @Column(name = "manual_refund_amount")
    private Double manualRefundAmount;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    void createTimestamp() {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp() {
        this.updatedAt = DateTimeHelper.now();
    }

    public Payment newCopy(double amount, PaymentStatus status, String json) {
        Payment newObj = new Payment();
        LocalDateTime currentDateTime = LocalDateTime.now();
        newObj.createdAt = currentDateTime;
        newObj.updatedAt = currentDateTime;
        newObj.isDeleted = this.isDeleted;
        newObj.order = this.order;
        newObj.pgType = this.pgType;
        newObj.status = status;
        newObj.amount = amount;
        newObj.gatewayResponse = json;

        return newObj;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Payment.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("amount=" + amount)
                .add("pgType=" + pgType)
                .add("status=" + status)
                .add("gatewayResponse='" + gatewayResponse + "'")
                .add("webhookResponse='" + webhookResponse + "'")
                .add("reason='" + reason + "'")
                .add("manualRefundAmount='" + manualRefundAmount + "'")
                .toString();
    }
}
