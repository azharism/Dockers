package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.untransportable.OrderState;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "order_line_items")
public class OrderLineItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @JsonIgnoreProperties({"orderLineItems"})
    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    @Column(name = "sku_group_id")
    private Long skuGroupId;

    @Column(name = "slot_identifier")
    private Long slotIdentifier;

    @Column(name = "manufacturer_variant_id")
    private Long manufacturerVariantId;

    @Column(name = "name")
    private String name;

    @Column(name = "mrp")
    private Double mrp;

    @Column(name = "offer_price")
    private Double offerPrice;

    @Column(name = "form_type")
    private String formType;

    @Column(name = "quantity")
    private String quantity;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "item_quantity")
    private Long itemQuantity;

    @Column(name = "cgst_rate")
    private Double cgstRate;

    @Column(name = "sgst_rate")
    private Double sgstRate;

    @Column(name = "dc_code")
    private String dcCode;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "variant_image_id")
    private VariantImage variantImage;

    @Column(name = "vending_machine_id")
    private Long vendingMachineId;

    @Column(name = "status")
    private OrderState status;

    @Column(name = "sub_status")
    private String subStatus;

    @Column(name = "success")
    private Long success;

    @Column(name = "failed")
    private Long failed;

    @Column(name = "refund_count")
    private Long refundCount;

    @Column(name = "hold_reset_done")
    private Boolean holdResetDone;

    @Column(name = "vend_remaining", insertable = false, updatable = false)
    private Integer vendRemaining;

    @OneToOne
    @JoinColumn(name = "vm_mv_sku_id", updatable = false)
    private MachineManufacturerVariantSkuGroup machineMvSkg;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public OrderLineItem withStatus (OrderState status) {
        this.status = status;
        return this;
    }

    public OrderLineItem fulfilQuantity (Long success, Long failed) {
        this.setSuccess(success);
        this.setFailed(failed);
        this.setHoldResetDone(true);

        return this;
    }

    @PrePersist
    void createTimestamp () {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp () {
        this.updatedAt = DateTimeHelper.now();
    }

    @Override
    public String toString () {
        return new StringJoiner(", ", OrderLineItem.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("order=" + order)
            .add("skuGroupId=" + skuGroupId)
            .add("slotIdentifier=" + slotIdentifier)
            .add("manufacturerVariantId=" + manufacturerVariantId)
            .add("name='" + name + "'")
            .add("mrp=" + mrp)
            .add("offerPrice=" + offerPrice)
            .add("formType='" + formType + "'")
            .add("quantity='" + quantity + "'")
            .add("productName='" + productName + "'")
            .add("itemQuantity=" + itemQuantity)
            .add("cgstRate=" + cgstRate)
            .add("sgstRate=" + sgstRate)
            .add("dcCode='" + dcCode + "'")
            .add("vendingMachineId=" + vendingMachineId)
            .add("status=" + status)
            .add("success=" + success)
            .add("failed=" + failed)
            .add("holdResetDone=" + holdResetDone)
            .add("vendRemaining=" + vendRemaining)
            .toString();
    }
}
