package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import in.co.daalchini.util.DateAndTimeDeserialize;

import java.io.Serializable;
import java.util.Date;

public class InvoiceDetailsReqResHelper implements Serializable{

	private static final long serialVersionUID = -530754687057639753L;

	private Long id;

	@JsonProperty(value = "invoice_no") private String invoiceNo;

	@JsonDeserialize(using= DateAndTimeDeserialize.class)
	@JsonProperty(value = "recieved_date") private Date recievedDate;
	
	@JsonDeserialize(using=DateAndTimeDeserialize.class)
	@JsonProperty(value = "invoice_date") private Date invoiceDate;

	@JsonProperty(value = "warehouse_id") private Long warehouse;

	private String comments;
	
	private Long user;

	public Long getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(Long warehouse) {
		this.warehouse = warehouse;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Date getRecievedDate() {
		return recievedDate;
	}

	public void setRecievedDate(Date recievedDate) {
		this.recievedDate = recievedDate;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Long getUser() {
		return user;
	}

	public void setUser(Long user) {
		this.user = user;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public InvoiceDetailsReqResHelper(Long id, String invoiceNo, Date recievedDate, Date invoiceDate, Long warehouse,
                                      String comments, Long user) {
		super();
		this.id = id;
		this.invoiceNo = invoiceNo;
		this.recievedDate = recievedDate;
		this.invoiceDate = invoiceDate;
		this.warehouse = warehouse;
		this.comments = comments;
		this.user = user;
	}

	public InvoiceDetailsReqResHelper(InvoiceDetails details) {
		super();
		this.id = details.getId();
		this.invoiceNo = details.getInvoiceNo();
		this.recievedDate = details.getRecievedDate();
		this.invoiceDate = details.getInvoiceDate();
		this.comments = details.getComments();

		if(details.getUser() != null && details.getUser().getId()!= null)
			this.user = details.getUser().getId();
		
		if(details.getWarehous() != null && details.getWarehous().getId()!= null)
			this.warehouse = details.getWarehous().getId();

	}
	
}
