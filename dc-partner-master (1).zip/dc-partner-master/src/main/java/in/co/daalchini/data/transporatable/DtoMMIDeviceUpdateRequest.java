package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMMIDeviceUpdateRequest {

    @NotNull
    @NoLeadingAndTrailingSpace
    @JsonProperty("mmi_device_id")
    private String mmiDeviceId;
}
