package in.co.daalchini.data.transporatable;


import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Data;

import javax.validation.constraints.*;
import java.util.StringJoiner;

@Data
@JsonIncludeProperties({"corporate_id", "code", "description", "initial_balance"})
public class CreateTagSeriesRequest {

    @NotNull
    @Positive
    @JsonProperty("corporate_id")
    private Long corporateId;

    @NotBlank
    @NoLeadingAndTrailingSpace
    @Size(min = 4, max = 64, message = "code must be between 4 and 64 characters")
    @JsonProperty("code")
    private String code;

    @NoLeadingAndTrailingSpace
    @Size(max = 200, message = "description must not exceed 200 characters")
    @JsonProperty("description")
    private String description;

    @PositiveOrZero
    @JsonProperty("initial_balance")
    private Double initialBalance;


    @Override
    public String toString() {
        return new StringJoiner(", ", CreateTagSeriesRequest.class.getSimpleName() + "[", "]")
                .add("corporateId=" + corporateId)
                .add("code='" + code + "'")
                .add("description='" + description + "'")
                .add("initialBalance=" + initialBalance)
                .toString();
    }
}
