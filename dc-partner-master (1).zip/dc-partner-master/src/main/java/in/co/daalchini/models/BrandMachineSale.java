package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "brand_machine_sale_history")
public class BrandMachineSale {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(name = "brand_id")
    private Long brandId;

    @Column(name = "eod_sale_amount")
    private Long eodSaleAmount;

    @Column(name = "eod_vm_count")
    private Long eodVmCount;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;


    @PrePersist
    void createTimestamp () {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
    }

}

