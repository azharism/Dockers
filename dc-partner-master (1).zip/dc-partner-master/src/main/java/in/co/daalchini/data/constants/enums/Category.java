package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum Category {
    MP("MP"),
    GMP("GMP"),
    STD("STD");

    private final @JsonValue String value;

    Category(String value) {
        this.value = value;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CouponUsageDuration of(String status) {
        return Arrays.stream(CouponUsageDuration.values())
                .filter(x -> x.getValue().equalsIgnoreCase(status))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return value;
    }

}
