package in.co.daalchini.Interfaces;

import in.co.daalchini.models.EntityModel;
import in.co.daalchini.models.Warehouse;

public interface EntityAttributeWarehouseInterface {
	
	Warehouse getWarehouseId ();
	Integer getId();
	EntityModel getEntityId ();

}
