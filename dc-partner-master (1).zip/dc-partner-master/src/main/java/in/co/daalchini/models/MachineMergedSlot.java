package in.co.daalchini.models;

import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.time.Instant;
import java.time.LocalDateTime;

@Entity
@Table(name = "machine_merged_slots")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class MachineMergedSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "machine_id")
    private Long machineId;

    @Column(name = "slot_id")
    private Long slotId;

    @Column(name = "merged_slot")
    private Long mergedSlot;

    @Column(name = "merged_by")
    private Long mergedBy;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    void createTimestamp() {
        this.createdAt = DateTimeHelper.now();
    }
}
