package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum RfidCardStatus {

    New("new", false),
    Issued("issued", false),
    Active("active", true),
    Inactive("inactive", false);

    private final @JsonValue String value;
    private final boolean active;

    RfidCardStatus (String value, boolean active) {
        this.value = value;
        this.active = active;
    }

    @JsonCreator
    public static RfidCardStatus of (String value) {
        return Stream.of(RfidCardStatus.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }
}
