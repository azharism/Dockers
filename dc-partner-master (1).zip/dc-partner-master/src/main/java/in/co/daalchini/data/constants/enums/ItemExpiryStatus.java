package in.co.daalchini.data.constants.enums;

public enum ItemExpiryStatus {
    scheduled,
    processed,
    skipped,
    failed;
}
