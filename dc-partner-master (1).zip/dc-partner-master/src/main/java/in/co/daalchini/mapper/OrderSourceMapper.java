package in.co.daalchini.mapper;

import in.co.daalchini.data.untransportable.OrderSource;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OrderSourceMapper {

    default String toValue (OrderSource source) {
        if (source == null) return null;
        return source.getValue();
    }
}
