package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import in.co.daalchini.util.DateAndTimeDeserialize;

import java.io.Serializable;
import java.util.Date;

public class StockInReqResHelper implements Serializable{

	private static final long serialVersionUID = 8308958764970233921L;

	private Long id;

	private String batch;

	@JsonProperty(value = "checked_in") private Double checkedIn;
	
	@JsonDeserialize(using=DateAndTimeDeserialize.class)
	@JsonProperty(value = "created_at") private Date createdAt;
	
	@JsonDeserialize(using=DateAndTimeDeserialize.class)
	@JsonProperty(value = "expiry_date") private Date expiryDate;

	private Double filled;
	
	@JsonProperty(value = "in_transit") private Integer inTransit;

	@JsonDeserialize(using= DateAndTimeDeserialize.class)
	@JsonProperty(value = "manufacture_date") private Date manufactureDate;
	
	private Integer sold;

	@JsonDeserialize(using=DateAndTimeDeserialize.class)
	@JsonProperty(value = "updated_at") private Date updatedAt;

	@JsonProperty(value = "sku_number") private Integer skuNumber;

	@JsonProperty(value = "manufacturer_variant_id") private Long manufacturerVariant;

	@JsonProperty(value = "invoice_details_id") private Long invoiceDetailsId;

	public Long getId() {
		return id;
	}

	public Integer getSkuNumber() {
		return skuNumber;
	}

	public void setSkuNumber(Integer skuNumber) {
		this.skuNumber = skuNumber;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public Double getCheckedIn() {
		return checkedIn;
	}

	public void setCheckedIn(Double checkedIn) {
		this.checkedIn = checkedIn;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Double getFilled() {
		return filled;
	}

	public void setFilled(Double filled) {
		this.filled = filled;
	}

	public Integer getInTransit() {
		return inTransit;
	}

	public void setInTransit(Integer inTransit) {
		this.inTransit = inTransit;
	}

	public Date getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public Integer getSold() {
		return sold;
	}

	public void setSold(Integer sold) {
		this.sold = sold;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Long getManufacturerVariant() {
		return manufacturerVariant;
	}

	public void setManufacturerVariant(Long manufacturerVariant) {
		this.manufacturerVariant = manufacturerVariant;
	}

	public Long getInvoiceDetailsId() {
		return invoiceDetailsId;
	}

	public void setInvoiceDetailsId(Long invoiceDetailsId) {
		this.invoiceDetailsId = invoiceDetailsId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public StockInReqResHelper() {
		super();
	}
	
	public StockInReqResHelper(Long id, String batch, Double checkedIn, Date createdAt, Date expiryDate, Double filled,
                               Integer inTransit, Date manufactureDate, Integer sold, Date updatedAt, Integer skuNumber,
                               Long manufacturerVariant, Long invoiceDetailsId) {
		super();
		this.id = id;
		this.batch = batch;
		this.checkedIn = checkedIn;
		this.createdAt = createdAt;
		this.expiryDate = expiryDate;
		this.filled = filled;
		this.inTransit = inTransit;
		this.manufactureDate = manufactureDate;
		this.sold = sold;
		this.updatedAt = updatedAt;
		this.skuNumber = skuNumber;
		this.manufacturerVariant = manufacturerVariant;
		this.invoiceDetailsId = invoiceDetailsId;
	}

	public StockInReqResHelper(SkuGroupStockIn stockIn) {
		super();
		this.id = stockIn.getId();
		this.batch = stockIn.getBatch();
		this.checkedIn = stockIn.getCheckedIn();
		this.createdAt = stockIn.getCreatedAt();
		this.expiryDate = stockIn.getExpiryDate();
		this.filled = stockIn.getFilled();
		this.inTransit = stockIn.getInTransit();
		this.manufactureDate = stockIn.getManufactureDate();
		this.sold = stockIn.getSold();
		this.updatedAt = stockIn.getUpdatedAt();
		this.skuNumber = stockIn.getSkuNumber();
//		this.invoiceNo = stockIn.getInvoiceNo();
//		this.recievedAt = stockIn.getRecievedAt();
//		this.invoiceDate = stockIn.getInvoiceDate();
//		this.comments = stockIn.getComments();		

		if(stockIn.getManufacturerVariant() != null && stockIn.getManufacturerVariant().getId()!= null)
			this.manufacturerVariant = stockIn.getManufacturerVariant().getId();
	}

	@Override
	public String toString() {
		return "StockInReqResHelper [id=" + id + ", batch=" + batch + ", checkedIn=" + checkedIn + ", createdAt="
				+ createdAt + ", expiryDate=" + expiryDate + ", filled=" + filled + ", inTransit=" + inTransit
				+ ", manufactureDate=" + manufactureDate + ", sold=" + sold + ", updatedAt=" + updatedAt
				+ ", skuNumber=" + skuNumber + ", manufacturerVariant=" + manufacturerVariant + ", invoiceDetailsId="
				+ invoiceDetailsId + "]";
	}


}
