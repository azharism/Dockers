package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.Instant;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vending_machine_keys")
@EntityListeners(AuditingEntityListener.class)
public class MachineKey {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "vending_machine_id")
    private Long vendingMachineId;

    @Column(name = "remote_board_id", nullable = false)
    private String remoteBoardId;

    @Column(name = "remote_bluetooth_id", nullable = false)
    private String remoteBluetoothId;

    @Column(name = "remote_com_id")
    private String remoteComId;

    @Column(name = "remote_device_id", nullable = false)
    private String remoteDeviceId;

    @Column(name = "serial_number", nullable = false, unique = true)
    private String serialNumber;

    @JsonIgnore
    @CreatedDate
    @Column(name = "created_at")
    private Instant createdAt;

    @JsonIgnore
    @LastModifiedDate
    @Column(name = "updated_at")
    private Instant updatedAt;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    @Override
    public String toString () {
        return new StringJoiner(", ", MachineKey.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("vendingMachineId=" + vendingMachineId)
            .add("remoteBoardId='" + remoteBoardId + "'")
            .add("remoteBluetoothId='" + remoteBluetoothId + "'")
            .add("remoteComId='" + remoteComId + "'")
            .add("remoteDeviceId='" + remoteDeviceId + "'")
            .add("serialNumber='" + serialNumber + "'")
            .toString();
    }

    public MachineKey generateNext (String serialNumber) {
        var machineKey = new MachineKey();
        String nextBluetoothId = String.valueOf(Long.parseLong(remoteBluetoothId) + 1);
        String nextDeviceId = String.valueOf(Long.parseLong(remoteDeviceId) + 1);
        machineKey.setRemoteBluetoothId(nextBluetoothId);
        machineKey.setRemoteBoardId("D" + nextBluetoothId);
        machineKey.setRemoteDeviceId(nextDeviceId);
        machineKey.setRemoteComId(nextDeviceId);
        machineKey.setSerialNumber(serialNumber);

        return machineKey;
    }

    public static MachineKey generateNew (String serialNumber) {
        var machineKey = new MachineKey();
        String nextBluetoothId = "10001";
        String nextDeviceId = "10001";
        machineKey.setRemoteBluetoothId(nextBluetoothId);
        machineKey.setRemoteBoardId("D" + nextBluetoothId);
        machineKey.setRemoteDeviceId(nextDeviceId);
        machineKey.setRemoteComId(nextDeviceId);
        machineKey.setSerialNumber(serialNumber);

        return machineKey;
    }

    public MachineKey withMachineId (Long machineId) {
        this.vendingMachineId = machineId;
        return this;
    }
}
