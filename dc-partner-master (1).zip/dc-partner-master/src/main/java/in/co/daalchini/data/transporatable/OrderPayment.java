package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;

public final class OrderPayment {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Request {
        private Integer pgId;
    }

    @Data
    @Builder
    public static final class Response {
        private String orderId;
        private Double amount;
        private Integer pgId;
    }
}
