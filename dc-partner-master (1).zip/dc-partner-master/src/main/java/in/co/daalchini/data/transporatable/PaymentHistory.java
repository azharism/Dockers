package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.transporatable.wallet.TransactionHistory.PayloadData;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;

public final class PaymentHistory {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @Builder
    public static final class Request {

        @NotNull(message = "from required")
        private String from;

        @NotNull(message = "to required")
        private String to;

        @NotNull(message = "sortBy required")
        private String sortBy;
    }


    @Data
    @Builder
    public static final class Response {
        private Integer totalCount;
        private List<Transaction> transactions;
    }

    @Data
    @Builder
    public static final class Transaction {
        private String transactionId;
        private String orderId;
        private Double amount;
        private String opsType;
        private String transactionType;
        private String timestamp;

        public static Transaction of (PayloadData data) {
            return PaymentHistory.Transaction
                .builder()
                .transactionId(data.getTransactionId().toString())
                .orderId(data.getOrderId())
                .amount(data.getAmount())
                .opsType(data.getOpsType())
                .transactionType(data.getTransactionType())
                .timestamp(data.getTimestamp())
                .build();
        }
    }
}
