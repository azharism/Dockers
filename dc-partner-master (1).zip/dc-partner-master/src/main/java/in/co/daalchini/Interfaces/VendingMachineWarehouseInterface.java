package in.co.daalchini.Interfaces;

public interface VendingMachineWarehouseInterface {

    Long getWarehouseId();

    Long getMachineId();
}
