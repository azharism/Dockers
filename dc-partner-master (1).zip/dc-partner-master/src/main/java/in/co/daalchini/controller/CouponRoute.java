package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.CouponContext;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.external.CouponApiService;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Log4j2
@RestController
public class CouponRoute {

    private final CouponApiService couponService;

    @Autowired
    public CouponRoute(CouponApiService couponService) {
        this.couponService = couponService;
    }


    @PreAuthorize("hasAuthority('create_coupon')")
    @PostMapping(CouponContext.CREATE_DRAFT)
    public CreateDraft.Response createCoupon(@RequestBody CreateDraft.Request request,
                                             @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for creating coupon draft :{}", request);
        Long userId = userDetails.getUserId();

        try {
            CreateDraft.Response response = couponService.createNewDraft(request, userId);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("Error in creating coupon draft :{}", e.getMessage());
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('create_coupon')")
    @PostMapping(CouponContext.CREATE_COUPON)
    public CouponCreate.Response createCoupon(@PathVariable(value = "draftId") Long draftId,
                                              @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for creating coupon with draftId :{}", draftId);
        Long userId = userDetails.getUserId();

        try {
            CouponCreate.Response response = couponService.createCoupon(draftId, userId);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("Error in creating coupon :{}", e.getMessage());
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('view_coupon')")
    @GetMapping(CouponContext.VIEW_COUPONS)
    public CouponView.Response viewCoupons(@AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for fetching all coupons by :{}", userDetails);

        try {
            CouponView.Response response = couponService.fetchAllCoupons();
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("Error in fetching coupons :{}", e.getMessage());
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('view_coupon')")
    @GetMapping(CouponContext.FETCH_COUPON)
    public CouponDetails.Response fetchCoupon(
            @PathVariable(value = "couponId") Long couponId) {
        log.info("Request received for fetching couponId:{}", couponId);
        try {
            var response = couponService.fetchCouponId(couponId);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.info("Error in fetching coupon");
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('create_coupon')")
    @PostMapping(CouponContext.RETRIEVE_COUPON)
    public CouponCreate.Response retriveCoupon(
           @Valid @RequestBody RetrieveCoupon.Request request) {
        log.info("Request received for fetching draftId:{}", request);
        try {
            var response = couponService.retriveCoupon(request);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.info("Error in fetching coupon");
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('view_coupon')")
    @GetMapping(CouponContext.FETCH_DRAFT)
    public CreateDraft.Response FetchDraft(@PathVariable(value = "draftId") Long draftId,
                                           @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for fetching draftId: {}", draftId);
        try {
            CreateDraft.Response response = couponService.fetchDraftId(draftId);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.info("Error in fetching Draft");

            throw e;
        }
    }

}