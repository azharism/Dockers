package in.co.daalchini.models;

import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;

import javax.persistence.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@Table(name = "combos")
public class Combo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "total_price")
    private Double totalPrice;

    @Column(name = "actual_price")
    private Double actualPrice;

    @Column(name = "activates_at")
    private LocalDateTime activatesAt;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "consumer_app_enabled")
    private Boolean consumerAppEnabled;

    @Column(name = "kiosk_app_enabled")
    private Boolean kioskAppEnabled;

    @Column(name = "created_at")
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;

    @OneToMany(mappedBy = "combo",fetch = FetchType.LAZY)
    private List<ComboMvConfig> comboMvConfigs;

    @OneToMany(mappedBy = "combo",fetch = FetchType.LAZY)
    private List<ComboCohortConfig> comboCohortConfigs;


    @PrePersist
    void createTimestamp() {
        final var currentTimestamp = DateTimeHelper.instant();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp() {
        this.updatedAt = DateTimeHelper.instant();
    }


}
