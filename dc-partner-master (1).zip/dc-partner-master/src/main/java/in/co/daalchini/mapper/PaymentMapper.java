package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoOrderDetailResponse.PaymentDetails;
import in.co.daalchini.data.transporatable.DtoOrderDetailResponse.RefundDetails;
import in.co.daalchini.models.Payment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = {PaymentStatusMapper.class})
public interface PaymentMapper {

    @Mapping(target = "pgName", source = "pgType.pgName")
    PaymentDetails toPaymentDetails (Payment payment);

    @Mapping(target = "reason", source = "order.subStatus")
    @Mapping(target = "pgName", source = "pgType.pgName")
    @Mapping(target = "refundStatus", source = "reason")
    RefundDetails toRefundDetails (Payment payment);
}
