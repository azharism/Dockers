package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
@JsonIncludeProperties({"id", "name", "expiry_date_month", "is_active", "domains"})
public class DtoCorporateSummarized implements Comparable<DtoCorporateSummarized> {

    @JsonProperty("id")
    public Integer id;

    @JsonProperty("name")
    public String name;

    @JsonProperty("expiry_date_month")
    public Integer expiryDateMonth;

    @JsonProperty("is_active")
    public Boolean active;

    @JsonProperty("domains")
    public List<DtoCorporateDomain> domains;

    @Override
    public int compareTo(DtoCorporateSummarized o) {
        return this.id.compareTo(o.id);
    }

    @Data
    @Builder
    @JsonIncludeProperties({"domain", "description", "initial_balance", "is_active"})
    public static class DtoCorporateDomain {

        @JsonProperty("domain")
        public String domain;

        @JsonProperty("description")
        public String description;

        @JsonProperty("initial_balance")
        public String initialBalance;

        @JsonProperty("is_active")
        public Boolean active;
    }
}

