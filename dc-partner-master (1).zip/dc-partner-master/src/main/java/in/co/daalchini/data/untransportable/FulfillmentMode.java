package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum FulfillmentMode {

    MachinePickup("machine_pickup"),
    ContactLessPickup("contact-less_pickup"),
    Delivery("delivery"),
    B2bPickup("b2b_pickup"),
    B2bDelivery("b2b_delivery"),
    MobilityManual("mobility_manual"),
    MobilityAutomatic("mobility_automatic");

    private final @JsonValue String value;

    FulfillmentMode (String value) {
        this.value = value;
    }

    @JsonCreator
    public static FulfillmentMode of (String value) {
        return Stream.of(FulfillmentMode.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }
}
