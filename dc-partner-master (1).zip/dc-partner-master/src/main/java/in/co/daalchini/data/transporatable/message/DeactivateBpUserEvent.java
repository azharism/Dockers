package in.co.daalchini.data.transporatable.message;

import in.co.daalchini.service.helper.JsonUtil;
import lombok.*;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DeactivateBpUserEvent {

    private  Long userId;
    private  String employeeId;
    private  Long ucmId;

    public String json () {
        return JsonUtil.toJson(this);
    }
}
