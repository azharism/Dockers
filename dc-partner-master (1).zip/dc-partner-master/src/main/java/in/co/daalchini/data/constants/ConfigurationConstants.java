package in.co.daalchini.data.constants;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class ConfigurationConstants {

	public static final int ORDER_VIA_BOTH = 0;
	public static final int ORDER_VIA_VM = 1;
	public static final int ORDER_VIA_APP = 2;
	
	public static final int ORDER_ID_LENGTH_APP = 16;
	public static final int ORDER_ID_LENGTH_VM = 13;
	
	public static final List<Integer> MEAL_TYPES_CODE = new ArrayList<>();
	public static final List<Integer> MEAL_TYPE_MEALS_CODE = new ArrayList<>();
	public static final List<Integer> MEAL_TYPE_DESSERTS_SNACKS_CODE = new ArrayList<>();
	public static final List<Integer> MEAL_TYPE_BEVERAGES_DRINKS_CODE = new ArrayList<>();	

	public static final TreeMap<Integer, String> MONTH_MAPPER = new TreeMap<>();
	public static final TreeMap<Integer, String> DAY_MAPPER = new TreeMap<>();
	public static final List<Integer> DEMO_VM = new ArrayList<>();

	public static final TreeMap<Integer, String> REFILL_TYPE_MAPPER = new TreeMap<>();
	
	static {
		MONTH_MAPPER.put(1, "JANUARY");
		MONTH_MAPPER.put(2, "FEBRUARY");
		MONTH_MAPPER.put(3, "MARCH");
		MONTH_MAPPER.put(4, "APRIL");
		MONTH_MAPPER.put(5, "MAY");
		MONTH_MAPPER.put(6, "JUNE");
		MONTH_MAPPER.put(7, "JULY");
		MONTH_MAPPER.put(8, "AUGUST");
		MONTH_MAPPER.put(9, "SEPTEMBER");
		MONTH_MAPPER.put(10, "OCTOBER");
		MONTH_MAPPER.put(11, "NOVEMBER");
		MONTH_MAPPER.put(12, "DECEMBER");
	}
	static {
		DAY_MAPPER.put(1, "MONDAY");
		DAY_MAPPER.put(2, "TUESDAY");
		DAY_MAPPER.put(3, "WEDNESDAY");
		DAY_MAPPER.put(4, "THURSDAY");
		DAY_MAPPER.put(5, "FRIDAY");
		DAY_MAPPER.put(6, "SATURDAY");
		DAY_MAPPER.put(7, "SUNDAY");
	}
	static {
//		(2,5,6,8,10,11,12,13,15)
		DEMO_VM.add(2);
		DEMO_VM.add(5);
		DEMO_VM.add(6);
		DEMO_VM.add(8);
		DEMO_VM.add(10);
		DEMO_VM.add(11);
		DEMO_VM.add(12);
		DEMO_VM.add(13);
		DEMO_VM.add(15);
	}
	static {
		MEAL_TYPES_CODE.add(1);
		MEAL_TYPES_CODE.add(2);
		MEAL_TYPES_CODE.add(3);
		MEAL_TYPES_CODE.add(4);
		MEAL_TYPES_CODE.add(5);
		MEAL_TYPES_CODE.add(6);
		
		MEAL_TYPE_MEALS_CODE.add(2);
		MEAL_TYPE_MEALS_CODE.add(3);
		
		MEAL_TYPE_DESSERTS_SNACKS_CODE.add(1);
		MEAL_TYPE_DESSERTS_SNACKS_CODE.add(5);
		
		MEAL_TYPE_BEVERAGES_DRINKS_CODE.add(4);
		MEAL_TYPE_BEVERAGES_DRINKS_CODE.add(6);
	}
	static {
		REFILL_TYPE_MAPPER.put(1, "FRESH");
		REFILL_TYPE_MAPPER.put(2, "EXTRA");
		REFILL_TYPE_MAPPER.put(3, "EXPIRED");
		REFILL_TYPE_MAPPER.put(4, "LOSS");
		REFILL_TYPE_MAPPER.put(5, "TRANSFER");
		REFILL_TYPE_MAPPER.put(6, "OTHER");
	}
}
