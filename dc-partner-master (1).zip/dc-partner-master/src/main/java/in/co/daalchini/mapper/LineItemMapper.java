package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoOrderDetailResponse.LineItem;
import in.co.daalchini.models.OrderLineItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface LineItemMapper {

    @Mapping(target = "successCount", source = "success")
    @Mapping(target = "failureCount", source = "failed")
    @Mapping(target = "itemCount", source = "itemQuantity")
    @Mapping(target = "vendRemainingCount", source = "vendRemaining")
    @Mapping(target = "slotId", source = "slotIdentifier")
    @Mapping(target = "subTotal", expression = "java(item.getItemQuantity() * item.getOfferPrice())")
    LineItem toValue (OrderLineItem item);

    List<LineItem> toValues (List<OrderLineItem> item);
}
