package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.data.constants.enums.BpUnlinkStatus;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "bp_unlink_requests")
@EntityListeners(AuditingEntityListener.class)
public class BpUnlinkRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_corporate_mapping_id")
    private Long userCorporateMappingId;

    @Column(name = "userId")
    private Long userId;

    @Column(name = "status")
    private BpUnlinkStatus status;

    @Column(name = "updated_At")
    private LocalDateTime updatedAt;

    @Column(name = "processed_by")
    private Long processedBy;

    @Column(name = "created_At")
    private LocalDateTime createdAt;

    @Column(name = "expired_At")
    private LocalDateTime expiredAt;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_corporate_mapping_id", insertable = false, updatable = false)
    private UserCorporateMapping userCorporateMapping;



    @Override
    public String toString() {
        return new StringJoiner(", ", BpUnlinkRequest.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("userCorporateMappingId=" + userCorporateMappingId)
                .add("status=" + status)
                .add("updatedAt=" + updatedAt)
                .add("processedBy=" + processedBy)
                .add("createdAt=" + createdAt)
                .add("expiredAt=" + expiredAt)
                .toString();
    }
}
