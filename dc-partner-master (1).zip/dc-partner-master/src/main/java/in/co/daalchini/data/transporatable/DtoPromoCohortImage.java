package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIncludeProperties({"promo_image_id", "priority", "duration_sec", "is_mandatory", "description", "image_path", "target_url"})
public class DtoPromoCohortImage {

    @JsonProperty("promo_image_id")
    private Long promoImageId;

    @JsonProperty("priority")
    private Integer priority;

    @JsonProperty("duration_sec")
    private Integer durationSec;

    @JsonProperty("is_mandatory")
    private boolean mandatory;

    @JsonProperty("description")
    private String description;

    @JsonProperty("image_path")
    private String imagePath;

    @JsonProperty("target_url")
    private String targetUrl;
}
