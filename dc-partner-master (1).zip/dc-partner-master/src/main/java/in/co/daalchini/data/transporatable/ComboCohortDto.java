package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ComboCohortDto {

    @JsonProperty("cohort_id")
    private Long cohortId;
    @JsonProperty("is_overridden")
    private Boolean isOverridden;
    @JsonProperty("vm_ids")
    private List<Long> vmIds;

    public String getMachineIds(){
        return vmIds != null
                ? this.vmIds.stream().map(String::valueOf).collect(Collectors.joining(","))
                : null;
    }

}
