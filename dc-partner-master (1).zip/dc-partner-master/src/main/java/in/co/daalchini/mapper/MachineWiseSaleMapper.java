package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoMachineWiseSale;
import in.co.daalchini.models.MachineWiseSale;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface MachineWiseSaleMapper {

    DtoMachineWiseSale toDto (MachineWiseSale machineWiseSale);

    List<DtoMachineWiseSale> toDto (List<MachineWiseSale> machineWiseSales);
}
