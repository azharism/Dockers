package in.co.daalchini.data.transporatable.wallet;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

public final class TransferWalletBatch {

    @Data
    @Builder
    public static final class Request {
        private String reason;
        private SourceWallet sourceWallet;
        private List<TransferOrder> transferOrders;

        public static Request ofTag(String reason, SourceWallet sourceWallet, List<TransferOrder> transferOrders) {
            return TransferWalletBatch.Request
                    .builder()
                    .reason(reason)
                    .sourceWallet(sourceWallet)
                    .transferOrders(transferOrders)
                    .build();
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private List<IndividualResponse> successes;
        private List<IndividualResponse> failures;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class IndividualResponse {
        private Integer index;
        private boolean success;
        private String message;
        private String orderId;
        private Long transactionId;
        private Double balance;
    }
}
