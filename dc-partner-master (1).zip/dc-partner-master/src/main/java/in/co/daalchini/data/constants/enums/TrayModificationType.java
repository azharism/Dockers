package in.co.daalchini.data.constants.enums;

public enum TrayModificationType {
    tray_addition, tray_removal, slot_removal, slot_addition
}
