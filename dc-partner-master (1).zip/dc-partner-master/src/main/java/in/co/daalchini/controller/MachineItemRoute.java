package in.co.daalchini.controller;

import in.co.daalchini.data.feature.MachineItemDto;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.MachineItemService;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.PositiveOrZero;
import java.util.Collection;

import static in.co.daalchini.data.constants.RouteConstants.MACHINE_ITEM_BASE;
import static in.co.daalchini.data.feature.MachineItemDto.ItemPlacement;


@Log4j2
@Validated
@RestController
@RequestMapping(MACHINE_ITEM_BASE)
public class MachineItemRoute {

    private final MachineItemService machineItemService;

    public MachineItemRoute(
            MachineItemService machineItemService
    ) {
        this.machineItemService = machineItemService;
    }

    @GetMapping("{mvId}/list")
    public RestResponseV2<Collection<ItemPlacement>> listMachineItems(
            @PathVariable Long mvId,
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestParam(value = "include_slots", defaultValue = "false") Boolean includeSlots,
            @RequestParam(value = "current_warehouse_id", required = false) @PositiveOrZero Long currentWarehouseId
    ) {
        var userId = userDetails.getUserId();
        log.info("[listMachineItems] userId={}, mvId={}, includeSlots={}", userId, mvId, includeSlots);
        try {
            var itemPlacements = machineItemService.fetchMachineSlots(userId, currentWarehouseId, mvId, includeSlots);

            return RestResponseV2.ofSuccess(itemPlacements);
        } catch (Exception e) {
            log.warn("[listMachineItems] Error: ", e);
            throw e;
        }
    }

    @ResponseStatus(HttpStatus.ACCEPTED)
    @PatchMapping("{mvId}/expire")
    public RestResponseV2<Void> expireMachineItem(
            @PathVariable Long mvId,
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestBody @Valid MachineItemDto.MvExpireRequest request,
            @RequestParam(value = "current_warehouse_id", required = false) @PositiveOrZero Long currentWarehouseId
    ) {
        var userId = userDetails.getUserId();
        log.info("[expireMachineItem] userId={}, mvId={}, request={}", userId, mvId, request);
        try {
            machineItemService.expireMachineItem(userId, currentWarehouseId, mvId, request);

            return RestResponseV2.ofSuccess("Request submitted", null);
        } catch (Exception e) {
            log.warn("[expireMachineItem] Error: ", e);
            throw e;
        }
    }

}
