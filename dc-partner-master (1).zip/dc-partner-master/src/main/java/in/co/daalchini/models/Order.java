package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.untransportable.*;
import in.co.daalchini.service.helper.DateTimeHelper;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "orders")
public class Order {

    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "status")
    private OrderState status;

    @Column(name = "amount")
    private Double amount;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payment_id")
    private Payment payment;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "username")
    private String username;

    @Column(name = "email")
    private String email;

    @Column(name = "phone")
    private String phone;

    @Column(name = "coupon")
    private String coupon;

    @Column(name = "coupon_description")
    private String couponDescription;

    @Column(name = "cashback")
    private Double cashback;

    @JsonIgnoreProperties({"orders"})
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    @Column(name = "vending_machine_id")
    private Long vendingMachineId;

    @Column(name = "vending_machine_city")
    private String vendingMachineCity;

    @JsonIgnoreProperties({"order"})
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "order")
    private List<OrderLineItem> orderLineItems;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "cgst_rate")
    private Double cgstRate;

    @Column(name = "sgst_rate")
    private Double sgstRate;

    @Column(name = "txn_value")
    private Double txnValue;

    @Column(name = "is_cashback_credited")
    private Long isCashbackCredited;

    @Column(name = "source")
    private OrderSource source;

    @Column(name = "pickup_time")
    private LocalDateTime pickupTime;

    @Column(name = "dc_code")
    private String dcCode;

    @Column(name = "user_details_id")
    private Long userDetailsId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_details_id", insertable = false, updatable = false)
    private UserDetails userDetails;

    @Column(name = "hold_reset_done")
    private Boolean holdResetDone;

    @Column(name = "fulfillment_mode")
    private FulfillmentMode fulfillmentMode;

    @Column(name = "type")
    private OrderType type = OrderType.B2B;

    @Column(name = "user_type")
    private UserType userType = UserType.Partner;

    @JsonIgnore
    @LazyToOne(LazyToOneOption.NO_PROXY)
    @OneToOne(mappedBy = "order", fetch = FetchType.LAZY)
    private OrderDetail orderDetail;

    @Column(name = "code")
    private String code;

    @Column(name = "version")
    private Double version;

    @Column(name = "sub_status")
    private String subStatus;

    public Order(String id) {
        this.id = id;
    }

    public static Order of(String orderId) {
        return new Order(orderId);
    }

    @PrePersist
    void createTimestamp() {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp() {
        this.updatedAt = DateTimeHelper.now();
    }

    public String getEmail() {
        return PiiHelper.maskEmail(email);
    }

    public String getPhone() {
        return PiiHelper.maskPhone(phone);
    }

    @Override
    public String toString() {
        final String vmId = String.valueOf(vendingMachine.getId());
        return new StringJoiner(", ", Order.class.getSimpleName() + "[", "]")
                .add("id='" + id + "'")
                .add("status=" + status)
                .add("amount=" + amount)
                .add("userId=" + userId)
                .add("username='" + username + "'")
                .add("email='" + getEmail() + "'")
                .add("phone='" + getPhone() + "'")
                .add("coupon='" + coupon + "'")
                .add("couponDescription='" + couponDescription + "'")
                .add("cashback=" + cashback)
                .add("vendingMachine=" + vmId)
                .add("vendingMachineCity='" + vendingMachineCity + "'")
                .add("cgstRate=" + cgstRate)
                .add("sgstRate=" + sgstRate)
                .add("txnValue=" + txnValue)
                .add("isCashbackCredited=" + isCashbackCredited)
                .add("source='" + source + "'")
                .add("pickupTime=" + pickupTime)
                .add("dcCode='" + dcCode + "'")
                .add("userDetailsId=" + userDetailsId)
                .add("holdResetDone=" + holdResetDone)
                .add("code='" + code + "'")
                .add("version=" + version)
                .toString();
    }
}
