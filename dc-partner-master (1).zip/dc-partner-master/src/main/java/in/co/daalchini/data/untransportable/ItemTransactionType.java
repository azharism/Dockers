package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum ItemTransactionType {

    Incoming("incoming"),
    Outgoing("outgoing");

    private final @JsonValue String value;

    ItemTransactionType (String value) {
        this.value = value;
    }

    @JsonCreator
    public static ItemTransactionType of (String value) {
        return Stream.of(ItemTransactionType.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }
}
