package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.TreeSet;

@Data
@JsonIncludeProperties({"name", "machine_id_list", "promo_id_list"})
public class DtoPromoOverrideUpdateRequest {

    @Size(min = 3, max = 100)
    @NoLeadingAndTrailingSpace
    @JsonProperty("name")
    private String name;

    @Size(min = 1)
    @JsonProperty("machine_id_list")
    private TreeSet<Long> machineIdList;

    @Size(min = 1)
    @JsonProperty("promo_id_list")
    private TreeSet<Long> promoIdList;
}
