package in.co.daalchini.messaging;

import in.co.daalchini.data.transporatable.websocket.PaymentCompleteMessage;
import lombok.NonNull;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.HashMap;
import java.util.Optional;

@Log4j2
@Service
public class WebSocketService extends TextWebSocketHandler {

    private final HashMap<String, WebSocketSession> sessionMap = new HashMap<>();

    @Override
    public void handleTextMessage (@NonNull WebSocketSession session, @NonNull TextMessage inboundMessage) {
        log.info("session = {}, message = {}", session.getId(), inboundMessage);
        final String payload = inboundMessage.getPayload();
        log.debug("payload = {}", payload);

        String message = payload.equalsIgnoreCase("ping") ? "pong" : "ACK:" + payload;
        try {
            session.sendMessage(new TextMessage(message, true));
        } catch (IOException e) {
            log.error("Unable to send outbound message");
        }
    }

    @Override
    public void afterConnectionEstablished (@NonNull WebSocketSession session) throws Exception {
        super.afterConnectionEstablished(session);
        getSessionKey(session).ifPresent(key -> sessionMap.putIfAbsent(key, session));
        log.info("session established, sessionMap = {}", sessionMap);
    }

    @Override
    public void afterConnectionClosed (
        @NonNull WebSocketSession session,
        @NonNull CloseStatus status) throws Exception
    {
        super.afterConnectionClosed(session, status);
        getSessionKey(session).ifPresent(sessionMap::remove);
        log.info("session terminated, sessionMap = {}", sessionMap);
    }

    public void sendPaymentSuccessMessage (
        @NonNull String orderId,
        @NonNull String pgName,
        @NonNull String dcCode,
        String transactionId,
        Double balance)
    {
        sendMessage(orderId, pgName, true, dcCode, transactionId, balance);
    }

    public void sendPaymentFailureMessage (
        @NonNull String orderId, @NonNull String pgName)
    {
        sendMessage(orderId, pgName, true, null, null, null);
    }

    public void sendMessage (
        @NonNull String orderId,
        @NonNull String pgName,
        @NonNull Boolean success,
        String dcCode,
        String transactionId,
        Double balance)
    {
        log.debug("sendMessage, orderId = {}, pgName = {}, success = {}, dcCode = {}, transactionId = {}, balance = {}",
                  orderId, pgName, success, dcCode, transactionId, balance);
        try {
            final String sessionKey = generateSessionKey(orderId, pgName);
            final WebSocketSession session = sessionMap.get(sessionKey);
            final PaymentCompleteMessage messageWS =
                PaymentCompleteMessage
                    .builder()
                    .orderId(orderId)
                    .pgName(pgName)
                    .success(success)
                    .dcCode(dcCode)
                    .pgTxnId(transactionId)
                    .userBalance(balance)
                    .build();
            if (session != null) session.sendMessage(new TextMessage(messageWS.json()));
            else log.error("Session not found, sessionKey = {}", sessionKey);
        } catch (IOException e) {
            log.error("Unable to send outbound message");
        }
    }

    private Optional<String> getSessionKey (@NonNull WebSocketSession session) {
        String sessionKey = null;
        if (session.getUri() != null) {
            final MultiValueMap<String, String> queryParams =
                UriComponentsBuilder.fromUri(session.getUri()).build().getQueryParams();
            final String orderId = queryParams.getFirst("order_id");
            final String pgName = queryParams.getFirst("pg_name");
            log.info("orderId = {}, pgName = {}", orderId, pgName);
            sessionKey = generateSessionKey(orderId, pgName);
        }

        return Optional.ofNullable(sessionKey);
    }

    private String generateSessionKey (@NonNull String orderId, @NonNull String pgName) {
        String sessionKey = null;
        if (orderId != null && pgName != null) sessionKey = orderId + "_" + pgName;
        return sessionKey;
    }
}
