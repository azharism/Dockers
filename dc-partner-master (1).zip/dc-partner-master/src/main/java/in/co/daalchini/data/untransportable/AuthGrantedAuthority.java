package in.co.daalchini.data.untransportable;

import lombok.Data;
import org.springframework.security.core.GrantedAuthority;

@Data
public class AuthGrantedAuthority implements GrantedAuthority {

    private static final long serialVersionUID = -2819898514097069913L;

    private String authority;

    public static GrantedAuthority of (final String authority) {
        final AuthGrantedAuthority dto = new AuthGrantedAuthority();
        dto.setAuthority(authority);

        return dto;
    }

    @Override
    public String getAuthority () {
        return authority;
    }

    @Override
    public String toString () {
        return authority;
    }
}
