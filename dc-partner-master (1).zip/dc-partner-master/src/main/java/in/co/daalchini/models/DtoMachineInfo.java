package in.co.daalchini.models;

import org.springframework.beans.factory.annotation.Value;

public interface DtoMachineInfo {

    @Value("#{target.id}")
    Long getId();

    @Value("#{target.name}")
    String getName();
}
