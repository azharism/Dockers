package in.co.daalchini.data.transporatable.dashboard;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public final class DashboardResponse<T> {
    private String status;
    private String message;
    private T data;
}
