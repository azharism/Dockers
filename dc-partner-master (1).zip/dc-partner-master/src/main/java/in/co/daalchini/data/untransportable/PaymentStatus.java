package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import in.co.daalchini.data.transporatable.BankRefund;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum PaymentStatus {

    PROCESSING("processing"),
    INIT("init"),
    SUCCESS("success"),
    FAILED("FAILED"),
    NO_RESPONSE("NO_RESPONSE"),
    REFUND_FAILED("REFUND_FAILED"),
    REFUNDED_BACK("REFUNDED_BACK"),
    REFUND_MANUAL("REFUND_MANUAL");

    private final @JsonValue String value;

    PaymentStatus (String value) {
        this.value = value;
    }

    @JsonCreator
    public static PaymentStatus of (String status) {
        return Arrays.stream(PaymentStatus.values())
                     .filter(x -> x.value.equalsIgnoreCase(status))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return value;
    }
}
