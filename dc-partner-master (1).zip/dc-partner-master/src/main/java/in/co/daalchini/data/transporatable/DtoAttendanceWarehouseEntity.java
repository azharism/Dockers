package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.StringJoiner;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoAttendanceWarehouseEntity {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("entityId")
    private DtoAttendanceEntity entityId;

    @JsonProperty("warehouseId")
    private DtoAttendanceWarehouse warehouseId;


    @Override
    public String toString() {
        return new StringJoiner(", ", DtoAttendanceWarehouseEntity.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("entityId=" + (entityId == null ? null : entityId.getId()))
                .add("warehouseId=" + (warehouseId == null ? null : warehouseId.getId()))
                .toString();
    }
}
