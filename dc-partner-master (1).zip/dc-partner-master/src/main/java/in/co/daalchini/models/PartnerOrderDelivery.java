package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "partner_order_delivery")
public class PartnerOrderDelivery {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "partner_address_id")
    private Long partnerAddressId;

    @Column(name = "delivery_date_end")
    private LocalDateTime deliveryDateEnd;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "partner_address_id", updatable = false, insertable = false)
    private PartnerAddress partnerAddress;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public PartnerOrderDelivery (Long id) {
        this.id = id;
    }

    public static PartnerOrderDelivery of (Long id) {
        return new PartnerOrderDelivery(id);
    }

    @PrePersist
    void createTimestamp () {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp () {
        this.updatedAt = DateTimeHelper.now();
    }

    @Override
    public String toString () {
        return new StringJoiner(", ", PartnerOrderDelivery.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("partnerAddressId=" + partnerAddressId)
            .add("createdAt=" + createdAt)
            .add("updatedAt=" + updatedAt)
            .toString();
    }
}
