package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "corporate_domains")
@EntityListeners(AuditingEntityListener.class)
public class CorporateDomain {

    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "corporate_id")
    private Long corporateId;

    @Column(name = "domain")
    private String domain;

    @Column(name = "description")
    private String description;

    @Column(name = "initial_balance")
    private Double initialBalance;

    @Column(name = "active")
    private boolean active;

    @CreatedDate
    @Column(name = "created_timestamp")
    private LocalDateTime createdTimestamp;

    @LastModifiedDate
    @Column(name = "updated_timestamp")
    private LocalDateTime updatedTimestamp;

}
