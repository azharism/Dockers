package in.co.daalchini.data.transporatable;

import org.springframework.beans.factory.annotation.Value;

public interface ItemCountInfo {

    @Value("#{target.reserved_count}")
    int getReservedCount();

    @Value("#{target.expired_count}")
    int getExpiredCount();

    @Value("#{target.non_test_active_count}")
    int getNonTestActiveCount();

}
