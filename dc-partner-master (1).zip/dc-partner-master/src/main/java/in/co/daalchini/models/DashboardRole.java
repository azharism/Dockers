package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.List;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_user_roles")
public class DashboardRole {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Basic
    @Column(name = "name", unique = true)
    private String name;

    @Basic
    @Column(name = "description")
    private String description;

    @JsonIgnoreProperties({"dashboardRoles"})
    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "dashboardRoles")
    private List<DashboardUserPermission> dashboardUserPermissions;

    @JsonIgnoreProperties({"dashboardRole"})
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "dashboardRole")
    private List<DashboardUser> dashboardUsers;

    @JsonIgnore
    @Column(name = "created_at")
    private Instant createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private Instant updatedAt;

    public String getRoleName () {
        return name.toUpperCase();
    }

    @Override
    public String toString () {
        final String userId = dashboardUsers != null ? String.valueOf(dashboardUsers.size()) : "";
        return new StringJoiner(", ", DashboardRole.class.getSimpleName() + "[", "]")
            .add("id=" + this.id)
            .add("name='" + name + "'")
            .add("description='" + description + "'")
            .add("dashboardUser=" + userId)
            .toString();
    }
}
