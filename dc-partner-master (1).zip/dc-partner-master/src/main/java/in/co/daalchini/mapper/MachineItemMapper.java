package in.co.daalchini.mapper;


import in.co.daalchini.Interfaces.MachineItemSlotInfo;
import in.co.daalchini.data.feature.MachineItemDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static in.co.daalchini.data.feature.MachineItemDto.ItemPlacement;
import static in.co.daalchini.data.feature.MachineItemDto.ItemPlacementSlot;

@Mapper(componentModel = "spring")
public interface MachineItemMapper {

    @Mapping(target = "slotId", source = "slotId")
    @Mapping(target = "activeCount", source = "activeCount")
    ItemPlacementSlot toItemPlacementSlot(MachineItemDto.MachineItemSlotInfo slotInfo);


    default Collection<ItemPlacement> getItemPlacements(List<MachineItemSlotInfo> tuples, Map<Long, String> machineNameMap) {
        var responseMap = new HashMap<Long, ItemPlacement>();
        tuples.forEach(t -> {
            var si = t.toRecord();
            responseMap.putIfAbsent(si.machineId(), ItemPlacement.of(si.machineId(), machineNameMap.getOrDefault(si.machineId(), "")));
            responseMap.computeIfPresent(si.machineId(), (k, v) -> v.addSlot(toItemPlacementSlot(si)));
        });

        return responseMap.values();
    }
}
