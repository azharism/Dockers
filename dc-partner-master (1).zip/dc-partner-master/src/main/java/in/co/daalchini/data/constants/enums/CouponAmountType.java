package in.co.daalchini.data.constants.enums;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Objects;
import java.util.stream.Stream;

@Getter
public enum CouponAmountType {
    NotApplicable(0),
    Flat(1),
    Percentage(2);

    private final @JsonValue Integer value;

    CouponAmountType (int value) {this.value = value;}

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CouponAmountType of (Integer value) {
        return Stream.of(CouponAmountType.values())
                     .filter(x -> Objects.equals(x.value, value))
                     .findFirst()
                     .orElse(null);
    }
}
