package in.co.daalchini.controller;


import in.co.daalchini.data.constants.RouteConstants.UnblockSlotContext;
import in.co.daalchini.data.transporatable.BlockedSlotsReportInfo;
import in.co.daalchini.data.transporatable.SlotReportV2;
import in.co.daalchini.data.transporatable.SlotReported;
import in.co.daalchini.data.transporatable.UnblockSlotInfo.Request;
import in.co.daalchini.data.transporatable.UnblockSlotInfo.Response;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.UnblockSlotService;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;


@Log4j2
@RestController
public class UnblockSlotController {

    UnblockSlotService unblockSlotService;

    public UnblockSlotController(UnblockSlotService unblockSlotService) {
        this.unblockSlotService = unblockSlotService;
    }

    @PostMapping(value = UnblockSlotContext.UNBLOCK_SLOT)
    @PreAuthorize("hasAuthority('slot_repair') or hasAuthority('quick_unblock')")
    public Response unblockSlot(
            @RequestBody Request request,
            @AuthenticationPrincipal AuthUserDetails userDetails
    ) {
        try {
            return request.getShouldUnblock()
                    ? unblockSlotService.unblockAndPersist(request, userDetails)
                    : unblockSlotService.reportAndPersist(request, userDetails.getUserId());
        } catch (RuntimeException e) {
            log.error("[unblockSlot] error ", e);
            throw e;
        }
    }

    @GetMapping(value = UnblockSlotContext.SLOT_BLOCK_REPORT)
    @PreAuthorize("hasAuthority('slot_report')")
    public BlockedSlotsReportInfo.Response fetchBlockedSlotsReport(
            @RequestParam(value = "type") String type
    ) {
        try {
            return unblockSlotService.getSlotsReport(type);
        } catch (RuntimeException e) {
            log.warn("Error in fetching Report");
            throw e;
        }
    }

    @GetMapping(value = UnblockSlotContext.SLOT_ISSUE_REPORTED)
    public SlotReported.Response checkSlotReported(
            @RequestParam(value = "vmId") Long vmId,
            @RequestParam(value = "slotId") Integer slotId
    ) {
        try {
            return unblockSlotService.isSlotReported(vmId, slotId);
        } catch (RuntimeException e) {
            log.warn("Error in checking slot reported");
            throw e;
        }
    }

    @GetMapping(UnblockSlotContext.SLOT_BLOCK_REPORT_V2)
    @PreAuthorize("hasAuthority('slot_report')")
    public Collection<SlotReportV2.Response> getSlotsReportV2(
            @AuthenticationPrincipal AuthUserDetails authUserDetails,
            @PathVariable(value = "warehouseId") Long warehouseId,
            @RequestParam(value = "type") String type,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "offset", required = false) Integer offset
    ) {
        log.info("[getSlotsReportV2] warehouseId = {}", warehouseId);
        try {
            return unblockSlotService.getSlotsReportV2(warehouseId, type, offset, limit, authUserDetails);
        } catch (RuntimeException e) {
            log.warn("Error in fetching slots report v2", e);
            throw e;
        }
    }

}

