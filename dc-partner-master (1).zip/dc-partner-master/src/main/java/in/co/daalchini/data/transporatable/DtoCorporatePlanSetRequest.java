package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@Builder
@JsonIncludeProperties({"monthly", "add_on"})
public class DtoCorporatePlanSetRequest {

    @JsonProperty("monthly")
    private PlanMonthly monthly;

    @JsonProperty("add_on")
    private PlanAddOn addOn;


    @Data
    @Builder
    @JsonIncludeProperties({"name", "amount", "reset_balance"})
    public static class PlanMonthly {

        @Size(min = 3, max = 50)
        @NoLeadingAndTrailingSpace
        @JsonProperty("name")
        private String name;

        @NotNull
        @DecimalMin("1.0")
        @Digits(integer = 6, fraction = 2)
        @JsonProperty("amount")
        private Double amount;

        @NotNull
        @JsonProperty("reset_balance")
        public Boolean resetBalance;
    }

    @Data
    @Builder
    @JsonIncludeProperties({"name", "amount", "low_balance"})
    public static class PlanAddOn {

        @Size(min = 3, max = 50)
        @NoLeadingAndTrailingSpace
        @JsonProperty("name")
        private String name;

        @NotNull
        @DecimalMin("1.0")
        @Digits(integer = 6, fraction = 2)
        @JsonProperty("amount")
        private Double amount;

        @NotNull
        @DecimalMin("1.0")
        @Digits(integer = 5, fraction = 2)
        @JsonProperty("low_balance")
        public Double lowBalance;
    }
}
