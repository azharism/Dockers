package in.co.daalchini.mapper;


import in.co.daalchini.data.transporatable.RefillSuggestionDetails;
import in.co.daalchini.models.RefillSuggestionUrgencyScore;
import in.co.daalchini.models.VendingMachineAddress;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Mapper(componentModel = "spring")
public interface RefillSuggestionMapper {


    @Mapping(target = "machineName", source = "refillSuggestionUrgencyScore.vendingMachine.name")
    @Mapping(target = "machineAddress", source = "refillSuggestionUrgencyScore.vendingMachine.address", qualifiedByName = "getAddressString")
    @Mapping(target = "lastRefilled", source = "refillSuggestionUrgencyScore",qualifiedByName = "getLastRefilled")
    RefillSuggestionDetails toDto(RefillSuggestionUrgencyScore refillSuggestionUrgencyScore);

    List<RefillSuggestionDetails> toDto(List<RefillSuggestionUrgencyScore> refillSuggestionUrgencyScores);

    @Named("getAddressString")
    default String getAddressString(VendingMachineAddress vendingMachineAddress){
        return vendingMachineAddress.getAddressStr();
    }

    @Named("getLastRefilled")
    default Long getLastRefilled(RefillSuggestionUrgencyScore refillSuggestionUrgencyScore){
       return ChronoUnit.DAYS.between(refillSuggestionUrgencyScore.getLastRefilledDate(),LocalDate.now());
    }
}
