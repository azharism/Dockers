package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


public final class ProfileAddress {

    @Data
    public static final class Request {
        @NotEmpty(message = "save as cannot be empty")
        private String saveAs;
        private String landmark;
        @NotEmpty(message = "house Number cannot be empty")
        private String houseNumber;
        @NotEmpty(message = "street cannot be empty")
        private String street;
        private String locationUrl;
    }

    @Data
    @Builder
    public static final class Response {
        private Long addressId;
        private String street;
        private String landmark;
        private String houseNumber;
        private String locationUrl;
        private String saveAs;
    }
}
