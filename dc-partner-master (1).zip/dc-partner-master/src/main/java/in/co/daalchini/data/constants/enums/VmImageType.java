package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum VmImageType {
    Screensaver("screensaver"),
    Banner("banner"),
    Banner_Payment("banner_payment");

    private final @JsonValue String value;

    VmImageType (String value) {this.value = value;}

    @JsonCreator(mode = Mode.DELEGATING)
    public static VmImageType of (String value) {
        return Arrays.stream(VmImageType.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }
}
