package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum DurationUnit {

    Hour("hour"),
    Day("day"),
    Month("month");

    private final @JsonValue String value;

    DurationUnit(String value) {
        this.value = value;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static DurationUnit of (String value) {
        return Stream.of(DurationUnit.values())
                .filter(x -> x.value.equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }
}
