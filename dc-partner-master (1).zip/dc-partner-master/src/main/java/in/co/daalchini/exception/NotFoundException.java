package in.co.daalchini.exception;

public class NotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1210799400212601431L;

    public NotFoundException (String message) {
        super(message);
    }
}
