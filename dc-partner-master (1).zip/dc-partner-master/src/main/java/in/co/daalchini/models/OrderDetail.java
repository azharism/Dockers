package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.data.constants.enums.PriceType;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "order_details")
public class OrderDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "partner_id")
    private Long partnerId;

    @Column(name = "partner_pickup_id")
    private Long partnerOrderPickupId;

    @Column(name = "partner_delivery_id")
    private Long partnerOrderDeliveryId;

    @Column(name = "price_type")
    private PriceType priceType;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", insertable = false, updatable = false)
    private Order order;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "partner_id", insertable = false, updatable = false)
    private DashboardUser partner;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "partner_pickup_id", insertable = false, updatable = false)
    private PartnerOrderPickup partnerOrderPickup;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "partner_delivery_id", insertable = false, updatable = false)
    private PartnerOrderDelivery partnerOrderDelivery;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public OrderDetail (Long id) {
        this.id = id;
    }

    public static OrderDetail of (Long id) {
        return new OrderDetail(id);
    }

    @PrePersist
    void createTimestamp () {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp () {
        this.updatedAt = DateTimeHelper.now();
    }


    @Override
    public String toString () {
        return new StringJoiner(", ", OrderDetail.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("createdAt=" + createdAt)
            .add("updatedAt=" + updatedAt)
            .toString();
    }
}
