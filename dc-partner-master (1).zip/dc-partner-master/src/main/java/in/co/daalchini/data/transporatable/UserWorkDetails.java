package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class UserWorkDetails {

    @Data
    @Builder
    public static final class Response {
        @JsonProperty(value = "dashboard_user_id")
        private Long dashboardUserId;
        @JsonProperty(value = "name")
        private String name;
        @JsonProperty(value = "working_hours")
        private Long totalWorkingHours;
        @JsonProperty(value = "operation_details")
        private List<OperationWiseDetails> operationWiseDetails;
        @JsonProperty(value = "distinct_vms")
        private Long distinctVms;

    }

    @Data
    @Builder
    public static final class OperationWiseDetails {
        @JsonProperty(value = "operation_name")
        private String operationName;
        @JsonProperty(value = "item_quantity")
        private Long itemQuantity;

        public static List<OperationWiseDetails> of (Map<String, Long> refillMap){
            List<OperationWiseDetails> operationWiseDetailsList = new ArrayList<>();
            if(refillMap.isEmpty()){
                 return Collections.emptyList();
            }else {
                refillMap.forEach((key, value) -> operationWiseDetailsList.add(OperationWiseDetails.builder()
                        .operationName(key)
                        .itemQuantity(value)
                        .build()));
            }
            return operationWiseDetailsList;
        }
    }

}
