package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.StringJoiner;

@Entity
@Table(name = "dashboard_users_last_check_in_details")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"}, allowGetters = true)
public class DashboardUserLastCheckInDetailsModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "flag")
    private Integer flag;

    @Column(name = "dashboard_user_id")
    private Long dashboardUserId;

    @Column(name = "location_details_id")
    private Integer location_details_id;

    @ReadOnlyProperty
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_details_id", insertable = false, updatable = false)
    private LocationDetailsModel locationDetail;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_at")
    private Date createdAt;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated_at")
    private Date updatedAt;


    public Integer getId () {
        return id;
    }

    public void setId (Integer id) {
        this.id = id;
    }

    public Long getDashboard_user_id () {
        return dashboardUserId;
    }

    public void setDashboard_user_id (Long dashboard_user_id) {
        this.dashboardUserId = dashboard_user_id;
    }

    public Integer getLocation_details_id () {
        return location_details_id;
    }

    public void setLocation_details_id (Integer location_details_id) {
        this.location_details_id = location_details_id;
    }

    public Integer getFlag () {
        return flag;
    }

    public void setFlag (Integer flag) {
        this.flag = flag;
    }

    public Date getUpdatedAt () {
        return updatedAt;
    }

    public LocationDetailsModel getLocationDetail () {
        return locationDetail;
    }

    public void setLocationDetail (LocationDetailsModel locationDetail) {
        this.locationDetail = locationDetail;
    }

    @Override
    public String toString () {
        return new StringJoiner(", ", DashboardUserLastCheckInDetailsModel.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("flag=" + flag)
            .add("dashboardUserId=" + dashboardUserId)
            .add("location_details_id=" + location_details_id)
            .add("createdAt=" + createdAt)
            .add("updatedAt=" + updatedAt)
            .toString();
    }
}
