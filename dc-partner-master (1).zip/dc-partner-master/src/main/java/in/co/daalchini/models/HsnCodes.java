package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "hsn_codes")
@NamedQuery(name = "HsnCodes.findAll", query = "SELECT t FROM HsnCodes t")
public class HsnCodes implements Serializable {
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "value")
    private String value;

    @Column(name = "description")
    private String description;

    @Column(name = "sub_heading_id")
    private Long subHeadingId;

    @Column(name = "gst_rate")
    private Double gstRate;

    @Column(name = "cess_rate")
    private Double cessRate;

    @Column(name = "intra")
    private String intra;

    @Column(name = "inter")
    private String inter;
}
