package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "payment_config")
public class PaymentConfig implements Comparable<PaymentConfig> {

    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;

    @Column(name = "config_name")
    String configName;

    @OneToOne
    @JoinColumn(name = "payment_gateway_id")
    PaymentGateway paymentGateway;

    @Column(name = "merchant_key")
    String merchantKey;

    @Column(name = "merchant_id")
    String merchantId;

    @Column(name = "merchant_name")
    String merchantName;

    @Column(name = "aes_key")
    String aesKey;

    @Column(name = "display_text")
    String displayText;

    @Column(name = "key_1")
    String key1;

    @Column(name = "key_2")
    String key2;

    @Column(name = "key_3")
    String key3;

    @Column(name = "platform_name")
    String platformName;

    @Column(name = "operation_type")
    String operationType;

    @Column(name = "request_type")
    String requestType;

    @Column(name = "industry_type")
    String industryType;

    @Column(name = "created_by")
    Long createdBy;

    @JsonIgnore
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @JsonIgnore
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    String version;
    String json;

    @Override
    public int compareTo (PaymentConfig o) {
        return id.compareTo(o.id);
    }
}
