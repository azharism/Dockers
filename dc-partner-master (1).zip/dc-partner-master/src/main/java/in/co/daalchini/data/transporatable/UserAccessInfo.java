package in.co.daalchini.data.transporatable;

import org.springframework.beans.factory.annotation.Value;

import java.util.Objects;

public interface UserAccessInfo {

    @Value("#{target.mv_allowed}")
    Integer mvAllowed();

    @Value("#{target.vm_allowed}")
    Integer vmAllowed();

    default boolean isMvAllowed() {
        return Objects.equals(mvAllowed(), 1);
    }

    default boolean isVmAllowed() {
        return Objects.equals(vmAllowed(), 1);
    }

}
