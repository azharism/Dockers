package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder({"id","street","city_id","state_id","lat","lng","created_at","updated_at"})
@Entity
@Table(name = "manufacturers_addresses")
@EntityListeners(AuditingEntityListener.class)
public class ManufacturersAddress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "street")
    private String street;

    @Column(name = "city_id")
    private Integer city_id;

    @Column(name = "state_id")
    private Integer state_id;

    @Column(name = "lat")
    private Double lat;

    @Column(name = "lng")
    private Double lng;

    @JsonIgnore
    @Column(name = "address_line1", length = 250)
    private String addressLine1;

    @JsonIgnore
    @Column(name = "address_line2", length = 250)
    private String addressLine2;

    @JsonIgnore
    @Column(name = "is_default")
    private Boolean isDefault;

    @JsonIgnore
    @Column(name = "is_shipping")
    private Boolean isShipping;

    @JsonIgnore
    @Column(name = "is_billing")
    private Boolean isBilling;

    @JsonIgnore
    @Column(name = "gstin", length = 45)
    private String gstin;

    @JsonIgnore
    @Column(name = "fssai_number", length = 14)
    private String fssaiNumber;

    @JsonIgnore
    @Column(name = "active")
    private Boolean active;

    @Column(name = "manufacturer_id")
    private Long manufacturerId;

    @JsonProperty("created_at")
    @Column(name = "created_at")
    @CreationTimestamp
    private LocalDateTime createdAt;

    @JsonProperty("updated_at")
    @Column(name = "updated_at")
    @UpdateTimestamp
    private LocalDateTime updatedAt;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "manufacturer_id",insertable = false,updatable = false)
    private Manufactures manufactures;

}
