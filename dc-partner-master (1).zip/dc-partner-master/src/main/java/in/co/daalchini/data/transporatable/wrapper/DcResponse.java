package in.co.daalchini.data.transporatable.wrapper;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public final class DcResponse<T> {
    private String status;
    private String statusCode;
    private String statusMessage;
    private T response;
}
