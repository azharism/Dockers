package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vm_location_type")
public class LocationType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "location_name")
    private String name;

    @Column(name =  "image_url")
    private String imageUrl;

    @OneToOne(mappedBy = "locationType", fetch = FetchType.LAZY)
    private VendingMachineAddress vendingMachineAddress;
}
