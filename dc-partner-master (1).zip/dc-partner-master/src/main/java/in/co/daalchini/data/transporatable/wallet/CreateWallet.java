package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

import java.util.List;

public final class CreateWallet {

    @Data
    @Builder
    public static final class Request {
        private Long ownerId;
        private String subOwnerId;
        @Default
        private WalletType type = WalletType.Prepaid;
        @Default
        private WalletSubType subType = WalletSubType.Normal;
        @Default
        private OwnerType ownerType = OwnerType.User;
        private Double initialBalance;

        public static Request of(Long ownerId, String subOwnerId, Double initialBalance) {
            return Request.builder().ownerId(ownerId).subOwnerId(subOwnerId).initialBalance(initialBalance).build();
        }

        public static Request ofInternalCorporate(Long corporateId) {
            return CreateWallet.Request.builder()
                    .ownerId(corporateId)
                    .subOwnerId(null)
                    .ownerType(OwnerType.Corporate)
                    .type(WalletType.Overdraft)
                    .subType(WalletSubType.Internal)
                    .initialBalance(null)
                    .build();
        }
    }

    @Data
    @Builder
    public static final class IndexedRequest {
        private Integer index;
        private Long ownerId;
        private String subOwnerId;
        @Default
        private WalletType type = WalletType.Prepaid;
        @Default
        private WalletSubType subType = WalletSubType.Normal;
        @Default
        private OwnerType ownerType = OwnerType.User;
        private Double initialBalance;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private Boolean active;
        private Long walletId;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class BatchIndexResponse {
        private List<IndexResponse> successes;
        private List<IndexResponse> failures;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class IndexResponse {
        private Integer index;
        private String message;
        private Boolean active;
        private Long walletId;
    }
}
