package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum UserWorkDuration {
    week("week"),
    Month("month");

    private final @JsonValue String value;

    UserWorkDuration(String value){this.value = value;}

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static UserWorkDuration of (String value){
        return Arrays.stream(UserWorkDuration.values())
                .filter(x -> x.getValue().equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }
}
