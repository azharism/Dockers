
package in.co.daalchini.models;

import in.co.daalchini.data.untransportable.PaymentGatewayType;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;


@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Table(name = "payment_gateways")
public class PaymentGateway {

    @Id
    @Column(name = "id", updatable = false)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "kiosk_app_enabled")
    private boolean kioskAppEnabled;

    @Column(name = "consumer_app_enabled")
    private boolean consumerAppEnabled;

    @Column(name = "partner_app_enabled")
    private boolean partnerAppEnabled;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public PaymentGateway (Integer id) {
        this.id = id;
    }

    public static PaymentGateway of (PaymentGatewayType pgType) {
        return new PaymentGateway(pgType.getId());
    }

    public PaymentGatewayType toEnum () {
        return PaymentGatewayType.of(id);
    }

}
