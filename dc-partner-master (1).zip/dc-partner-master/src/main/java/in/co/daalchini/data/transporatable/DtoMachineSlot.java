package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Positive;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineSlot implements Comparable<DtoMachineSlot> {

    @Positive
    @JsonProperty("slot_id")
    private Long slotId;

    @Positive
    @JsonProperty("mv_id")
    private Long mvId;

    @Positive
    @JsonProperty("capacity")
    private Long capacity;

    @JsonIgnore
    private boolean active;

    @Override
    public int compareTo (DtoMachineSlot o) {
        return this.slotId.compareTo(o.getSlotId());
    }
}
