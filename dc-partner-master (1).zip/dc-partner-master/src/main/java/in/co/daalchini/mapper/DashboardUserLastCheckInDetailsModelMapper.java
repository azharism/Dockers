package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoLastCheckInEntity;
import in.co.daalchini.models.DashboardUserLastCheckInDetailsModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface DashboardUserLastCheckInDetailsModelMapper {

    @Mapping(target = "flag", source = "flag")
    @Mapping(target = "entityLat", source = "locationDetail.entityLat")
    @Mapping(target = "entityLng", source = "locationDetail.entityLng")
    @Mapping(target = "entityType", source = "locationDetail.entityAttribute.entityId.name")
    @Mapping(target = "vendingMachineName", source = "locationDetail.entityAttribute.vendingMachineId.name")
    @Mapping(target = "vendingMachineStreet", source = "locationDetail.entityAttribute.vendingMachineId.address.street")
    @Mapping(target = "warehouseName", source = "locationDetail.entityAttribute.warehouseId.name")
    @Mapping(target = "warehouseStreet", source = "locationDetail.entityAttribute.warehouseId.warehouseAddress.street")
    @Mapping(target = "vendorName", source = "locationDetail.entityAttribute.manufacturerId.name")
    DtoLastCheckInEntity toDto (DashboardUserLastCheckInDetailsModel model);
}
