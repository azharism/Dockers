package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.data.transporatable.GetKitInvoiceResponse;
import lombok.*;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@DynamicUpdate
@Table(name = "kit_invoices")
@EntityListeners(AuditingEntityListener.class)
public class KitInvoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "kit_id")
    private Long kitId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "series_id")
    private KitInvoiceSeries series;

    @Column(name = "serial_number")
    private String serialNumber;

    @Column(name = "data")
    private GetKitInvoiceResponse data;

    @JsonIgnore
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString () {
        return new StringJoiner(", ", KitInvoice.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("kitId=" + kitId)
            .add("serialNumber='" + serialNumber + "'")
            .add("createdAt=" + createdAt)
            .toString();
    }
}
