package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

import static in.co.daalchini.data.constants.DCConstants.RECHARGE_MV_SKG_ID;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@DynamicUpdate
@Table(name = "vending_machine_manufacturer_variant_sku_group_mappings")
@EntityListeners(AuditingEntityListener.class)
public class MachineManufacturerVariantSkuGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @With
    @Column(name = "active_count")
    private Long activeCount;

    @Column(name = "hold_count")
    private Long holdCount;

    @With
    @Column(name = "expiry_count")
    private Long expiryCount;

    @Column(name = "sku_group_id")
    private Long skuGroupId;

    @Column(name = "vending_machine_manufacturer_variant_id")
    private Long machineManufacturerVariantId;

    @Column(name = "is_active")
    private Boolean isActive;

    @JsonIgnore
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_manufacturer_variant_id", insertable = false, updatable = false)
    private MachineManufacturerVariant machineManufacturerVariant;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sku_group_id", insertable = false, updatable = false)
    private SkuGroup skuGroup;


    @Override
    public String toString () {
        return new StringJoiner(", ",
                                MachineManufacturerVariantSkuGroup.class.getSimpleName() + "[",
                                "]")
            .add("id=" + id)
            .add("activeCount=" + activeCount)
            .add("holdCount=" + holdCount)
            .toString();
    }

    public MachineManufacturerVariantSkuGroup releaseQuantity (Long quantity) {
        activeCount = activeCount + quantity;
        holdCount = holdCount - quantity;
        updatedAt = DateTimeHelper.now();

        return this;
    }

    public MachineManufacturerVariantSkuGroup holdQuantity (Long itemQuantity) {
        if (this.id != RECHARGE_MV_SKG_ID) {
            activeCount = activeCount - itemQuantity;
            holdCount = holdCount + itemQuantity;
        }

        return this;
    }

    public MachineManufacturerVariantSkuGroup saleReservedQuantity (Long reserved, Long sold) {
        activeCount = activeCount + reserved - sold;
        holdCount = holdCount - reserved;
        updatedAt = DateTimeHelper.now();

        return this;
    }
}
