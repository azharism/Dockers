package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

public final class SlotRefill {

    @Data
    @Builder
    public static final class Request {
        private Long vmId;
        private Long mvId;
        private Long kitId;
        private Long refillKitId;
        private Long itemQuantity;
        private Integer slotId;
        private Long skuGroupId;
        private Long vmSkuMapId;
        @Default private Integer vmMvMapId = 0;
        @Default private Integer sequence = 1;
        @Default private Integer holdCount = 0;
        @Default private String operationType = "fresh";
        @Default private Integer operationCode = 1;
    }
}
