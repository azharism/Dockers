package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

public class FCMTokenUpdate {


    @Data
    public static final class Response {
        private final boolean tokenUpdated;

        @Builder
        @JsonCreator
        public Response (
            @JsonProperty("tokenUpdated") boolean tokenUpdated)
        {
            this.tokenUpdated = tokenUpdated;
        }
    }
}
