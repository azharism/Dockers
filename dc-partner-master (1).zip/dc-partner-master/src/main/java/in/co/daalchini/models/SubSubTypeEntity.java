package in.co.daalchini.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "TypeSubSubType")
@Table(name = "type_sub_sub_type")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(value = {"created_at", "updated_at"}, 
        allowGetters = true)
public class SubSubTypeEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "type_subtype_id")
	private Integer typeOfSubTypeId;
	
	@Column(name = "sub_sub_type_tag_id")
	private String subSubTypeTagId;
	
	
	public String getSubSubTypeTagId() {
		return subSubTypeTagId;
	}

	public void setSubSubTypeTagId(String subSubTypeTagId) {
		this.subSubTypeTagId = subSubTypeTagId;
	}

	@Column(name = "sub_subtype_name")
	private String subSubtypeName;
	
	@Column(name = "sub_subtype_dec")
	private String subSubtypeDec;
	
	@Column(name = "sub_subtype_answer")
	private String subSubTypeAnswer;
	
	@Column(name = "field1_name")
	private String field1Name;
	
	@Column(name = "field2_name")
	private String field2Name;
	
	@Column(name = "field1_type")
	private String field1Type;
	
	@Column(name = "field2_type")
	private String field2Type;
	
	
	public String getField1Type() {
		return field1Type;
	}

	public void setField1Type(String field1Type) {
		this.field1Type = field1Type;
	}

	public String getField2Type() {
		return field2Type;
	}

	public void setField2Type(String field2Type) {
		this.field2Type = field2Type;
	}

	@Column(nullable = false, updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	private Date created_at;
	
	@Column(nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date updated_at;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTypeOfSubTypeId() {
		return typeOfSubTypeId;
	}

	public void setTypeOfSubTypeId(Integer typeOfSubTypeId) {
		this.typeOfSubTypeId = typeOfSubTypeId;
	}

	public String getSubSubtypeName() {
		return subSubtypeName;
	}

	public void setSubSubtypeName(String subSubtypeName) {
		this.subSubtypeName = subSubtypeName;
	}

	public String getSubSubtypeDec() {
		return subSubtypeDec;
	}

	public void setSubSubtypeDec(String subSubtypeDec) {
		this.subSubtypeDec = subSubtypeDec;
	}

	public String getSubSubTypeAnswer() {
		return subSubTypeAnswer;
	}

	public void setSubSubTypeAnswer(String subSubTypeAnswer) {
		this.subSubTypeAnswer = subSubTypeAnswer;
	}

	public String getField1Name() {
		return field1Name;
	}

	public void setField1Name(String field1Name) {
		this.field1Name = field1Name;
	}

	public String getField2Name() {
		return field2Name;
	}

	public void setField2Name(String field2Name) {
		this.field2Name = field2Name;
	}

	public Date getCreated_at() {
		return created_at;
	}

	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}

	public Date getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(Date updated_at) {
		this.updated_at = updated_at;
	}
	
	

}
