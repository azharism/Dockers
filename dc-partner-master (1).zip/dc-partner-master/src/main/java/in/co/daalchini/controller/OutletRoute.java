package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.OutletContext;
import in.co.daalchini.data.transporatable.CreateOrder;
import in.co.daalchini.data.transporatable.OutletInventory;
import in.co.daalchini.data.transporatable.OutletSearch;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.http.OrderService;
import in.co.daalchini.service.http.OutletService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.annotation.CurrentSecurityContext;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Log4j2
@RestController
public class OutletRoute {

    private final OutletService outletService;
    private final OrderService orderService;

    @Autowired
    public OutletRoute (
        OutletService outletService,
        OrderService orderService)
    {
        this.outletService = outletService;
        this.orderService = orderService;
    }

    @PreAuthorize("hasAuthority('bulk_purchase')")
    @GetMapping(OutletContext.OUTLET_SEARCH)
    public List<OutletSearch.Response> outletSearch (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @RequestParam(name = "lat") Double latitude,
        @RequestParam(name = "lng") Double longitude)
    {
        log.info("[outletSearch], userDetails = {}, latitude = {}, longitude = {}", userDetails, latitude, longitude);
        List<OutletSearch.Response> responses =
            outletService.searchOutlet(userDetails.getUserId(), latitude, longitude);

        log.info("[outletSearch], responses = {}", responses);
        return responses;
    }

    @PreAuthorize("hasAuthority('bulk_purchase')")
    @GetMapping(OutletContext.OUTLET_INVENTORY)
    public List<OutletInventory.Response> outletInventory (
        @PathVariable(name = "vmId") Long machineId)
    {
        log.info("[outletInventory], machineId = {}", machineId);
        List<OutletInventory.Response> responses = outletService.getOutletInventory(machineId);

        log.info("[outletInventory], responses = {}", responses);
        return responses;
    }

    @PreAuthorize("hasAuthority('bulk_purchase')")
    @PostMapping(OutletContext.OUTLET_ORDER_PLACE)
    public CreateOrder.Response orderPlace (
        @PathVariable(name = "vmId") Long machineId,
        @RequestParam(name = "vendor_price_enabled", required = false) Boolean vendorPriceEnabled,
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @RequestBody CreateOrder.Request request)
    {
        log.info("[orderPlace], userDetails = {}, machineId = {}, request = {}", userDetails, machineId, request);

        try {
            if(vendorPriceEnabled != null && vendorPriceEnabled &&
                    !userDetails.hasPermission("buy_at_vp")) {
                throw new AccessDeniedException("Permission required");
            }
            CreateOrder.Response response = orderService.createOrder(userDetails, machineId, request, vendorPriceEnabled);
            log.info("[orderPlace], responses = {}", response);
            return response;
        } catch (Exception e) {
            log.error("[orderPlace], error = ", e);
            throw e;
        }
    }

}
