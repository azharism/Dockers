package in.co.daalchini.exception;

public class ItemNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 5227468995814082187L;

    public ItemNotFoundException () {
        super();
    }

    public ItemNotFoundException (String message) {
        super(message);
    }

    public ItemNotFoundException (String message, Throwable cause) {
        super(message, cause);
    }

    public ItemNotFoundException (Throwable cause) {
        super(cause);
    }

    public static ItemNotFoundException of (String message) {
        return new ItemNotFoundException(message);
    }

}
