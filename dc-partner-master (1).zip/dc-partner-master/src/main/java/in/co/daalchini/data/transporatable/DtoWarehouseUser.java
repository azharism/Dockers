package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DtoWarehouseUser implements Comparable<DtoWarehouseUser> {

    @JsonProperty("wh_name")
    private String warehouseName;

    @JsonProperty("user_id")
    private Long userId;

    @JsonProperty("user_name")
    private String name;

    @JsonProperty("user_role")
    private String role;

    @JsonProperty("mmi_device_id")
    private String mmiDeviceId;

    @Override
    public int compareTo (DtoWarehouseUser that) {
        return this.userId.compareTo(that.userId);
    }
}
