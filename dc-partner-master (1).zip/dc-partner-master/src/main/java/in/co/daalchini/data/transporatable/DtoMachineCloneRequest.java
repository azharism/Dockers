package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineCloneRequest {

    @NotNull
    @Size(max = 50)
    @JsonProperty("name")
    private String name;


    @NotNull
    @JsonProperty("serial_number")
    private String serialNumber;

    @NotNull
    @Valid
    @JsonProperty("address")
    private DtoMachineAddress address;
}
