package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum BpUnlinkStatus {

    NEW("NEW"),
    REJECTED("REJECTED"),
    APPROVED("APPROVED");
    private final @JsonValue String value;

    BpUnlinkStatus (String value) {
        this.value = value;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static BpUnlinkStatus of (final String valueStr) {
        return Stream.of(BpUnlinkStatus.values())
                     .filter(x -> x.value.equalsIgnoreCase(valueStr))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return value;
    }
}
