package in.co.daalchini.data.constants;

import org.springframework.stereotype.Component;

import java.time.Clock;

import static in.co.daalchini.data.constants.GeneralConstants.TIME_ZONE_ID_INDIA;
import static in.co.daalchini.data.constants.GeneralConstants.TIME_ZONE_ID_UTC;


@Component
public class TimeZoneClock {

    public Clock indianClock () {
        return Clock.system(TIME_ZONE_ID_INDIA);
    }

    public Clock utcClock () {
        return Clock.system(TIME_ZONE_ID_UTC);
    }

}
