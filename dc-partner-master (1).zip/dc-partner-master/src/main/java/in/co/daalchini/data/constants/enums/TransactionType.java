package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum TransactionType {
    AddMoney("money_add", true),
    Payment("payment", false),
    Refund("refund", true),
    Withdrawal("withdraw", false),
    ExtendLimit("limit_extent", true),
    ReduceLimit("limit_reduce", false);

    private final String value;
    private final boolean isCredit;

    TransactionType(final String value, boolean isCredit) {
        this.value = value;
        this.isCredit = isCredit;
    }

    @JsonValue
    public String value () {
        return value;
    }

    @JsonCreator(mode = Mode.DELEGATING)
    public static TransactionType of (final String valueStr) {
        return Arrays.stream(TransactionType.values())
                     .filter(x -> x.value.equalsIgnoreCase(valueStr))
                     .findAny()
                     .orElse(null);
    }
}
