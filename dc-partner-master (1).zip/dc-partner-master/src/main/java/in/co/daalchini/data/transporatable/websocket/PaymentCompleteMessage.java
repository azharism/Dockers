package in.co.daalchini.data.transporatable.websocket;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentCompleteMessage {

    @JsonProperty("orderId")
    private String orderId;

    @JsonProperty("pgName")
    private String pgName;

    @JsonProperty("success")
    private boolean success;

    @JsonProperty("dcCode")
    private String dcCode;

    @JsonProperty("pgTxnId")
    private String pgTxnId;

    @JsonProperty("userBalance")
    private Double userBalance;

    public String json () {
        return JsonUtil.toJson(this);
    }
}
