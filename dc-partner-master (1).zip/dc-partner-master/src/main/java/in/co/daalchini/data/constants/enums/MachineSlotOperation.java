package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum MachineSlotOperation {
    Add("add"),
    Remove("remove");

    private final @JsonValue String value;

    MachineSlotOperation(String value) {
        this.value = value;
    }

    @JsonCreator(mode = Mode.DELEGATING)
    public static MachineSlotOperation of(String value) {
        return Arrays.stream(MachineSlotOperation.values())
                .filter(x -> x.value.equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }
}
