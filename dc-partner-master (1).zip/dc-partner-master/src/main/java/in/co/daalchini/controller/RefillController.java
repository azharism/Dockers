package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.RefillContext;
import in.co.daalchini.data.constants.DCConstants;
import in.co.daalchini.models.RefillDetailsReqResHelper;
import in.co.daalchini.models.RefillReqResHelper;
import in.co.daalchini.models.request.DCRequest;
import in.co.daalchini.models.request.RefillRequest;
import in.co.daalchini.models.response.DCResponse;
import in.co.daalchini.service.RefillDetailsService;
import in.co.daalchini.service.RefillService;
import in.co.daalchini.service.RefillTypeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RefillController {

	private static Logger log = LoggerFactory.getLogger(RefillController.class);
	
	private RefillService refillService;
	private RefillDetailsService refillDetailsService;
	private RefillTypeService refillTypeService;
	
	@Autowired
	public RefillController(RefillService refillService, RefillDetailsService refillDetailsService, RefillTypeService refillTypeService) {
		this.refillService = refillService;
		this.refillDetailsService = refillDetailsService;
		this.refillTypeService = refillTypeService;
	}
	
	@RequestMapping(path = RefillContext.BASE)
	public DCResponse<Boolean> refillHandler(@RequestBody DCRequest<RefillRequest> request){

		log.info("[refillHandler] : Inside Controller");
		DCResponse<Boolean> response = new DCResponse<>();
//		RefillResponse refillResponse = null;
		Boolean resp = false;
		try {
			
			if (request == null || request.getRequest() == null) {
				response.setStatusCode(DCConstants.API_FAILURE_CODE_NULL_REQUEST);
				throw new NullPointerException("Null Request");
			}
			if(request.getRequest().getRefillHelper() == null || request.getRequest().getRefillDetailsHelper() == null || request.getRequest().getRefillDetailsHelper().size()<1) {
				response.setStatusCode(DCConstants.API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST);
				throw new NullPointerException("Request Parameters Missing");
			}

			validateRequestRefill(request.getRequest().getRefillHelper());
			List<Long> idList = this.refillTypeService.getDistinctRefilTypesById();		//check for valid refill_types
			validateRequestRefillDetails(request.getRequest().getRefillDetailsHelper(), idList);

			Long id = this.refillService.persist(request.getRequest().getRefillHelper());
			resp = this.refillDetailsService.persist(request.getRequest().getRefillDetailsHelper(), id);
			
			response.setData(true);
			response.setStatus(DCConstants.API_SUCCESS);
			response.setStatusCode(DCConstants.API_SUCCESS_CODE);
			if(resp)
				response.setStatusMessage("RECORD SUCCESSFULLY SAVED");
			else 
				response.setStatusMessage("RECORD NOT SAVED");
		} catch (NullPointerException e) {

			response.setData(false);
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusCode(DCConstants.API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST);
			response.setStatusMessage(e.getMessage());
			log.error("[refillHandler] : " + e.getMessage());
			e.printStackTrace();

		} catch (Exception e) {

			response.setData(false);
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
			response.setStatusMessage(e.getMessage());
			log.error("[refillHandler] : " + e.getMessage());
			e.printStackTrace();
		}

		return response;
	}
	
	private void validateRequestRefillDetails(List<RefillDetailsReqResHelper> refillList, List<Long> idList) throws Exception{
		
		for(RefillDetailsReqResHelper req : refillList) {
			if(req.getSlot() == null) throw new NullPointerException(" REFILL DETAILS : Empty SLOT recieved");
			if(req.getRefillType() == null) throw new NullPointerException(" REFILL DETAILS : Empty REFILL TYPE recieved");
			if(req.getManufacturerVariant() == null) throw new NullPointerException(" REFILL DETAILS : Empty MANUFACTURER CODE recieved");
			if(req.getFinalQuantity() == null || req.getFinalQuantity()<0) throw new NullPointerException(" REFILL DETAILS : Empty or less than 0 Final Quantity recieved");
			if(req.getImpactedQuantity() == null || req.getImpactedQuantity()<0) throw new NullPointerException(" REFILL DETAILS : Empty or less than 0 Impacted Quantity recieved");
			if(!idList.contains(req.getRefillType())) throw new Exception("REFILL DETAILS : Invalid Refill Type Value : " + req.getRefillType()); 
		}
	}

	private void validateRequestRefill(RefillReqResHelper req) throws NullPointerException{
		if(req.getVendingMachine() == null) throw new NullPointerException(" REFILL : NULL VENDING MACHINE RECIEVED");
	}

}