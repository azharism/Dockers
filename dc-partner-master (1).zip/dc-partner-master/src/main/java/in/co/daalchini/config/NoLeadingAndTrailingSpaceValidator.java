package in.co.daalchini.config;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;


public class NoLeadingAndTrailingSpaceValidator implements ConstraintValidator<NoLeadingAndTrailingSpace, String> {

    @Override
    public void initialize (final NoLeadingAndTrailingSpace constraintAnnotation) {
    }

    @Override
    public boolean isValid (final String content, final ConstraintValidatorContext context) {
        if (content == null || content.length() == 0) return true;

        var letters = content.toCharArray();
        return !Character.isWhitespace(letters[0])
            && !Character.isWhitespace(letters[content.length() - 1]);
    }
}
