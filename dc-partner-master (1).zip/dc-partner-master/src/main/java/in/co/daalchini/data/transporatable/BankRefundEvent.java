package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.transporatable.message.Jsonable;
import in.co.daalchini.data.untransportable.PaymentGatewayType;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankRefundEvent implements Jsonable {
    @JsonProperty("userId")
    private Long userId;
    @JsonProperty("pgName")
    private PaymentGatewayType pgName;
    @JsonProperty("orderId")
    private String orderId;
    @JsonProperty("refundAmount")
    private Double refundAmount;
    @JsonProperty("reason")
    private String reason;

    public String json () {
        return JsonUtil.toJson(this);
    }

}
