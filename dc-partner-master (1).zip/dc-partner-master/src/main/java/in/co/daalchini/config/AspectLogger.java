package in.co.daalchini.config;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Component
public class AspectLogger {

    @Around("execution(* in.co.daalchini.controller..*(..)))")
    public Object logIngressRoutes (ProceedingJoinPoint joinPoint) throws Throwable
    {
        final var signature = (MethodSignature) joinPoint.getSignature();
        final var log = LoggerFactory.getLogger(signature.getDeclaringType());
        final var name = signature.getName();

        log.info("[{}] arguments = {}", name, Arrays.toString(joinPoint.getArgs()));
        var result = joinPoint.proceed();
        log.info("[{}] result = {}", name, result);

        return result;
    }
}
