package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

import java.util.List;

public class LastRefillDetails {

    @Builder
    @Data
    public static class Response {
       private List<KitRefillDetails> kitRefillDetails;
       private Integer kitItemQuantity;
    }

    @Builder
    @Data
    public static class KitRefillDetails{
        private Long slotIdentifier;
        private Integer itemQuantity;
        private String operationType;
        private String variant;
    }
}
