package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.KitInvoiceContext;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.service.KitInvoiceService;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Log4j2
@RestController
public class KitInvoiceRoute {

    private final KitInvoiceService kitInvoiceService;

    public KitInvoiceRoute (KitInvoiceService kitInvoiceService) {
        this.kitInvoiceService = kitInvoiceService;
    }

    @PreAuthorize("hasAnyAuthority('vm_allowed')")
    @PostMapping(KitInvoiceContext.WAREHOUSE_INVOICE_KIT)
    public RestResponseV2<GetKitInvoiceResponse> generateAndGetWarehouseInvoiceKit (
        @PathVariable("warehouseId") Long warehouseId,
        @PathVariable("kitId") Long kitId)
    {
        return RestResponseV2.ofSuccess(kitInvoiceService.generateKitInvoice(warehouseId, kitId));
    }

    @PreAuthorize("hasAnyAuthority('vm_allowed')")
    @GetMapping(KitInvoiceContext.WAREHOUSE_SEZ_LOCATION)
    public RestResponseV2<GetWarehouseSezLocationResponse> getSezAddressForWarehouse (
        @PathVariable("warehouseId") Long warehouseId)
    {
        return RestResponseV2.ofSuccess(kitInvoiceService.fetchAddresses(warehouseId));
    }

    @PreAuthorize("hasAnyAuthority('vm_allowed')")
    @PatchMapping(KitInvoiceContext.WAREHOUSE_WITH_ID)
    public RestResponseV2<DtoWarehouseLocation> updateWarehouseLocation (
        @PathVariable("warehouseId") Long warehouseId,
        @RequestBody UpdateWarehouseLocationRequest request)
    {
        return RestResponseV2.ofSuccess(kitInvoiceService.updateWarehouseLocation(warehouseId, request));
    }

    @PreAuthorize("hasAnyAuthority('vm_allowed')")
    @PostMapping(KitInvoiceContext.WAREHOUSE_SEZ_LOCATION)
    public RestResponseV2<DtoWarehouseSezLocation> addWarehouseLocationSez (
        @PathVariable("warehouseId") Long warehouseId,
        @RequestBody AddWarehouseSezLocationRequest request)
    {
        return RestResponseV2.ofSuccess(kitInvoiceService.addWarehouseSezLocation(warehouseId, request));
    }

    @PreAuthorize("hasAnyAuthority('vm_allowed')")
    @PatchMapping(KitInvoiceContext.WAREHOUSE_SEZ_LOCATION_ID)
    public RestResponseV2<DtoWarehouseSezLocation> updateWarehouseLocationSez (
        @PathVariable("warehouseId") Long warehouseId,
        @PathVariable("locationId") Long locationId,
        @RequestBody UpdateWarehouseSezLocationRequest request)
    {
        return RestResponseV2.ofSuccess(kitInvoiceService.updateWarehouseSezLocation(warehouseId, locationId, request));
    }
}
