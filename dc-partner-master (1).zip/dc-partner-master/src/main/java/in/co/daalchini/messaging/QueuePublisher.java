package in.co.daalchini.messaging;

import in.co.daalchini.data.constants.GeneralConstants;
import in.co.daalchini.data.transporatable.BankRefund;
import in.co.daalchini.data.transporatable.BankRefundEvent;
import in.co.daalchini.data.transporatable.InventoryChangeEvent;
import in.co.daalchini.data.transporatable.message.DeactivateBpUserEvent;
import in.co.daalchini.data.transporatable.message.PartnerDueEvent;
import in.co.daalchini.data.transporatable.message.SendNotificationEvent;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import static in.co.daalchini.data.constants.GeneralConstants.BrokerConfig.*;

@Log4j2
@Service
public class QueuePublisher {
    private final JmsTemplate jmsQueueTemplate;

    @Autowired
    public QueuePublisher (@Qualifier("jmsQueueTemplate") JmsTemplate jmsTopicTemplate) {
        this.jmsQueueTemplate = jmsTopicTemplate;
    }

    public void publishSendNotificationEvent (SendNotificationEvent event) {
        try {
            final MessageCreator messageCreator = session -> createSendNotificationMessage(session, event);
            jmsQueueTemplate.send(GeneralConstants.BrokerConfig.QUEUE_SEND_NOTIFICATION, messageCreator);
        } catch (Exception e) {
            log.warn("Unable to publish event");
        }
    }

    private Message createSendNotificationMessage (
        final Session session, final SendNotificationEvent event) throws JMSException
    {
        final String jsonBody = event.json();
        log.debug("preparing message for publish = {}", jsonBody);
        return session.createTextMessage(jsonBody);
    }

    public void publishDeactivateBpUserEvent (DeactivateBpUserEvent event) {
        try {
            final MessageCreator messageCreator = session -> createDeactivateBpUserMessage(session, event);
            jmsQueueTemplate.send(GeneralConstants.BrokerConfig.QUEUE_DEACTIVATE_BP_USER, messageCreator);
        } catch (Exception e) {
            log.warn("Unable to publish event");
        }
    }
    public void publishBankRefundEvent(BankRefundEvent bankRefundEvent) {
        try {
            jmsQueueTemplate.convertAndSend(GeneralConstants.BrokerConfig.QUEUE_BANK_REFUND, bankRefundEvent);
        } catch (Exception e) {
            log.warn("Unable to publish message", e);
        }
    }

    private Message createDeactivateBpUserMessage (
        final Session session, final DeactivateBpUserEvent event) throws JMSException
    {
        final String jsonBody = event.json();
        log.debug("preparing message for publish = {}", jsonBody);
        return session.createTextMessage(jsonBody);

    }

    private Message createDeRegisterBpUnlinkRequest (
        final Session session, final BpDeregisterChangeEvent event) throws JMSException
    {
        final String jsonBody = event.json();
        log.debug("preparing message for publish = {}", jsonBody);
        return session.createTextMessage(jsonBody);

    }

    public void publishPartnerDue (PartnerDueEvent event) {
        try {
            jmsQueueTemplate.convertAndSend(GeneralConstants.BrokerConfig.QUEUE_PARTNER_DUE, event);
        } catch (Exception e) {
            log.warn("Unable to publish message", e);
        }
    }

    public void publishHoldQuantityChangeEvent (InventoryChangeEvent event) {
        try {
            jmsQueueTemplate.convertAndSend(QUEUE_INVENTORY_HOLD_QUANTITY_CHANGE, event);
        } catch (Exception e) {
            log.warn("Unable to publish message", e);
        }
    }

    public void publishActiveQuantityChangeEvent (InventoryChangeEvent event) {
        try {
            jmsQueueTemplate.convertAndSend(QUEUE_INVENTORY_ACTIVE_QUANTITY_CHANGE, event);
        } catch (Exception e) {
            log.warn("Unable to publish message", e);
        }
    }

    public void publishApproveBpUnlinkRequest (BpDeregisterChangeEvent event) {
        try {
            jmsQueueTemplate.convertAndSend(QUEUE_DEREGISTER_BP_USER, event);
        } catch (Exception e) {
            log.warn("Unable to publish event");
        }
    }
}
