package in.co.daalchini.models;


import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.StringJoiner;

@Immutable
@Entity
@Getter
@RequiredArgsConstructor
@Table(name = "user_wallets")
public class UserWallet {

    @Id
    @Column(name = "id", insertable = false, updatable = false)
    private Long id;

    @Column(name = "owner_id", insertable = false, updatable = false)
    private Long ownerId;

    @Column(name = "sub_owner_id", insertable = false, updatable = false)
    private String subOwnerId;

    @Column(name = "owner_type", insertable = false, updatable = false)
    private String ownerType;

    @Column(name = "type", insertable = false, updatable = false)
    private String type;

    @Column(name = "sub_type", insertable = false, updatable = false)
    private String subType;

    @Column(name = "balance", insertable = false, updatable = false)
    private Double balance;

    @Column(name = "active", insertable = false, updatable = false)
    private boolean active;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "owner_id", insertable = false, updatable = false)
    private UserDetails userDetails;

    @Override
    public String toString () {
        return new StringJoiner(", ", UserWallet.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("ownerId=" + ownerId)
            .add("subOwnerId='" + subOwnerId + "'")
            .add("ownerType='" + ownerType + "'")
            .add("type='" + type + "'")
            .add("subType='" + subType + "'")
            .add("balance=" + balance)
            .add("active=" + active)
            .toString();
    }
}
