package in.co.daalchini.exception;

import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import javax.validation.ConstraintViolationException;
import java.io.IOException;

@Log4j2
@RestControllerAdvice
public class RestExceptionHandler {

    @ExceptionHandler(value = {IOException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> badRequest(IOException ex) {
        log.warn("Uncaught exception", ex);
        return RestResponse.ofFailure(400, "Bad Request");
    }


    @ExceptionHandler(value = {ItemNotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public RestResponse<Object> ItemNotFoundException(ItemNotFoundException ex) {
        log.warn("ItemNotFoundException", ex);
        return RestResponse.ofFailure(404, ex.getMessage());
    }

    @ExceptionHandler(value = {MethodArgumentTypeMismatchException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> typeMismatch(MethodArgumentTypeMismatchException ex) {
        log.warn("MethodArgumentTypeMismatchException", ex);
        return RestResponse.ofFailure(400, "Bad Request");
    }

    @ExceptionHandler(value = {HttpMessageNotReadableException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> httpMessageNotReadable(HttpMessageNotReadableException ex) {
        log.warn("HttpMessageNotReadableException", ex);
        return RestResponse.ofFailure(400, "Invalid request body");
    }

    @ExceptionHandler(value = {IllegalArgumentException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> illegalArgument(IllegalArgumentException ex) {
        log.warn("IllegalArgumentException", ex);
        return RestResponse.ofFailure(400, ex.getMessage());
    }

    @ExceptionHandler(value = {MissingServletRequestParameterException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> missingServletRequestParameterException(MissingServletRequestParameterException ex) {
        log.warn("MissingServletRequestParameterException", ex);
        return RestResponse.ofFailure(400, ex.getMessage());
    }

    @ExceptionHandler(value = {ConstraintViolationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> constraintViolationException(ConstraintViolationException ex) {
        var errorMessage =
                ex.getConstraintViolations()
                        .stream()
                        .findFirst().map(v -> String.format("%s: %s", v.getMessage(), v.getInvalidValue()))
                        .orElse(ex.getMessage());
        log.warn("ConstraintViolationException", ex);
        return RestResponse.ofFailure(400, errorMessage);
    }

    @ExceptionHandler(value = {MethodArgumentNotValidException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> argumentNotValid(MethodArgumentNotValidException ex) {
        log.warn("MethodArgumentNotValidException", ex);
        String errorMessage =
                ex.getBindingResult()
                        .getFieldErrors()
                        .stream()
                        .findFirst()
                        .map(x -> String.format("%s %s", x.getField(), x.getDefaultMessage()))
                        .orElse("Bad Request");

        return RestResponse.ofFailure(400, errorMessage);
    }

    @ExceptionHandler(value = {AccessDeniedException.class})
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public RestResponse<Object> accessDenied(Exception ex) {
        log.warn("AccessDeniedException", ex);
        return RestResponse.ofFailure(403, ex.getMessage());
    }

    @ExceptionHandler(value = {BusinessException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> businessError(Exception ex) {
        log.warn("Uncaught business exception", ex);
        return RestResponse.ofFailure(400, ex.getMessage());
    }

    @ExceptionHandler(value = {BadRequestException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public RestResponse<Object> badRequestException(BadRequestException ex) {
        log.warn("bad request exception", ex);
        return RestResponse.ofFailure(400, ex.getMessage());
    }

    @ExceptionHandler(value = {NotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public RestResponse<Object> badRequestException(NotFoundException ex) {
        log.warn("not found exception", ex);
        return RestResponse.ofFailure(404, ex.getMessage());
    }

    @ExceptionHandler(value = {RuntimeException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public RestResponse<Object> unKnownException(Exception ex) {
        log.warn("Uncaught runtime exception", ex);
        return RestResponse.ofFailure(500, "Something went wrong!");
    }
}
