package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum OrderSource {

    ConsumerApp("consumer_app_nodejs"),
    ConsumerWeb("consumer_web"),
    ConsumerAppDelivery("consumer_app_delivery"),
    VendingMachine("vending_java"),
    PartnerApp("partner_app"),
    MachineV2("machine_v2");

    private final @JsonValue String value;

    OrderSource (String value) {
        this.value = value;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static OrderSource of (String value) {
        return Stream.of(OrderSource.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return value;
    }
}
