package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public final class Status {
    private Integer code;
    private String message;
}
