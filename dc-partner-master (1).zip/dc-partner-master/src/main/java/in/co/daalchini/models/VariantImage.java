package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the variant_images database table.
 * 
 */
@Entity
@Table(name="variant_images")
@NamedQueries({
	@NamedQuery(name="VariantImage.findAll", query="SELECT v FROM VariantImage v"),
	@NamedQuery(name="VariantImage.findById", query="SELECT v FROM VariantImage v where v.id=:id"),
	@NamedQuery(name="VariantImage.findByVariantId", query="SELECT v FROM VariantImage v where v.variant.id =:variant")
})
public class VariantImage implements Serializable {

	private static final long serialVersionUID = 5966095391723050955L;

	@Id
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_at")
	private Date createdAt;

	@Column(name="image_id")
	private String imageId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_at")
	private Date updatedAt;

	//bi-directional many-to-one association to Variant
	@JsonIgnoreProperties({"variantImages"})
	@ManyToOne
	private Variant variant;

	public VariantImage() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getImageId() {
		return this.imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Variant getVariant() {
		return this.variant;
	}

	public void setVariant(Variant variant) {
		this.variant = variant;
	}

}
