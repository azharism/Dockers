package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_corporate_mappings")
public class UserCorporateMapping {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "corporate_id")
    private Long corporateId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "users_corporate_id")
    private String usersCorporateId;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "email_id")
    private String emailId;

    @Column(name = "business")
    private String business;

    @Column(name = "last_file_name")
    private String lastFileName;

    @Column(name = "unlink_request_id")
    private Long unlinkRequestId;

    @Column(name = "status")
    private boolean active;

    @Column(name = "created_timestamp", insertable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_timestamp", insertable = false)
    private LocalDateTime updatedAt;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "unlink_request_id", insertable = false, updatable = false)
    private BpUnlinkRequest unlinkRequest;

    @JsonIgnore
    @OneToOne
    @JoinColumn(name = "user_id", updatable = false, insertable = false)
    private UserDetails userDetails;

    public Boolean getStatus() {
        return this.active;
    }

    public void setStatus(final Short status) {
        switch (status) {
            case 0: {
                this.active = false;
                break;
            }
            case 1:
            default: {
                this.active = true;
            }
        }
    }

    public String getEmailId() {
        return PiiHelper.maskEmail(emailId);
    }

    public String getEmailIdUnmasked() {
        return emailId;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", UserCorporateMapping.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("corporateId=" + corporateId)
                .add("userId=" + userId)
                .add("usersCorporateId='" + usersCorporateId + "'")
                .add("userName='" + userName + "'")
                .add("emailId='" + getEmailId() + "'")
                .add("business='" + business + "'")
                .add("lastFileName='" + lastFileName + "'")
                .add("active=" + active)
                .toString();
    }
}
