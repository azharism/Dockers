package in.co.daalchini.data.transporatable;

import lombok.*;

import java.util.List;

public class BlockedSlotsReportInfo {


    @Builder
    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Response {

        private List<SlotResolvedReport> slotResolvedList;
        private List<SlotBlockedReport> sLotBlockedList;

        public static Response of(List<SlotResolvedReport> resolvedSlots, List<SlotBlockedReport> blockedSlots) {
            return BlockedSlotsReportInfo.Response.builder().slotResolvedList(resolvedSlots).sLotBlockedList(blockedSlots).build();
        }
    }
}
