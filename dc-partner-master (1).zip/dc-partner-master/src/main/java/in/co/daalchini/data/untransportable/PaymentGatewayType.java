package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum PaymentGatewayType {

    PG_PAYTM(1, "PAYTM"),
    PG_RAZORPAY(2, "RAZORPAY"),
    CORPORATE_OTP(3, "CORPORATE_OTP"),
    QR_PAYTM(4, "QR_PAYTM"),
    BHARAT_QR(6, "BHARAT_QR"),
    SODEXO_QR(7, "SODEXO_QR"),
    WALLET(8, "WALLET"),
    WALLET_LOYALTY(9, "WALLET_LOYALTY"),
    PAYTM_UPI(10, "PAYTM_UPI"),
    WALLET_RFID(11, "WALLET_RFID"),
    WALLET_PARTNER(12, "WALLET_PARTNER"),
    CASH(13, "CASH"),
    SODEXO(14, "SODEXO"),
    PHONEPE_QR(15, "PHONEPE_QR"),
    RAZORPAY_LINK(16, "RAZORPAY_LINK"),
    CORPORATE_OTP_EMAIL(-1, "CORPORATE_OTP_EMAIL");

    private final Integer id;
    private final @JsonValue String pgName;


    PaymentGatewayType (Integer id, String pgName) {
        this.id = id;
        this.pgName = pgName;
    }

    /**
     * Find payment gateway by type
     *
     * @param type String value of payment gateway
     * @return PaymentGatewayType enum
     */
    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static PaymentGatewayType of (String type) {
        return Arrays.stream(PaymentGatewayType.values())
                     .filter(x -> x.pgName.equalsIgnoreCase(type))
                     .findFirst()
                     .orElse(null);
    }

    /**
     * Find payment gateway by id
     *
     * @param id Payment gateway number
     * @return PaymentGatewayType enum
     */
    public static PaymentGatewayType of (Integer id) {
        return Arrays.stream(PaymentGatewayType.values())
                     .filter(x -> x.id.equals(id))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return pgName;
    }

    public static boolean manualRefund(PaymentGatewayType pgName) {
        var manualRefundList = Arrays.asList(PG_PAYTM,PG_RAZORPAY, QR_PAYTM, WALLET, WALLET_LOYALTY, WALLET_RFID, SODEXO,PHONEPE_QR);
       return manualRefundList.stream().anyMatch(i->i.equals(pgName));

    }
}
