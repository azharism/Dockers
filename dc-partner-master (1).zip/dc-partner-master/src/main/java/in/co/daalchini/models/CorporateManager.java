package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "corporate_managers")
public class CorporateManager {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "dashboard_user_id")
    private Long dashboardUserId;

    @Column(name = "corporate_id")
    private Long corporateId;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "corporate_id", insertable = false, updatable = false)
    private CorporateDetails corporateDetails;


    @Override
    public String toString() {
        return new StringJoiner(", ", CorporateManager.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("dashboardUserId=" + dashboardUserId)
                .add("corporateId=" + corporateId)
                .toString();
    }
}
