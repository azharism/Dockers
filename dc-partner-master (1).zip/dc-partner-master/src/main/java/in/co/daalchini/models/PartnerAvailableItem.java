package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.data.annotation.Immutable;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@Table(name = "partner_available_items")
public class PartnerAvailableItem {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "partner_id")
    private Long partnerId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manufacturer_variant_id", updatable = false, insertable = false)
    private ManufacturerVariant manufacturerVariant;

    @Column(name = "manufacturer_variant_id")
    private Long manufacturerVariantId;

    @Column(name = "quantity")
    private String quantity;

    @Column(name = "unit_count")
    private Long unitCount;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString () {
        return new StringJoiner(", ", PartnerAvailableItem.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("partnerId=" + partnerId)
            .add("manufacturerVariantId=" + manufacturerVariantId)
            .add("quantity='" + quantity + "'")
            .add("unitCount=" + unitCount)
            .add("updatedAt=" + updatedAt)
            .toString();
    }
}
