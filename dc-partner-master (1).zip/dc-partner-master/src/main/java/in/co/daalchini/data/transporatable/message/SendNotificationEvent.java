package in.co.daalchini.data.transporatable.message;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;

@Getter
@Setter
public class SendNotificationEvent {
    private static final ObjectMapper mapper = new ObjectMapper();

    private final String fileName;
    private final String campaignId;
    private final String text;
    private final String heading;
    private final String imageUrl;

    @Builder
    @JsonCreator
    public SendNotificationEvent(
            @JsonProperty("fileName") final String fileName,
            @JsonProperty("campaignId") final String campaignId,
            @JsonProperty("text") final String text,
            @JsonProperty("heading") final String heading,
            @JsonProperty("imageUrl") final String imageUrl
    ) {
        this.fileName=fileName;
        this.campaignId=campaignId;
        this.text=text;
        this.heading=heading;
        this.imageUrl=imageUrl;
    }

    public String json () {
        String jsonString;
        try {
            jsonString = mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            jsonString = String.format(
                    "{\"fileName\":\"%s\",\"campaignId\":\"%s\",\"text\":\"%s\",\"heading\":\"%s\",\"imageUrl\":%.2f}",
                    this.fileName,
                    this.campaignId,
                    this.text,
                    this.heading,
                    this.imageUrl);
        }

        return jsonString;
    }
}
