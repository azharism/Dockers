package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.Collection;

@Data
@Builder
@JsonIncludeProperties({"id", "name", "expiry_date_month", "is_active", "wallet_details", "wallet_rfid_details"})
public class DtoCorporateComprehensive {

    @JsonProperty("id")
    public Integer id;

    @JsonProperty("name")
    public String name;

    @JsonProperty("expiry_date_month")
    public Integer expiryDateMonth;

    @JsonProperty("is_active")
    public Boolean active;

    @JsonProperty("wallet_details")
    public DtoWalletDetails walletDetails;

    @JsonProperty("wallet_rfid_details")
    public DtoWalletRfidDetails walletRfidDetails;

    @Data
    @Builder
    @JsonIncludeProperties({"domains", "limits", "recharge_plan"})
    public static class DtoWalletDetails {

        @JsonProperty("domains")
        public Collection<DtoCorporateDomain> domains;

        @JsonProperty("limits")
        public Collection<DtoCorporateLimitSummarized> usageLimits;

        @JsonProperty("recharge_plan")
        public DtoCorporatePlanSummarized rechargePlan;

    }

    @Data
    @Builder
    @JsonIncludeProperties({"limits", "recharge_plan"})
    public static class DtoWalletRfidDetails {

        @JsonProperty("limits")
        public Collection<DtoCorporateLimitSummarized> usageLimits;

        @JsonProperty("recharge_plan")
        public DtoCorporatePlanSummarized rechargePlan;
    }


    @Data
    @Builder
    @JsonIncludeProperties({"domain", "description", "initial_balance", "is_active"})
    public static class DtoCorporateDomain {

        @JsonProperty("domain")
        public String domain;

        @JsonProperty("description")
        public String description;

        @JsonProperty("initial_balance")
        public String initialBalance;

        @JsonProperty("is_active")
        public Boolean active;
    }
}

