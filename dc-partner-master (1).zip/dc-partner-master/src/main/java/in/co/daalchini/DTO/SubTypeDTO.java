package in.co.daalchini.DTO;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

public class SubTypeDTO {

	private Integer id;
	
	private Integer typeOfTicketId;
	
	private String subtypeName;
	
	private String subTypeTagId;
	
	public String getSubTypeTagId() {
		return subTypeTagId;
	}

	public void setSubTypeTagId(String subTypeTagId) {
		this.subTypeTagId = subTypeTagId;
	}

	private String subtypeDec;
	
	private String subTypeAnswer;
	
	private String field1Name;
	
	private String field2Name;
	
	
	private String field1Type;
	
	
	private String field2Type;
	

	public String getField1Type() {
		return field1Type;
	}

	public void setField1Type(String field1Type) {
		this.field1Type = field1Type;
	}

	public String getField2Type() {
		return field2Type;
	}

	public void setField2Type(String field2Type) {
		this.field2Type = field2Type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTypeOfTicketId() {
		return typeOfTicketId;
	}

	public void setTypeOfTicketId(Integer typeOfTicketId) {
		this.typeOfTicketId = typeOfTicketId;
	}

	public String getSubtypeName() {
		return subtypeName;
	}

	public void setSubtypeName(String subtypeName) {
		this.subtypeName = subtypeName;
	}

	public String getSubtypeDec() {
		return subtypeDec;
	}

	public void setSubtypeDec(String subtypeDec) {
		this.subtypeDec = subtypeDec;
	}

	public String getSubTypeAnswer() {
		return subTypeAnswer;
	}

	public void setSubTypeAnswer(String subTypeAnswer) {
		this.subTypeAnswer = subTypeAnswer;
	}

	public String getField1Name() {
		return field1Name;
	}

	public void setField1Name(String field1Name) {
		this.field1Name = field1Name;
	}

	public String getField2Name() {
		return field2Name;
	}

	public void setField2Name(String field2Name) {
		this.field2Name = field2Name;
	}

	@Override
	public String toString() {
		return "SubTypeDTO [id=" + id + ", typeOfTicketId=" + typeOfTicketId + ", subtypeName=" + subtypeName
				+ ", subtypeDec=" + subtypeDec + ", subTypeAnswer=" + subTypeAnswer + ", field1Name=" + field1Name
				+ ", field2Name=" + field2Name + "]";
	}
	


}
