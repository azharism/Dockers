package in.co.daalchini.data.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum SlotStatus {

    TRACKING("tracking"),
    BLOCKED("blocked"),
    REPORTED("reported"),
    RESOLVED("resolved");

    private final @JsonValue
    String value;

    SlotStatus(String value) {
        this.value = value;
    }

    @JsonCreator
    public static SlotStatus of(String value) {
        return Arrays.stream(SlotStatus.values())
                .filter(x -> x.value.equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }
}
