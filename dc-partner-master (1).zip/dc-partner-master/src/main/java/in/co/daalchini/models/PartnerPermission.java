package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;
import java.util.Collections;
import java.util.Set;
import java.util.StringJoiner;
import java.util.TreeSet;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "partner_permissions")
public class PartnerPermission {

    @Id
    @Column(name = "id", insertable = false, updatable = false)
    private Long userId;

    @Column(name = "mobile")
    private String mobileNumber;

    @Column(name = "email")
    private String email;

    @Column(name = "role_id")
    private Integer roleId;

    @Column(name = "name")
    private String roleName;

    @Column(name = "permissions")
    private String permissions;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id", insertable = false, updatable = false)
    private DashboardUser dashboardUser;

    public Set<String> getPermissionSet() {
        var permissionSet = new TreeSet<String>();
        Collections.addAll(permissionSet, permissions.split(","));

        return permissionSet;
    }

    public String getRoleNameUpperCase() {
        if (roleName != null && !roleName.isEmpty()) return roleName.toUpperCase();

        return null;
    }


    @Override
    public String toString() {
        return new StringJoiner(", ", PartnerPermission.class.getSimpleName() + "[", "]")
                .add("userId=" + userId)
                .add("roleId=" + roleId)
                .add("roleName='" + roleName + "'")
                .add("permissions='" + permissions + "'")
                .toString();
    }
}
