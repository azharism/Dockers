package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum ChangeType {
    ActiveQuantity("ActiveQuantity"),
    HoldQuantity("HoldQuantity");

    private final @JsonValue
    String value;

    ChangeType(String value) {
        this.value = value;
    }

    @JsonCreator
    public static ChangeType of(String value) {
        return Arrays.stream(ChangeType.values())
                .filter(x -> x.value.equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }
}
