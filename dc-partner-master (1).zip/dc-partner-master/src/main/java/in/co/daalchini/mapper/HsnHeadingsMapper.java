package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.Hsn;
import in.co.daalchini.models.HsnHeadings;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface HsnHeadingsMapper {

    Hsn.HeadingsResponse toDto(HsnHeadings hsnHeadings);

    List<Hsn.HeadingsResponse> toDto(List<HsnHeadings> hsnHeadings);
}
