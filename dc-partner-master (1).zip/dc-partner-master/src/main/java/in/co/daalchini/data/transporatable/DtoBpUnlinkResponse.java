package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.constants.enums.BpUnlinkStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DtoBpUnlinkResponse {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("user_corporate_mapping_id")
    private Long userCorporateMappingId;

    @JsonProperty("status")
    private BpUnlinkStatus status;
}
