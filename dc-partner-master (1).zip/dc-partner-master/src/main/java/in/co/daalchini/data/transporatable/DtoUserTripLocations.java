package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DtoUserTripLocations {

    @JsonProperty("warehouses")
    private Collection<DtoTripLocation> warehouses;

    @JsonProperty("machines")
    private Collection<DtoTripLocation> machines;

    @JsonProperty("vendors")
    private Collection<DtoTripLocation> vendors;

}
