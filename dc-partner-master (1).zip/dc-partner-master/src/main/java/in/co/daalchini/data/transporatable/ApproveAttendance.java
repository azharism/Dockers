package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

public class ApproveAttendance {

    @Data
    public static final class Request{
        @JsonProperty(value = "id")
        private Long id;
        @JsonProperty(value = "check_in")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime checkIn;
        @JsonProperty(value = "check_out")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime checkOut;
    }

    @Data
    @Builder
    public static final class Response {
        private String message;
    }
}
