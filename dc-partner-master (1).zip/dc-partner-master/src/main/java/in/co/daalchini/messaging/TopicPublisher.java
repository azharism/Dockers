package in.co.daalchini.messaging;

import in.co.daalchini.data.constants.GeneralConstants.BrokerConfig;
import in.co.daalchini.data.transporatable.message.InventoryReleaseEvent;
import in.co.daalchini.data.transporatable.message.OrderStatusChanged;
import in.co.daalchini.data.untransportable.OrderState;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

@Log4j2
@Service
public class TopicPublisher {

    private final JmsTemplate jmsTopicTemplate;

    @Autowired
    public TopicPublisher (@Qualifier("jmsTopicTemplate") JmsTemplate jmsTopicTemplate) {
        this.jmsTopicTemplate = jmsTopicTemplate;
    }

    public void publishOrderStatusChanged (OrderStatusChanged statusChanged) {
        try {
            String topicName = BrokerConfig.TOPIC_ORDER_UPDATED_STATUS;
            final MessageCreator messageCreator = session -> createMessage(session, topicName, statusChanged);
            jmsTopicTemplate.send(topicName, messageCreator);
        } catch (Exception e) {
            log.warn("Unable to publish message", e);
        }
    }

    public void publishOrderInventoryRelease (String orderId) {
        InventoryReleaseEvent event = InventoryReleaseEvent.builder().orderId(orderId).build();
        log.info("INVENTORY_RELEASE, message = {}", event.json());
        jmsTopicTemplate.convertAndSend(BrokerConfig.TOPIC_INVENTORY_RELEASE, event);
    }

    private Message createMessage (
        final Session session, String topicName, final OrderStatusChanged statusChanged)
        throws JMSException
    {
        final String jsonBody = statusChanged.json();
        log.debug("Publishing message on [{}], body = {}", topicName, jsonBody);
        final Message message = session.createTextMessage(jsonBody);

        final OrderState orderState = statusChanged.getOrderState();

        switch (orderState) {
            case PRE_PLACED:
            case FAILED:
                message.setStringProperty("order_state", orderState.toString());
                message.setStringProperty("order_source", statusChanged.getOrderSource().toString());
                message.setStringProperty("order_type", statusChanged.getOrderType().toString());
                message.setStringProperty("pg_type", statusChanged.getPgType().toString());
                message.setStringProperty("user_type", statusChanged.getUserType().toString());
                message.setStringProperty("machine_type", statusChanged.getVMType().toString());
                break;
            default:
                log.warn("Invalid state to publish [{}]", orderState);
                throw new IllegalArgumentException("Invalid state to publish");
        }

        return message;
    }
}
