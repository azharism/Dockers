package in.co.daalchini.exception;

public class SystemException extends RuntimeException {
    private static final long serialVersionUID = 5227468995814082187L;

    public SystemException (String message) {
        super(message);
    }

    public SystemException (String message, Throwable cause) {
        super(message, cause);
    }

    public static SystemException of (String message) {
        return new SystemException(message);
    }

    public static SystemException of (String message, Exception e) {
        return new SystemException(message, e);
    }
}
