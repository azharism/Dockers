package in.co.daalchini.data.transporatable;

import lombok.*;

public class BrandCategory {
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    @Builder
    public static final class Request {
        private Long warehouseId;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    public static final class Response {
        private Long brandId;
        private String displayName;
        private Boolean active;
        private Long last3MonthSales;
        private Long onboardedTime;
        private Long vmCount;
        private String brandCategory;
        private Long billingCycle;
        private Long warehouseId;

    }
}
