package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoOrderDetailResponse;
import in.co.daalchini.models.UserDetails;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface UserDetailMapper {

    @Mapping(target = "id", source = "userId")
    @Mapping(target = "email", source = "emailId")
    @Mapping(target = "name", source = "profileDetail.fullName")
    DtoOrderDetailResponse.UserDetails toDto (UserDetails userDetails);

}
