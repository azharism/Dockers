package in.co.daalchini.exception;

public class BadRequestException extends RuntimeException {

    private static final long serialVersionUID = -5873620594146772943L;

    public BadRequestException (String message) {
        super(message);
    }
}
