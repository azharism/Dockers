package in.co.daalchini.Interfaces;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import in.co.daalchini.models.EntityModel;
import in.co.daalchini.models.Manufactures;

@JsonPropertyOrder({"entityId", "manufacturerId", "id"})
public interface EntityAttributeManufacturerInterface {

    Manufactures getManufacturerId ();

    Integer getId ();

    EntityModel getEntityId ();
}
