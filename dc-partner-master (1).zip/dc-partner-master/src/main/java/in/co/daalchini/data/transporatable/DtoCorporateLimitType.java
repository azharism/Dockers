package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIncludeProperties({"id", "type", "sub_type", "duration", "duration_unit"})
public class DtoCorporateLimitType {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("type")
    private String type;

    @JsonProperty("sub_type")
    private String subType;

    @JsonProperty("duration")
    private String duration;

    @JsonProperty("duration_unit")
    private String durationUnit;
}
