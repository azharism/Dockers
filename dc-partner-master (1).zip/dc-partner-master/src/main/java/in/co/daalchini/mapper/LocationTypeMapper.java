package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoLocationType;
import in.co.daalchini.models.LocationType;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface LocationTypeMapper {

    DtoLocationType toDto(LocationType locationType);

    List<DtoLocationType> toDto(List<LocationType> locationTypes);
}
