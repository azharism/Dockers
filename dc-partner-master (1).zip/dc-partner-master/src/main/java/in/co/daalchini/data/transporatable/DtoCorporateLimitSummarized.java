package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIncludeProperties({"id", "card_series_id", "pg_id", "value", "is_active", "limit_type"})
public class DtoCorporateLimitSummarized {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("card_series_id")
    private Long cardSeriesId;

    @JsonProperty("pg_id")
    private Integer pgId;

    @JsonProperty("value")
    private Integer value;

    @JsonProperty("is_active")
    public Boolean active;

    @JsonProperty("limit_type")
    private LimitType limitType;


    @Data
    @Builder
    @JsonIncludeProperties({"id", "type", "sub_type", "duration", "duration_unit"})
    public static class LimitType {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("type")
        private String type;

        @JsonProperty("sub_type")
        private String subType;

        @JsonProperty("duration")
        private String duration;

        @JsonProperty("duration_unit")
        private String durationUnit;
    }
}
