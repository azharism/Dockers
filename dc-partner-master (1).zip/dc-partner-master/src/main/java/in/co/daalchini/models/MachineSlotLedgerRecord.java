package in.co.daalchini.models;

import in.co.daalchini.data.constants.enums.MachineSlotOperation;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "machine_slot_ledger")
@EntityListeners(AuditingEntityListener.class)
public class MachineSlotLedgerRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "machine_id")
    private Long machineId;

    @Column(name = "slot_id")
    private Integer slotId;

    @Column(name = "operation")
    private MachineSlotOperation operation;

    @Column(name = "vm_mv_id")
    private Long vmMvId;

    @Column(name = "source")
    private String source;

    @CreatedBy
    @Column(name = "user_id")
    private Long createdBy;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public static MachineSlotLedgerRecord ofAddition(
            Long machineId,
            Integer slotId,
            Long vmMvId,
            String source
    ) {
        var ledger = new MachineSlotLedgerRecord();
        ledger.machineId = machineId;
        ledger.slotId = slotId;
        ledger.vmMvId = vmMvId;
        ledger.source = source;
        ledger.operation = MachineSlotOperation.Add;

        return ledger;
    }

    public static MachineSlotLedgerRecord ofRemoval(
            Long machineId,
            Integer slotId,
            Long vmMvId,
            String source
    ) {
        var ledger = new MachineSlotLedgerRecord();
        ledger.machineId = machineId;
        ledger.slotId = slotId;
        ledger.vmMvId = vmMvId;
        ledger.source = source;
        ledger.operation = MachineSlotOperation.Remove;

        return ledger;
    }

    @Override
    public String toString() {
        return JsonUtil.stringifyObject(this);
    }
}
