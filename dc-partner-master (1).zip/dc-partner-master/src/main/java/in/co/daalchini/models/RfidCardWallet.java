package in.co.daalchini.models;


import in.co.daalchini.data.untransportable.PaymentGatewayType;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "rfid_card_wallets")
public class RfidCardWallet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    private Long id;

    @Column(name = "card_id")
    private Long cardId;

    @Column(name = "card_uid")
    private String cardUid;

    @Column(name = "pg_id")
    private Integer pgId;

    @Column(name = "access_key")
    private String accessKey;

    @Column(name = "external_id")
    private Long externalId;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "external_id", insertable = false, updatable = false)
    private UserWallet wallet;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pg_id", insertable = false, updatable = false)
    private PaymentGateway paymentGateway;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_id", insertable = false, updatable = false)
    private RfidCard rfidCard;

    @Transient
    public boolean isActive() {
        return getActive();
    }

    public PaymentGatewayType getPgType() {
        return paymentGateway.toEnum();
    }

    @PrePersist
    void createTimestamp() {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp() {
        this.updatedAt = DateTimeHelper.now();
    }

    public static RfidCardWallet of(RfidCard dbCard, String token, Long walletId) {
        var wallet = new RfidCardWallet();
        wallet.setPgId(PaymentGatewayType.WALLET_RFID.getId());
        wallet.setCardId(dbCard.getId());
        wallet.setCardUid(dbCard.getUid());
        wallet.setAccessKey(token);
        wallet.setExternalId(walletId);
        wallet.setActive(true);

        return wallet;
    }


    @Override
    public String toString() {
        return new StringJoiner(", ", RfidCardWallet.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("cardId=" + cardId)
                .add("cardUid='" + cardUid + "'")
                .add("pgId=" + pgId)
                .add("externalId=" + externalId)
                .add("active=" + active)
                .toString();
    }
}
