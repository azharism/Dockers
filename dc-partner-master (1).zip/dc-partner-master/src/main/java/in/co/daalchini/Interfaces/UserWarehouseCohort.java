package in.co.daalchini.Interfaces;


import org.springframework.beans.factory.annotation.Value;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;


public interface UserWarehouseCohort {

    @Value("#{target.wh_id}")
    Long warehouseId();

    @Value("#{target.cohort_ids}")
    String cohortIdStrArr();

    default Collection<Long> cohortIds() {
        if (null == cohortIdStrArr()) return Collections.emptyList();

        return Arrays.stream(cohortIdStrArr().split(","))
                .map(Long::valueOf)
                .collect(Collectors.toUnmodifiableSet());
    }
}


