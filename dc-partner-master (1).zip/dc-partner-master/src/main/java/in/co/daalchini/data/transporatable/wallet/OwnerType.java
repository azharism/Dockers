package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum OwnerType {
    User("user"),
    Corporate("corporate");

    private final String value;

    OwnerType (final String value) {
        this.value = value;
    }

    @JsonValue
    public String value () {
        return value;
    }

    @JsonCreator
    public static OwnerType of (final String valueStr) {
        return Arrays.stream(OwnerType.values())
                     .filter(x -> x.value.equalsIgnoreCase(valueStr))
                     .findAny()
                     .orElseThrow(IllegalArgumentException::new);
    }
}
