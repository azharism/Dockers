package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_user_warehouse_mapping")
public class DashboardUserWarehouseMapping {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "warehouse_id")
    private Long warehouseId;

    @Column(name = "dashboard_user_id")
    private Long dashboardUserId;

    @JoinColumn(name = "warehouse_id", insertable = false, updatable = false)
    @ManyToOne(fetch = FetchType.LAZY)
    private Warehouse warehouse;
}
