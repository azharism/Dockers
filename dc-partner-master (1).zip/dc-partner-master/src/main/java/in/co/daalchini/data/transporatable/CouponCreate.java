package in.co.daalchini.data.transporatable;

import lombok.Data;

public class CouponCreate {

    @Data
    public static final class Response {
        private Boolean isCouponCreated;
        private Long couponId;
    }
}
