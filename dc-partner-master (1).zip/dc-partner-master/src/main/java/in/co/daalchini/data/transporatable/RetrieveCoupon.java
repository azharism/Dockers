package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

public class RetrieveCoupon {

    @Data
    @Builder
    @NotNull
    public static final class Request
    {
        private Long draftId;
        @NotNull(message = "couponStartDate is required")
        private String couponStartDate;
        @NotNull(message = "couponExpiryDate is required")
        private String couponExpiryDate;
        @NotNull(message = "couponUsagePerDevice is required")
        private Long couponUsagePerDevice;
    }

}
