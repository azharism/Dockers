package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoMachineCartLimit;
import in.co.daalchini.models.MachineCartLimit;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.Set;

@Mapper(componentModel = "spring")
public interface MachineCartLimitMapper {

    default DtoMachineCartLimit toVendConfig(Collection<MachineCartLimit> limits) {
        var defaultLimit = new DtoMachineCartLimit.MachineLimit(0L, 4);
        var specialValues = toMachineLimit(limits);

        return new DtoMachineCartLimit(defaultLimit, specialValues);
    }

    @Mapping(source = "machineId", target = "machineId")
    @Mapping(source = "cartLimit", target = "cartLimit")
    DtoMachineCartLimit.MachineLimit toMachineLimit(MachineCartLimit limit);

    Set<DtoMachineCartLimit.MachineLimit> toMachineLimit(Collection<MachineCartLimit> limit);
}
