package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.constants.enums.TrayModificationType;
import lombok.Data;

import javax.validation.constraints.Positive;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoTrayModificationRequest {

    @JsonProperty("default_mv_id")
    private @Positive Long defaultMvId;

    @JsonProperty("modification_type")
    private TrayModificationType trayModificationType;

    @JsonProperty("added_slots")
    private Set<DtoTraySlot> addedSlots = Collections.emptySet();

    @JsonProperty("removed_slot_ids")
    private Set<@Positive Long> removedSlotIds = Collections.emptySet();


    public Set<DtoMachineSlot> getAddedMachineSlots() {
        return addedSlots.stream()
                .map(x->x.withMvId(defaultMvId))
                .collect(Collectors.toSet());
    }
}
