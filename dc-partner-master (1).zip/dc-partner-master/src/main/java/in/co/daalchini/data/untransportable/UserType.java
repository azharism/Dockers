package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum UserType {

    User("user"),
    Guest("guest"),
    Partner("partner");

    private final @JsonValue String value;

    UserType (String value) {
        this.value = value;
    }

    @JsonCreator
    public static UserType of (String status) {
        return Arrays.stream(UserType.values())
                     .filter(x -> x.value.equalsIgnoreCase(status))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return value;
    }
}
