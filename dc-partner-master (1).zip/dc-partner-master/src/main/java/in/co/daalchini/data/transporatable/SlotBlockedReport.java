package in.co.daalchini.data.transporatable;

import lombok.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class SlotBlockedReport {

    private Long vmId;
    private Long slotId;
    private Integer failCount;
    private String blockedAt;
    private Long timeSinceFailure;

    @Builder
    public SlotBlockedReport(
            Long vmId,
            Long slotId,
            Integer failCount,
            LocalDateTime blockedAt,
            Long timeSinceFailure
    ) {
        this.vmId = vmId;
        this.slotId = slotId;
        this.failCount = failCount;
        this.blockedAt = DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(blockedAt).concat(" UTC");
        this.timeSinceFailure = timeSinceFailure;

    }
}
