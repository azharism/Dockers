package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.models.ZohoItemTypes;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

public class ProductSearchDto {
    @Data
    @Builder
    public static class SearchResponse
    {
        private final List<VariantResponse> variantResponse;
        private final List<ProductResponse> productResponse;
        private final List<BrandResponse> brandResponse;
    }
    @Data
    @Builder
    public static final class VariantResponse
    {
        private final Long variantId;
        private final String variantName;
        private final Long productId;
        private final String productName;
        private final Long BrandId;
        private final String BrandName;
        private final Boolean isActive;
        private final List<VariantImage> variantImages;
    }
    @Data
    @Builder
    public static final class ProductResponse
    {
        private final Long productId;
        private final String productName;
    }

    @Data
    @Builder
    public static final class BrandResponse
    {
        private final Long BrandId;
        private final String BrandName;
    }

    @Data
    @Builder
    public static class VariantImage {
        private final Long id;
        private final String imageId;
    }

    @Data
    @Builder
    public static class ManufacturerVariant {
        private Long id;
        private String manufacturerName;
        private Double mrp;
        private Double offerPrice;
        private Double vendorPrice;
        private Long variantId;
        private Boolean isActive;
        private Integer manufacturerId;
        private String purchaseType;
        private String zohoItemTypeId;
        private String zohoId;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
    @Data
    @Builder
    public static final class ManufacturerVariantResponse
    {
        private final VariantResponse variantResponse;
        private final Long mfIdCount;
        private final List<ManufacturerVariant> ManufacturerVariant;
        private final List<ZohoItemTypes> zohoItemTypes;
    }

    @Data
    @Builder
    public static final class ManufacturerVariantRequest
    {
        @JsonIgnore
        private Long mvId;
        private Integer manufacturerId;
        private Long variantId;
        private Double mrp;
        private Double offerPrice;
        private Double vendorPrice;
        private Long zohoItemTypeId;
        @JsonIgnore
        private Long warehouseId;
    }

    @Data
    @Builder
    public static final class UpdateManufacturerVariantRequest
    {
        private Long mvId;
        private Integer manufacturerId;
        @JsonIgnore
        private Long variantId;
        private Double mrp;
        private Double offerPrice;
        private Double  vendorPrice;
        private Long zohoItemTypeId;
        @JsonIgnore
        private Long warehouseId;

    }

    @Data
    @Builder
    public static final class VendorRequest
    {
        private String name;
        private String phoneNumber;
        private String email;
        private String gstNumber;
        private String fssaiNumber;
        private Integer state_id;
        private Integer city_id;
        private String street;
        private String addressLine1;
        private Integer pinCode;
        private Double lat;
        private Double lng;
        @JsonIgnore
        private Boolean active;
    }

    @Data
    @Builder
    public static final class Response
    {
        private Integer manufacturerId;
        private Long variantId;
        private Double mrp;
        private Double offerPrice;
        private Double  vendorPrice;
        private Long zohoItemTypeId;
        private Long warehouseId;

    }

}
