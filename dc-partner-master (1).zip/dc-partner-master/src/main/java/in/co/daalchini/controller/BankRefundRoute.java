package in.co.daalchini.controller;

import in.co.daalchini.data.transporatable.BankRefund;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.BankRefundService;
import lombok.Value;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import static in.co.daalchini.data.constants.RouteConstants.BankRefundContext.BANK_REFUND;
import static in.co.daalchini.data.constants.RouteConstants.BankRefundContext.BANK_REFUND_STATUS;

@RestController
@Log4j2
public class BankRefundRoute {
    private final BankRefundService bankRefundService;

    @Autowired
    public BankRefundRoute(BankRefundService bankRefundService) {
        this.bankRefundService = bankRefundService;
    }

    @PostMapping(BANK_REFUND)
    @PreAuthorize("hasAuthority('refund_revoke')")
    public BankRefund.Response BankRefund(@RequestBody @Valid BankRefund.Request request,
                                          @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for refund BankRefund:{}", request);
        try {
            var response = bankRefundService.processBankRequest(request,userDetails.getUserId());
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("Error  :{}", e.getMessage());
            throw e;
        }
    }
    @GetMapping(BANK_REFUND_STATUS)
    @PreAuthorize("hasAuthority('refund_revoke')")
    public BankRefund.RefundStatusResponse BankRefundStatus(@PathVariable(value = "orderId")String orderId,
                                                            @PathVariable(value = "paymentId") String paymentId,
    @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for refund BankRefund:{}", orderId,paymentId);
        try {
            var response = bankRefundService.processBankRefundStatus(orderId,paymentId);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("Error  :{}", e.getMessage());
            throw e;
        }
    }
}
