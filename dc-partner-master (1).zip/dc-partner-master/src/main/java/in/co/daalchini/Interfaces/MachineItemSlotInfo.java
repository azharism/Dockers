package in.co.daalchini.Interfaces;


import in.co.daalchini.data.feature.MachineItemDto;
import org.springframework.beans.factory.annotation.Value;


public interface MachineItemSlotInfo {

    @Value("#{target.machine_id}")
    Long machineId();

    @Value("#{target.active_count}")
    Integer activeCount();

    @Value("#{target.slot_id}")
    Integer slotId();

    default MachineItemDto.MachineItemSlotInfo toRecord() {
        return new MachineItemDto.MachineItemSlotInfo(machineId(), slotId(), activeCount());
    }

}
