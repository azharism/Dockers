package in.co.daalchini.messaging;

import com.fasterxml.jackson.core.JsonProcessingException;
import in.co.daalchini.data.constants.GeneralConstants.BrokerConfig;
import in.co.daalchini.data.transporatable.message.OrderStateChange;
import in.co.daalchini.data.transporatable.message.OrderStatusChanged;
import in.co.daalchini.data.transporatable.message.SlotBlockEvent;
import in.co.daalchini.service.SlotBlockedService;
import in.co.daalchini.service.helper.JsonUtil;
import in.co.daalchini.service.http.PaymentService;
import lombok.extern.log4j.Log4j2;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import static in.co.daalchini.data.constants.GeneralConstants.BrokerConfig.TOPIC_ORDER_UPDATED_STATUS;

@Log4j2
@Service
public class TopicListener {
    private static final String TOPIC_PRE_PLACED = BrokerConfig.TOPIC_PRE_PLACED;
    private static final String SELECTOR_PRE_PLACED = "order_state = 'PRE_PLACED'";
    private static final String TOPIC_SLOT_BLOCK = BrokerConfig.TOPIC_SLOT_BLOCK;
    private static final String SELECTOR_ORDER_PRE_PLACED_PARTNER = "order_state in ('PRE_PLACED','FAILED') and user_type = 'partner' and pg_type in ('WALLET_PARTNER')";
    private final DriverNotifier driverNotifier;
    private final SlotBlockedService slotBlockedService;

    private final PaymentService paymentService;


    @Autowired
    public TopicListener (
        DriverNotifier driverNotifier,
        PaymentService paymentService,
        SlotBlockedService slotBlockedService)
    {
        this.driverNotifier = driverNotifier;
        this.paymentService = paymentService;
        this.slotBlockedService = slotBlockedService;
    }

    @JmsListener(
        containerFactory = "jmsTopicListenerContainerFactory",
        destination = TOPIC_PRE_PLACED,
        selector = SELECTOR_PRE_PLACED)
    public void receiveMessagePrePlaced (TextMessage message) {
        try {
            final String jsonStr = message.getText();
            log.info("New message on topic ORDERS_PRE_PLACED, text = {}", jsonStr);
            final OrderStateChange stateChange = JsonUtil.fromJson(jsonStr, OrderStateChange.class);
            log.debug("Order state change pre-placed = {}", stateChange);
            driverNotifier.notifyDriver(stateChange);
        } catch (JMSException | JsonProcessingException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @JmsListener(
        containerFactory = "jmsTopicListenerContainerFactory",
        destination = TOPIC_SLOT_BLOCK)
    public void receiveSlotBlockEvent (ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();
            log.info("New message on [{}], content = {}", topicName, jsonStr);
            final SlotBlockEvent event = JsonUtil.fromJson(jsonStr, SlotBlockEvent.class);
            slotBlockedService.processSlotBlocked(event);
        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @JmsListener(
        containerFactory = "jmsTopicListenerContainerFactory",
        destination = TOPIC_ORDER_UPDATED_STATUS,
        selector = SELECTOR_ORDER_PRE_PLACED_PARTNER)
    public void receiveMessageOrderUpdatedStatus (ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();
            log.info("New message on [{}], content = {}", topicName, jsonStr);
            final OrderStatusChanged statusChanged = JsonUtil.fromJson(jsonStr, OrderStatusChanged.class);
            log.debug("Order state change = {}", statusChanged);
            paymentService.pushPaymentStatus(statusChanged);
        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }


}


