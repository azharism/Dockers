package in.co.daalchini.models;


import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "recharge_filter")
@EntityListeners(AuditingEntityListener.class)
public class RechargeFilter {

    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "pg_id")
    private Integer pgId;

    @Column(name = "min_balance")
    private Double minBalance;

    @Column(name = "max_balance")
    private Double maxBalance;

    @Column(name = "active")
    private boolean active;

    @Column(name = "scan_users_active")
    private boolean scanUsersActive;

    @Column(name = "max_credit_limit")
    private Double maxCreditLimit;

    @Column(name = "card_series_id")
    private Long cardSeriesId;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString() {
        return new StringJoiner(", ", RechargeFilter.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("pgId=" + pgId)
                .add("minBalance=" + minBalance)
                .add("maxBalance=" + maxBalance)
                .add("active=" + active)
                .add("scanUsersActive=" + scanUsersActive)
                .add("maxCreditLimit=" + maxCreditLimit)
                .add("cardSeriesId=" + cardSeriesId)
                .toString();
    }
}
