package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIncludeProperties({"initial_delay_sec", "refresh_interval_sec", "default_promo_duration_sec"})
public class DtoPromoCohortConfig {

    @JsonProperty("initial_delay_sec")
    private String initialDelaySec;

    @JsonProperty("refresh_interval_sec")
    private String refreshIntervalSec;

    @JsonProperty("default_promo_duration_sec")
    private String defaultPromoDurationSec;
}
