package in.co.daalchini.controller;


import in.co.daalchini.data.constants.RouteConstants.WarehouseContext;
import in.co.daalchini.data.transporatable.ListWarehouse;
import in.co.daalchini.data.transporatable.NullResponse;
import in.co.daalchini.data.transporatable.UserWorkDetails;
import in.co.daalchini.data.transporatable.VmWarehouseMap;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.WarehouseService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;

@Log4j2
@RestController
public class WarehouseRoute {

    private final WarehouseService warehouseService;

    @Autowired
    public WarehouseRoute (WarehouseService warehouseService) {
        this.warehouseService = warehouseService;
    }

    @GetMapping(WarehouseContext.WAREHOUSE_LIST_ALL)
    public List<ListWarehouse.Response> getAllWarehouses (@AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for fetching all warehouses by :{}", userDetails.getUserId());
        List<ListWarehouse.Response> responseList;
        try {
            responseList = warehouseService.fetchAllWarehouses();
            log.info("Response :{}", responseList);
            return responseList;
        } catch (RuntimeException e) {
            log.warn("Error in fetching all warehouses : {}", e.getMessage());
            throw e;
        }
    }

    @GetMapping(WarehouseContext.WAREHOUSE_MAPPED)
    public List<ListWarehouse.Response> getMappedWarehouse (@AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for fetching mapped warehouses by :{}", userDetails.getUserId());
        List<ListWarehouse.Response> responseList;
        try {
            if(userDetails.isAdmin()) return warehouseService.fetchAllWarehouses();
            responseList = warehouseService.fetchMappedWarehouses(userDetails.getUserId());
            log.info("Response :{}", responseList);
            return responseList;
        } catch (RuntimeException e) {
            log.warn("Error in fetching mapped warehouses : {}", e.getMessage());
            throw e;
        }
    }

    @PostMapping(WarehouseContext.MAP_WAREHOUSE_VM)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority('map_machines')")
    public NullResponse mapVmWarehouse (
        @PathVariable(value = "warehouseId") Long warehouseId,
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @RequestBody VmWarehouseMap.Request request)
    {
        log.info("Request received for mapping vending machines {} to warehouse :{}", request, warehouseId);
        try {
            warehouseService.mapVmToWarehouse(request, warehouseId, userDetails.getUserId());
        } catch (RuntimeException e) {
            log.warn("Error in mapping vms");
            throw e;
        }
        return NullResponse.builder().message("Accepted").build();
    }

    @GetMapping(WarehouseContext.USER_WORKING_DETAILS)
    public List<UserWorkDetails.Response> fetchUserWorkDetails (
        @PathVariable(value = "warehouseId") Long warehouseId,
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @RequestParam(value = "from")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") LocalDateTime from,
        @RequestParam(value = "to")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") LocalDateTime to)
    {
        log.info("Request received for fetching work details from {} to {} by :{}", from, to, userDetails.getUserId());
        List<UserWorkDetails.Response> responseList;
        try {
            responseList = warehouseService.fetchWorkDetails(warehouseId, from, to, userDetails);
            log.info("Response :{}", responseList);
            return responseList;
        } catch (RuntimeException e) {
            log.warn("Error in fetching work details : {}", e.getMessage());
            throw e;
        }
    }
    @PostMapping(WarehouseContext.DUMP_WAREHOUSE_INVENTORY)
    public NullResponse warehouseInventoryDump(
            @PathVariable(value = "warehouseId") Long warehouseId,
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestPart(value = "file") MultipartFile file){

        log.info("Request received for dumping inventory by  {} to warehouse :{}", userDetails.getUserId(), warehouseId);
        try {
            warehouseService.dumpWarehouseInventory(file, warehouseId, userDetails.getUserId());
        } catch (RuntimeException e) {
            log.warn("Error in Dumping inventory");
            throw e;
        }
        return NullResponse.builder().message("Accepted").build();
    }

//to be used initially to dump data in zoho_item_warehouse_count
    @PostMapping(WarehouseContext.DUMP_WAREHOUSE_ITEM_COUNT_INIT)
    public NullResponse warehouseItemCountDumpInit(
            @PathVariable(value = "warehouseId") Long warehouseId,
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestPart(value = "file") MultipartFile file){

        log.info("Request received for dumping inventory by  {} to warehouse :{}", userDetails.getUserId(), warehouseId);
        try {
            warehouseService.dumpZohoItemWarehouseCount(file, warehouseId);
        } catch (RuntimeException e) {
            log.warn("Error in Dumping inventory");
            throw e;
        }
        return NullResponse.builder().message("Accepted").build();
    }

    @PostMapping(WarehouseContext.DUMP_WAREHOUSE_CLOSING_INVENTORY)
    public NullResponse warehouseClosingInventoryDump(
            @PathVariable(value = "warehouseId") Long warehouseId,
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestPart(value = "file") MultipartFile file,
            @RequestParam(value = "date") String date){

        log.info("Request received for dumping closing inventory by  {} to warehouse :{}", userDetails.getUserId(), warehouseId);
        try {
            warehouseService.dumpClosingInventory(file, warehouseId, date);
        } catch (RuntimeException e) {
            log.warn("Error in Dumping inventory");
            throw e;
        }
        return NullResponse.builder().message("Accepted").build();
    }
}
