package in.co.daalchini.messaging;

import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.transporatable.message.Jsonable;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BpDeregisterChangeEvent implements Jsonable {

    @JsonProperty("ucm_id")
    private Long ucmId;

    @JsonProperty("user_id")
    private Long userId;

    @JsonProperty("employee_id")
    private String employeeId;

    public String json () {
        return JsonUtil.toJson(this);
    }
}
