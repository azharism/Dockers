package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.AddWarehouseSezLocationRequest;
import in.co.daalchini.data.transporatable.DtoWarehouseSezLocation;
import in.co.daalchini.data.transporatable.UpdateWarehouseSezLocationRequest;
import in.co.daalchini.models.SezLocation;
import org.mapstruct.*;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public interface WarehouseSezLocationMapper {

    @Mapping(target = "address", source = "streetAddress")
    DtoWarehouseSezLocation toDto (SezLocation address);

    List<DtoWarehouseSezLocation> toDto (Collection<SezLocation> addresses);

    @Mapping(target = "streetAddress", source = "request.address")
    SezLocation toEntity (Long warehouseId, AddWarehouseSezLocationRequest request);

    @Mapping(target = "streetAddress", source = "address")
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    SezLocation updateEntity (UpdateWarehouseSezLocationRequest source, @MappingTarget SezLocation location);
}
