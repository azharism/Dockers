package in.co.daalchini.data.transporatable;

import lombok.*;
import org.springframework.beans.factory.annotation.Value;


public interface BrandSales {
    @Value("#{target.brand_id}")
    Long getbrandId();

    @Value("#{target.brand}")
    Long getbrand();
    @Value("#{target.mvid}")
    Long getmvid();
    @Value("#{target.sales}")
    Long getsales();

}