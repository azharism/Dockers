package in.co.daalchini.Interfaces;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.models.EntityModel;
import in.co.daalchini.models.VendingMachine;

public interface EntityAttributeInterface {

    @JsonIgnoreProperties({"dashboardUsers", "orders"})
    VendingMachine getVendingMachineId ();

    Integer getId ();

    EntityModel getEntityId ();


}
