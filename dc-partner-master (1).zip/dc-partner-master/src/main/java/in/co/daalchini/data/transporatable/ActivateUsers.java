package in.co.daalchini.data.transporatable;

import lombok.*;

import java.util.List;

public class ActivateUsers {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static final class Request{
        private List<String> employeeIds;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static final class Response{
        private List<String> successes;
        private List<String> failures;
    }
}
