package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoHardwareType;
import in.co.daalchini.models.MachineHardwareType;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface MachineHardwareTypeMapper {

    DtoHardwareType toDto (MachineHardwareType hardwareType);
    List<DtoHardwareType> toDto (List<MachineHardwareType> hardwareType);
}
