package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;

public class MachineRestock {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Request {

        @NotNull(message = "mvId required")
        @PositiveOrZero(message = "mvId must be positive")
        private Long mvId;

        @NotNull(message = "unitCount required")
        @PositiveOrZero(message = "unitCount must be positive")
        private Long unitCount;
    }

}
