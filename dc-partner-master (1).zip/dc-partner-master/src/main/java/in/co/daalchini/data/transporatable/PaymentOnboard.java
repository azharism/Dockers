package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;
import java.util.List;

public class PaymentOnboard {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Request {

        @NotNull(message = "initialBalance required")
        @PositiveOrZero(message = "initialBalance must be positive")
        private Double initialBalance;

        @NotNull(message = "phoneNumbers required")
        @Size(max = 50, message = "phoneNumbers can have upto 50 entries")
        private List<String> phoneNumbers;
    }

    @Data
    @Builder
    public static final class Response {
        private List<String> successes;
        private List<String> failures;
    }

}
