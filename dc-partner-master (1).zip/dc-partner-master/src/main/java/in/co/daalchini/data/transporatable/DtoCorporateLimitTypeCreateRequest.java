package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Pattern;

@Data
@Builder
@JsonIncludeProperties({"id", "type", "sub_type", "duration", "duration_unit"})
public class DtoCorporateLimitTypeCreateRequest {

    @JsonProperty("id")
    private Long id;

    @Pattern(regexp = "item|amount", message = "invalid type")
    @JsonProperty("type")
    private String type;

    @JsonProperty("duration")
    private String duration;

    @Pattern(regexp = "hour|day", message = "invalid duration_unit")
    @JsonProperty("duration_unit")
    private String duration_unit;
}
