package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

import javax.persistence.*;
import java.util.List;
import java.util.StringJoiner;

@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_details")
@NamedQueries({@NamedQuery(name = "UserDetails.findAll", query = "SELECT k FROM UserDetails k"),
        @NamedQuery(
                name = "UserDetails.findById",
                query = "SELECT k FROM UserDetails k where k.userId = :id"),
        @NamedQuery(
                name = "UserDetails.findByReferCode",
                query = "SELECT k FROM UserDetails k where k.referCode = :referCode"),
        @NamedQuery(
                name = "UserDetails.findByMobileNo",
                query = "SELECT k FROM UserDetails k where k.mobileNo = :mobileNo"),
        @NamedQuery(
                name = "UserDetails.findByEmailId",
                query = "SELECT k FROM UserDetails k where k.emailId = :email"),
        @NamedQuery(
                name = "UserDetails.findByOauthToken",
                query = "SELECT k FROM UserDetails k where k.oauthToken = :oauthToken")
})
public class UserDetails {

    @Id
    @Column(name = "user_id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(name = "email_id", length = 50)
    private String emailId;

    @Column(name = "mobile_no", length = 50)
    private String mobileNo;

    @Column(name = "oauth_token", length = 50)
    private String oauthToken;

    @Column(name = "refer_code", length = 50)
    private String referCode;

    @Column(name = "status")
    private Short status;

    @Column(name = "paytm_oauth_token", length = 50)
    private String paytmOauthToken;

    @Column(name = "paytm_user_id", length = 50)
    private String paytmUserId;

    @Column(name = "oauth_token_expired")
    private Short oauthTokenExpired;

    @Column(name = "device_id", length = 100)
    private String deviceId;

    @Column(name = "fcm_token", length = 100)
    private String fcmToken;

    @Column(name = "fcm_token_status")
    private Short fcmTokenStatus;

    @JsonIgnore
    @LazyToOne(LazyToOneOption.NO_PROXY)
    @OneToOne(mappedBy = "userDetails")
    private UserCorporateMapping userCorporateMapping;

    @JsonIgnore
    @LazyToOne(LazyToOneOption.NO_PROXY)
    @OneToOne(mappedBy = "userDetails")
    private UserProfileDetail profileDetail;

    @Column(name = "user_type")
    private String userType;

    @OneToMany(mappedBy = "userDetails", fetch = FetchType.LAZY)
    private List<UserWallet> userWallets;

    @OneToMany(mappedBy = "userDetails", fetch = FetchType.LAZY)
    private List<UserKey> userKeys;

    public UserDetails(Long userId) {
        super();
        this.userId = userId;
    }

    public String getEmailId() {
        return PiiHelper.maskEmail(emailId);
    }

    public String getMobileNo() {
        return PiiHelper.maskPhone(mobileNo);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", UserDetails.class.getSimpleName() + "[", "]")
                .add("userId=" + userId)
                .add("emailId='" + getEmailId() + "'")
                .add("mobileNo='" + getMobileNo() + "'")
                .add("oauthToken='" + oauthToken + "'")
                .add("referCode='" + referCode + "'")
                .add("status=" + status)
                .add("paytmOauthToken='" + paytmOauthToken + "'")
                .add("paytmUserId='" + paytmUserId + "'")
                .add("oauthTokenExpired=" + oauthTokenExpired)
                .add("deviceId='" + deviceId + "'")
                .add("fcmToken='" + fcmToken + "'")
                .add("fcmTokenStatus=" + fcmTokenStatus)
                .add("userType='" + userType + "'")
                .toString();
    }
}
