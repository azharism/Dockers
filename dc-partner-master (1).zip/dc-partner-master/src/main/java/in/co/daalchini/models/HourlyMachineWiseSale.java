package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "machine_wise_sale_hourly")
public class HourlyMachineWiseSale {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "machine_id")
    private Long machineId;

    @Column(name = "hour_0")
    private Double hour0;
    @Column(name = "hour_1")
    private Double hour1;
    @Column(name = "hour_2")
    private Double hour2;
    @Column(name = "hour_3")
    private Double hour3;
    @Column(name = "hour_4")
    private Double hour4;
    @Column(name = "hour_5")
    private Double hour5;
    @Column(name = "hour_6")
    private Double hour6;
    @Column(name = "hour_7")
    private Double hour7;
    @Column(name = "hour_8")
    private Double hour8;
    @Column(name = "hour_9")
    private Double hour9;
    @Column(name = "hour_10")
    private Double hour10;
    @Column(name = "hour_11")
    private Double hour11;
    @Column(name = "hour_12")
    private Double hour12;
    @Column(name = "hour_13")
    private Double hour13;
    @Column(name = "hour_14")
    private Double hour14;
    @Column(name = "hour_15")
    private Double hour15;
    @Column(name = "hour_16")
    private Double hour16;
    @Column(name = "hour_17")
    private Double hour17;
    @Column(name = "hour_18")
    private Double hour18;
    @Column(name = "hour_19")
    private Double hour19;
    @Column(name = "hour_20")
    private Double hour20;
    @Column(name = "hour_21")
    private Double hour21;
    @Column(name = "hour_22")
    private Double hour22;
    @Column(name = "hour_23")
    private Double hour23;
    @Column(name = "hour_24")
    private Double hour24;


    @Column(name = "total_sale")
    private Double totalSale;

    @CreationTimestamp
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;


    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachines;
    
}


