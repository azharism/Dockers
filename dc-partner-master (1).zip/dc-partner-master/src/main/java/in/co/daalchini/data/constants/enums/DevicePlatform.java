package in.co.daalchini.data.constants.enums;

public enum DevicePlatform {
    android, web
}
