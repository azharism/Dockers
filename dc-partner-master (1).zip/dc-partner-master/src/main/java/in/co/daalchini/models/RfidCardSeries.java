package in.co.daalchini.models;

import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.ReadOnlyProperty;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.StringJoiner;


@Entity
@Getter
@Setter
@RequiredArgsConstructor
@Table(name = "rfid_card_series")
public class RfidCardSeries {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    private Long id;

    @Column(name = "code", unique = true)
    private String code;

    @Column(name = "description")
    private String description;

    @Column(name = "corporate_id")
    private Long corporateId;

    @ReadOnlyProperty
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "corporate_id", insertable = false, updatable = false)
    private CorporateDetails corporateDetails;

    @Column(name = "initial_balance")
    private Double initialBalance;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "rfidCardSeries", fetch = FetchType.LAZY)
    private Collection<RfidCard> rfidCards;

    @PrePersist
    void createTimestamp() {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp() {
        this.updatedAt = DateTimeHelper.now();
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", RfidCardSeries.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("code='" + code + "'")
                .add("description='" + description + "'")
                .add("initialBalance=" + initialBalance)
                .add("active=" + active)
                .toString();
    }
}
