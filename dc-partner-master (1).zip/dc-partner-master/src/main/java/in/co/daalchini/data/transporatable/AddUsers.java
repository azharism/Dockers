package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.Collection;
import java.util.List;
import java.util.StringJoiner;

public final class AddUsers {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static final class Request {

        @JsonProperty("userInfoList")
        private List<@Valid UserInfo> userInfoList;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class UserInfo {

        @Positive
        @NotNull(message = "Index is required")
        @JsonProperty("index")
        private Integer index;

        @NotNull(message = "Employee Id required")
        @Pattern(regexp = "[A-Z0-9]+$", message = "invalid employeeId")
        @JsonProperty("employeeId")
        private String employeeId;

        @NotNull(message = "Employee name required")
        @Pattern(regexp = "[a-zA-Z ]+$", message = "Invalid employeeName")
        @JsonProperty("employeeName")
        private String employeeName;

        @NotNull(message = "Employee email required")
        @Email(message = "Invalid Email")
        @JsonProperty("employeeEmail")
        private String employeeEmail;

        @Size(max = 40)
        @JsonProperty("businessName")
        private String businessName;

        public String getEmployeeEmailDomain() {
            return employeeEmail.split("@")[1];
        }


        @Override
        public String toString() {
            return new StringJoiner(", ", UserInfo.class.getSimpleName() + "[", "]")
                    .add("index=" + index)
                    .add("employeeId='" + employeeId + "'")
                    .add("employeeName='" + employeeName + "'")
                    .add("employeeEmail='" + PiiHelper.maskEmail(employeeEmail) + "'")
                    .add("businessName=" + businessName)
                    .toString();
        }
    }


    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    @Builder
    public static final class Response {
        private Integer usersAdded;
        private Collection<UserInfoResponse> successes;
        private Collection<UserInfoResponse> failures;
    }


    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    @Builder
    public static final class UserInfoResponse {
        private Integer index;
        private String employeeId;
        private String employeeEmail;
        private String reason;
    }
}
