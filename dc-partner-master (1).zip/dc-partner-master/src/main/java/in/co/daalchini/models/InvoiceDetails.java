package in.co.daalchini.models;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "sku_groups_invoice_details")
@NamedQuery(name = "InvoiceDetails.findAll", query = "SELECT i FROM InvoiceDetails i")
public class InvoiceDetails implements Serializable{

	private static final long serialVersionUID = -2323064517363733978L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	private Long id;
	
	@Column(name = "invoice_no")
	private String invoiceNo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "invoice_date")
	private Date invoiceDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "recieved_date")
	private Date recievedDate;

	private String comments;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
	@CreationTimestamp
	private Date createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at")
	@UpdateTimestamp
	private Date updatedAt;

	@Column(name = "user_id")
	private User user;
	
	// bi-directional many-to-one association to Warehous
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "warehouse_id")
	private Warehouse warehous;
	
	public Date getUpdatedAt() {
		return updatedAt;
	}

	public InvoiceDetails() {
		super();
	}

	public InvoiceDetails(Long id) {
		super();
		this.id = id;
	}
	
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Date getRecievedDate() {
		return recievedDate;
	}

	public void setRecievedDate(Date recievedDate) {
		this.recievedDate = recievedDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getCreatedAt() {
		return createdAt;
	}
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Warehouse getWarehous() {
		return warehous;
	}

	public void setWarehous(Warehouse warehous) {
		this.warehous = warehous;
	}

	@Override
	public String toString() {
		return "InvoiceDetails [id=" + id + ", invoiceNo=" + invoiceNo + ", invoiceDate=" + invoiceDate
				+ ", recievedDate=" + recievedDate + ", comments=" + comments + ", createdAt=" + createdAt
				+ ", updatedAt=" + updatedAt + ", user=" + user + ", warehous=" + warehous + "]";
	}


}
