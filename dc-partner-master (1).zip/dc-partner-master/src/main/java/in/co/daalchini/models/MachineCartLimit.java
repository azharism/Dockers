package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vm_cart_limit")
@EntityListeners(AuditingEntityListener.class)
public class MachineCartLimit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "vm_id")
    private Long machineId;

    @Column(name = "cart_limit")
    private Integer cartLimit;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vm_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    public MachineCartLimit(Long machineId) {
        this.machineId = machineId;
    }

    public MachineCartLimit withCartLimit(Integer cartLimit) {
        this.cartLimit = cartLimit;

        return this;
    }
}
