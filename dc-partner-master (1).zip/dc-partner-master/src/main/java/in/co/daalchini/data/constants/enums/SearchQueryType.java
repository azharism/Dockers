package in.co.daalchini.data.constants.enums;

public enum SearchQueryType {
    phone, order_id
}
