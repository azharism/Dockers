package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.Collections;
import java.util.List;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineSeedData {

    @Builder.Default
    @JsonProperty("hardware_types")
    private List<DtoHardwareType> hardwareTypes = Collections.emptyList();

    @Builder.Default
    @JsonProperty("machine_types")
    private List<DtoMachineType> machineTypes = Collections.emptyList();

    @Builder.Default
    @JsonProperty("operational_status")
    private List<DtoOperationalStatus> operationalStatus = Collections.emptyList();

    @Builder.Default
    @JsonProperty("cohorts")
    private List<DtoCohort> cohorts = Collections.emptyList();

    @Builder.Default
    @JsonProperty("warehouses")
    private List<DtoWarehouse> warehouses = Collections.emptyList();

    @Builder.Default
    @JsonProperty("payment_configs")
    private List<DtoPaymentConfig> paymentConfigs = Collections.emptyList();

    @Builder.Default
    @JsonProperty("location_types")
    private List<DtoLocationType> locationTypes = Collections.emptyList();

    @Builder.Default
    @JsonProperty("corporates")
    private List<DtoCorporate> corporates = Collections.emptyList();
}
