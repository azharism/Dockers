package in.co.daalchini.models;


import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the form_types database table.
 * 
 */
@Entity
@Table(name="form_types")
@NamedQuery(name="FormType.findAll", query="SELECT f FROM FormType f")
public class FormType implements Serializable {

	private static final long serialVersionUID = -8348478365884527411L;

	@Id
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_at")
	private Date createdAt;

	private String type;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_at")
	private Date updatedAt;

	public FormType() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

}