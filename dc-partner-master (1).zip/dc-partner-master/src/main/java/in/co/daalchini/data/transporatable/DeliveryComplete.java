package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;


public final class DeliveryComplete {

    @Getter
    @ToString
    @EqualsAndHashCode
    public static final class Request {

        private final String orderId;
        private final String pin;
        private final Long vendingMachineId;
        private final Long skuGroupId;
        private final Long manufacturerVariantId;
        private final Long slotIdentifier;
        private final List<LineItem> orderLineItems;

        @JsonCreator
        public Request (
            @JsonProperty("orderId") final String orderId,
            @JsonProperty("pin") final String pin,
            @JsonProperty("vendingMachineId") final Long vendingMachineId,
            @JsonProperty("skuGroupId") final Long skuGroupId,
            @JsonProperty("manufacturerVariantId") final Long manufacturerVariantId,
            @JsonProperty("slotIdentifier") final Long slotIdentifier,
            @JsonProperty("orderLineItems") final List<LineItem> orderLineItems)
        {
            this.orderId = orderId;
            this.pin = pin;
            this.vendingMachineId = vendingMachineId;
            this.skuGroupId = skuGroupId;
            this.manufacturerVariantId = manufacturerVariantId;
            this.slotIdentifier = slotIdentifier;
            this.orderLineItems = orderLineItems;
        }
    }

    @Builder
    @Getter
    @ToString
    @EqualsAndHashCode
    @RequiredArgsConstructor
    public static final class Response {
        private final String orderId;
    }

    @Getter
    @ToString
    @EqualsAndHashCode
    public static final class LineItem {

        private final Long id;
        private final Integer successCount;
        private final Integer failureCount;

        @JsonCreator
        public LineItem (
            @JsonProperty("id") final Long id,
            @JsonProperty("successCount") final Integer successCount,
            @JsonProperty("failureCount") final Integer failureCount)
        {
            this.id = id;
            this.successCount = successCount;
            this.failureCount = failureCount;
        }
    }

}
