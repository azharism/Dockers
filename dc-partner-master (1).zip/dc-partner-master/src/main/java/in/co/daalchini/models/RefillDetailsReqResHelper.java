package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Date;

public class RefillDetailsReqResHelper implements Serializable{

	private static final long serialVersionUID = 5612561727337335685L;

	private Long id;
	
	@JsonProperty(value = "manufacturer_variant_id") private Long manufacturerVariant;

	@JsonProperty(value = "refill_id") private Long refill;

	@JsonProperty(value = "slot_identifier") private String slot;
	
//	@JsonProperty(value = "prefilled_quantity") private short prefilledQuantity;

	@JsonProperty(value = "impacted_quantity") private Short impactedQuantity;
	
	@JsonProperty(value = "final_quantity") private Short finalQuantity;
	
	@JsonProperty(value = "refill_type_id") private Long refillType;

	private Date createdAt;

	private Date updatedAt;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getManufacturerVariant() {
		return manufacturerVariant;
	}

	public void setManufacturerVariant(Long manufacturerVariant) {
		this.manufacturerVariant = manufacturerVariant;
	}

	public Long getRefill() {
		return refill;
	}

	public void setRefill(Long refill) {
		this.refill = refill;
	}

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}

//	public short getPrefilledQuantity() {
//		return prefilledQuantity;
//	}
//
//	public void setPrefilledQuantity(short prefilledQuantity) {
//		this.prefilledQuantity = prefilledQuantity;
//	}

	public Short getImpactedQuantity() {
		return impactedQuantity;
	}

	public void setImpactedQuantity(Short impactedQuantity) {
		this.impactedQuantity = impactedQuantity;
	}

	public Short getFinalQuantity() {
		return finalQuantity;
	}

	public void setFinalQuantity(Short finalQuantity) {
		this.finalQuantity = finalQuantity;
	}

	public Long getRefillType() {
		return refillType;
	}

	public void setRefillType(Long refillType) {
		this.refillType = refillType;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public RefillDetailsReqResHelper(Long id, Long manufacturerVariant, Long refill, String slot,
                                     short impactedQuantity, short finalQuantity, Long refillType, Date createdAt, Date updatedAt) {
		super();
		this.id = id;
		this.manufacturerVariant = manufacturerVariant;
		this.refill = refill;
		this.slot = slot;
//		this.prefilledQuantity = prefilledQuantity;
		this.impactedQuantity = impactedQuantity;
		this.finalQuantity = finalQuantity;
		this.refillType = refillType;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}

	public RefillDetailsReqResHelper(RefillDetails details) {
		super();
		this.id = details.getId();
		this.finalQuantity = details.getFinalQuantity();
		this.impactedQuantity = details.getImpactedQuantity();
//		this.prefilledQuantity = details.getPrefilledQuantity();
		this.slot = details.getSlot();
		
		if(details.getManufacturerVariant()!=null && details.getManufacturerVariant().getId()!=null)
			this.manufacturerVariant = (details.getManufacturerVariant().getId());
		
		if(details.getRefill()!=null && details.getRefill().getId()!=null)
			this.refill = (details.getRefill().getId());
		
		if(details.getRefillType()!=null && details.getRefillType().getId()!=null)
			this.refillType = (details.getRefillType().getId());
	}
}
