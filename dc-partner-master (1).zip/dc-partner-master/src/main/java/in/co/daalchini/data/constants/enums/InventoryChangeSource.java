package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum InventoryChangeSource {
    Database("database"),
    Application("application");

    private final @JsonValue
    String value;

   InventoryChangeSource(String value) {
       this.value = value;
   }

    @JsonCreator
    public static InventoryChangeSource of(String value) {
        return Arrays.stream(InventoryChangeSource.values())
                .filter(x -> x.value.equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }
}
