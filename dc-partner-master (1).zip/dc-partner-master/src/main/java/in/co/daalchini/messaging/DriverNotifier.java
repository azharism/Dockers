package in.co.daalchini.messaging;

import com.fasterxml.jackson.core.JsonProcessingException;
import in.co.daalchini.data.transporatable.OrderComplete.LineItem;
import in.co.daalchini.data.transporatable.OrderComplete.Request;
import in.co.daalchini.data.transporatable.message.OrderStateChange;
import in.co.daalchini.data.untransportable.VMType;
import in.co.daalchini.data.untransportable.OrderState;
import in.co.daalchini.data.untransportable.TokenType;
import in.co.daalchini.models.*;
import in.co.daalchini.repository.DashboardUserTokenRepository;
import in.co.daalchini.repository.OrderRepository;
import in.co.daalchini.repository.PartnerCurrentMachineRepository;
import in.co.daalchini.service.FirebaseMessagingService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Log4j2
@Service
public class DriverNotifier {

    private final FirebaseMessagingService firebaseMessagingService;
    private final OrderRepository orderRepository;
    private final DashboardUserTokenRepository dashboardUserTokenRepository;
    private final PartnerCurrentMachineRepository partnerCurrentMachineRepository;

    @Autowired
    public DriverNotifier (
        FirebaseMessagingService firebaseMessagingService,
        OrderRepository orderRepository,
        DashboardUserTokenRepository dashboardUserTokenRepository,
        PartnerCurrentMachineRepository partnerCurrentMachineRepository)
    {
        this.firebaseMessagingService = firebaseMessagingService;
        this.orderRepository = orderRepository;
        this.dashboardUserTokenRepository = dashboardUserTokenRepository;
        this.partnerCurrentMachineRepository = partnerCurrentMachineRepository;
    }

    @Transactional
    public void notifyDriver (OrderStateChange stateChange) throws JsonProcessingException {
        // fetch order details with vending machine type check
        final String orderId = stateChange.getOrderId();
        final OrderState orderState = stateChange.getOrderState();

        final Optional<Order> orderOptional =
            orderRepository.findByIdAndStatus(orderId, orderState);

        if (orderOptional.isPresent()) {
            final Order order = orderOptional.get();
            log.debug("Fetched order = {}", order);
            final VendingMachine vendingMachine = order.getVendingMachine();
            final VMType VMType = vendingMachine.getVmType();
            log.debug("Vending machine, id= {}, type = {}", vendingMachine.getId(), VMType);
            if (!VMType.equals(VMType.Mobility)) return;

            final Long vendingMachineId = vendingMachine.getId();
            Long dashboardUserId = partnerCurrentMachineRepository
                    .findByVmId(vendingMachineId)
                    .map(PartnerCurrentMachine::getCurrentDashboardUserId)
                    .orElse(null);
            if(dashboardUserId!=null){
                String token = dashboardUserTokenRepository
                        .findByUserIdAndTokenType(dashboardUserId, TokenType.FCM)
                        .map(DashboardUserToken::getAccessToken)
                        .orElse(null);
                if(token!=null){
                    List<String> tokens = Collections.singletonList(token);
                    sendDataMessage(tokens, order, vendingMachineId);
                }else{
                    log.warn("No fcm token associated with dashboard user");
                }
            }else{
                log.warn("No driver checked in with vmId :{}", vendingMachineId);
            }
        } else log.warn("Unable to find order in the database, id = [{}], status [{}]",
                        orderId, orderState);
    }

    private void sendDataMessage(
        final List<String> tokens,
        final Order order,
        final Long vendingMachineId) throws JsonProcessingException
    {
        final List<LineItem> lineItems = order.getOrderLineItems().stream()
                                              .map(LineItem::of).collect(Collectors.toList());
        firebaseMessagingService.sendDataMessage(
            tokens,
            order,
            Request.builder()
                   .orderId(order.getId())
                   .pin(order.getDcCode())
                   .vendingMachineId(vendingMachineId)
                    .mobileNo(order.getPhone())
                   .orderLineItems(lineItems)
                   .build()
                   .dataMap());

    }
}
