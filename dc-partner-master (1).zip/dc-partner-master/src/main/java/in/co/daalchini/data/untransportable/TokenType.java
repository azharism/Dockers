package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum TokenType {
    Auth("auth"),
    FCM("fcm"),
    PartnerWallet("ppw");

    private final @JsonValue String type;

    TokenType (String type) {
        this.type = type;
    }

    @JsonCreator
    public static TokenType of (final String typeStr) {
        return Stream.of(TokenType.values())
                     .filter(x -> x.type.equalsIgnoreCase(typeStr))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return type;
    }
}
