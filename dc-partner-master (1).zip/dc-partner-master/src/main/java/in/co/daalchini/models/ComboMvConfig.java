package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@Table(name = "combo_mv_config")
public class ComboMvConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "combo_id")
    private Long comboId;

    @Column(name = "mv_id")
    private Long mvId;

    @Column(name = "quantity")
    private Integer quantity;

    @Column(name = "price")
    private Double price;

    @ManyToOne
    @JoinColumn(name = "combo_id", insertable = false, updatable = false)
    private Combo combo;
}
