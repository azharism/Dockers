package in.co.daalchini.data.transporatable;


import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Data;

import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;
import java.util.StringJoiner;

@Data
@JsonIncludeProperties({"code", "description", "initial_balance"})
public class UpdateTagSeriesRequest {

    @NoLeadingAndTrailingSpace
    @Size(min = 4, max = 64, message = "code must be between 4 and 64 characters")
    @JsonProperty("code")
    private String code;

    @NoLeadingAndTrailingSpace
    @Size(max = 200, message = "description must not exceed 200 characters")
    @JsonProperty("description")
    private String description;

    @PositiveOrZero
    @JsonProperty("initial_balance")
    private Double initialBalance;


    @Override
    public String toString() {
        return new StringJoiner(", ", UpdateTagSeriesRequest.class.getSimpleName() + "[", "]")
                .add("code='" + code + "'")
                .add("description='" + description + "'")
                .add("initialBalance=" + initialBalance)
                .toString();
    }
}
