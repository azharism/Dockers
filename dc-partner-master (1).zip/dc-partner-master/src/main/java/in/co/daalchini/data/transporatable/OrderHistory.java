package in.co.daalchini.data.transporatable;

import in.co.daalchini.data.untransportable.OrderState;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

public final class OrderHistory {

    @Data
    @Builder
    public static final class Response {
        private Long vendingMachineId;
        private String vendingMachineAddress;
        private Long paymentId;
        private String orderId;
        private OrderState status;
        private Double amount;
        private Double mrp;
        private String dcCode;
        private LocalDateTime createdAt;
        private List<LineItem> lineItems;
    }

    @Data
    @Builder
    public static final class LineItem {
        private Long id;
        private Long skuGroupId;
        private Long variantId;
        private String variantName;
        private String variantFormType;
        private Long itemQuantity;
        private String imageUrl;
        private Double offerPrice;
        private Double mrp;
    }

}
