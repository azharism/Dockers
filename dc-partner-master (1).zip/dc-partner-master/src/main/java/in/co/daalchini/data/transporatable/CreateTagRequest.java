package in.co.daalchini.data.transporatable;


import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.util.StringJoiner;

@Data
@JsonIncludeProperties({"uid", "token"})
public class CreateTagRequest {

    @NotBlank
    @NoLeadingAndTrailingSpace
    @Pattern(regexp = "^[0-9]{10}$", message = "invalid uid")
    @JsonProperty("uid")
    private String uid;

    @NotBlank
    @NoLeadingAndTrailingSpace
    @Pattern(regexp = "^[A-Z0-9]{8,10}$", message = "invalid token")
    @JsonProperty("token")
    private String token;

    @Override
    public String toString() {
        return new StringJoiner(", ", CreateTagRequest.class.getSimpleName() + "[", "]")
                .add("uid='" + uid + "'")
                .add("token='" + token + "'")
                .toString();
    }
}
