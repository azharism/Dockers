package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoWarehouseUser;
import in.co.daalchini.models.DashboardUser;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface DashboardUserMapper {

    @Mapping(target = "userId", source = "user.id")
    @Mapping(target = "name", source = "user.dashboardUserDetails.userName")
    @Mapping(target = "mmiDeviceId", source = "user.dashboardUserData.mmiDeviceId")
    @Mapping(target = "role", source = "user.dashboardRole.name")
    @Mapping(target = "warehouseName", source = "warehouseName")
    DtoWarehouseUser toDtoWarehouseUser (String warehouseName, DashboardUser user);

    default Collection<DtoWarehouseUser> toDtoWarehouseUsers (
        String warehouseName,
        Collection<DashboardUser> users)
    {
        return users.stream().map(user -> toDtoWarehouseUser(warehouseName, user)).sorted().collect(Collectors.toList());
    }
}
