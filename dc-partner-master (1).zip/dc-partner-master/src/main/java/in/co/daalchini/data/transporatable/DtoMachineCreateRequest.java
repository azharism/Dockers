package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.Set;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineCreateRequest {

    @NotNull
    @Size(max = 50)
    @JsonProperty("name")
    private String name;

    @NotNull
    @JsonProperty("hardware_type_id")
    private Integer hardwareTypeId;

    @NotNull
    @JsonProperty("machine_type_id")
    private Integer machineTypeId;

    @Max(10)
    @Positive
    @JsonProperty("cart_limit")
    private Integer cartLimit;

    @NotNull
    @JsonProperty("health_report_enabled")
    private boolean healthReportEnabled;

    @NotNull
    @JsonProperty("consumer_app_enabled")
    private boolean consumerAppEnabled;

    @Max(100)
    @PositiveOrZero
    @JsonProperty("share_percentage")
    private Integer sharePercentage = 0;

    @NotNull
    @Positive
    @JsonProperty("warehouse_id")
    private Long warehouseId;

    @NotNull
    @Positive
    @JsonProperty("corporate_id")
    private Long corporateId;

    @NotNull
    @Valid
    @JsonProperty("address")
    private DtoMachineAddress address;

    @NotNull
    @JsonProperty("serial_number")
    private String serialNumber;

    @NotNull
    @JsonProperty("cohort_ids")
    private Set<Long> cohortIds;

    @NotNull
    @JsonProperty("payment_config_ids")
    private Set<Long> paymentConfigIds;

    @NotNull
    @JsonProperty("slots")
    private Set<DtoMachineSlot> slots;

}
