package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

public final class SchedulePickup {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Request {
        private LocalDate date;
        private LocalTime timeRangeStart;
        private LocalTime timeRangeEnd;
    }
}
