package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonFormat;
import in.co.daalchini.data.untransportable.OrderState;
import in.co.daalchini.models.OrderLineItem;
import in.co.daalchini.models.PartnerAddress;
import in.co.daalchini.models.PartnerOrderDelivery;
import in.co.daalchini.models.PartnerOrderPickup;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public final class ScheduledPickupDelivery {

    @Data
    @Builder
    public static final class Response {
        private String orderId;
        private OrderState status;
        private String displayStatus;
        private LocalDateTime updatedAt;
        private Long partnerId;
        private PickupDetails pickupDetails;
        private DeliveryDetails deliveryDetails;
        private List<LineItem> lineItems;
    }

    @Data
    @Builder
    public static class PickupDetails {
        private LocalDateTime createdAt;
        private LocalDate scheduledDate;
        private LocalTime scheduledTimeBegin;
        private LocalTime scheduledTimeEnd;

        public static PickupDetails of (PartnerOrderPickup pickup) {
            return PickupDetails
                .builder()
                .createdAt(pickup.getCreatedAt())
                .scheduledDate(pickup.getDate())
                .scheduledTimeBegin(pickup.getTimeBegin())
                .scheduledTimeBegin(pickup.getTimeEnd())
                .build();
        }
    }

    @Data
    @Builder
    public static class DeliveryDetails{
        private String street;
        private String houseNumber;
        private String landmark;
        private String locationUrl;
        private String saveAs;
        @JsonFormat(pattern = "yyyy-MM-dd HH-mm-ss")
        private LocalDateTime deliveryDateEnd;

        public static DeliveryDetails of (PartnerOrderDelivery partnerOrderDelivery){
            PartnerAddress partnerAddress = partnerOrderDelivery.getPartnerAddress();
            return DeliveryDetails
                    .builder()
                    .street(partnerAddress.getStreet())
                    .houseNumber(partnerAddress.getHouseNumber())
                    .landmark(partnerAddress.getLandmark())
                    .locationUrl(partnerAddress.getLocationUrl())
                    .saveAs(partnerAddress.getSaveAs())
                    .deliveryDateEnd(partnerOrderDelivery.getDeliveryDateEnd())
                    .build();
        }
    }

    @Data
    @Builder
    public static class LineItem {
        private Long id;
        private Long quantity;
        private String mvName;

        public static LineItem of (OrderLineItem oli) {
            return LineItem
                .builder()
                .id(oli.getId())
                .quantity(oli.getItemQuantity())
                .mvName(oli.getProductName())
                .build();
        }
    }

}
