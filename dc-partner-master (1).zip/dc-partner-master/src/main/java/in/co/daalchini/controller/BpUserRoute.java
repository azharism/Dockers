package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.BpUserContext;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.BpUsers.BpUserInfo;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.BpUserService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collection;
import java.util.List;


@Log4j2
@RestController
public class BpUserRoute {

    private final BpUserService bpUserService;

    public BpUserRoute(BpUserService bpUserService) {
        this.bpUserService = bpUserService;
    }

    @PreAuthorize("hasAuthority('map_bp_user') or hasAuthority('map_bp_user_internal')")
    @PostMapping(BpUserContext.BUSINESS_PROFILE)
    public AddUsers.Response addUser(
            @RequestBody @Valid AddUsers.Request request,
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @PathVariable(value = "id") Long corporateId) {
        log.info("Request received for adding users :{}", request);
        AddUsers.Response response;
        try {
            var isInternalUser = userDetails.hasPermission("map_bp_user_internal");
            response = bpUserService.addBpUsers(userDetails.getUserId(), isInternalUser, corporateId, request.getUserInfoList());
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error in Adding User profile: ", e);
            throw e;
        }
        return response;
    }

    @PreAuthorize("hasAuthority('view_bp_user')or hasAuthority('map_bp_user_internal')")
    @PostMapping(BpUserContext.BUSINESS_PROFILE_APPROVE)
    public DtoBpUnlinkResponse approveUnlink(
            @PathVariable(value = "ucmId") Long ucmId,
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        DtoBpUnlinkResponse bpResponse;
        try {
            bpResponse = bpUserService.approveUnlinkRequest(userDetails.getUserId(), ucmId);
        } catch (Exception e) {
            log.error("Error in fetching users: ", e);
            throw e;
        }

        return bpResponse;
    }

    @PreAuthorize("hasAuthority('view_bp_user')or hasAuthority('map_bp_user_internal')")
    @GetMapping(BpUserContext.BUSINESS_PROFILE)
    public Collection<BpUsers.BpUserInfo> getBpUsers(
            @RequestParam(value = "status", required = false) Boolean status,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "offset", required = false) Integer offset,
            @RequestParam(value = "unlinkRequest", required = false) Boolean unlinkRequest,
            @RequestParam(value = "usersCorporateId", required = false) String usersCorporateId,
            @RequestParam(value = "userName", required = false) String userName,
            @RequestParam(value = "emailId", required = false) String email,
            @PathVariable(value = "id") Long corporateId,
            @AuthenticationPrincipal AuthUserDetails userDetails
    ) {
        log.info(
                "Request received for fetching users of status :{} by userId : {},limit {} and offset {} and unlinkRequest {}",
                status,
                userDetails.getUserId(),
                limit,
                offset,
                unlinkRequest);
        Collection<BpUserInfo> response;
        try {
            response = bpUserService.fetchBpUsers(
                    status, limit, offset, userDetails.getUserId(), corporateId, userName, usersCorporateId, email);
        } catch (Exception e) {
            log.error("Error in fetching users: ", e);
            throw e;
        }
        return response;
    }

    @PreAuthorize("hasAuthority('map_bp_user')or hasAuthority('map_bp_user_internal')")
    @DeleteMapping(BpUserContext.BUSINESS_PROFILE)
    public DeactivateUsers.Response deactivateUsers(
            @RequestBody DeactivateUsers.Request request,
            @PathVariable(value = "id") Long corporateId,
            @AuthenticationPrincipal AuthUserDetails userDetails
    ) {
        DeactivateUsers.Response response;
        try {
            response = bpUserService.deactivateUsers(request, corporateId, userDetails.getUserId());
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error in Deactivating users: ", e);
            throw e;
        }
        return response;
    }

    @PreAuthorize("hasAuthority('map_bp_user') or hasAuthority('map_bp_user_internal')")
    @PostMapping(BpUserContext.ACTIVATE)
    public ActivateUsers.Response activateUsers(
            @RequestBody ActivateUsers.Request request,
            @PathVariable("id") Long corporateId,
            @AuthenticationPrincipal AuthUserDetails userDetails
    ) {
        ActivateUsers.Response response;
        try {
            boolean isInternal = userDetails.hasPermission("map_bp_user_internal");
            response = bpUserService.activateUsers(request, corporateId, userDetails.getUserId(), isInternal);
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error in activating users: ", e);
            throw e;
        }
        return response;
    }

    @PreAuthorize("hasAuthority('map_bp_user') or hasAuthority('map_bp_user_internal')")
    @PatchMapping(BpUserContext.BUSINESS_PROFILE)
    public BpUsers.UpdateResponse updateUsers(
            @RequestBody @Valid BpUsers.UpdateRequest request,
            @PathVariable("id") Long ucmId,
            @AuthenticationPrincipal AuthUserDetails userDetails
    ) {
        BpUsers.UpdateResponse response;
        try {
            response = bpUserService.updateUserInfo(request, ucmId, userDetails.getUserId());
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error in updating user: ", e);
            throw e;
        }
        return response;
    }

    @GetMapping(BpUserContext.USER_CORPORATE)
    public List<UserCorporate.Response> fetchUserCorporates(
            @AuthenticationPrincipal AuthUserDetails userDetails
    ) {
        log.info("Request received for fetching corporate details for user :{}", userDetails);
        try {
            List<UserCorporate.Response> responses = bpUserService.fetchCorporateDetails(userDetails);
            log.info("Response :{}", responses);
            return responses;
        } catch (Exception e) {
            log.error("Error in fetching user corporate details: ", e);
            throw e;
        }
    }
}
