package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.StringJoiner;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoOrderDetailResponse {

    @JsonProperty("id")
    private String id;

    @JsonProperty("status")
    private String status;

    @JsonProperty("created_at")
    private LocalDateTime createdAt;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("amount")
    private Double amount;

    @JsonProperty("city")
    private String city;

    @JsonProperty("vmAddress")
    private String vmAddress;

    @JsonProperty("name")
    private String vmName;

    @JsonProperty("machine_id")
    private Long machineId;

    @JsonProperty("source")
    private String source;

    @JsonProperty("dcCode")
    private String dcCode;

    @JsonProperty("user_details")
    private UserDetails userDetails;

    @Builder.Default
    @JsonProperty("line_items")
    private List<LineItem> lineItems = Collections.emptyList();

    @JsonProperty("payment_details")
    private PaymentDetails paymentDetails;

    @JsonProperty("refund_details")
    private List<RefundDetails> refundDetails;

    @Data
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class UserDetails {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("name")
        private String name;

        @JsonProperty("email")
        private String email;


        @Override
        public String toString() {
            return new StringJoiner(", ", UserDetails.class.getSimpleName() + "[", "]")
                    .add("id=" + id)
                    .add("name='" + name + "'")
                    .add("email='" + PiiHelper.maskEmail(email) + "'")
                    .toString();
        }
    }

    @Data
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LineItem {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("name")
        private String name;

        @JsonProperty("slot_id")
        private Integer slotId;

        @JsonProperty("mrp")
        private Double mrp;

        @JsonProperty("offer_price")
        private Double offerPrice;

        @JsonProperty("item_count")
        private Integer itemCount;

        @JsonProperty("sub_total")
        private Double subTotal;

        @JsonProperty("success_count")
        private Integer successCount;

        @JsonProperty("failure_count")
        private Integer failureCount;

        @JsonProperty("vend_remaining_count")
        private Integer vendRemainingCount;

        @JsonProperty("refund_count")
        private Integer refundCount;
    }

    @Data
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PaymentDetails {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("pg_name")
        private String pgName;

        @JsonProperty("amount")
        private Double amount;

        @JsonProperty("status")
        private String status;

        @JsonProperty("updated_at")
        private LocalDateTime updatedAt;
    }

    @Data
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RefundDetails {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("pg_name")
        private String pgName;

        @JsonProperty("amount")
        private Double amount;

        @JsonProperty("status")
        private String status;

        @JsonProperty("reason")
        private String reason;

        @JsonProperty("updated_at")
        private LocalDateTime updatedAt;

        @JsonProperty("refundStatus")
        private String refundStatus;


    }
}

