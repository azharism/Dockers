package in.co.daalchini.data.transporatable.message;

import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ZohoInventorySyncEvent implements Jsonable {

    private Long kitId;
    private Long kitRefillId;
    private String operation;
    private List<MachineWiseMvSale> machineWiseMvSales;


    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static final class MachineWiseMvSale{
        private Long machineId;
        private List<MvIdSale> mvIdSales;
    }

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static final class MvIdSale{
        private Long mvId;
        private Integer saleCount;
    }

    public String json () {
        return JsonUtil.toJson(this);
    }
}
