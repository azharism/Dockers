package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.data.untransportable.VMType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vending_machines")
@EntityListeners(AuditingEntityListener.class)
public class VendingMachine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "hardware_type_id")
    private Integer hardwareTypeId;

    @Column(name = "vendor_machine_type_id")
    private Integer machineTypeId;

    @Column(name = "operational_status_id")
    private Integer operationalStatusId;

    @Column(name = "health_reports_enabled")
    private boolean healthReportEnabled;

    @Column(name = "consumer_app_enable")
    private boolean consumerAppEnabled;

    @Column(name = "vendor_machine_address_id")
    private Long addressId;

    @Column(name = "warehouse_id")
    private Long warehouseId;

    @JsonIgnore
    @CreatedBy
    @Column(name = "created_by")
    private Long createdBy;

    @JsonIgnore
    @OneToMany(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private List<VmFailedSlotStatus> vmFailedSlotStatus;

    @JsonIgnore
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @JsonIgnore
    @Column(name = "share_percentage")
    private Integer sharePercentage;

    @JsonIgnore
    @Column(name = "vending_machine_health_details_id")
    private Long vendingMachineHealthDetailsId;

    @JsonIgnore
    @Column(name = "vendor_machine_type_id", insertable = false, updatable = false)
    private VMType vmType;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_machine_address_id", insertable = false, updatable = false)
    private VendingMachineAddress address;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_health_details_id", insertable = false, updatable = false)
    private VendingMachineHealthDetails VendingMachineHealthDetails;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "warehouse_id", insertable = false, updatable = false)
    private Warehouse warehouse;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hardware_type_id", insertable = false, updatable = false)
    private MachineHardwareType hardwareType;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_machine_type_id", insertable = false, updatable = false)
    private MachineType machineType;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "operational_status_id", insertable = false, updatable = false)
    private MachineOperationalStatus operationalStatus;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "vm_cohort_machine_user_mapping",
        joinColumns = {@JoinColumn(name = "machine_id")},
        inverseJoinColumns = {@JoinColumn(name = "user_id")})
    private Set<DashboardUser> dashboardUsers;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "vm_cohort_machine_user_mapping",
        joinColumns = {@JoinColumn(name = "machine_id")},
        inverseJoinColumns = {@JoinColumn(name = "cohort_id")})
    private Set<MachineCohort> cohorts;

    @JsonIgnore
    @OneToMany(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private List<Order> orders;

    @JsonIgnore
    @OneToMany(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private List<VmFailedSlotSession> vmFailedSlotSessions;

    @JsonIgnore
    @OneToMany(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private Set<MachinePaymentConfig> paymentConfigs;

    @JsonIgnore
    @OneToMany(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private Set<MachineAvailableItem> items;

    @JsonIgnore
    @LazyToOne(LazyToOneOption.NO_PROXY)
    @OneToOne(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private MachineKey machineKey;

    @JsonIgnore
    @LazyToOne( LazyToOneOption.NO_PROXY )
    @OneToOne(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private MachineStatus machineStatus;

    @JsonIgnore
    @LazyToOne( LazyToOneOption.NO_PROXY )
    @OneToOne(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private VmWarehouseLedger vmWarehouseMapping;

    @JsonIgnore
    @LazyToOne( LazyToOneOption.NO_PROXY )
    @OneToOne(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private CorporateMachine corporateMachine;

    @JsonIgnore
    @LazyToOne( LazyToOneOption.NO_PROXY )
    @OneToOne(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private RefillSuggestionUrgencyScore refillSuggestionUrgencyScore;

    @JsonIgnore
    @LazyToOne( LazyToOneOption.NO_PROXY )
    @OneToOne(mappedBy = "vendingMachine", fetch = FetchType.LAZY)
    private MachineCartLimit machineCartLimit;

    public VendingMachine (Long vendingMachineId) {
        this.id = vendingMachineId;
    }

    @Override
    public String toString () {
        return new StringJoiner(", ", VendingMachine.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("name='" + name + "'")
            .add("hardwareTypeId=" + hardwareTypeId)
            .add("machineTypeId=" + machineTypeId)
            .add("operationalStatusId=" + operationalStatusId)
            .add("healthReportEnabled=" + healthReportEnabled)
            .add("consumerAppEnabled=" + consumerAppEnabled)
            .add("addressId=" + addressId)
            .add("warehouseId=" + warehouseId)
            .add("createdAt=" + createdAt)
            .add("updatedAt=" + updatedAt)
            .add("sharePercentage=" + sharePercentage)
            .add("vendingMachineHealthDetailsId=" + vendingMachineHealthDetailsId)
            .add("vmType=" + vmType)
            .toString();
    }
}
