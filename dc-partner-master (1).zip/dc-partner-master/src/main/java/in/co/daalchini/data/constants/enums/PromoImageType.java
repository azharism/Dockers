package in.co.daalchini.data.constants.enums;

public enum PromoImageType {
    screensaver,
    banner_app,
    banner_kiosk,
    banner_kiosk_payment;

    public VmImagePlatform getImagePlatform() {
        switch (this) {
            case banner_app: {
                return VmImagePlatform.ConsumerApp;
            }
            case banner_kiosk:
            case banner_kiosk_payment:
            case screensaver: {
                return VmImagePlatform.Kiosk;
            }
        }

        return null;
    }

    public VmImageType getImageType() {
        switch (this) {
            case banner_kiosk:
            case banner_app: {
                return VmImageType.Banner;
            }
            case screensaver: {
                return VmImageType.Screensaver;
            }
            case banner_kiosk_payment: {
                return VmImageType.Banner_Payment;
            }
        }

        return null;
    }
}
