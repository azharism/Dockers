package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@Table(name = "machine_payment_gateway_configs")
public class MachinePaymentConfig {

    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "machine_id", nullable = false)
    private Long machineId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    @Column(name = "config_id", nullable = false)
    private Long configId;

    @Column(name = "payment_gateway_id", nullable = false)
    private Integer paymentGatewayId;

    @Column(name = "name", length = 20)
    private String name;

    @JsonIgnore
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @JsonIgnore
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
}
