package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Builder;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;

@Data
@Builder
@JsonIncludeProperties({"name", "expiry_date_month", "domains"})
public class DtoCorporateCreateRequest {

    @NotNull
    @Size(min = 3, max = 100)
    @NoLeadingAndTrailingSpace
    @JsonProperty("name")
    public String name;

    @Min(1)
    @Max(28)
    @JsonProperty("expiry_date_month")
    public Integer expiryDateMonth;

    @JsonProperty("domains")
    public List<@Valid EmailDomain> emailDomains;

    @Data
    @Builder
    @JsonIncludeProperties({"domain", "description", "initial_balance"})
    public static class EmailDomain {

        @NotNull
        @Size(min = 3, max = 256)
        @NoLeadingAndTrailingSpace
        @JsonProperty("domain")
        public String domain;

        @Size(min = 3, max = 45)
        @NoLeadingAndTrailingSpace
        @JsonProperty("description")
        public String description;

        @DecimalMin("0.0")
        @Digits(integer = 3, fraction = 2)
        @JsonProperty("initial_balance")
        public Double initialBalance;
    }
}

