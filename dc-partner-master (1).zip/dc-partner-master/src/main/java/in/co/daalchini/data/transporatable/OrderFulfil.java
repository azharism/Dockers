package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

public final class OrderFulfil {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Request {
        private boolean success;
        private String reason;
        private String dcCode;
        private List<LineItem> lineItems;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class LineItem {
        private Long id;
        private Long successCount;
        private Long failureCount;
    }
}
