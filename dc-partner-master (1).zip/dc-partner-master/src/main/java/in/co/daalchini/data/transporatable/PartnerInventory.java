package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

import java.util.List;


public final class PartnerInventory {

    @Data
    @Builder
    public static final class Response {
        private Long mvId;
        private String name;
        private Long unitCount;
        private String quantity;
        private List<String> images;
    }
}
