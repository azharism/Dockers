package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.SlotUtilizationContext;
import in.co.daalchini.data.constants.RouteConstants.SlotUtilizationContextV2Context;
import in.co.daalchini.data.constants.RouteConstants.UserCohortsContext;
import in.co.daalchini.data.constants.DCConstants;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.models.response.CohortsResponse;
import in.co.daalchini.models.response.DCResponse;
import in.co.daalchini.models.response.SlotUtilizationResponse;
import in.co.daalchini.service.CohortsService;
import in.co.daalchini.service.SlotUtilizationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class SlotUtilizationController {

	private static Logger log = LoggerFactory.getLogger(SlotUtilizationController.class);
	private SlotUtilizationService service;
	private CohortsService cohortsService;
	
	@Autowired
	public SlotUtilizationController(SlotUtilizationService service,
									 CohortsService cohortsService) {
		this.service = service;
		this.cohortsService=cohortsService;
	}

	@Deprecated
	@RequestMapping(value = SlotUtilizationContext.BASE, method = RequestMethod.GET)
	public DCResponse<SlotUtilizationResponse> slotUtilizationHelper(){
		
		log.info("[Fetching Slot Utilization]");

		DCResponse<SlotUtilizationResponse> response = new DCResponse<>();
		response.setStatus(DCConstants.API_SUCCESS);
		response.setStatusMessage(DCConstants.API_SUCCESS_MESSAGE);
		response.setStatusCode(DCConstants.API_SUCCESS_CODE);
		
		try{
			response.setData(this.service.getSlotUtilzDetails());
		} catch (NullPointerException  e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getMessage());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_NULL_REQUEST);
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getMessage());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST);
			e.printStackTrace();
		} catch (Exception e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getClass().getSimpleName());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
			e.printStackTrace();
		}

		return response;
	}

	@RequestMapping(value = SlotUtilizationContextV2Context.SLOT_UTILIZATION, method = RequestMethod.GET)
	@PreAuthorize("hasAuthority('slot_utilization')")
	public DCResponse<SlotUtilizationResponse> getSlotUtilization(@RequestParam(value = "cohortId") String cohortId,
														   @AuthenticationPrincipal AuthUserDetails userDetails){
		String userId=userDetails.getUserId().toString();
		DCResponse<SlotUtilizationResponse> response = new DCResponse<>();
		response.setStatus(DCConstants.API_SUCCESS);
		response.setStatusMessage(DCConstants.API_SUCCESS_MESSAGE);
		response.setStatusCode(DCConstants.API_SUCCESS_CODE);

		try{
			response.setData(this.service.getSlotUtilzDetails(userId,cohortId));
		} catch (NullPointerException  e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getMessage());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_NULL_REQUEST);
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getMessage());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST);
			e.printStackTrace();
		} catch (Exception e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getClass().getSimpleName());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
			e.printStackTrace();
		}
		return response;
	}

	@RequestMapping(value=UserCohortsContext.USER_COHORTS, method = RequestMethod.GET)
	public DCResponse<List<CohortsResponse>> getCohorts(
			@AuthenticationPrincipal AuthUserDetails userDetails){
		String userId=userDetails.getUserId().toString();
		DCResponse<List<CohortsResponse>> response = new DCResponse<>();
		response.setStatus(DCConstants.API_SUCCESS);
		response.setStatusMessage(DCConstants.API_SUCCESS_MESSAGE);
		response.setStatusCode(DCConstants.API_SUCCESS_CODE);

		try{
			response.setData(this.cohortsService.getCohorts(userId));
		}catch (NullPointerException  e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getMessage());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_NULL_REQUEST);
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getMessage());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST);
			e.printStackTrace();
		} catch (Exception e) {
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getClass().getSimpleName());
			response.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
			e.printStackTrace();
		}
		return response;
	}

}
