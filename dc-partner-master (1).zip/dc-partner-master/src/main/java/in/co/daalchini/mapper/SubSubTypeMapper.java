package in.co.daalchini.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import in.co.daalchini.DTO.SubSubTypeDTO;
import in.co.daalchini.DTO.SubTypeDTO;
import in.co.daalchini.models.SubSubTypeEntity;
import in.co.daalchini.models.SubTypeEntity;

@Mapper(componentModel="spring")
public interface SubSubTypeMapper {
	public SubSubTypeMapper INSTANCE = Mappers.getMapper(SubSubTypeMapper.class);
	List<SubSubTypeDTO> toSubSubTypeDTOs(List<SubSubTypeEntity> subTypeEntities);
}
