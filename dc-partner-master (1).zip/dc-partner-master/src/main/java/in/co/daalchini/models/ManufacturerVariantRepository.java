package in.co.daalchini.models;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ManufacturerVariantRepository extends JpaRepository<ManufacturerVariant, Long> {

    @Query("select m from ManufacturerVariant m where m.id in :productCodes")
    List<ManufacturerVariant> findByIdIn (@Param("productCodes") List<Long> productCodes);

    @Query("select count(mv.id) from ManufacturerVariant  mv where mv.id in (:mvIds)")
    Long countByIdIn(List<Long> mvIds);

    @Query("SELECT m FROM ManufacturerVariant m WHERE m.manufacturer.id = :manufacturerId AND m.variant.id = :variantId")
    Optional<ManufacturerVariant> findByManufacturerAndVariant(@Param("manufacturerId") Integer manufacturerId, @Param("variantId") Long variantId);

    @Query("select m from ManufacturerVariant m where m.variant.id = :variantId")
    List<ManufacturerVariant> findByVariantId (@Param("variantId") Long variantId);

}
