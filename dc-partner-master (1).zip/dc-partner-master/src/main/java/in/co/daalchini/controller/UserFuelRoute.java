package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.UserFuelContext;
import in.co.daalchini.data.transporatable.DtoFuelWarehouse;
import in.co.daalchini.data.transporatable.DtoFuelWarehouseRateRequest;
import in.co.daalchini.data.transporatable.DtoWarehouseFuelRate;
import in.co.daalchini.data.transporatable.DtoWarehouseUser;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.UserFuelService;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collection;
import java.util.List;

@Log4j2
@RestController
public class UserFuelRoute {

    private final UserFuelService userFuelService;

    public UserFuelRoute (UserFuelService userFuelService) {
        this.userFuelService = userFuelService;
    }

    @PreAuthorize("hasAuthority('fuel_rate') or hasRole('ADMIN')")
    @GetMapping(UserFuelContext.FUEL_WAREHOUSE_ASSOCIATED)
    public RestResponseV2<List<DtoFuelWarehouse>> fetchAssociatedWarehouses (
        @AuthenticationPrincipal AuthUserDetails userDetails)
    {
        var data = userFuelService.fetchAssociatedWarehouses(userDetails.getUserId(), userDetails.isAdmin());

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAuthority('fuel_rate_read') or hasAuthority('fuel_rate') or hasRole('ADMIN')")
    @GetMapping(UserFuelContext.FUEL_WAREHOUSE_WITH_ID)
    public RestResponseV2<DtoWarehouseFuelRate> fetchWarehouseFuelRate (
        @PathVariable("warehouseId") Long warehouseId)
    {
        var data = userFuelService.fetchWarehouseFuelRate(warehouseId);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAuthority('fuel_rate') or hasRole('ADMIN')")
    @PatchMapping(UserFuelContext.FUEL_WAREHOUSE_WITH_ID)
    public RestResponseV2<DtoWarehouseFuelRate> updateWarehouseFuelRate (
        @PathVariable("warehouseId") Long warehouseId,
        @RequestBody @Valid DtoFuelWarehouseRateRequest request)
    {
        var data = userFuelService.updateWarehouseFuelRate(warehouseId, request);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAuthority('fuel_rate') or hasRole('ADMIN')")
    @GetMapping(UserFuelContext.FUEL_WAREHOUSE_USERS)
    public RestResponseV2<Collection<DtoWarehouseUser>> fetchWarehouseUsers (
        @PathVariable("warehouseId") Long warehouseId)
    {
        var data = userFuelService.fetchWarehouseUsers(warehouseId);

        return RestResponseV2.ofSuccess(data);
    }

}
