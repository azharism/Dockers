package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

public final class TransactionHistory {

    @Data
    @Builder
    public static final class Request {
        private String to;
        private String from;
        private String transactionType;
        private String opsType;
        private String sortBy;
        private Integer limit;
        private Integer pageNo;
        private PartnerWallet walletDetails;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private Integer count;
        private List<PayloadData> payload;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class PayloadData {
        private Integer transactionId;
        private String orderId;
        private String transactionType;
        private String opsType;
        private String timestamp;
        private Double amount;
    }


}

