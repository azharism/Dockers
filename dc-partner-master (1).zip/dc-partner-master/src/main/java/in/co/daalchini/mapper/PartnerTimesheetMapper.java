package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.PartnerTimesheetDto;
import in.co.daalchini.models.PartnerTimesheet;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.LocalDateTime;
import java.util.List;

@Mapper(componentModel = "spring")
public interface PartnerTimesheetMapper {

    @Mapping(target = "name", source = "partnerTimesheet.dashboardUser.dashboardUserDetails.userName")
    @Mapping(target = "checkInApproved", source = "partnerTimesheet.checkInApprovedAt", qualifiedByName = "isCheckinApproved")
    @Mapping(target = "checkOutApproved", source = "partnerTimesheet.checkOutApprovedAt",qualifiedByName = "isCheckOutApproved")
    PartnerTimesheetDto.Response toDto(PartnerTimesheet partnerTimesheet);

    List<PartnerTimesheetDto.Response> toDto(List<PartnerTimesheet> partnerTimesheetList);

    @Named("isCheckinApproved")
    static Boolean isCheckinApproved (LocalDateTime checkInApprovedAt){
        return checkInApprovedAt != null;
    }

    @Named("isCheckOutApproved")
    static Boolean isCheckOutApproved (LocalDateTime checkOutApprovedAt){
        return checkOutApprovedAt != null;
    }
}
