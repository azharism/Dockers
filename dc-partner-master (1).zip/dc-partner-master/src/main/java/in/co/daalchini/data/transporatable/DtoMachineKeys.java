package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineKeys {

    @JsonProperty("board_id")
    private String boardId;

    @JsonProperty("bluetooth_id")
    private String bluetoothId;

    @JsonProperty("com_id")
    private String comId;

    @JsonProperty("device_id")
    private String deviceId;

    @JsonProperty("serial_number")
    private String serialNumber;
}
