package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Immutable;

import javax.persistence.*;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Immutable
@Entity
@Table(name = "cohort_machine_user_mapping")
public class CohortMachineUserMapping {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "vending_machine_id")
    private Long vendingMachineId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    @Column(name = "dashboard_user_id")
    private Long dashboardUserId;

    @Override
    public String toString () {
        return new StringJoiner(", ", CohortMachineUserMapping.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("vendingMachineId=" + vendingMachineId)
            .add("dashboardUserId=" + dashboardUserId)
            .toString();
    }
}
