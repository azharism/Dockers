package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoFuelWarehouseRateRequest {

    @NotNull
    @Digits(integer = 3, fraction = 2)
    @JsonProperty("fuel_rate")
    private Double fuelRate;
}
