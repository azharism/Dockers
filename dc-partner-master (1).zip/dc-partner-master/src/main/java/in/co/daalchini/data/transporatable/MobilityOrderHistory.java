package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.untransportable.OrderState;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

public class MobilityOrderHistory {
    @Data
    @Builder
    public static final class Response {
        private Integer total;
        private List<OrderInfo> list;
    }

    @Data
    @Builder
    public static final class OrderInfo {
        @JsonProperty(value = "id") private String orderId;
        @JsonProperty(value = "status") private OrderState orderState;
        @JsonProperty(value = "amount") private Double amount;
        @JsonProperty(value = "payment_id")  private Long paymentId;
        @JsonProperty(value = "user_id") private Long userId;
        @JsonProperty(value = "username") private String userName;
        @JsonProperty(value = "email") private String email;
        @JsonProperty(value = "phone") private String phone;
        @JsonProperty(value = "coupon") private String coupon;
        @JsonProperty(value = "cashback") private Double cashback;
        @JsonProperty(value = "dc_code") private String dcCode;
        @JsonProperty(value = "VM_id") private Long vmId;
        @JsonProperty(value = "VM_name") private String vmName;
        @JsonProperty(value = "VM_city") private String vmCity;
        @JsonProperty(value = "created_at")
        @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        private LocalDateTime createdAt;
        @JsonProperty(value = "updated_at")
        @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        private LocalDateTime updatedAt;
    }
}
