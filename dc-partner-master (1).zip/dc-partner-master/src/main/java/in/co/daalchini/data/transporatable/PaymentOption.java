package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;


public final class PaymentOption {

    @Data
    @Builder
    public static final class Response {
        public Integer pgId;
        public String pgName;
        public String displayName;
        public Double balance;
        public Boolean active;
    }
}
