package in.co.daalchini.data.transporatable.wallet;


import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

@Data
@Builder
public class TransferOrder {
    private Integer index;
    private @Default String orderId = null;
    private Double amount;
    private DestinationWallet destinationWallet;

    public static TransferOrder ofTag(Integer index, Double amount, Long cardId, String cardUid) {
        return TransferOrder
                .builder()
                .index(index)
                .amount(amount)
                .destinationWallet(DestinationWallet.ofTag(cardId, cardUid))
                .build();
    }
}
