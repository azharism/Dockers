package in.co.daalchini.data.transporatable.message;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerDueEvent implements Jsonable {

    @JsonProperty("orderId")
    private String orderId;

    @JsonProperty("vendingMachineId")
    private Long vendingMachineId;

    @JsonProperty("amount")
    private Double amount;

    public String json () {
        return JsonUtil.toJson(this);
    }
}
