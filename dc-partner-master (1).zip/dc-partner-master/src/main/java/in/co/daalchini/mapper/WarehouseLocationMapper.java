package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoWarehouseLocation;
import in.co.daalchini.data.transporatable.UpdateWarehouseLocationRequest;
import in.co.daalchini.models.WarehouseAddress;
import org.mapstruct.*;

@Mapper(componentModel = "spring")
public interface WarehouseLocationMapper {

    @Mapping(target = "address", source = "billingAddress")
    DtoWarehouseLocation toDto (WarehouseAddress address);

    @Mapping(target = "billingAddress", source = "address")
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    WarehouseAddress updateEntity (UpdateWarehouseLocationRequest source, @MappingTarget WarehouseAddress location);
}
