package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonFormat;
import in.co.daalchini.models.VmFailedSlotSession;
import in.co.daalchini.models.VmFailedSlotStatus;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static in.co.daalchini.data.constants.SlotStatus.REPORTED;

public class SlotReportV2 {

    @Data
    @Builder
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Response {

        private Long vmId;
        private String vmName;

        @Builder.Default
        private List<SlotsBlocked> slotsBlocked = new ArrayList<>();

        @Builder.Default
        private List<SlotsResolved> slotsResolved = new ArrayList<>();

        public static Response ofBlocked(Long vmId, String vmName) {
            return SlotReportV2.Response.builder().vmId(vmId).vmName(vmName).slotsBlocked(new ArrayList<>()).build();
        }

        public static Response ofResolved(Long vmId, String vmName) {
            return SlotReportV2.Response.builder().vmId(vmId).vmName(vmName).slotsResolved(new ArrayList<>()).build();
        }
    }

    @Data
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SlotsBlocked {
        private Long slotId;
        private Integer failCount;
        @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        private LocalDateTime blockedAt;
        private Long timeSinceLastFailure;
        private String byteCode;
        private String byteReason;
        private String reason;
        private Boolean isReported;
        private String reportedBy;
        @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        private LocalDateTime reportedAt;

        public static SlotsBlocked of(VmFailedSlotStatus slotStatus, VmFailedSlotSession slotSession) {
            String reason  = null;
            if(slotSession.getMachineByteCodeReason() != null) {
                reason = slotSession.getMachineByteCodeReason().getName();
            }
            return SlotReportV2.SlotsBlocked.builder()
                    .slotId(slotStatus.getSlotId())
                    .failCount(slotStatus.getFailCount())
                    .blockedAt(slotStatus.getBlockedAt())
                    .timeSinceLastFailure(slotStatus.timeSinceFailure())
                    .isReported(REPORTED.equals(slotStatus.getStatus()))
                    .reportedAt(slotStatus.getReportedAt())
                    .reportedBy(slotStatus.getReportedBy())
                    .byteCode(slotSession.getByteCode())
                    .byteReason(reason)
                    .reason(slotStatus.getReportedReason())
                    .build();
        }
    }

    @Data
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SlotsResolved {
        private Long slotId;
        private Integer failCount;
        @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        private LocalDateTime blockedAt;
        @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        private LocalDateTime resolvedAt;
        private Long resolvedTimeMinutes;
        private String reason;
        private String resolvedBy;

        public static SlotsResolved of(VmFailedSlotStatus status) {
            return SlotsResolved.builder()
                    .slotId(status.getSlotId())
                    .failCount(status.getFailCount())
                    .blockedAt(status.getBlockedAt())
                    .reason(status.getResolvedReason())
                    .resolvedAt(status.getResolvedAt())
                    .resolvedTimeMinutes(status.resolvedTimeMinutes())
                    .resolvedBy(status.getResolvedBy())
                    .build();
        }
    }
}
