package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.data.untransportable.RfidCardStatus;
import in.co.daalchini.data.untransportable.RfidCardType;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;
import lombok.experimental.Accessors;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.ReadOnlyProperty;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@DynamicUpdate
@Table(name = "rfid_cards")
public class RfidCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    private Long id;

    @Column(name = "series_id")
    private Long seriesId;

    @Column(name = "uid")
    private String uid;

    @Column(name = "type")
    private RfidCardType cardType;

    @With
    @Column(name = "status")
    private RfidCardStatus cardStatus;

    @Column(name = "token")
    private String token;

    @With
    @Column(name = "wallet_id")
    private Long walletId;

    @Accessors(fluent = true)
    @Setter(AccessLevel.NONE)
    @Column(name = "active", insertable = false, updatable = false)
    private Boolean isActive;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    @CreatedDate
    private LocalDateTime updatedAt;

    @JsonIgnore
    @ReadOnlyProperty
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "series_id", insertable = false, updatable = false)
    private RfidCardSeries rfidCardSeries;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wallet_id", insertable = false, updatable = false)
    private RfidCardWallet cardWallet;

    public Optional<RfidCardWallet> getWalletOptional() {
        return Optional.ofNullable(cardWallet);
    }

    public Optional<RfidCardWallet> getActiveWalletOptional() {
        return getWalletOptional().filter(RfidCardWallet::isActive);
    }

    @PrePersist
    void createTimestamp() {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp() {
        this.updatedAt = DateTimeHelper.now();
    }


    @Override
    public String toString() {
        return new StringJoiner(", ", RfidCard.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("seriesId=" + seriesId)
                .add("uid='" + uid + "'")
                .add("cardType=" + cardType)
                .add("cardStatus=" + cardStatus)
                .add("token='" + token + "'")
                .add("isActive=" + isActive)
                .toString();
    }

    public RfidCard withActiveWallet(Long walletId) {
        this.cardStatus = RfidCardStatus.Active;
        this.walletId = walletId;

        return this;
    }
}
