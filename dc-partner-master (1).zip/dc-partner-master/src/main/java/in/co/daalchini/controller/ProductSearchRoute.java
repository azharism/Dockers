package in.co.daalchini.controller;

import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import in.co.daalchini.data.constants.RouteConstants;
import in.co.daalchini.data.transporatable.ProductSearchDto;
import in.co.daalchini.data.transporatable.ProductSearchDto.*;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.ProductSearchService;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Log4j2
@Validated
@RestController
public class ProductSearchRoute {

    private final ProductSearchService productSearchService;

    public ProductSearchRoute(ProductSearchService productSearchService) {

        this.productSearchService = productSearchService;
    }

    @GetMapping(RouteConstants.VariantContext.VARIANT_SEARCH)
    public RestResponseV2<SearchResponse> getVariantSearch(@AuthenticationPrincipal AuthUserDetails userDetails,
                                                           @NoLeadingAndTrailingSpace
                                                           @RequestParam(value = "variantName") String variantName,
                                                           @RequestParam(value = "productName") List<String> productName,
                                                           @RequestParam(value = "brandName") List<String> brandName,
                                                           @RequestParam(value = "sortBy", required = false, defaultValue = "asc") String sortBy,
                                                           @RequestParam(value = "limit", required = false) Integer limit,
                                                           @RequestParam(value = "offset", required = false) Integer offset) {
        try {
            log.info("request variantName:{},productName:{},brandName:{},sortBy:{}", variantName,productName,brandName,sortBy);
            var response = productSearchService.getVariantSearch(variantName,productName,brandName,sortBy, offset ,limit);
            return RestResponseV2.ofSuccess(response);
        } catch (RuntimeException e) {
            log.warn("Error in fetching variant ");
            throw e;
        }
    }

    @GetMapping(RouteConstants.VariantContext.MFID_SEARCH)
    public RestResponseV2<ManufacturerVariantResponse> getManufacturerVariant(@AuthenticationPrincipal AuthUserDetails userDetails,
                                                                              @PathVariable(value = "variantId") Long variantId) {
        try {
            log.info("request variantId:{}", variantId);
            Long dashboardUserId = userDetails.getUserId();
            var response = productSearchService.getManufacturerVariant(variantId, dashboardUserId);
            return RestResponseV2.ofSuccess(response);
        } catch (RuntimeException e) {
            log.warn("Error in fetching getManufacturerVariant");
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('variant_config')")
    @PostMapping(RouteConstants.VariantContext.CREATE_MFID)
    public RestResponseV2<Response> createManufacturerVariant(@AuthenticationPrincipal AuthUserDetails userDetails,
                                                              @Valid @RequestBody ProductSearchDto.ManufacturerVariantRequest manufacturerVariantRequest) {
        try {
            log.info("request createManufacturerVariant:{}", manufacturerVariantRequest);
            Long dashboardUserId = userDetails.getUserId();
            var response = productSearchService.createManufacturerVariant(manufacturerVariantRequest, dashboardUserId);
            return RestResponseV2.ofSuccess(response);
        } catch (RuntimeException e) {
            log.warn("Error in creating  createManufacturerVariant");
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('variant_config')")
    @PutMapping(RouteConstants.VariantContext.UPDATE_MFID)
    public RestResponseV2<Response> updateManufacturerVariant(@AuthenticationPrincipal AuthUserDetails userDetails,
                                                              @Valid @RequestBody ProductSearchDto.UpdateManufacturerVariantRequest updateManufacturerVariantRequest) {
        try {
            log.info("request updateManufacturerVariant:{}", updateManufacturerVariantRequest);
            Long dashboardUserId = userDetails.getUserId();
            var response = productSearchService.updateManufacturerVariant(updateManufacturerVariantRequest, dashboardUserId);
            return RestResponseV2.ofSuccess(response);
        } catch (RuntimeException e) {
            log.warn("Error in creating  updateManufacturerVariant");
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('variant_config')")
    @PostMapping(RouteConstants.VariantContext.CREATE_VENDOR)
    public void createVendor(@AuthenticationPrincipal AuthUserDetails userDetails,
                             @Valid @RequestBody ProductSearchDto.VendorRequest vendorRequest) {
        try {
            log.info("request createVendor:{}", vendorRequest);
            Long dashboardUserId = userDetails.getUserId();
            productSearchService.createVendor(vendorRequest, dashboardUserId);
        } catch (RuntimeException e) {
            log.warn("Error in creating  createVendor");
            throw e;
        }

    }


}
