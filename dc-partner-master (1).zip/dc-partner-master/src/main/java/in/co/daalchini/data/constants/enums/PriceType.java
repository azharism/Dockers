package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum PriceType {
    OfferPrice("Offer_Price"),
    VendorPrice("Vendor_Price");

    private final @JsonValue String value;

    PriceType(String value){this.value = value;}

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static PriceType of (String value) {
        return Arrays.stream(PriceType.values())
                .filter(x -> x.value.equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }


}
