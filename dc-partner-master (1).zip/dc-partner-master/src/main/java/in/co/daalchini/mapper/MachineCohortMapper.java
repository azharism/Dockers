package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoCohort;
import in.co.daalchini.models.MachineCohort;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface MachineCohortMapper {

    @Mapping(target = "type", source = "cohortType.name")
    DtoCohort toDto (MachineCohort cohort);

    List<DtoCohort> toDto (List<MachineCohort> cohorts);
}
