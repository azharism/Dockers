package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

public class PartnerTimesheetDto {

    @Data
    @Builder
    public static final class Response {
        @JsonProperty(value = "name")
        private String name;
        @JsonProperty(value = "id")
        private Long id;
        @JsonProperty(value = "check_in")
        private String checkIn;
        @JsonProperty(value = "check_out")
        private String checkOut;
        @JsonProperty(value = "checkInApproved")
        private Boolean checkInApproved;
        @JsonProperty(value = "checkOutApproved")
        private Boolean checkOutApproved;
    }
}
