package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.data.annotation.Immutable;

import javax.persistence.*;
import java.time.LocalDateTime;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Immutable
@Entity
@Table(name = "user_profile_details")
public class UserProfileDetail {

    @Id
    @Column(name = "user_profile_id")
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private UserDetails userDetails;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "gender")
    private String gender;

    @Column(name = "dob")
    private String dob;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "country")
    private String country;

    @JsonIgnore
    @Column(name = "created_timestamp", updatable = false)
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_timestamp")
    private LocalDateTime updatedAt;

    public String getFullName () {
        String fName = this.firstName != null ? firstName : "";
        String lName = this.lastName != null ? " " + lastName : "";
        return String.format("%s%s", fName, lName);
    }
}
