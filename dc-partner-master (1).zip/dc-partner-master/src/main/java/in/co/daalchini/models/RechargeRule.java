package in.co.daalchini.models;


import in.co.daalchini.data.constants.enums.RechargeType;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "recharge_rule")
@EntityListeners(AuditingEntityListener.class)
public class RechargeRule {

    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "type")
    private RechargeType rechargeType;

    @Column(name = "recharge_budget")
    private Double rechargeBudget;

    @Column(name = "recharge_expenditure")
    private Double rechargeExpenditure;

    @Column(name = "prefill_corporate")
    private boolean prefillCorporate;

    @Column(name = "carry_forward")
    private boolean carryForward;

    @Column(name = "amount")
    private Double amount;

    @Column(name = "active")
    private boolean active;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString() {
        return new StringJoiner(", ", RechargeRule.class.getSimpleName() + "[", "]")
                .add("rechargeBudget=" + rechargeBudget)
                .add("rechargeExpenditure=" + rechargeExpenditure)
                .add("prefillCorporate=" + prefillCorporate)
                .add("carryForward=" + carryForward)
                .add("amount=" + amount)
                .add("active=" + active)
                .toString();
    }
}
