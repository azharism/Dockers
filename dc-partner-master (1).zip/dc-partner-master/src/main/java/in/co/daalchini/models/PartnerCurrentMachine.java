package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.ZoneId;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "partner_current_machine")
public class PartnerCurrentMachine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    private Long id;

    @Column(name = "vm_id")
    private Long vmId;

    @Column(name = "current_dashboard_user_id")
    private Long currentDashboardUserId;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    @CreatedDate
    private LocalDateTime updatedAt;

    @OneToOne
    @JoinColumn(name = "vm_id", insertable = false, updatable = false)
    VendingMachine vendingMachine;

    @OneToOne
    @JoinColumn(name = "current_dashboard_user_id", insertable = false, updatable = false)
    DashboardUser dashboardUser;

    @PrePersist
    void createTimestamp () {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp () {
        this.updatedAt = DateTimeHelper.now();
    }

    public LocalDateTime toIst(){
      return   this.updatedAt.atZone(ZoneId.systemDefault())
              .withZoneSameInstant(ZoneId.of("Asia/Kolkata"))
              .toLocalDateTime();
    }
}
