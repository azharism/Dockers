package in.co.daalchini.mapper;

import in.co.daalchini.data.untransportable.OrderState;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OrderStateMapper {

    default String toValue (OrderState state) {
        if (state == null) return null;
        return state.getStatus();
    }
}
