package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WarehouseDumpData {

    @JsonProperty("skuId")
    private Long skuId;

    @JsonProperty("count")
    private Integer count;
}
