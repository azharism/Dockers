package in.co.daalchini.models;


import lombok.*;

import javax.persistence.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@Table(name = "combo_cohort_config")
public class ComboCohortConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "combo_id")
    private Long comboId;

    @Column(name = "cohort_id")
    private Long cohortId;

    @Column(name = "is_overridden")
    private Boolean isOverridden;

    @Column(name = "vm_ids")
    private String vmIds;

    @Column(name = "is_active")
    private Boolean isActive;

    @ManyToOne
    @JoinColumn(name = "combo_id", insertable = false, updatable = false)
    private Combo combo;

}
