package in.co.daalchini.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import in.co.daalchini.DTO.TicketTypeDto;
import in.co.daalchini.models.TicketTypeActivityEntity;

@Mapper(componentModel="spring")
public interface TicketTypeMapper {

	public TicketTypeMapper INSTANCE = Mappers.getMapper(TicketTypeMapper.class);
	TicketTypeDto toTicketTypeDTO(TicketTypeActivityEntity ticketTypeActivityEntity);
	
	List<TicketTypeDto> toTicketTypeDTOs(List<TicketTypeActivityEntity> ticketTypeActivityEntitys);
		
	TicketTypeActivityEntity toTicketTypeActivityEntity(TicketTypeDto ticketTypeDto);
}
