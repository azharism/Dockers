package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;

import java.util.List;

public class PaymentRecharge {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class IndexedRequest {
        private Integer index;
        private String phoneNumber;
        private Double amount;
    }

    @Data
    @Builder
    public static final class EnrichedIndexedRequest {
        private Integer index;
        private String phoneNumber;
        private Double amount;
        private Long dashboardUserId;

        public static EnrichedIndexedRequest of (IndexedRequest request) {
            return EnrichedIndexedRequest
                .builder()
                .index(request.getIndex())
                .phoneNumber(request.getPhoneNumber())
                .amount(request.getAmount())
                .dashboardUserId(null)
                .build();
        }
    }

    @Data
    @Builder
    public static final class Response {
        private List<IndexedResponse> successes;
        private List<IndexedResponse> failures;
    }

    @Data
    @Builder
    public static final class IndexedResponse {
        private Integer index;
        private String pgTxnId;
        private Double balance;
    }

}
