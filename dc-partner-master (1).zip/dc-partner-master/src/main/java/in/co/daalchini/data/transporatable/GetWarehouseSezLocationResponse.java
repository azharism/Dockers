package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GetWarehouseSezLocationResponse {

    @JsonProperty("warehouse_location")
    private DtoWarehouseLocation warehouseLocation;

    @JsonProperty("sez_locations")
    private List<DtoWarehouseSezLocation> sezLocations;
}
