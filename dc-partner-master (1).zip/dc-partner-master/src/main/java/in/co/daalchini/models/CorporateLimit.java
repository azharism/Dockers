package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "corporate_limits")
@EntityListeners(AuditingEntityListener.class)
public class CorporateLimit {

    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "corporate_id")
    private Long corporateId;

    @Column(name = "pg_id")
    private Integer pgId;

    @Column(name = "limit_type_id")
    private Long limitTypeId;

    @Column(name = "card_series_id")
    private Long cardSeriesId;

    @Column(name = "value")
    private Integer value;

    @Column(name = "active")
    private boolean active;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @ReadOnlyProperty
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "limit_type_id", insertable = false, updatable = false)
    private CorporateLimitType limitType;

}
