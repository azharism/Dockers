package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.StringJoiner;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoAttendanceManufacturerEntity {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("entityId")
    private DtoAttendanceEntity entityId;

    @JsonProperty("manufacturerId")
    private DtoAttendanceManufacturer manufacturerId;


    @Override
    public String toString() {
        return new StringJoiner(", ", DtoAttendanceManufacturerEntity.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("entityId=" + (null == entityId ? null : entityId.getId()))
                .add("manufacturerId=" + (null == manufacturerId ? null : manufacturerId.getId()))
                .toString();
    }
}
