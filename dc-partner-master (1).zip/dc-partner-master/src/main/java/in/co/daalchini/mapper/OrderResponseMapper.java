package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoOrderDetailResponse;
import in.co.daalchini.data.transporatable.DtoOrderResponse;
import in.co.daalchini.models.Order;
import in.co.daalchini.models.Payment;
import in.co.daalchini.service.helper.MobileMaskHelper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring", uses = {
        OrderStateMapper.class,
        OrderSourceMapper.class,
        UserDetailMapper.class,
        LineItemMapper.class,
        PaymentMapper.class
})
public interface OrderResponseMapper {

    @Mapping(target = "id", source = "id")
    @Mapping(target = "phone", source = "order", qualifiedByName = "mapMaskedPhone")
    @Mapping(target = "amount", source = "amount")
    @Mapping(target = "status", source = "status")
    @Mapping(target = "dcCode", source = "dcCode")
    @Mapping(target = "city", source = "vendingMachineCity")
    @Mapping(target = "createdAt", source = "createdAt")
    DtoOrderResponse toDto(Order order);


    @Named("mapMaskedPhone")
    default String mapMaskedPhone(Order order) {
        var userDetails = order.getUserDetails();
        var phoneNumber = userDetails == null ? order.getPhone() : userDetails.getMobileNo();

        return MobileMaskHelper.maskPhone(phoneNumber);
    }

    List<DtoOrderResponse> toDto(Collection<Order> orders);

    @Mapping(target = "id", source = "order.id")
    @Mapping(target = "status", source = "order.status")
    @Mapping(target = "createdAt", source = "order.createdAt")
    @Mapping(target = "amount", source = "order.amount")
    @Mapping(target = "phone", source = "order", qualifiedByName = "mapMaskedPhone")
    @Mapping(target = "machineId", source = "order.vendingMachineId")
    @Mapping(target = "city", source = "order.vendingMachineCity")
    @Mapping(target = "vmAddress", source = "order.vendingMachine.address.street")
    @Mapping(target = "vmName", source = "order.vendingMachine.name")
    @Mapping(target = "userDetails", source = "order.userDetails")
    @Mapping(target = "lineItems", source = "order.orderLineItems")
    @Mapping(target = "paymentDetails", source = "order.payment")
    @Mapping(target = "refundDetails", source = "refundedPayments")
    @Mapping(target = "dcCode", source = "order.dcCode")
    DtoOrderDetailResponse toDetailDto(Order order, List<Payment> refundedPayments);
}
