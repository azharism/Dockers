package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.StringJoiner;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoAttendanceWarehouseAddress {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("street")
    private String street;

    @JsonProperty("city_id")
    private Integer city_id;

    @JsonProperty("state_id")
    private Integer state_id;

    @JsonProperty("lat")
    private Double lat;

    @JsonProperty("lng")
    private Double lng;

    @JsonProperty("created_at")
    private LocalDateTime createdAt;

    @JsonProperty("updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString() {
        return new StringJoiner(", ", DtoAttendanceWarehouseAddress.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("city_id=" + city_id)
                .add("state_id=" + state_id)
                .toString();
    }
}
