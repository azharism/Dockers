package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;


public final class FulfilOrder {

    @Getter
    @ToString
    @EqualsAndHashCode
    public static final class Request {

        private final String order_id;
        private final Long vending_machine_id;
        private final Long sku_group_id;
        private final Long manufacturer_variant_id;
        private final Long slot_identifier;
        private final List<LineItem> orderLineItems;

        @JsonCreator
        public Request (
            @JsonProperty("order_id") final String order_id,
            @JsonProperty("vending_machine_id") final Long vending_machine_id,
            @JsonProperty("sku_group_id") final Long sku_group_id,
            @JsonProperty("manufacturer_variant_id") final Long manufacturer_variant_id,
            @JsonProperty("slot_identifier") final Long slot_identifier,
            @JsonProperty("orderLineItems") final List<LineItem> orderLineItems)
        {
            this.order_id = order_id;
            this.vending_machine_id = vending_machine_id;
            this.sku_group_id = sku_group_id;
            this.manufacturer_variant_id = manufacturer_variant_id;
            this.slot_identifier = slot_identifier;
            this.orderLineItems = orderLineItems;
        }

        public static List<Request> of (final DeliveryComplete.Request request) {
            return request
                .getOrderLineItems()
                .stream()
                .flatMap(lineItem -> Stream
                    .concat(
                        IntStream.rangeClosed(
                            1, lineItem.getSuccessCount()).boxed().map(x -> "success"),
                        IntStream.rangeClosed(
                            1, lineItem.getFailureCount()).boxed().map(x -> "failed"))
                    .map(x -> new Request(
                        request.getOrderId(),
                        request.getVendingMachineId(),
                        request.getSkuGroupId(),
                        request.getManufacturerVariantId(),
                        request.getSlotIdentifier(),
                        Collections.singletonList(new LineItem(lineItem.getId(), x))
                    ))).collect(Collectors.toList());
        }

        public static List<Request> of (final OrderComplete.Request request) {
            return request
                .getOrderLineItems()
                .stream()
                .flatMap(lineItem -> Stream
                    .concat(
                        IntStream.rangeClosed(
                            1, lineItem.getSuccessCount()).boxed().map(x -> "success"),
                        IntStream.rangeClosed(
                            1, lineItem.getFailureCount()).boxed().map(x -> "failed"))
                    .map(x -> new Request(
                        request.getOrderId(),
                        request.getVendingMachineId(),
                        lineItem.getSkuGroupId(),
                        lineItem.getManufacturerVariantId(),
                        lineItem.getSlotIdentifier(),
                        Collections.singletonList(new LineItem(lineItem.getId(), x))
                    ))).collect(Collectors.toList());
        }
    }

    @Builder
    @Getter
    @ToString
    @EqualsAndHashCode
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private final String status;

        @JsonCreator
        public Response (
            @JsonProperty("status") final String status)
        {
            this.status = status;
        }
    }

    @Getter
    @ToString
    @EqualsAndHashCode
    public static final class LineItem {

        private final Long id;
        private final String status;

        @JsonCreator
        public LineItem (
            @JsonProperty("id") final Long id,
            @JsonProperty("status") final String status)
        {
            this.id = id;
            this.status = status;
        }
    }

}
