package in.co.daalchini.data.transporatable;

import lombok.*;


public final class UnblockSlotInfo {

    @Builder
    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Request {
        private Integer slotId;
        private Long vmId;
        private Boolean shouldUnblock;
        private String reason;
    }

    @Builder
    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Response {

        private String status;
        private String statusMessage;

        public static Response ofSuccess() {
            return Response.builder().status("Success").statusMessage("Reported").build();
        }

        public static Response ofSuccess(String message) {
            return Response.builder().status("Success").statusMessage(message).build();
        }
    }

}
