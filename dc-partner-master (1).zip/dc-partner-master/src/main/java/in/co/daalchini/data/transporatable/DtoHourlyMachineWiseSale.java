package in.co.daalchini.data.transporatable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DtoHourlyMachineWiseSale {
    private Long machineId;
    private String name;
    private Double totalSale;
    private LocalDateTime updatedAt;
}
