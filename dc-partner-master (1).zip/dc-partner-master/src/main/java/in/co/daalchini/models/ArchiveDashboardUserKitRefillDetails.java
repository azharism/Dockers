package in.co.daalchini.models;

import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.proxy.HibernateProxy;

import javax.persistence.*;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "archive_dashboard_user_kit_refill_with_details")
public class ArchiveDashboardUserKitRefillDetails implements Serializable {

    @Serial
    private static final long serialVersionUID = 4777789391301206407L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pkey")
    private Long pkey;

    @Column(name = "id")
    private Long refillId;

    @Column(name = "dashboard_user_id")
    private Long dashboardUserId;

    @Column(name = "start_time")
    private LocalDateTime startTime;

    @Column(name = "end_time")
    private LocalDateTime endTime;

    @Column(name = "operation_type")
    private String operationType;

    @Column(name = "item_quantity")
    private Long itemQuantity;

    @Column(name = "vending_machine_id")
    private Long vmId;

    @Column(name = "refill_status")
    private String refillStatus;

    @Column(name = "manufacturer_variant_id")
    private Long mvId;

    @Column(name = "sku_group_id")
    private Long skuGroupId;

    @Column(name = "slot_identifier")
    private Integer slotId;

    @Column(name = "vending_machine_manufacturer_variant_id")
    private Long machineMvId;

    @Column(name = "vending_machine_manufacturer_variant_sku_group_mappings_id")
    private Long machineMvSkgId;

    @Column(name = "final_quantity")
    private Long finalQuantity;

    @Column(name = "vending_machine_name")
    private String vendingMachineName;

    @Column(name = "vending_machine_image")
    private String vendingMachineImage;

    @Column(name = "operation_code")
    private Integer operationCode;

    @Column(name = "sequence")
    private Integer sequence;

    public static ArchiveDashboardUserKitRefillDetails of(
            Long userId,
            MachineManufacturerVariantSkuGroup item
    ) {
        var krd = new ArchiveDashboardUserKitRefillDetails();
        var currentDateTime = DateTimeHelper.now();
        var itemMachineMv = item.getMachineManufacturerVariant();

        krd.setRefillId(0L);
        krd.setVendingMachineName("");
        krd.setVendingMachineImage("");
        krd.setOperationType("expire");
        krd.setRefillStatus("scheduled_expire");
        krd.setSequence(0);
        krd.setOperationCode(0);
        krd.setFinalQuantity(0L);
        krd.setStartTime(currentDateTime);
        krd.setEndTime(currentDateTime);

        krd.setDashboardUserId(userId);
        krd.setMachineMvId(itemMachineMv.getId());
        krd.setSlotId(itemMachineMv.getSlotIdentifier());
        krd.setVmId(itemMachineMv.getVendingMachineId());
        krd.setMvId(item.getMachineManufacturerVariantId());
        krd.setSkuGroupId(item.getSkuGroupId());
        krd.setMachineMvSkgId(item.getId());
        krd.setItemQuantity(item.getActiveCount());

        return krd;
    }


    @Override
    public final boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        Class<?> oEffectiveClass = o instanceof HibernateProxy ? ((HibernateProxy) o).getHibernateLazyInitializer().getPersistentClass() : o.getClass();
        Class<?> thisEffectiveClass = this instanceof HibernateProxy ? ((HibernateProxy) this).getHibernateLazyInitializer().getPersistentClass() : this.getClass();
        if (thisEffectiveClass != oEffectiveClass) return false;
        ArchiveDashboardUserKitRefillDetails that = (ArchiveDashboardUserKitRefillDetails) o;
        return getPkey() != null && Objects.equals(getPkey(), that.getPkey());
    }

    @Override
    public final int hashCode() {
        return this instanceof HibernateProxy ? ((HibernateProxy) this).getHibernateLazyInitializer().getPersistentClass().hashCode() : getClass().hashCode();
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", ArchiveDashboardUserKitRefillDetails.class.getSimpleName() + "[", "]")
                .add("id=" + pkey)
                .add("dashboardUserId=" + dashboardUserId)
                .add("operationType='" + operationType + "'")
                .add("itemQuantity=" + itemQuantity)
                .add("vmId=" + vmId)
                .toString();
    }
}
