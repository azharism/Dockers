package in.co.daalchini.data.constants.enums;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Objects;
import java.util.stream.Stream;

@Getter
public enum CouponType {
    CashBack(1),
    Freegift(2),
    Referral(3),
    Recharge(4);

    private final @JsonValue Integer value;

    CouponType (int value) {this.value = value;}

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CouponType of (Integer value) {
        return Stream.of(CouponType.values())
                     .filter(x -> Objects.equals(x.value, value))
                     .findFirst()
                     .orElse(null);
    }
}
