package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

public class ListWarehouse {

    @Data
    @Builder
    public static final class Response {
        public Long warehouseId;
        public String warehouseName;
        public String warehouseCity;
    }
}
