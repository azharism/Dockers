package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Collection;

public class CorporateTagSeries {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Corporate {

        @JsonProperty("corporate_id")
        private Long corporateId;

        @JsonProperty("corporate_name")
        private String corporateName;

        @JsonProperty("corporate_series")
        private Collection<Series> corporateSeries;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Series {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("code")
        private String code;

        @JsonProperty("description")
        private String description;

        @JsonProperty("initial_balance")
        private Double initialBalance;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class CorporateSeriesSummary {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("code")
        private String code;

        @JsonProperty("description")
        private String description;

        @JsonProperty("initial_balance")
        private Double initialBalance;

        @JsonProperty("corporate_id")
        private Long corporateId;

        @JsonProperty("corporate_name")
        private String corporateName;
    }
}

