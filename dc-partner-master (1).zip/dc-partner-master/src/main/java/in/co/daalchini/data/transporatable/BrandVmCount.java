package in.co.daalchini.data.transporatable;

import org.springframework.beans.factory.annotation.Value;

public interface BrandVmCount {
    @Value("#{target.brand_id}")
    Long getbrandId();

    @Value("#{target.brand}")
    Long getbrand();
    @Value("#{target.machine_count}")
    Long getmachinecount();

}