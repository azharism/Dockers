package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.AdminRouteContext;
import in.co.daalchini.data.constants.enums.SearchQueryType;
import in.co.daalchini.data.transporatable.DtoOrderDetailResponse;
import in.co.daalchini.data.transporatable.DtoOrderResponse;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.exception.BadRequestException;
import in.co.daalchini.service.AdminOrderService;
import lombok.extern.log4j.Log4j2;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.List;

@Log4j2
@Validated
@RestController
public class AdminRoute {

    private final AdminOrderService adminOrderService;

    public AdminRoute(
            AdminOrderService adminOrderService) {
        this.adminOrderService = adminOrderService;
    }

    @GetMapping(AdminRouteContext.FETCH_ORDERS)
    public RestResponseV2<List<DtoOrderResponse>> fetchOrders(
            @RequestParam(value = "from_timestamp", required = false)
            @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") LocalDateTime fromTimestamp,

            @RequestParam(value = "to_timestamp", required = false)
            @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") LocalDateTime toTimestamp,

            @RequestParam(value = "page_size", required = false, defaultValue = "50")
            @Max(value = 500, message = "page_size can not exceed 500")
            @Positive(message = "page_size should be positive")
            @Valid Integer pageSize,

            @RequestParam(value = "page_number", required = false, defaultValue = "0")
            @PositiveOrZero(message = "page_number should be positive") Integer pageNumber,

            @RequestParam(value = "search_query", required = false)
            @Size(min = 3, max = 16, message = "search_query should be between 3 and 16 characters") String searchQuery,

            @RequestParam(value = "city", required = false)
            @Size(min = 3, max = 16, message = "search_query should be between 3 and 16 characters") String city,

            @RequestParam(value = "amount", required = false) Double amount
    ) {
        if (fromTimestamp == null && toTimestamp != null) throw new BadRequestException("from_timestamp is required");
        if (fromTimestamp != null && toTimestamp == null) throw new BadRequestException("to_timestamp is required");

        var data = adminOrderService.fetchOrders(fromTimestamp, toTimestamp, pageSize, pageNumber, searchQuery, city, amount);

        return RestResponseV2.ofSuccess(data);
    }

    @GetMapping(AdminRouteContext.FETCH_ORDER_DETAIL)
    public RestResponseV2<DtoOrderDetailResponse> fetchOrderDetail(@PathVariable String orderId) {
        DtoOrderDetailResponse data = adminOrderService.fetchOrderDetails(orderId);

        return RestResponseV2.ofSuccess(data);
    }
}
