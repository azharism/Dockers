package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.untransportable.OrderSource;
import in.co.daalchini.data.untransportable.OrderType;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.util.List;

public final class CreateOrder {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Request {

        @NotNull(message = "source is missing")
        public OrderSource source;

        @NotNull(message = "type is missing")
        public OrderType type;

        @NotNull(message = "items are missing")
        public List<@Valid Item> items;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Item {
        @NotNull(message = "slotIdentifier is missing")
        public Integer slotIdentifier;

        @Positive(message = "quantity must be a positive number")
        @NotNull(message = "quantity is missing")
        public Integer quantity;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        public String orderId;
        public Double amount;
        public List<LineItem> lineItems;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class LineItem {
        public Long id;
        public Double amount;
        public Integer quantity;
        public String variantName;
    }
}
