package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.CorporateContext;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.data.untransportable.PaymentGatewayType;
import in.co.daalchini.service.CorporateService;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.util.Collection;
import java.util.List;

@Log4j2
@Validated
@RestController
public class CorporateRoute {

    private final CorporateService corporateService;

    public CorporateRoute(CorporateService corporateService) {
        this.corporateService = corporateService;
    }

    @PreAuthorize("hasAnyAuthority('corporate:read','corporate:modify','corporate:all')")
    @GetMapping(CorporateContext.CORPORATE)
    public RestResponseV2<Collection<DtoCorporateSummarized>> getCorporates(
            @RequestParam(value = "has_only_active", defaultValue = "true", required = false) Boolean hasOnlyActive
    ) {
        var response = corporateService.getCorporates(hasOnlyActive);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAnyAuthority('corporate:read','corporate:modify','corporate:all')")
    @GetMapping(CorporateContext.CORPORATE_ID)
    public RestResponseV2<DtoCorporateComprehensive> getCorporateById(
            @Positive @PathVariable Long corporateId
    ) {
        var response = corporateService.getCorporateById(corporateId);

        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAnyAuthority('corporate:all')")
    @PostMapping(CorporateContext.CORPORATE)
    public RestResponseV2<DtoCorporateSummarized> createCorporate(
            @Valid @RequestBody DtoCorporateCreateRequest corporateDetails
    ) {
        var response = corporateService.createCorporates(corporateDetails);

        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAnyAuthority('corporate:all')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping(CorporateContext.CORPORATE_ID)
    public void deactivateCorporate(
            @Positive @PathVariable Long corporateId
    ) {
        corporateService.deactivateCorporate(corporateId);
    }

    @PreAuthorize("hasAnyAuthority('corporate:read','corporate:modify','corporate:all')")
    @GetMapping(CorporateContext.CORPORATE_LIMIT_TYPE)
    public RestResponseV2<Collection<DtoCorporateLimitType>> getCorporateLimitType() {
        var response = corporateService.getCorporateLimitTypes();
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAnyAuthority('corporate:read','corporate:modify','corporate:all')")
    @GetMapping(CorporateContext.CORPORATE_ID_LIMIT)
    public RestResponseV2<Collection<DtoCorporateLimitSummarized>> getCorporateLimits(
            @Positive @PathVariable Long corporateId,
            @RequestParam(value = "account_type", required = false)
            @Pattern(regexp = "WALLET|WALLET_RFID", message = "invalid account type")
            String accountType
    ) {
        var response = corporateService.getCorporateLimits(corporateId, PaymentGatewayType.of(accountType));
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAnyAuthority('corporate:modify','corporate:all')")
    @PutMapping(CorporateContext.CORPORATE_ID_LIMIT)
    public RestResponseV2<Collection<DtoCorporateLimitSummarized>> updateCorporateLimits(
            @Positive @PathVariable Long corporateId,
            @Pattern(regexp = "WALLET|WALLET_RFID", message = "invalid account type") @RequestParam(value = "account_type") String accountType,
            @Size(min = 1) @RequestBody List<@Valid DtoCorporateLimitRequest> requests
    ) {
        var response = corporateService.setCorporateLimits(corporateId, PaymentGatewayType.of(accountType), requests);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAnyAuthority('corporate:read','corporate:modify','corporate:all')")
    @GetMapping(CorporateContext.CORPORATE_ID_PLAN)
    public RestResponseV2<DtoCorporatePlanSummarized> getRechargePlansByCorporateId(
            @Positive @PathVariable Long corporateId,
            @Pattern(regexp = "WALLET|WALLET_RFID", message = "invalid account type") @RequestParam(value = "account_type") String accountType
    ) {
        var response = corporateService.getRechargePlansByCorporateId(corporateId, PaymentGatewayType.of(accountType));
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAnyAuthority('corporate:modify','corporate:all')")
    @PutMapping(CorporateContext.CORPORATE_ID_PLAN)
    public RestResponseV2<DtoCorporatePlanSummarized> setRechargePlansByCorporateId(
            @Positive @PathVariable Long corporateId,
            @Pattern(regexp = "WALLET|WALLET_RFID", message = "invalid account type") @RequestParam(value = "account_type") String accountType,
            @Valid @RequestBody DtoCorporatePlanSetRequest request
    ) {
        var response = corporateService.setRechargePlansByCorporateId(corporateId, PaymentGatewayType.of(accountType), request);
        return RestResponseV2.ofSuccess(response);
    }
}
