package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tax_types")
@NamedQuery(name = "TaxType.findAll", query = "SELECT t FROM TaxType t")
public class TaxType implements Serializable {

    private static final long serialVersionUID = -9106597896064707301L;

    @Id
    private Long id;

    @Column(name = "cgst")
    private Double cgst;

    @Column(name = "igst")
    private Double igst;

    @Column(name = "sgst")
    private Double sgst;


    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

}
