package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "sez_warehouse_variant_taxes")
@EntityListeners(AuditingEntityListener.class)
public class SezWarehouseVariantTax {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "warehouse_id")
    private Long warehouseId;

    @Column(name = "variant_id")
    private Long variantId;

    @Column(name = "hsn_code")
    private String hsnCode;

    @Column(name = "igst_rate")
    private Double igstRate;

    @Column(name = "cgst_rate")
    private Double cgstRate;

    @Column(name = "sgst_rate")
    private Double sgstRate;

    @Column(name = "cess_rate")
    private Double cessRate;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "variant_id", insertable = false, updatable = false)
    private Variant variant;

    @JsonIgnore
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString () {
        return new StringJoiner(", ", SezWarehouseVariantTax.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("warehouseId=" + warehouseId)
            .add("variantId=" + variantId)
            .add("hsnCode='" + hsnCode + "'")
            .add("igstRate=" + igstRate)
            .add("cgstRate=" + cgstRate)
            .add("sgstRate=" + sgstRate)
            .add("cessRate=" + cessRate)
            .toString();
    }
}
