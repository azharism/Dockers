package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum WalletSubType {
    Normal("normal"),
    Cashback("cashback"),
    Internal("internal");

    private final String value;

    WalletSubType (final String value) {
        this.value = value;
    }

    @JsonValue
    public String value () {
        return value;
    }

    @JsonCreator
    public static WalletSubType of (final String valStr) {
        return Arrays.stream(WalletSubType.values())
                     .filter(x -> x.value.equalsIgnoreCase(valStr))
                     .findAny()
                     .orElseThrow(IllegalArgumentException::new);
    }
}
