package in.co.daalchini.controller;

import in.co.daalchini.data.constants.DCConstants;
import in.co.daalchini.data.constants.RouteConstants.ProductPlacementContext;
import in.co.daalchini.models.request.DCRequest;
import in.co.daalchini.models.request.ProductPlacementRequest;
import in.co.daalchini.models.response.DCResponse;
import in.co.daalchini.models.response.ProductPlacementResponse;
import in.co.daalchini.service.ProductPlacementCountService;
import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.List;

@Log4j2
@RestController
public class ProductPlacementCountController {

    private final ProductPlacementCountService placementCountService;

    public ProductPlacementCountController (
        ProductPlacementCountService placementCountService)
    {
        this.placementCountService = placementCountService;
    }

    @PostMapping(ProductPlacementContext.BASE)
    public DCResponse<Collection<ProductPlacementResponse>> getProductPlacementDetails (
        @RequestBody DCRequest<ProductPlacementRequest> dcRequest)
    {
        log.info("[getProductPlacementDetails] dcRequest = {}", dcRequest);
        DCResponse<Collection<ProductPlacementResponse>> response = new DCResponse<>();
        response.setStatus(DCConstants.API_SUCCESS);
        response.setStatusMessage(DCConstants.API_SUCCESS_MESSAGE);
        response.setStatusCode(DCConstants.API_SUCCESS_CODE);

        try {
            if (dcRequest == null || dcRequest.getRequest() == null)
                throw new NullPointerException("NULL REQUEST RECEIVED");
            else if (dcRequest.getRequest().getProductCodes() == null)
                throw new NullPointerException("NULL PRODUCT CODES");
            else {
                Collection<ProductPlacementResponse> list =
                    placementCountService.getCodeActiveCount(dcRequest.getRequest().getProductCodes());
                response.setData(list);
            }
        } catch (NullPointerException e) {
            response.setStatus(DCConstants.API_FAILURE);
            response.setStatusMessage(e.getMessage());
            response.setStatusCode(DCConstants.API_FAILURE_CODE_NULL_REQUEST);
        } catch (IllegalArgumentException e) {
            response.setStatus(DCConstants.API_FAILURE);
            response.setStatusMessage(e.getMessage());
            response.setStatusCode(DCConstants.API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST);
        } catch (Exception e) {
            response.setStatus(DCConstants.API_FAILURE);
            response.setStatusMessage(e.getClass().getSimpleName());
            response.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
        }

        log.info("[getProductPlacementDetails] response = {}", response);

        return response;
    }
}
