package in.co.daalchini.data.transporatable;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

public class CouponDetails {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static final class Response {
        private Long id;
        private String name;
        private boolean isVm;
        private boolean isMV;
        private Double minCashBack;
        private Double maxCashback;
        private Double maxBudget;
        private Double currentBudget;
        private boolean isBudgetReached;
        private boolean isActivated;
        private Integer flatTypeId;
        private Double flatAmount;
        private Long couponLimit;
        private boolean isOrder;
        private String couponDescription;
        private String couponImage;
        private String deeplink;
        private Integer platformId;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        private boolean isPG;
        private LocalDateTime startDate;
        private LocalDateTime expiryDate;
        private boolean isFirstOrder;
        private boolean isNewUser;
        private boolean minTotalOrderAmount;
        private Integer couponType;
        private String amountType;
        private String platform;
        private String type;
        private Long usagePerDevice;
        private boolean isMealType;
        private boolean isSlotId;
        private Boolean isAutoApplicable;
    }
}

