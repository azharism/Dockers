package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

public class CorporateTag {

    @Data
    @JsonIncludeProperties({"id","uid","token","status","series_id","balance"})
    public static final class Summary {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("uid")
        private String uid;

        @JsonProperty("token")
        private String token;

        @JsonProperty("status")
        private String status;

        @JsonProperty("balance")
        private Double balance;
    }
}

