package in.co.daalchini.data.transporatable.message;

import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ZohoVendorEvent implements  Jsonable{

    @JsonProperty("manufacturerId")
    private Integer manufacturerId;

    @JsonProperty("variantId")
    private Long variantId;
    public String json () {
        return JsonUtil.toJson(this);
    }

}
