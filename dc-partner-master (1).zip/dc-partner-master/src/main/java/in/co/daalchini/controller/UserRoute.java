package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.UserContext;
import in.co.daalchini.data.constants.enums.DevicePlatform;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.data.untransportable.OrderSource;
import in.co.daalchini.service.*;
import in.co.daalchini.service.http.OrderService;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.annotation.CurrentSecurityContext;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

import static in.co.daalchini.data.constants.RouteConstants.GeneralContext.USER_LOGIN;
import static in.co.daalchini.data.constants.RouteConstants.UserContext.UPDATE_FCM_TOKEN;
import static org.springframework.web.bind.annotation.RequestMethod.*;

@Log4j2
@Validated
@RestController
public class UserRoute {

    private final UserProfileService userProfileService;
    private final MachineService machineService;
    private final DriverService driverService;
    private final OrderService orderService;
    private final PartnerTimesheetService partnerTimesheetService;
    private final UserFuelService userFuelService;
    private final UserAuthService userAuthService;

    public UserRoute(
            UserProfileService userProfileService,
            MachineService machineService,
            DriverService driverService,
            OrderService orderService,
            PartnerTimesheetService partnerTimesheetService,
            UserFuelService userFuelService,
            UserAuthService userAuthService
    ) {
        this.userProfileService = userProfileService;
        this.machineService = machineService;
        this.driverService = driverService;
        this.orderService = orderService;
        this.partnerTimesheetService = partnerTimesheetService;
        this.userFuelService = userFuelService;
        this.userAuthService = userAuthService;
    }

    @PostMapping(value = USER_LOGIN)
    public DtoUserLoginResponse userLogin(
            @RequestHeader("x-app-platform") DevicePlatform appPlatform,
            @RequestHeader("x-app-version") String appVersion,
            @RequestHeader("x-device-id") String deviceId,
            @RequestHeader("x-fcm-token") String fcmToken,
            @Valid @RequestBody DtoUserLoginRequest request
    ) {
        var response = userAuthService.generateNewToken(request, appPlatform, appVersion, deviceId, fcmToken);
        log.debug("[userLogin] response = {}", response);

        return response;
    }

    @RequestMapping(value = UPDATE_FCM_TOKEN, method = {PATCH, PUT, POST})
    public FCMTokenUpdate.Response updateFCMToken(
            @RequestHeader("fcm_token") String fcmToken,
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.debug("[updateFCMToken] user = {}, fcmToken = {}", userDetails, fcmToken);
        boolean updated = false;
        try {
            updated = userProfileService.putFCMToken(userDetails.getUserId(), fcmToken);
        } catch (Exception e) {
            log.warn("Error while storing fcm token", e);
        }
        final FCMTokenUpdate.Response response = FCMTokenUpdate.Response.builder().tokenUpdated(updated).build();
        log.info("[updateFCMToken] response = {}", response);

        return response;
    }

    @GetMapping(UserContext.PROFILE_ADDRESS)
    public List<ProfileAddress.Response> userProfileAddress(
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("[userProfileAddress] user = {}", userDetails);
        try {
            List<ProfileAddress.Response> responses = userProfileService.getUserAddresses(userDetails.getUserId());
            log.info("[userProfileAddress] responses = {}", responses);
            return responses;
        } catch (Exception e) {
            log.error("[userProfileAddress] error = ", e);
            throw e;
        }
    }

    @PostMapping(UserContext.SAVE_PROFILE_ADDRESS)
    public ProfileAddress.Response saveUserAddress(
            @Valid @RequestBody ProfileAddress.Request request,
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("[saveUserAddress] user = {}", userDetails);
        try {
            ProfileAddress.Response response = userProfileService.saveUserAddress(request, userDetails.getUserId());
            log.info("[saveUserAddress] response = {}", response);
            return response;
        } catch (Exception e) {
            log.error("[saveUserAddress] error = ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('mobility_checkin')")
    @PostMapping(UserContext.DRIVER_CHECK_IN)
    public DriverCheckIn.Response checkInDriver(
            @RequestParam Long vmId,
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        try {
            Long userId = userDetails.getUserId();
            DriverCheckIn.Response response = driverService.checkIn(vmId, userId);
            log.info("Response = {}", response);
            return response;
        } catch (Exception e) {
            log.error("Caught error while checking in = {}", e.getMessage());
            throw e;
        }
    }

    @GetMapping(UserContext.DRIVER_CURRENT_MACHINE)
    public DriverCheckIn.Response getDriverCurrentMachine(@AuthenticationPrincipal AuthUserDetails userDetails) {
        Long userId = userDetails.getUserId();
        log.info("Request received for checking current mvm for dashboard user id : {}", userId);
        try {
            DriverCheckIn.Response response = driverService.fetchCurrentMachine(userId);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("Caught error while getting machine :{}", e.getMessage());
            throw e;
        }
    }

    @GetMapping(UserContext.CHECK_BALANCE_PARTNER)
    public PartnerBalance.Response checkBalance(@AuthenticationPrincipal AuthUserDetails userDetails) {
        Long userId = userDetails.getUserId();
        try {
            PartnerBalance.Response response = driverService.checkPartnerBalance(userId);
            log.info("Response : {}", response);
            return response;
        } catch (Exception e) {
            log.error("Caught error while checking balance = {}", e.getMessage());
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('orders_allowed')")
    @GetMapping(UserContext.MOBILITY_ORDER_HISTORY)
    public MobilityOrderHistory.Response getOrders(
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "offset", required = false) Integer offset) {
        log.info("Get order history for driver :{}", userDetails);
        MobilityOrderHistory.Response response = orderService
                .getMobilityOrderHistory(userDetails.getUserId(), limit, offset, OrderSource.ConsumerApp);
        log.info("Response :{}", response);
        return response;
    }

    @GetMapping(UserContext.MACHINE_LIST)
    public List<PartnerMachine.Response> listPartnerMachines(
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("[listPartnerMachines] user = {}", userDetails);
        try {
            List<PartnerMachine.Response> responses = machineService.fetchUserMachines(userDetails.getUserId());
            log.info("[listPartnerMachines] responses = {}", responses);
            return responses;
        } catch (Exception e) {
            log.error("[listPartnerMachines] error = ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('mobility_refill')")
    @GetMapping(UserContext.CURRENT_INVENTORY)
    public List<PartnerInventory.Response> partnerCurrentInventory(
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("[partnerCurrentInventory] user = {}", userDetails);
        try {
            List<PartnerInventory.Response> responses = machineService.fetchUserInventory(userDetails.getUserId());
            log.info("[partnerCurrentInventory] responses = {}", responses);
            return responses;
        } catch (Exception e) {
            log.error("[partnerCurrentInventory] error = ", e);
            throw e;
        }
    }

    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority('mobility_refill')")
    @PutMapping(UserContext.MACHINE_INVENTORY_RESTOCK)
    public NullResponse partnerMachineRestock(
            @CurrentSecurityContext(expression = "authentication") Authentication authentication,
            @PathVariable(name = "vmId") Long machineId,
            @Valid @RequestBody List<MachineRestock.Request> requestList) {
        log.info("[partnerMachineRestock] user = {}, machineId = {}, requestList = {}",
                authentication, machineId, requestList);
        try {
            AuthUserDetails userDetails = (AuthUserDetails) authentication.getPrincipal();
            String token = (String) authentication.getCredentials();
            machineService.restockMachine(userDetails.getUserId(), token, machineId, requestList);
        } catch (Exception e) {
            log.error("[partnerMachineRestock] error = ", e);
            throw e;
        }

        NullResponse response = NullResponse.of("Request submitted");
        log.info("[partnerMachineRestock], response = {}", response);

        return response;
    }

    @GetMapping(UserContext.USER_CHECK_IN_DETAILS)
    public List<PartnerTimesheetDto.Response> fetchPartnerTimesheet(
            @AuthenticationPrincipal AuthUserDetails authUserDetails,
            @PathVariable(value = "warehouseId") Long warehouseId) {
        log.info("[fetchPartnerTimesheet] warehouse = {}", warehouseId);
        try {
            List<PartnerTimesheetDto.Response> responses = partnerTimesheetService.fetchTimesheet(warehouseId);
            log.info("[fetchPartnerTimesheet] responses = {}", responses);
            return responses;
        } catch (Exception e) {
            log.error("[fetchPartnerTimesheet] error = ", e);
            throw e;
        }
    }

    @PatchMapping(UserContext.ATTENDANCE_APPROVE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority('approve_attendance')")
    public ApproveAttendance.Response approveUserAttendance(
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestBody List<ApproveAttendance.Request> requests) {
        log.info("[approveUserAttendance] approve req by = {}", userDetails.getUserId());
        try {
            ApproveAttendance.Response response = partnerTimesheetService.approveAttendance(requests);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("[approveUserAttendance] error = ", e);
            throw e;
        }
    }

    @PutMapping(UserContext.USER_MMI_DEVICE)
    public RestResponseV2<DtoMMIDeviceUpdateResponse> updateUserMMIDeviceId(
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @Valid @RequestBody DtoMMIDeviceUpdateRequest deviceUpdateRequest) {
        var data = userProfileService.updateUserMMIDeviceId(userDetails.getUserId(), deviceUpdateRequest);

        return RestResponseV2.ofSuccess(data);
    }

    @GetMapping(UserContext.USER_TRIP_LOCATIONS)
    public RestResponseV2<DtoUserTripLocations> fetchUserTripLocations(
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        var data = userFuelService.fetchUserTripLocations(userDetails.getUserId());

        return RestResponseV2.ofSuccess(data);
    }

}
