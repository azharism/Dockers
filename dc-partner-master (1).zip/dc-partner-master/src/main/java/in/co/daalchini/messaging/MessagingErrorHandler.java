package in.co.daalchini.messaging;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import org.springframework.util.ErrorHandler;

@Log4j2
@Service
public class MessagingErrorHandler implements ErrorHandler {

    @Override
    public void handleError (Throwable t) {
        log.error("Error while processing message", t);
    }

}
