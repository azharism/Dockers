package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NullResponse {
    private String message;

    public static NullResponse of (String message) {
        return NullResponse.builder().message(message).build();
    }
}
