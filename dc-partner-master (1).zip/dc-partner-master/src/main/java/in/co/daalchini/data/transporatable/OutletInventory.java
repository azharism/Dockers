package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

import java.util.Collections;
import java.util.List;


public final class OutletInventory {

    @Data
    @Builder
    public static final class Response {
        public Integer slotIdentifier;
        public Long slotCapacity;
        public @Default Long activeQuantity = 0L;
        public @Default Long holdQuantity = 0L;
        public @Default Boolean isActive = true;
        public MfVariant mfVariant;
    }

    @Data
    @Builder
    public static final class MfVariant {
        public Long id;
        public Long productId;
        public Double mrp;
        public Double offerPrice;
        public Double vendorPrice;
        public String manufacturerName;
        public String name;
        public String title;
        public String description;
        public Integer serving;
        public String withPackagingWeight;
        public Boolean isActive;
        public Boolean isSpecial;
        public Boolean isVeg;
        public Boolean microwaveHeating;
        public String shelfLife;
        public String mealType;
        public String cuisineType;
        public String formType;
        public Integer caseSize;
        public String hsn;
        public String productName;
        public TaxValue taxValue;
        public @Default List<String> images = Collections.emptyList();
    }

    @Data
    @Builder
    public static final class TaxValue {
        private Double cgst;
        private Double igst;
        private Double sgst;
    }
}
