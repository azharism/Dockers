package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoHardwareIssue;
import in.co.daalchini.data.transporatable.DtoHardwareIssueReason;
import in.co.daalchini.models.HardwareIssue;
import in.co.daalchini.models.HardwareIssueReason;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public interface HardwareIssueMapper {

    @Mapping(target = "id", source = "id")
    @Mapping(target = "reason", source = "title")
    DtoHardwareIssueReason toDtoReason(HardwareIssueReason reason);

    @Mapping(target = "isOff", expression = "java(issue.isOff())")
    @Mapping(target = "issueId", source = "id")
    @Mapping(target = "offReasonId", source = "reason.id")
    @Mapping(target = "offReasonDescription", source = "reason.title")
    DtoHardwareIssue toDtoIssue(HardwareIssue issue);

    @Mapping(target = "isOff", expression = "java(issue.isOff())")
    @Mapping(target = "issueId", source = "issue.id")
    @Mapping(target = "offReasonId", source = "reason.id")
    @Mapping(target = "offReasonDescription", source = "reason.title")
    DtoHardwareIssue toDtoIssue(HardwareIssue issue, HardwareIssueReason reason);

    List<DtoHardwareIssueReason> toDtoReasons(Collection<HardwareIssueReason> collection);
}
