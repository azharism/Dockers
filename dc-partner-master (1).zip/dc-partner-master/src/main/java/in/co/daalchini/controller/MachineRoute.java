package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.MachineContext;
import in.co.daalchini.data.constants.RouteConstants.S3UploadContext;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.HardwareIssueService;
import in.co.daalchini.service.MachineService;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

@Log4j2
@RestController
public class MachineRoute {

    private final MachineService machineService;
    private final HardwareIssueService hardwareIssueService;

    public MachineRoute(
            MachineService machineService,
            HardwareIssueService hardwareIssueService
    ) {
        this.machineService = machineService;
        this.hardwareIssueService = hardwareIssueService;
    }

    @PreAuthorize("hasAnyAuthority('vm_create', 'vm_update','vm_view')")
    @GetMapping(MachineContext.MACHINE_SEED)
    public RestResponseV2<DtoMachineSeedData> fetchCreateMachineSeedData() {
        var data = machineService.fetchCreationSeedData();

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('vm_create','vm_update')")
    @PostMapping(S3UploadContext.MACHINE_IMAGE)
    public RestResponseV2<DtoMachineImage> uploadMachineImageS3(
            @RequestPart(value = "file") MultipartFile file) throws IOException {
        DtoMachineImage data = machineService.uploadImageS3(file);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('vm_create', 'vm_update','vm_view')")
    @GetMapping(MachineContext.MACHINE)
    public RestResponseV2<List<DtoMachineSummary>> fetchMachines(
            @RequestParam(value = "pageSize", required = false) Integer pageSize,
            @RequestParam(value = "pageNumber", required = false) Integer pageNumber) {
        var data = machineService.fetchMachines(pageSize, pageNumber);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('vm_create', 'vm_update','vm_view')")
    @GetMapping(MachineContext.MACHINE_W_ID)
    public RestResponseV2<DtoMachineDetails> fetchMachineDetails(@PathVariable("machineId") Long machineId) {
        var data = machineService.fetchMachineDetails(machineId);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAuthority('vm_create')")
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(MachineContext.MACHINE)
    public RestResponseV2<DtoMachineDetails> createMachine(
            @Valid @RequestBody DtoMachineCreateRequest createRequest) throws IOException {
        var data = machineService.createMachine(createRequest);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('vm_create','vm_update')")
    @PatchMapping(MachineContext.MACHINE_W_ID)
    public RestResponseV2<DtoMachineDetails> updateMachineDetails(
            @PathVariable("machineId") Long machineId,
            @Valid @RequestBody DtoMachineUpdateRequest request) {
        var data = machineService.updateMachine(machineId, request);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAuthority('vm_create')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping(MachineContext.MACHINE_W_ID)
    public void terminateMachine(
            @PathVariable("machineId") Long machineId) {
        machineService.terminateMachine(machineId);
    }

    @PreAuthorize("hasAuthority('vm_create')")
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(MachineContext.MACHINE_W_ID)
    public RestResponseV2<DtoMachineDetails> cloneMachine(
            @PathVariable("machineId") Long machineId,
            @RequestBody DtoMachineCloneRequest request) throws IOException {
        DtoMachineDetails data = machineService.cloneMachine(machineId, request);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('vm_create', 'vm_update','vm_view')")
    @GetMapping(MachineContext.MACHINE_SEARCH)
    public RestResponseV2<List<DtoMachineSummary>> searchMachine(
            @RequestParam(value = "value") String value
    ) {
        var data = machineService.machineSearch(value);
        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('vm_create','vm_update','slot_operation')")
    @GetMapping(MachineContext.MACHINE_W_ID_TRAY)
    public RestResponseV2<Collection<DtoMachineTray>> fetchMachineTrays(
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @PathVariable("machineId") Long machineId) {

        var data = machineService.fetchMachineTrays(userDetails.getUserId(), machineId);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('vm_create','vm_update','slot_operation')")
    @PatchMapping(MachineContext.MACHINE_W_ID_TRAY)
    public RestResponseV2<Collection<DtoMachineTray>> modifyTray(
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @PathVariable("machineId") Long machineId,
            @Valid @RequestBody DtoTrayModificationRequest request) {

        var data = machineService.modifyTray(userDetails.getUserId(), machineId, request);

        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('hardware_issue')")
    @GetMapping(MachineContext.HW_ISSUE_REASON)
    public RestResponseV2<List<DtoHardwareIssueReason>> fetchIssueReason() {
        var data = hardwareIssueService.fetchIssueReason();
        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('hardware_issue')")
    @GetMapping(MachineContext.HW_ISSUE_W_MACHINE_ID)
    public RestResponseV2<DtoHardwareIssue> fetchMachineStatus(
            @PathVariable(value = "machineId") Long machineId
    ) {
        var data = hardwareIssueService.fetchMachineStatus(machineId);
        return RestResponseV2.ofSuccess(data);
    }

    @PreAuthorize("hasAnyAuthority('hardware_issue')")
    @PatchMapping(MachineContext.HW_ISSUE_W_MACHINE_ID)
    public RestResponseV2<DtoHardwareIssue> updateMachineStatus(
            @PathVariable(value = "machineId") Long machineId,
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestBody @Valid DtoHardwareIssueUpdateRequest request
    ) {
        var data = hardwareIssueService.updateMachineStatus(machineId, userDetails.getUserId(), request);
        return RestResponseV2.ofSuccess(data);
    }
    @GetMapping(MachineContext.MACHINE_WISE_SALE)
    public RestResponseV2<List<DtoMachineWiseSale>> fetchMachineSale(
            @PathVariable("machineId") Long machineId,
            @RequestParam(value = "interval") Integer interval
    )
    {
        var data = machineService.getMachineSales(machineId, interval);
        return RestResponseV2.ofSuccess(data);
    }

    @GetMapping(MachineContext.HOURLY_MACHINE_WISE_SALE)
    public RestResponseV2<List<DtoHourlyMachineWiseSale>> fetchHourlyMachineSale(
            @AuthenticationPrincipal AuthUserDetails userDetails
    )
    {
        try{
            log.info("Request received for fetch  hourly machine wise sales");
            var  response =  machineService.getHourlyMachineSales(userDetails.getUserId());
            log.info("Response :{}", response);
            return RestResponseV2.ofSuccess(response);
        }catch (Exception e){
            log.error("Error in etch  hourly machine wise sales :{}", e.getMessage());
            throw e;
        }

    }

    @PostMapping(MachineContext.MACHINE_SLOT_MERGE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public RestResponseV2<?> mergeMachineSlot(
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @PathVariable(name = "machineId") Long machineId,
            @PathVariable(name = "slot") Long slotId,
            @PathVariable(name = "mergedSlot") Long mergedSlotId
    )
    {
        try{
            log.info("Request received for merging slot {} of machineId {} with {} by userId {}",
                    slotId, machineId, mergedSlotId, userDetails.getUserId());
             machineService.mergeSlot(machineId, slotId, mergedSlotId, userDetails.getUserId());
            return RestResponseV2.ofSuccess("Accepted");
        }catch (Exception e){
            log.error("Error [mergeMachineSlot] :{}", e.getMessage());
            throw e;
        }

    }

    @DeleteMapping(MachineContext.MACHINE_SLOT_MERGE_DELETE_ALL)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public RestResponseV2<?> deleteMachineMergeSlot(
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @PathVariable(name = "machineId") Long machineId
    )
    {
        try{
            log.info("Request received for deleting merge slots of machineId {} by userId {}",
                    machineId, userDetails.getUserId());
            machineService.deleteMergeSlot(machineId);
            return RestResponseV2.ofSuccess("Accepted");
        }catch (Exception e){
            log.error("Error [deleteMachineSlot] :{}", e.getMessage());
            throw e;
        }

    }

}
