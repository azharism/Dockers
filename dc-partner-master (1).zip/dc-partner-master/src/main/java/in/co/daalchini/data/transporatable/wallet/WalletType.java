package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum WalletType {
    Prepaid("prepaid"),
    Overdraft("overdraft");

    private final String value;

    WalletType (final String value) {
        this.value = value;
    }

    @JsonValue
    public String value () {
        return value;
    }

    @JsonCreator
    public static WalletType of (final String valueStr) {
        return Arrays.stream(WalletType.values())
                     .filter(x -> x.value.equalsIgnoreCase(valueStr))
                     .findAny()
                     .orElseThrow(IllegalArgumentException::new);
    }
}
