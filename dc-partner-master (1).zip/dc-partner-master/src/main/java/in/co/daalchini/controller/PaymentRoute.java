package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.PaymentContext;
import in.co.daalchini.data.transporatable.PaymentHistory;
import in.co.daalchini.data.transporatable.PaymentOnboard;
import in.co.daalchini.data.transporatable.PaymentOption;
import in.co.daalchini.data.transporatable.PaymentRecharge;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.http.PaymentService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Log4j2
@RestController
public class PaymentRoute {

    private final PaymentService paymentService;

    @Autowired
    public PaymentRoute (PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PreAuthorize("hasAuthority('bulk_purchase')")
    @GetMapping(PaymentContext.PAYMENT_OPTION)
    public List<PaymentOption.Response> paymentOption (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @RequestParam(name = "vmId") Long machineId,
        @RequestParam(name = "includeBalance") Boolean includeBalance)
    {
        log.info("[paymentOption] userDetails = {}, vmId = {}, includeBalance = {}",
                 userDetails, machineId, includeBalance);
        List<PaymentOption.Response> response = paymentService.getPaymentOption(userDetails.getUserId(),
                                                                                machineId,
                                                                                includeBalance);

        log.info("[paymentOption] userDetails = {}", response);
        return response;
    }

    @PreAuthorize("hasAuthority('bulk_purchase')")
    @GetMapping(PaymentContext.PAYMENT_HISTORY)
    public PaymentHistory.Response paymentHistory (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @PathVariable Integer pgId,
        @RequestParam(value = "limit", required = false) Integer limit,
        @RequestParam(value = "pageNumber", required = false) Integer pageNumber,
        @RequestParam(value = "from") String from,
        @RequestParam(value = "to") String to,
        @RequestParam(value = "sortBy") String sortBy)
    {
        log.info("[paymentHistory], userDetails = {}, limit = {}, pageNumber = {}, from = {}, to = {}, sortBy = {}",
                 userDetails, limit, pageNumber, from, to, sortBy);
        try {
            PaymentHistory.Response response =
                paymentService.getPaymentHistory(userDetails.getUserId(), pgId, limit, pageNumber, from, to,sortBy);

            log.info("[paymentHistory], responses = {}", response);
            return response;
        } catch (Exception e) {
            log.error("[paymentHistory], error = ", e);
            throw e;
        }
    }

    @PreAuthorize("hasAuthority('partner_recharge')")
    @PostMapping(PaymentContext.PAYMENT_ONBOARD_BULK)
    public PaymentOnboard.Response paymentOnboardBulk (
        @PathVariable Integer pgId,
        @RequestBody @Valid PaymentOnboard.Request request)
    {
        log.info("[paymentOnboardBulk] pgId = {}, request = {}", pgId, request);

        PaymentOnboard.Response response = paymentService.bulkOnboardUsers(pgId, request);
        log.info("[paymentOnboardBulk] response = {}", response);
        return response;
    }

    @PreAuthorize("hasAuthority('partner_recharge')")
    @PostMapping(PaymentContext.PAYMENT_RECHARGE_BULK)
    public PaymentRecharge.Response paymentRechargeBulk (
        @PathVariable Integer pgId,
        @RequestBody List<PaymentRecharge.IndexedRequest> requests)
    {
        log.info("[paymentOnboardBulk] pgId = {}, requests = {}", pgId, requests);

        PaymentRecharge.Response response = paymentService.bulkRechargeWallets(pgId, requests);
        log.info("[paymentOnboardBulk] response = {}", response);

        return response;
    }

}
