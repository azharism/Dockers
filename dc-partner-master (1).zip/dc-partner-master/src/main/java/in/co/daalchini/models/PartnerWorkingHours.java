package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "partner_working_hours")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PartnerWorkingHours {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name ="dashboard_user_id")
    private Long dashboardUserId;

    @Column(name = "name")
    private String name;

    @Column(name = "weekly_working_hours")
    private Long weeklyWorkingHours;

    @Column(name = "monthly_working_hours")
    private Long monthlyWorkingHours;

    @Column(name = "last_month_working_hours")
    private Long lastMonthWorkingHours;

    @OneToMany
    @JoinColumn(name = "dashboard_user_id",
            insertable = false,
            updatable = false,
            referencedColumnName = "dashboard_user_id")
    private List<ArchiveDashboardUserKitRefillDetails> archiveDashboardUserKitRefillDetails;

}
