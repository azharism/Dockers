package in.co.daalchini.data.transporatable.wrapper;

import lombok.*;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Status {

    private @NonNull Boolean success;
    private String code;
    private @NonNull String message;
    private @NonNull Instant timestamp;


    public static Status ofSuccess (String message) {
        return Status
            .builder()
            .success(true)
            .code("OK")
            .message(message)
            .timestamp(Instant.now())
            .build();
    }

    public static Status ofFailure (String message) {
        return ofFailure(null, message);
    }

    public static Status ofFailure (String code, String message) {
        return Status
            .builder()
            .success(false)
            .code(code)
            .message(message)
            .timestamp(Instant.now())
            .build();
    }
}
