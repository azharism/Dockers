package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoOrderResponse {
    private String id;
    private String phone;
    private Double amount;
    private String status;
    private String dcCode;
    private String city;
    private String createdAt;
}

