package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "hsn_headings")
public class HsnHeadings {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "value")
    private String value;

    @Column(name = "description")
    private String description;

    @Column(name = "chapter_id")
    private Long chapterId;
}
