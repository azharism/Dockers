package in.co.daalchini.models;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * The persistent class for the sku_groups_stock_in database table.
 */
@Entity
@Table(name = "sku_groups_stock_in")
@NamedQuery(name = "SkuGroupStockIn.findAll", query = "SELECT s FROM SkuGroupStockIn s")
public class SkuGroupStockIn implements Serializable {

	private static final long serialVersionUID = -5415561940907224857L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	private Long id;

	private String batch;

	@Column(name = "checked_in")
	private Double checkedIn;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
	@CreationTimestamp
	private Date createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expiry_date")
	private Date expiryDate;

	private Double filled;

	@Column(name = "in_transit")
	private Integer inTransit;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "manufacture_date")
	private Date manufactureDate;

	@Column(name = "sku_number")
	private Integer skuNumber;

	private Integer sold;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at")
	@UpdateTimestamp
	private Date updatedAt;

//	// bi-directional many-to-one association to Warehous
//	@ManyToOne(fetch = FetchType.EAGER)
//	@JoinColumn(name = "warehouse_id")
//	private Warehouse warehous;

	// bi-directional many-to-one association to ManufacturerVariant
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "manufacturer_variant_id")
	private ManufacturerVariant manufacturerVariant;
	
	@Column(name = "invoice_details_id") private Long invoiceDetailsId;

	public Long getInvoiceDetailsId() {
		return invoiceDetailsId;
	}

	public void setInvoiceDetailsId(Long invoiceDetailsId) {
		this.invoiceDetailsId = invoiceDetailsId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public Double getCheckedIn() {
		return checkedIn;
	}

	public void setCheckedIn(Double checkedIn) {
		this.checkedIn = checkedIn;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Double getFilled() {
		return filled;
	}

	public void setFilled(Double filled) {
		this.filled = filled;
	}

	public Integer getInTransit() {
		return inTransit;
	}

	public void setInTransit(Integer inTransit) {
		this.inTransit = inTransit;
	}

	public Date getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public Integer getSkuNumber() {
		return skuNumber;
	}

	public void setSkuNumber(Integer skuNumber) {
		this.skuNumber = skuNumber;
	}

	public Integer getSold() {
		return sold;
	}

	public void setSold(Integer sold) {
		this.sold = sold;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public ManufacturerVariant getManufacturerVariant() {
		return manufacturerVariant;
	}

	public void setManufacturerVariant(ManufacturerVariant manufacturerVariant) {
		this.manufacturerVariant = manufacturerVariant;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}