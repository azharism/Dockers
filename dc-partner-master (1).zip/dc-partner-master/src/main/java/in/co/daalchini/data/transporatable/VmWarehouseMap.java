package in.co.daalchini.data.transporatable;

import lombok.*;

import java.util.List;

public class VmWarehouseMap {

    @Data
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Request {
        private List<Long> vmList;
    }
}
