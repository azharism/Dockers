package in.co.daalchini.controller;

import in.co.daalchini.data.transporatable.NullResponse;
import in.co.daalchini.data.transporatable.RefundRevoke;
import in.co.daalchini.service.RefundRevokeService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import static in.co.daalchini.data.constants.RouteConstants.RefundRevokeRoute.REFUND_REVOKE;

@RestController
@Log4j2
public class RefundRevokeRoute {

    private final RefundRevokeService refundRevokeService;

    @Autowired
    public RefundRevokeRoute(RefundRevokeService refundRevokeService){
        this.refundRevokeService = refundRevokeService;
    }

    @PostMapping(REFUND_REVOKE)
    @PreAuthorize("hasAuthority('refund_revoke')")
    public NullResponse refundRevokeWallet(@RequestBody RefundRevoke.Request request){
        log.info("Request received for refund revoke:{}", request);
        NullResponse response;
        try {
            response = refundRevokeService.processRequest(request);
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error  :{}", e.getMessage());
            throw e;
        }
        return response;
    }
}
