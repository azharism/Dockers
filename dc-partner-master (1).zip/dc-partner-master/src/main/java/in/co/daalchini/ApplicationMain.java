package in.co.daalchini;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import in.co.daalchini.data.constants.GeneralConstants.BrokerConfig;
import in.co.daalchini.messaging.ActiveMQMessageConverter;
import in.co.daalchini.messaging.MessagingErrorHandler;
import lombok.extern.log4j.Log4j2;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.Resource;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.io.IOException;


@Log4j2
@SpringBootApplication
@EnableTransactionManagement
public class ApplicationMain {

    public static void main(String[] args) {
        SpringApplication.run(ApplicationMain.class, args);
    }

    @Bean
    public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        final ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module())
                .registerModule(new JavaTimeModule());
        return new MappingJackson2HttpMessageConverter(objectMapper);
    }

    @Bean("activemqConnectionFactory")
    public ActiveMQConnectionFactory activemqConnectionFactory(
            @Value("${url.activemq-broker.tcp}") String address) {
        log.info("Connecting to activemq at [{}]", address);
        ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(address);
        factory.setClientIDPrefix(BrokerConfig.getServiceClientId("partner"));
        return factory;
    }

    @Bean("jmsTopicListenerContainerFactory")
    public JmsListenerContainerFactory<?> jmsTopicListenerContainerFactory(
            ActiveMQConnectionFactory activemqConnectionFactory,
            DefaultJmsListenerContainerFactoryConfigurer configurer,
            MessagingErrorHandler errorHandler) {
        DefaultJmsListenerContainerFactory containerFactory = new DefaultJmsListenerContainerFactory();
        configurer.configure(containerFactory, activemqConnectionFactory);
        containerFactory.setErrorHandler(errorHandler);
        containerFactory.setPubSubDomain(true);

        return containerFactory;
    }

    @Bean("jmsQueueListenerContainerFactory")
    public JmsListenerContainerFactory<?> jmsQueueListenerContainerFactory(
            ActiveMQConnectionFactory activemqConnectionFactory,
            MessagingErrorHandler errorHandler) {
        DefaultJmsListenerContainerFactory containerFactory = new DefaultJmsListenerContainerFactory();
        containerFactory.setConnectionFactory(activemqConnectionFactory);
        containerFactory.setErrorHandler(errorHandler);
        containerFactory.setPubSubDomain(false);

        return containerFactory;
    }

    @Bean("jmsTopicTemplate")
    public JmsTemplate jmsTopicTemplate(
            ActiveMQConnectionFactory activemqConnectionFactory,
            ActiveMQMessageConverter messageConverter) {
        final JmsTemplate jmsTemplate = new JmsTemplate();
        jmsTemplate.setConnectionFactory(activemqConnectionFactory);
        jmsTemplate.setMessageConverter(messageConverter);
        jmsTemplate.setPubSubDomain(true);

        return jmsTemplate;
    }

    @Bean("jmsQueueTemplate")
    public JmsTemplate jmsQueueTemplate(
            ActiveMQConnectionFactory activemqConnectionFactory,
            ActiveMQMessageConverter messageConverter) {
        final JmsTemplate jmsTemplate = new JmsTemplate();
        jmsTemplate.setConnectionFactory(activemqConnectionFactory);
        jmsTemplate.setMessageConverter(messageConverter);
        jmsTemplate.setPubSubDomain(false);

        return jmsTemplate;
    }

    @Bean("firebaseMessaging")
    public FirebaseMessaging firebaseMessaging(
            @Value("classpath:firebase-sdk-partner-${spring.profiles.active:dev}.json") Resource resource,
            @Value("${url.firebase.db}") String address)
            throws IOException {
        final FirebaseOptions firebaseOptions =
                FirebaseOptions.builder()
                        .setDatabaseUrl(address)
                        .setCredentials(GoogleCredentials.fromStream(resource.getInputStream()))
                        .build();
        final FirebaseApp firebaseApp = FirebaseApp.initializeApp(firebaseOptions);
        log.info("Initializing firebase, object = {}", firebaseApp);

        return FirebaseMessaging.getInstance(firebaseApp);
    }

    @Bean
    public AmazonS3 amazonS3(
            @Value("${amazon.access.key}") String accessKey,
            @Value("${amazon.secret.key}") String secretKey,
            @Value("${s3.region.name}") String s3RegionName
    ) {
        final BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(accessKey, secretKey);
        // Get Amazon S3 client and return the S3 client object
        return AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
                .withRegion(s3RegionName)
                .build();
    }

    @Bean("redisTemplate")
    public RedisTemplate<String, Object> redisTemplate (RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);
        return template;
    }

    @Bean("stringRedisTemplate")
    StringRedisTemplate stringRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
        StringRedisTemplate template = new StringRedisTemplate();
        template.setConnectionFactory(redisConnectionFactory);

        return template;
    }
}
