package in.co.daalchini.data.untransportable;

import in.co.daalchini.data.constants.GeneralConstants.AuthConstants;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;

import java.util.StringJoiner;

@Log4j2
@Getter
public final class JwtAuthenticationToken extends UsernamePasswordAuthenticationToken {
    private static final long serialVersionUID = 162887258583582275L;
    private static final String JWT_PATTERN = "^\\p{Alnum}+\\.\\p{Alnum}+\\.\\p{Print}+$";

    private final String tokenString;

    public JwtAuthenticationToken (String tokenString) {
        super(null, null);
        this.tokenString = tokenString;
    }

    @Override
    public Object getCredentials () {
        return null;
    }

    @Override
    public Object getPrincipal () {
        return null;
    }

    public static String validate (String authHeader) throws AuthenticationException {
        if (authHeader != null && authHeader.startsWith(AuthConstants.TOKEN_PREFIX)) {
            final String tokenString = authHeader.replace(AuthConstants.TOKEN_PREFIX, "");

            if (!tokenString.matches(JWT_PATTERN)) {
                throw new BadCredentialsException("JWToken invalid");
            } else
                return tokenString;
        } else
            throw new BadCredentialsException("JWToken is missing");
    }

    @Override
    public String toString () {
        final String protectedToken = "[PROTECTED]." + tokenString.split("\\.")[1] + ".[PROTECTED]";
        return new StringJoiner(", ", JwtAuthenticationToken.class.getSimpleName() + "[", "]")
            .add("tokenString='" + protectedToken + "'")
            .toString();
    }
}
