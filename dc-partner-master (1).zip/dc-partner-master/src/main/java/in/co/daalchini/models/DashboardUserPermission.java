package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.untransportable.AuthGrantedAuthority;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_user_permissions")
public class DashboardUserPermission {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "permission_name")
    private String permissionName;

    @Column(name = "description")
    private String description;

    @JsonIgnoreProperties({"dashboardUserPermissions"})
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "dashboard_user_role_permission_mapping",
        joinColumns = {@JoinColumn(name = "permission_id")},
        inverseJoinColumns = {@JoinColumn(name = "role_id")})
    private List<DashboardRole> dashboardRoles;

    @JsonIgnore
    @Column(name = "created_at")
    private Timestamp createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    public GrantedAuthority toDto () {
        return AuthGrantedAuthority.of(permissionName);
    }
}
