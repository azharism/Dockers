package in.co.daalchini.data.transporatable.wallet;

import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

import static in.co.daalchini.data.constants.DCConstants.WALLET_SUB_OWNER_PARTNER;

@Data
@Builder
public class DestinationWallet {
    private Long ownerId;
    private @Default String ownerType = OwnerType.User.value();
    private @Default String subOwnerId = WALLET_SUB_OWNER_PARTNER;
    private @Default String type = WalletType.Overdraft.value();
    private @Default String subType = WalletSubType.Normal.value();

    public static DestinationWallet ofTag(Long cardId, String cardUid) {
        return DestinationWallet.builder().ownerId(cardId).subOwnerId("tag." + cardUid).type(WalletType.Prepaid.value()).build();
    }
}
