package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum SystemTxnType {

    DC_TO_USER_CASHBACK_CREDIT("DC_TO_USER_WALLET_CREDIT"), // Withdraw from dc to user
    DC_TO_USER_PREAUTH_TRANSFER("DC_TO_USER_PREAUTH_TRANSFER"),
    DC_TO_USER_REFERRAL_CREDIT("DC_TO_USER_REFERRAL_CREDIT"),
    DC_TO_USER_RELEASE_TRANSFER("DC_TO_USER_RELEASE_TRANSFER"),
    DC_TO_USER__WITHDRAW("DC_TO_USER_WITHDRAW"),
    ORDER_CANCEL("ORDER_CANCEL"),
    ORDER_REFUND("ORDER_REFUND"),
    USER_DC_PASS_BUY("USER_DC_PASS_BUY"),
    USER_DC_PASS_CANCEL("USER_DC_PASS_CANCEL"),
    USER_DC_PASS_STANDING_INSTRUCTION("USER_DC_PASS_STANDING_INSTRUCTION"),
    DC_TO_USER_PASS_REWARD_CREDIT("DC_TO_USER_PASS_REWARD_CREDIT"),
    DC_TO_USER_PASS_REWARD_ROLLBACK("DC_TO_USER_PASS_REWARD_ROLLBACK"),
    ORDER_CAPTURE("ORDER_CAPTURE"),
    USER_CORPORATE_OTP_PAYMENT("USER_CORPORATE_OTP_PAYMENT"),
    USER_QR_PAYTM_PAYMENT("USER_QR_PAYTM_PAYMENT"),
    USER_CORPORATE_OTP_EMAIL_PAYMENT("USER_CORPORATE_OTP_EMAIL_PAYMENT"),
    BHARAT_QR_PAYMENT("BHARAT_QR_PAYMENT"),
    SODEXO_QR_PAYMENT("SODEXO_QR_PAYMENT"),
    PAYTM_UPI_INIT("PAYTM_UPI_INIT"),
    PAYTM_UPI_WEBHOOK("PAYTM_UPI_WEBHOOK"),
    RFID_WALLET_INIT("RFID_WALLET_INIT"),
    PARTNER_WALLET_INIT("PARTNER_WALLET_INIT");

    private final @JsonValue String value;

    SystemTxnType (String value) {
        this.value = value;
    }

    @JsonCreator
    public static SystemTxnType of (String value) {
        return Arrays.stream(SystemTxnType.values())
                     .filter(x -> x.getValue().equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return value;
    }
}
