package in.co.daalchini.DTO;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class SubSubTypeDTO {

	private Integer id;
	
	private Integer typeOfSubTypeId;
	
	private String subSubtypeName;
	
	private String subSubtypeDec;
	
	private String subSubTypeAnswer;
	
	private String field1Name;
	
	private String field2Name;
	
	private String subSubTypeTagId;
	
	
	public String getSubSubTypeTagId() {
		return subSubTypeTagId;
	}

	public void setSubSubTypeTagId(String subSubTypeTagId) {
		this.subSubTypeTagId = subSubTypeTagId;
	}

	private String field1Type;
	
	
	private String field2Type;
	

	public String getField1Type() {
		return field1Type;
	}

	public void setField1Type(String field1Type) {
		this.field1Type = field1Type;
	}

	public String getField2Type() {
		return field2Type;
	}

	public void setField2Type(String field2Type) {
		this.field2Type = field2Type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTypeOfSubTypeId() {
		return typeOfSubTypeId;
	}

	public void setTypeOfSubTypeId(Integer typeOfSubTypeId) {
		this.typeOfSubTypeId = typeOfSubTypeId;
	}

	public String getSubSubtypeName() {
		return subSubtypeName;
	}

	public void setSubSubtypeName(String subSubtypeName) {
		this.subSubtypeName = subSubtypeName;
	}

	public String getSubSubtypeDec() {
		return subSubtypeDec;
	}

	public void setSubSubtypeDec(String subSubtypeDec) {
		this.subSubtypeDec = subSubtypeDec;
	}

	public String getSubSubTypeAnswer() {
		return subSubTypeAnswer;
	}

	public void setSubSubTypeAnswer(String subSubTypeAnswer) {
		this.subSubTypeAnswer = subSubTypeAnswer;
	}

	public String getField1Name() {
		return field1Name;
	}

	public void setField1Name(String field1Name) {
		this.field1Name = field1Name;
	}

	public String getField2Name() {
		return field2Name;
	}

	public void setField2Name(String field2Name) {
		this.field2Name = field2Name;
	}

	@Override
	public String toString() {
		return "SubSubTypeDTO [id=" + id + ", typeOfSubTypeId=" + typeOfSubTypeId + ", subSubtypeName=" + subSubtypeName
				+ ", subSubtypeDec=" + subSubtypeDec + ", subSubTypeAnswer=" + subSubTypeAnswer + ", field1Name="
				+ field1Name + ", field2Name=" + field2Name + "]";
	}
	
	
	
}
