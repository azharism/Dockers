package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Positive;
import java.util.Collection;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineTray implements Comparable<DtoMachineTray> {

    @Positive
    @JsonProperty("level")
    private Long level;

    @JsonProperty("slots")
    private Collection<DtoMachineSlot> slots;

    @Override
    public int compareTo(DtoMachineTray o) {
        return this.level.compareTo(o.getLevel());
    }
}
