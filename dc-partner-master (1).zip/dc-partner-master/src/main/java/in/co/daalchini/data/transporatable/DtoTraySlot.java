package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Positive;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoTraySlot implements Comparable<DtoTraySlot> {

    @Positive
    @JsonProperty("slot_id")
    private Long slotId;

    @Positive
    @JsonProperty("capacity")
    private Long capacity;

    @JsonIgnore
    private boolean active;

    @Override
    public int compareTo(DtoTraySlot o) {
        return this.slotId.compareTo(o.getSlotId());
    }

    public DtoMachineSlot withMvId(Long defaultMvId) {
        return DtoMachineSlot.builder().slotId(slotId).capacity(capacity).active(active).mvId(defaultMvId).build();
    }
}
