package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.StringJoiner;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoAttendanceMachine {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("vendor_machine_type_id")
    private Integer machineTypeId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("type")
    private String machineType;

    @JsonProperty("share_percentage")
    private Integer sharePercentage;

    @JsonProperty("vending_machine_health_details_id")
    private Integer vendingMachineHealthDetailsId;

    @JsonProperty("consumer_app_enable")
    private boolean consumerAppEnabled;

    @JsonProperty("created_by")
    private Long createdBy;

    @JsonProperty("created_at")
    private LocalDateTime createdAt;

    @JsonProperty("updated_at")
    private LocalDateTime updatedAt;

    @JsonProperty("vendingMachineAddress")
    private DtoAttendanceMachineAddress address;


    @Override
    public String toString() {
        return new StringJoiner(", ", DtoAttendanceMachine.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("machineTypeId=" + machineTypeId)
                .add("name='" + name + "'")
                .add("machineType='" + machineType + "'")
                .add("sharePercentage=" + sharePercentage)
                .add("vendingMachineHealthDetailsId=" + vendingMachineHealthDetailsId)
                .add("consumerAppEnabled=" + consumerAppEnabled)
                .add("addressId=" + (null == address ? null : address.getId()))
                .toString();
    }
}
