package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.ComboDetailDto;
import in.co.daalchini.data.transporatable.DtoComboCohort;
import in.co.daalchini.models.Combo;
import in.co.daalchini.models.ComboMvConfig;
import in.co.daalchini.models.MachineCohort;
import org.mapstruct.*;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface ComboMapper {

    @Mapping(target = "id",ignore = true)
    Combo toEntity(ComboDetailDto comboDetailDto);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    Combo toEntityWithUpdate(ComboDetailDto comboDetailDto, @MappingTarget Combo combo);

    @Mapping(target = "id",source = "combo.id")
    @Mapping(target = "mvConfig", source = "comboMvConfigs", qualifiedByName = "mapMvConfig")
    ComboDetailDto toDto(Combo combo, List<ComboMvConfig> comboMvConfigs);

    DtoComboCohort toComboCohortDto(MachineCohort machineCohort);

    List<DtoComboCohort> toComboCohortDto(List<MachineCohort> machineCohorts);

    @Named("mapMvConfig")
    default List<ComboDetailDto.MvConfig> mapMvConfig(List<ComboMvConfig> comboMvConfigs){
        return comboMvConfigs.stream().map(x -> ComboDetailDto.MvConfig.of(x.getMvId(),x.getQuantity(), x.getPrice())).collect(Collectors.toList());
    }
}
