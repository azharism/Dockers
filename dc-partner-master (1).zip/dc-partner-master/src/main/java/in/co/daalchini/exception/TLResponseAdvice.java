package in.co.daalchini.exception;

import in.co.daalchini.data.constants.RouteConstants.MachineContext;
import in.co.daalchini.data.constants.RouteConstants.UserFuelContext;
import in.co.daalchini.data.transporatable.NullResponse;
import in.co.daalchini.data.transporatable.RestResponseCheckIn;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import lombok.NonNull;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import javax.servlet.http.HttpServletResponse;

import static in.co.daalchini.data.constants.RouteConstants.ROOT_V2;

@RestControllerAdvice
@Log4j2
public class TLResponseAdvice implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports (
        @NonNull MethodParameter returnType,
        @NonNull Class<? extends HttpMessageConverter<?>> converterType)
    {
        var parameterType = returnType.getParameterType();
        return
            parameterType != RestResponseV2.class
                && parameterType != String.class;
    }

    @Override
    public Object beforeBodyWrite (
        Object body,
        @NonNull MethodParameter returnType,
        @NonNull MediaType selectedContentType,
        @NonNull Class<? extends HttpMessageConverter<?>> selectedConverterType,
        @NonNull ServerHttpRequest request,
        @NonNull ServerHttpResponse response)
    {
        HttpServletResponse servletResponse = ((ServletServerHttpResponse) response).getServletResponse();
        HttpStatus httpStatus = HttpStatus.valueOf(servletResponse.getStatus());
        if ((body instanceof RestResponse) && httpStatus.is2xxSuccessful()) return body;
        if ((body instanceof RestResponseCheckIn) && httpStatus.is2xxSuccessful()) return body;
        if (body instanceof NullResponse) return RestResponse.ofSuccess(null, ((NullResponse) body).getMessage());

        if (!httpStatus.is2xxSuccessful() && (body instanceof RestResponse)) {
            var path = request.getURI().getPath();
            if (!path.startsWith(ROOT_V2)) return body;

            RestResponse<Object> restResponse = (RestResponse<Object>) body;
            return RestResponseV2.ofFailure(
                HttpStatus.valueOf(restResponse.getCode()).name(), restResponse.getMessage());
        }

        return RestResponse.ofSuccess(body, httpStatus.getReasonPhrase());
    }
}
