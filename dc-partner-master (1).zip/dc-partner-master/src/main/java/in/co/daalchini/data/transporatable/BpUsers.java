package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import java.time.LocalDateTime;
import java.util.List;

public final class BpUsers {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static final class Response{
        private List<BpUserInfo> bpUserInfoList;

    }


    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static final class BpUserInfo{
        private Long ucmId;
        private Long corporateId;
        private String usersCorporateId;
        private String userName;
        private String emailId;
        private boolean status;
        private boolean isUnlinkRequest;
        @JsonIgnore
        private LocalDateTime Expired;
        private String businessName;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static final class UpdateRequest{
        private Long corporateId;
        @Pattern(regexp = "^[a-zA-Z][a-zA-Z ]+[a-zA-Z]$")
        private String userName;
        @Email
        private String email;
        private String businessName;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static final class UpdateResponse {
        private Long ucmId;
        private String userName;
        private String email;
        private boolean isUpdated;
        private String businessName;
    }
}
