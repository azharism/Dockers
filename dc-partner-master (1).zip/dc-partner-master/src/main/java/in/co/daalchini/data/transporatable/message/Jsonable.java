package in.co.daalchini.data.transporatable.message;

public interface Jsonable {

    String json ();

}
