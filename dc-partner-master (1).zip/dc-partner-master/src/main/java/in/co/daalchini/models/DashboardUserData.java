package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_user_data")
public class DashboardUserData {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "password")
    private String password;

    @Column(name = "status")
    private String status;

    @Column(name = "corporate_id")
    private Long corporateId;

    @Column(name = "mmi_device_id")
    private String mmiDeviceId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "corporate_id", insertable = false,updatable = false)
    private CorporateDetails corporateDetails;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private DashboardUser dashboardUser;

}
