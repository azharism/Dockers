package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;
import java.util.StringJoiner;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_user_kit_details")
public class DashboardUserKitDetail {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "dashboard_user_kit_id")
    private DashboardUserKit kit;

    @Column(name = "vending_machine_id")
    private Long vendingMachineId;

    @Column(name = "manufacturer_variant_id")
    private Long manufacturerVariantId;

    @Column(name = "slot_identifier")
    private Long slotIdentifier;

    @Column(name = "item_quantity")
    private Integer itemQuantity;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_id", insertable = false, updatable = false)
    private VendingMachine machine;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manufacturer_variant_id", insertable = false, updatable = false)
    private ManufacturerVariant manufacturerVariant;


    @Override
    public String toString () {
        return new StringJoiner(", ", DashboardUserKitDetail.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("vendingMachineId=" + vendingMachineId)
            .add("slotIdentifier=" + slotIdentifier)
            .add("itemQuantity=" + itemQuantity)
            .toString();
    }
}
