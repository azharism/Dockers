package in.co.daalchini.data.transporatable.wrapper;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RestResponseV2<T> {

    private Status status;
    private T data;

    public static <T> RestResponseV2<T> ofSuccess (T body) {
        return new RestResponseV2<T>(Status.ofSuccess("Success"), body);
    }

    public static <T> RestResponseV2<T> ofSuccess (String message, T body) {
        return new RestResponseV2<T>(Status.ofSuccess(message), body);
    }

    public static <T> RestResponseV2<T> ofFailure (String code, String message) {
        return new RestResponseV2<T>(Status.ofFailure(code, message), null);
    }
}
