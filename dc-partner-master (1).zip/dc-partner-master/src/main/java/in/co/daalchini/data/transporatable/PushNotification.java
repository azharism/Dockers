package in.co.daalchini.data.transporatable;

import com.google.firebase.messaging.FirebaseMessagingException;
import lombok.Builder;
import lombok.Data;

import java.util.List;

public class PushNotification {

    @Data
    @Builder
    public static final class Request {
        private String title;
        private String description;
        private List<String> tokens;
    }

    @Data
    @Builder
    public static final class Response {
        private boolean success;
        private String messageId;
        private FirebaseMessagingException exception;
    }
}
