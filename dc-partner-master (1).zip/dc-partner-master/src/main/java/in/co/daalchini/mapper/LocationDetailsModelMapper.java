package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.models.EntityAttributesModel;
import in.co.daalchini.models.EntityModel;
import in.co.daalchini.models.LocationDetailsModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.List;

@Mapper(
    componentModel = "spring",
    uses = {MachineMapper.class, WarehouseMapper.class}
)
public interface LocationDetailsModelMapper {

    @Mapping(target = "entityAttributesModel", source = "entityAttribute")
    DtoLocationDetail toDto (LocationDetailsModel model);

    DtoAttendanceEntity toDto (EntityModel data);

    List<DtoLocationDetail> toLocationDetails (Collection<LocationDetailsModel> models);
}
