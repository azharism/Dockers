package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;


@Getter
public enum TxnStatus {

    INIT(0, "INIT"),
    SUCCESS(1, "SUCCESS"),
    FAILURE(2, "FAILURE"),
    PENDING(3, "PENDING"),
    REFUNDED_BACK(4, "REFUNDED_BACK"),
    CANCELLED(5, "CANCELLED"),
    INIT_REFUND(6, "INIT_REFUND");


    private final Integer code;
    private final @JsonValue String message;

    TxnStatus (Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    @JsonCreator
    public static TxnStatus of (String status) {
        return Arrays.stream(TxnStatus.values())
                     .filter(x -> x.message.equalsIgnoreCase(status))
                     .findFirst()
                     .orElse(null);
    }

    public static TxnStatus of (short code) {
        return Arrays.stream(TxnStatus.values())
                     .filter(x -> x.code == code)
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return message;
    }
}
