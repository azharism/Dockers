package in.co.daalchini.models;

import in.co.daalchini.data.constants.enums.DevicePlatform;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "partner_devices")
@EntityListeners(AuditingEntityListener.class)
public class PartnerDevice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    private Long id;

    @Column(name = "partner_id")
    private Long partnerId;

    @Column(name = "device_guid")
    private String deviceGuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "platform")
    private DevicePlatform platform;

    @Column(name = "app_version")
    private String appVersion;

    @Column(name = "jti")
    private String jti;

    @Column(name = "fcm_token")
    private String fcmToken;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "remote_logout_notified")
    private boolean remoteLogoutNotified;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToOne(fetch = FetchType.LAZY)
    @ReadOnlyProperty
    @JoinColumn(name = "partner_id", insertable = false, updatable = false)
    private DashboardUser dashboardUser;

    @Override
    public String toString() {
        return new StringJoiner(", ", PartnerDevice.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("partnerId=" + partnerId)
                .add("deviceGuid='" + deviceGuid + "'")
                .add("platform=" + platform)
                .add("appVersion='" + appVersion + "'")
                .add("jti='" + jti + "'")
                .add("remoteLogoutNotified=" + remoteLogoutNotified)
                .toString();
    }
}
