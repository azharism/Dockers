package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum CohortChangeType {
    MachineAdded("machine_added"),
    MachineRemoved("machine_removed"),
    UserAdded("user_added"),
    UserRemoved("user_removed");

    private final @JsonValue String value;

    CohortChangeType (String value) {this.value = value;}

    @JsonCreator(mode = Mode.DELEGATING)
    public static CohortChangeType of (String value) {
        return Arrays.stream(CohortChangeType.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }
}
