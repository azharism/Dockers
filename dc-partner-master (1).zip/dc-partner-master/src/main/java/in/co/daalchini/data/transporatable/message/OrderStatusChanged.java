package in.co.daalchini.data.transporatable.message;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.untransportable.*;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public final class OrderStatusChanged {
    private String orderId;
    private PaymentGatewayType pgType;
    private OrderState orderState;
    private OrderType orderType;
    private UserType userType;
    private OrderSource orderSource;
    private FulfillmentMode fulfillmentMode;
    private VMType VMType;

    public String json () {
        return JsonUtil.toJson(this);
    }

}
