package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoPaymentConfig;
import in.co.daalchini.models.PaymentConfig;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PaymentConfigMapper {

    @Mapping(target = "name", source = "configName")
    DtoPaymentConfig toDto (PaymentConfig config);

    List<DtoPaymentConfig> toDto (List<PaymentConfig> configs);
}
