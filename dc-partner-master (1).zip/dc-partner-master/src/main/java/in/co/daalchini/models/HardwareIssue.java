package in.co.daalchini.models;

import in.co.daalchini.data.constants.enums.HardwareIssueStatus;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

import static in.co.daalchini.data.constants.enums.HardwareIssueStatus.Closed;
import static in.co.daalchini.data.constants.enums.HardwareIssueStatus.Open;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "machine_hardware_issues")
@EntityListeners(AuditingEntityListener.class)
public class HardwareIssue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "machine_id")
    private Long machineId;

    @Column(name = "status")
    private HardwareIssueStatus status;

    @Column(name = "reason_id")
    private Long reasonId;

    @CreatedBy
    @Column(name = "reported_by")
    private Long createdBy;

    @CreatedDate
    @Column(name = "reported_at")
    private LocalDateTime createdAt;

    @Column(name = "resolved_by")
    private Long resolvedBy;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    @ReadOnlyProperty
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reason_id", insertable = false, updatable = false)
    private HardwareIssueReason reason;

    public static HardwareIssue of(Long machineId, Long offReasonId) {
        return HardwareIssue
                .builder()
                .machineId(machineId)
                .status(Open)
                .reasonId(offReasonId)
                .build();
    }

    public HardwareIssue closeIssue(Long userId) {
        this.status = Closed;
        this.resolvedBy = userId;
        this.resolvedAt = DateTimeHelper.now();

        return this;
    }

    public boolean isOn() {
        return !isOff();
    }

    public boolean isOff() {
        return this.getStatus() != null && this.getStatus().isOff();
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", HardwareIssue.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("machineId=" + machineId)
                .add("status=" + status)
                .add("reasonId=" + reasonId)
                .add("createdBy=" + createdBy)
                .add("createdAt=" + createdAt)
                .add("resolvedBy=" + resolvedBy)
                .add("resolvedAt=" + resolvedAt)
                .toString();
    }


}
