package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum RechargeType {

    Full("full"),
    Partial("partial"),
    Monthly("monthly"),
    AddOn("addon");

    private final @JsonValue String value;

    RechargeType(String message) {
        this.value = message;
    }

    @JsonCreator(mode = Mode.DELEGATING)
    public static RechargeType of (String status) {
        return Arrays.stream(RechargeType.values())
                     .filter(x -> x.value.equalsIgnoreCase(status))
                     .findFirst()
                     .orElse(null);
    }
}
