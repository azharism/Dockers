package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.Builder.Default;

import java.util.Collection;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GetKitInvoiceResponse {


    @JsonProperty("invoice_number")
    private String invoiceSerialNumber;

    @JsonProperty("date")
    private String date;

    @JsonProperty("item_details")
    private ItemDetails itemDetails;

    @JsonProperty("tax_details")
    private TaxDetails taxDetails;


    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ItemDetails {

        @JsonProperty("items")
        private List<Item> items;

        @JsonProperty("totals")
        private ItemTotals totals;

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public static class Item {

            @JsonProperty("index")
            private Integer index;

            @JsonProperty("description")
            private String description;

            @JsonProperty("hsn_code")
            private String hsnCode;

            @JsonProperty("quantity")
            private Integer quantity;

            @JsonProperty("mrp")
            private Double mrp;

            @JsonProperty("unit_price")
            private Double unitPrice;

            @JsonProperty("taxable_value")
            private Double taxableValue;

            @JsonProperty("igst_value")
            private Double igstValue;

            @JsonProperty("cgst_value")
            private Double cgstValue;

            @JsonProperty("sgst_value")
            private Double sgstValue;

            @JsonProperty("cess_value")
            private Double cessValue;

            @JsonProperty("item_value")
            private Double itemValue;
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public static class ItemTotals {

            @JsonProperty("quantity")
            private @Default Integer quantity = 0;

            @JsonProperty("item_value")
            private @Default Double itemValue = 0.0;

            @JsonProperty("taxable_value")
            private @Default Double taxableValue = 0.0;

            @JsonProperty("igst_value")
            private @Default Double igstValue = 0.0;

            @JsonProperty("cgst_value")
            private @Default Double cgstValue = 0.0;

            @JsonProperty("sgst_value")
            private @Default Double sgstValue = 0.0;

            @JsonProperty("cess_value")
            private @Default Double cessValue = 0.0;

            public void add (Item item) {
                this.quantity += item.getQuantity();
                this.itemValue += item.getItemValue();
                this.taxableValue += item.getTaxableValue();
                this.igstValue += item.getIgstValue();
                this.cgstValue += item.getCgstValue();
                this.sgstValue += item.getSgstValue();
                this.cessValue += item.getCessValue();
            }
        }
    }


    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TaxDetails {

        @JsonProperty("taxes")
        private Collection<Tax> taxes;

        @JsonProperty("totals")
        private TaxTotals totals;

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public static class Tax {

            @JsonProperty("gst_rate")
            private Double gstRate;

            @JsonProperty("taxable_value")
            private Double taxableValue;

            @JsonProperty("igst_value")
            private Double igstValue;

            @JsonProperty("cgst_value")
            private Double cgstValue;

            @JsonProperty("sgst_value")
            private Double sgstValue;

            @JsonProperty("cess_value")
            private Double cessValue;

            @JsonProperty("total_value")
            private Double totalValue;

            public static Tax sum (Tax a, Tax b) {
                return Tax
                    .builder()
                    .gstRate(a.gstRate)
                    .taxableValue(a.taxableValue + b.taxableValue)
                    .igstValue(a.igstValue + b.igstValue)
                    .cgstValue(a.cgstValue + b.cgstValue)
                    .sgstValue(a.sgstValue + b.sgstValue)
                    .cessValue(a.cessValue + b.cessValue)
                    .totalValue(a.totalValue + b.totalValue)
                    .build();
            }
        }

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public static class TaxTotals {

            @JsonProperty("taxable_value")
            private @Default Double taxableValue = 0.0;

            @JsonProperty("igst_value")
            private @Default Double igstValue = 0.0;

            @JsonProperty("cgst_value")
            private @Default Double cgstValue = 0.0;

            @JsonProperty("sgst_value")
            private @Default Double sgstValue = 0.0;

            @JsonProperty("cess_value")
            private @Default Double cessValue = 0.0;

            @JsonProperty("total_value")
            private @Default Double totalValue = 0.0;

            public void add (Tax tax) {
                this.taxableValue += tax.getTaxableValue();
                this.igstValue += tax.getIgstValue();
                this.cgstValue += tax.getCgstValue();
                this.sgstValue += tax.getSgstValue();
                this.cessValue += tax.getCessValue();
                this.totalValue += tax.getTotalValue();
            }
        }
    }
}
