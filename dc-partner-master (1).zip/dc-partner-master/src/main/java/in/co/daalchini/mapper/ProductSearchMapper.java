package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.ProductSearchDto;
import in.co.daalchini.models.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ProductSearchMapper {
    @Mapping(target = "variantId", source = "id")
    @Mapping(target = "variantName", source = "name")
    @Mapping(target = "productId", source = "product.id")
    @Mapping(target = "productName", source = "product.name")
    @Mapping(target = "BrandId", source = "product.brand.id")
    @Mapping(target = "BrandName", source = "product.brand.name")
    @Mapping(target = "isActive", source = "isActive")
    @Mapping(target = "variantImages",  source = "variantImages")
    ProductSearchDto.VariantResponse toVariantDto(Variant variantList);
    @Mapping(target = "variantId", source = "id")
    @Mapping(target = "variantName", source = "name")
    @Mapping(target = "productId", source = "product.id")
    @Mapping(target = "productName", source = "product.name")
    @Mapping(target = "BrandId", source = "product.brand.id")
    @Mapping(target = "BrandName", source = "product.brand.name")
    @Mapping(target = "isActive", source = "isActive")
    @Mapping(target = "variantImages",  source = "variantImages")
    List<ProductSearchDto.VariantResponse> toVariantDto(List<Variant> variantList);

    @Mapping(target = "productId", source = "id")
    @Mapping(target = "productName", source = "name")
    ProductSearchDto.ProductResponse toProductDto(Product productList);
    @Mapping(target = "productId", source = "id")
    @Mapping(target = "productName", source = "name")
    List<ProductSearchDto.ProductResponse> toProductDto(List<Product> productList);

    @Mapping(target = "BrandId", source = "id")
    @Mapping(target = "BrandName", source = "name")
    ProductSearchDto.BrandResponse toBrandDto(Brand brandList);

    @Mapping(target = "BrandId", source = "id")
    @Mapping(target = "BrandName", source = "name")
    List<ProductSearchDto.BrandResponse>  toBrandDto(List<Brand> brandList);

    @Mapping(target = "manufacturerName", source = "manufacturer.name")
    @Mapping(target = "zohoItemTypeId", source = "skuGroup.zohoItemTypeId")
    @Mapping(target = "purchaseType", source = "skuGroup.zohoItemTypes.type")
    ProductSearchDto.ManufacturerVariant toManufacturerVariantDto(ManufacturerVariant manufacturerVariantList);
    @Mapping(target = "manufacturerName", source = "manufacturer.name")
    @Mapping(target = "zohoItemTypeId", source = "skuGroup.zohoItemTypeId")
    @Mapping(target = "purchaseType", source = "skuGroup.zohoItemTypes.type")
    List<ProductSearchDto.ManufacturerVariant> toManufacturerVariantDto(List<ManufacturerVariant> manufacturerVariantList);

    @Mapping(target = "isActive",constant = "true")
    ManufacturerVariant toManufacturerVariantEntity(ProductSearchDto.ManufacturerVariantRequest request);
    List<ManufacturerVariant> toManufacturerVariantEntity(List<ProductSearchDto.ManufacturerVariantRequest> requestList);

    @Mapping(target = "id", source = "mvId")
    @Mapping(target = "isActive",constant = "true")
    ManufacturerVariant toUpdateManufacturerVariantEntity(ProductSearchDto.UpdateManufacturerVariantRequest request);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "batch",  source = "id")
    @Mapping(target = "manufacturerVariantId", source = "id")
    @Mapping(target = "checkedIn",constant = "1000")
    @Mapping(target = "filled",constant = "1000")
    @Mapping(target = "skuNumber",constant = "1000")
    @Mapping(target = "inTransit",constant = "0")
    @Mapping(target = "sold",constant = "0")
    SkuGroup toSkuGroupEntity(ManufacturerVariant manufacturerVariant);

    @Mapping(target = "active",constant = "true")
    Manufactures toManufacturer(ProductSearchDto.VendorRequest vendorRequest);

    @Mapping(target = "active",constant = "true")
    @Mapping(target = "isBilling",constant = "true")
    @Mapping(target = "isShipping",constant = "true")
    @Mapping(target = "isDefault",constant = "true")
    @Mapping(target = "gstin",source = "gstNumber")
    ManufacturersAddress toManufacturerAddress(ProductSearchDto.VendorRequest vendorRequest);
}
