package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public class SlotBlockDto {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class SlotBlockResponse {

        @JsonProperty("machine_id")
        private Long vendingMachineId;

        @JsonProperty("slot_id")
        private Integer slotIdentifier;

        @JsonProperty("byte_code")
        private String byteCode;

        @JsonProperty("byte_reason")
        private String byteReason;

        @JsonProperty("last_failed_time")
        private LocalDateTime lastFailedTime;

        @JsonProperty("city")
        private String city;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Response {
        @JsonProperty("cities")
        private Collection<String> cities;

        @JsonProperty("blocked_slots")
        private Collection<SlotBlockResponse> slotBlockResponse;
    }


}
