package in.co.daalchini.models;

import lombok.*;
import org.springframework.data.annotation.Immutable;

import javax.persistence.*;
import java.util.StringJoiner;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@Table(name = "machine_available_items")
public class MachineAvailableItem {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "machine_id")
    private Long machineId;

    @Column(name = "mv_id")
    private Long mvId;

    @Column(name = "skg_id")
    private Long skgId;

    @Column(name = "slot_id")
    private Integer slotId;

    @Column(name = "capacity")
    private Long capacity;

    @Column(name = "hold_count")
    private Long holdCount;

    @Column(name = "active_count")
    private Long activeCount;

    @Column(name = "expired_count")
    private Long expiredCount;

    @Column(name = "empty_count")
    private Long emptyCount;

    @Column(name = "is_active")
    private boolean active;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    @Override
    public String toString () {
        return new StringJoiner(", ", MachineAvailableItem.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("machineId=" + machineId)
            .add("mvId=" + mvId)
            .add("skgId=" + skgId)
            .add("slotId=" + slotId)
            .add("capacity=" + capacity)
            .add("holdCount=" + holdCount)
            .add("activeCount=" + activeCount)
            .add("expiredCount=" + expiredCount)
            .add("emptyCount=" + emptyCount)
            .add("active=" + active)
            .toString();
    }
}
