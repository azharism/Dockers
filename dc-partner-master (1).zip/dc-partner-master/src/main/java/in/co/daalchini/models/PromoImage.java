package in.co.daalchini.models;

import in.co.daalchini.data.constants.enums.VmImagePlatform;
import in.co.daalchini.data.constants.enums.VmImageType;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "promo_images")
@EntityListeners(AuditingEntityListener.class)
public class PromoImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "description")
    private String description;

    @Column(name = "image_path")
    private String imagePath;

    @Column(name = "target_url")
    private String targetUrl;

    @Column(name = "activates_at")
    private LocalDateTime activatesAt;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    @Column(name = "type")
    private VmImageType imageType;

    @Column(name = "platform")
    private VmImagePlatform platform;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public boolean isActive() {
        boolean isActivated = true;
        boolean isNotExpired = true;

        if (activatesAt != null) {
            isActivated = DateTimeHelper.nowIsAfter(activatesAt);
        }

        if (expiresAt != null) {
            isNotExpired = DateTimeHelper.nowIsBefore(expiresAt);
        }

        return isActivated && isNotExpired;
    }
}
