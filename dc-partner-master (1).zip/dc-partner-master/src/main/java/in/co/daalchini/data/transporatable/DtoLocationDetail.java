package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.StringJoiner;

@Data
@Builder
public class DtoLocationDetail {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("dashboard_user_id")
    private Integer dashboardUserId;

    @JsonProperty("df_lat")
    private Double dfLat;

    @JsonProperty("df_lng")
    private Double dfLng;

    @JsonProperty("entities_attributes_id")
    private Integer entitiesAttributesId;

    @JsonProperty("entity_lat")
    private Double entityLat;

    @JsonProperty("entity_lng")
    private Double entityLng;

    @JsonProperty("locationCaptureActivityId")
    private Integer locationCaptureActivityId;

    @JsonProperty("condition_value")
    private Integer conditionValue;

    @JsonProperty("flag")
    private Integer flag;

    @JsonProperty("createdAt")
    private String createdAt;

    @JsonProperty("updatedAt")
    private String updatedAt;

    @JsonProperty("location_type")
    private String locationType;

    @JsonProperty("entityAttributesModel")
    private DtoEntityAttribute entityAttributesModel;

    @Override
    public String toString() {
        return new StringJoiner(", ", DtoLocationDetail.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("dashboardUserId=" + dashboardUserId)
                .add("entitiesAttributesId=" + entitiesAttributesId)
                .add("locationCaptureActivityId=" + locationCaptureActivityId)
                .add("conditionValue=" + conditionValue)
                .add("flag=" + flag)
                .add("createdAt='" + createdAt + "'")
                .add("updatedAt='" + updatedAt + "'")
                .add("locationType='" + locationType + "'")
                .toString();
    }
}
