package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.*;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineAddressUpdate {

    @Size(max = 100)
    @NoLeadingAndTrailingSpace
    @JsonProperty("street")
    private String street;

    @Size(max = 50)
    @NoLeadingAndTrailingSpace
    @JsonProperty("city")
    private String city;

    @Size(max = 50)
    @NoLeadingAndTrailingSpace
    @JsonProperty("state")
    private String state;

    @DecimalMin("-90.0")
    @DecimalMax("90.0")
    @Digits(integer = 2, fraction = 8)
    @JsonProperty("latitude")
    private Double latitude;

    @DecimalMin("-180")
    @DecimalMax("180")
    @Digits(integer = 3, fraction = 8)
    @JsonProperty("longitude")
    private Double longitude;

    @Size(max = 200)
    @NoLeadingAndTrailingSpace
    @JsonProperty("image_path")
    private String imagePath;

    @JsonProperty("location_type_id")
    private Long locationTypeId;

    @JsonProperty("location_name")
    private String locationName;
}
