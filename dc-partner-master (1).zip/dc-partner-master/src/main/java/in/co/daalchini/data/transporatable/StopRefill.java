package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

public final class StopRefill {

    @Data
    @Builder
    public static final class Request {
        private Long kitRefillId;
    }
}
