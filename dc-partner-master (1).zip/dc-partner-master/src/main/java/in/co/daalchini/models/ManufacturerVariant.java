package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "manufacturer_variants")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ManufacturerVariant implements Serializable {

    @Serial
    private static final long serialVersionUID = 1843687242238088908L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "mrp")
    private Double mrp;

    @Column(name = "offer_price")
    private Double offerPrice;

    @Column(name = "vendor_price")
    private Double vendorPrice;

    @Column(name = "variant_id")
    private Long variantId;

    @Column(name = "is_Active")
    private Boolean isActive;

    @Column(name = "manufacturer_id")
    private Integer manufacturerId;

    @With
    @Column(name = "zoho_id")
    private String zohoId;

    @JsonIgnore
    @CreationTimestamp
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @ReadOnlyProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "manufacturer_id", insertable = false, updatable = false)
    private Manufactures manufacturer;

    @ReadOnlyProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "variant_id", insertable = false, updatable = false)
    private Variant variant;

    @ReadOnlyProperty
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id", insertable = false, updatable = false)
    private SkuGroup skuGroup;


    public ManufacturerVariant(Long itemId) {
        this.id = itemId;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", ManufacturerVariant.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("mrp=" + mrp)
                .add("variantId=" + variantId)
                .add("manufacturerId=" + manufacturerId)
                .add("isActive=" + isActive)
                .add("createdAt=" + createdAt)
                .add("updatedAt=" + updatedAt)
                .add("zohoId='" + zohoId + "'")
                .toString();
    }
    @PrePersist
    void createTimestamp () {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp () {
        this.updatedAt = DateTimeHelper.now();
    }
}
