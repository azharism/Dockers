package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;


public class PartnerBalance {
    @Data
    @Builder
    public static class Response{
        private final Double balance;
        private final Long userId;
    }
}
