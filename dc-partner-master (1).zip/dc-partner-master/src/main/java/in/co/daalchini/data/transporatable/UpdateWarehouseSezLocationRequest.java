package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.*;

import javax.validation.constraints.Size;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateWarehouseSezLocationRequest {

    @Size(max = 100)
    @NoLeadingAndTrailingSpace
    @JsonProperty("title")
    private String title;

    @Size(max = 45)
    @NoLeadingAndTrailingSpace
    @JsonProperty("gstin")
    private String gstin;

    @Size(max = 500)
    @NoLeadingAndTrailingSpace
    @JsonProperty("address")
    private String address;

    @Size(max = 50)
    @NoLeadingAndTrailingSpace
    @JsonProperty("supply_place")
    private String supplyPlace;

    @Size(max = 10)
    @NoLeadingAndTrailingSpace
    @JsonProperty("state_code")
    private String stateCode;
}
