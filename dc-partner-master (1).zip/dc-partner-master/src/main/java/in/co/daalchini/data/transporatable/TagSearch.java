package in.co.daalchini.data.transporatable;

import lombok.*;


public final class TagSearch {

    @Builder
    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Response {
        private String uid;
        private Boolean active;
    }
}
