package in.co.daalchini.mapper;

import in.co.daalchini.Interfaces.EntityAttributeInterface;
import in.co.daalchini.Interfaces.EntityAttributeManufacturerInterface;
import in.co.daalchini.Interfaces.EntityAttributeWarehouseInterface;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.models.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public interface WarehouseMapper {

    DtoWarehouse toDto (Warehouse warehouse);

    List<DtoWarehouse> toDto (List<Warehouse> warehouses);


    @Mapping(target = "createdAt", source = "created_at")
    @Mapping(target = "updatedAt", source = "updated_at")
    DtoAttendanceEntity toDto (EntityModel data);

    @Mapping(target = "latitude", source = "lat")
    @Mapping(target = "longitude", source = "lng")
    DtoAttendanceMachineAddress toDto (VendingMachineAddress address);

    DtoAttendanceWarehouseAddress toDto (ManufacturersAddress address);

    DtoAttendanceWarehouseAddress toDto (WarehouseAddress address);

    DtoAttendanceWarehouse toAttendanceDto (Warehouse data);

    @Mapping(target = "machineType", source = "machineTypeId")
    DtoAttendanceMachine toDto (VendingMachine machine);

    @Mapping(target = "latitude", source = "warehouseAddress.lat")
    @Mapping(target = "longitude", source = "warehouseAddress.lng")
    DtoFuelWarehouse toDtoFuelWarehouse (Warehouse data);

    @Mapping(target = "fuelRate", source = "fuelRate.rate")
    DtoWarehouseFuelRate toDtoFuelWarehouseRate (Warehouse data);

    @Mapping(target = "fuelRate", source = "rate")
    @Mapping(target = "id", source = "warehouse.id")
    @Mapping(target = "name", source = "warehouse.name")
    DtoWarehouseFuelRate toDtoFuelWarehouseRate (WarehouseFuelRate data);

    @Mapping(target = "latitude", source = "warehouseAddress.lat")
    @Mapping(target = "longitude", source = "warehouseAddress.lng")
    @Mapping(target = "street", source = "warehouseAddress.street")
    DtoTripLocation toDtoTripLocation (Warehouse data);

    @Mapping(target = "latitude", source = "lat")
    @Mapping(target = "longitude", source = "lng")
    @Mapping(target = "id", source = "manufactures.id")
    @Mapping(target = "name", source = "manufactures.name")
    DtoTripLocation toDtoTripLocation (ManufacturersAddress data);

    @Mapping(target = "latitude", source = "address.lat")
    @Mapping(target = "longitude", source = "address.lng")
    @Mapping(target = "street", source = "address.street")
    DtoTripLocation toDtoTripLocation (VendingMachine data);

    DtoAttendanceMachineEntity toDto (EntityAttributeInterface data);

    DtoAttendanceWarehouseEntity toDto (EntityAttributeWarehouseInterface data);

    DtoAttendanceManufacturerEntity toDto (EntityAttributeManufacturerInterface data);

    List<DtoAttendanceMachineEntity> toDtoMachines (List<EntityAttributeInterface> data);

    List<DtoAttendanceWarehouseEntity> toDtoWarehouses (List<EntityAttributeWarehouseInterface> data);

    List<DtoAttendanceManufacturerEntity> toDtoManufacturers (List<EntityAttributeManufacturerInterface> data);

    @Mapping(target = "warehouseId", source = "id")
    @Mapping(target = "warehouseName", source = "name")
    @Mapping(target = "warehouseCity", source = "city")
    ListWarehouse.Response toListWarehouseResponse (Warehouse data);

    List<ListWarehouse.Response> toListWarehouseResponse (List<Warehouse> data);

    List<DtoFuelWarehouse> toDtoFuelWarehouses (List<Warehouse> data);

    Collection<DtoTripLocation> toWarehouseDtoTripLocations (Collection<Warehouse> data);

    Collection<DtoTripLocation> toVendorDtoTripLocations (Collection<ManufacturersAddress> data);

    Collection<DtoTripLocation> toMachineDtoTripLocations (Collection<VendingMachine> data);

    default DtoUserTripLocations toDtoUserTripLocations (
        Collection<Warehouse> warehouses,
        Collection<VendingMachine> machines,
        Collection<ManufacturersAddress> vendors)
    {
        return DtoUserTripLocations
            .builder()
            .warehouses(toWarehouseDtoTripLocations(warehouses))
            .vendors(toVendorDtoTripLocations(vendors))
            .machines(toMachineDtoTripLocations(machines))
            .build();

    }
}
