package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.transporatable.message.Jsonable;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIncludeProperties({"default", "special"})
public class DtoMachineCartLimit implements Jsonable {

    @JsonProperty("default")
    private MachineLimit defaultValue;

    @JsonProperty("special")
    private Set<MachineLimit> specialValues;

    @Override
    public String json() {
        return JsonUtil.toJson(this);
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIncludeProperties({"vm_id", "max_vend_quantity"})
    public static class MachineLimit implements Comparable<MachineLimit> {

        @JsonProperty("vm_id")
        private Long machineId;

        @JsonProperty("max_vend_quantity")
        private Integer cartLimit;

        @Override
        public int compareTo(MachineLimit o) {
            return this.machineId.compareTo(o.machineId);
        }
    }
}
