package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "sez_locations")
@EntityListeners(AuditingEntityListener.class)
public class SezLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "warehouse_id")
    private Long warehouseId;

    @Column(name = "title")
    private String title;

    @Column(name = "gstin")
    private String gstin;

    @Column(name = "street_address")
    private String streetAddress;

    @Column(name = "supply_place")
    private String supplyPlace;

    @Column(name = "state_code")
    private String stateCode;

    @JsonIgnore
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString () {
        return new StringJoiner(", ", SezLocation.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("warehouseId=" + warehouseId)
            .add("title='" + title + "'")
            .add("gstin='" + gstin + "'")
            .add("streetAddress='" + streetAddress + "'")
            .add("supplyPlace='" + supplyPlace + "'")
            .add("stateCode='" + stateCode + "'")
            .toString();
    }
}
