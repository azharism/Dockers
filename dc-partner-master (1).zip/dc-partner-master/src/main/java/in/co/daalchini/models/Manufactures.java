package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder({"id", "name", "phone_number", "email", "created_at", "updated_at"})
@Entity
@Table(name = "manufacturers")
@EntityListeners(AuditingEntityListener.class)
public class Manufactures {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "name")
    private String name;

    @JsonProperty("phone_number")
    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "email")
    private String email;

    @JsonIgnore
    @Column(name = "active")
    private Boolean active;

    @JsonIgnore
    @Column(name = "created_by")
    private Long created_by;

    @JsonProperty("created_at")
    @Column(name = "created_at")
    @CreationTimestamp
    private LocalDateTime createdAt;

    @JsonProperty("updated_at")
    @Column(name = "updated_at")
    @UpdateTimestamp
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "manufactures")
    private Set<ManufacturersAddress> manufacturersAddresses;

    public String getPhoneNumber() {
        return PiiHelper.maskPhone(phoneNumber);
    }

    public String getEmail() {
        return PiiHelper.maskEmail(email);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Manufactures.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("name='" + name + "'")
                .add("phoneNumber='" + getPhoneNumber() + "'")
                .add("email='" + getEmail() + "'")
                .toString();
    }
}
