package in.co.daalchini.models;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "location_details")
@EntityListeners(AuditingEntityListener.class)
public class LocationDetailsModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "dashboard_user_id")
    private Long dashboardUserId;

    @Column(name = "df_lat")
    private Double dfLat;

    @Column(name = "df_lng")
    private Double dfLng;

    @Column(name = "entities_attributes_id")
    private Integer entitiesAttributesId;

    @Column(name = "entity_lat")
    private Double entityLat;

    @Column(name = "entity_lng")
    private Double entityLng;

    @Column(name = "location_capture_activity_id")
    private Integer locationCaptureActivityId;

    @Column(name = "condition_value")
    private Integer conditionValue;

    @Column(name = "flag")
    private Integer flag;

    @ReadOnlyProperty
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "entities_attributes_id", insertable = false, updatable = false)
    private EntityAttributesModel entityAttribute;

    @Transient
    private Integer locationType;

    @Transient
    private EntityAttributesModel entityAttributesModel;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_at")
    private Date createdAt;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated_at")
    private Date updatedAt;

    @JsonCreator
    public LocationDetailsModel (
        @JsonProperty("dashboard_user_id") Long dashboardUserId,
        @JsonProperty("location_type") Integer locationType,
        @JsonProperty("condition_value") Integer conditionValue,
        @JsonProperty("entities_attributes_id") Integer entitiesAttributesId,
        @JsonProperty("entity_lat") Double entityLat,
        @JsonProperty("entity_lng") Double entityLng,
        @JsonProperty("df_lat") Double dfLat,
        @JsonProperty("df_lng") Double dfLng)
    {
        this.dashboardUserId = dashboardUserId;
        this.locationType = locationType;
        this.conditionValue = conditionValue;
        this.entitiesAttributesId = entitiesAttributesId;
        this.entityLat = entityLat;
        this.entityLng = entityLng;
        this.dfLat = dfLat;
        this.dfLng = dfLng;
    }


    @Override
    public String toString() {
        return new StringJoiner(", ", LocationDetailsModel.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("dashboardUserId=" + dashboardUserId)
                .add("entitiesAttributesId=" + entitiesAttributesId)
                .add("locationCaptureActivityId=" + locationCaptureActivityId)
                .add("conditionValue=" + conditionValue)
                .add("flag=" + flag)
                .add("locationType=" + locationType)
                .toString();
    }
}
