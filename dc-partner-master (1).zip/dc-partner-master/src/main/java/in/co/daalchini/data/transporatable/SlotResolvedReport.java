package in.co.daalchini.data.transporatable;


import lombok.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class SlotResolvedReport {
    private Long vmId;
    private Long slotId;
    private Integer failCount;
    private String blockedAt;
    private String resolvedAt;
    private Long resolvedTimeMinutes;

    @Builder
    public SlotResolvedReport(
            Long vmId,
            Long slotId,
            Integer failCount,
            LocalDateTime blockedAt,
            LocalDateTime resolvedAt,
            Long resolvedTimeMinutes
    ) {
        this.vmId = vmId;
        this.slotId = slotId;
        this.failCount = failCount;
        this.blockedAt = DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(blockedAt).concat(" UTC");
        this.resolvedAt = DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(resolvedAt).concat(" UTC");
        this.resolvedTimeMinutes = resolvedTimeMinutes;
    }
}
