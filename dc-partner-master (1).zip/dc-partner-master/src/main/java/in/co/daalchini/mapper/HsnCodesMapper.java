package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.Hsn;
import in.co.daalchini.models.HsnCodes;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface HsnCodesMapper {

    Hsn.CodesResponse toDto(HsnCodes hsnCodes);

    List<Hsn.CodesResponse> toDto(List<HsnCodes> hsnCodes);
}
