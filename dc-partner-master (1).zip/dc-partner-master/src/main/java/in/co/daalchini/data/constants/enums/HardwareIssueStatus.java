package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum HardwareIssueStatus {

    Open("open"),
    Closed("closed");

    private final @JsonValue String value;

    HardwareIssueStatus(String value) {
        this.value = value;
    }

    @JsonCreator(mode = Mode.DELEGATING)
    public static HardwareIssueStatus of(String value) {
        return Arrays.stream(HardwareIssueStatus.values())
                .filter(x -> x.value.equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }

    public boolean isOff() {
        return this.equals(Open);
    }
}
