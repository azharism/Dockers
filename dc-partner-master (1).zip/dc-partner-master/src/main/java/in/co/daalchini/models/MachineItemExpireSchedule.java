package in.co.daalchini.models;

import in.co.daalchini.data.constants.enums.ItemExpiryStatus;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.Instant;
import java.util.StringJoiner;

@Getter
@Setter
@Entity
@Table(name = "machine_item_expire_schedules")
@EntityListeners(AuditingEntityListener.class)
public class MachineItemExpireSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotNull
    @Column(name = "mv_id", nullable = false)
    private Long mvId;

    @NotNull
    @Column(name = "machine_id", nullable = false)
    private Long machineId;

    @Size(max = 250)
    @Column(name = "slot_ids", length = 250)
    private String slotIds;

    @Column(name = "expires_at")
    private Instant expiresAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private ItemExpiryStatus status;

    @Size(max = 200)
    @Column(name = "message", length = 200)
    private String message;

    @CreatedBy
    @Column(name = "requested_by")
    private Long requestedBy;

    @CreatedDate
    @Column(name = "created_at")
    private Instant createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Instant updatedAt;


    public static MachineItemExpireSchedule of(Long mvId, Long machineId, String slotIdStrArr, Instant expireAt) {
        var schedule = new MachineItemExpireSchedule();
        schedule.setMvId(mvId);
        schedule.setMachineId(machineId);
        schedule.setSlotIds(slotIdStrArr);
        schedule.setExpiresAt(expireAt);
        schedule.setStatus(ItemExpiryStatus.scheduled);

        return schedule;
    }


    @Override
    public String toString() {
        return new StringJoiner(", ", MachineItemExpireSchedule.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("mvId=" + mvId)
                .add("machineId=" + machineId)
                .add("slotIds='" + slotIds + "'")
                .add("expiresAt=" + expiresAt)
                .add("status='" + status + "'")
                .add("message='" + message + "'")
                .add("requestedBy=" + requestedBy)
                .add("createdAt=" + createdAt)
                .add("updatedAt=" + updatedAt)
                .toString();
    }
}
