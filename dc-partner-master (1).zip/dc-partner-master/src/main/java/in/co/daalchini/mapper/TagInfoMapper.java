package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.untransportable.RfidCardStatus;
import in.co.daalchini.data.untransportable.RfidCardType;
import in.co.daalchini.models.CorporateDetails;
import in.co.daalchini.models.RfidCard;
import in.co.daalchini.models.RfidCardSeries;
import org.mapstruct.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface TagInfoMapper {

    @Mapping(target = "active", source = "cardStatus.active")
    TagInfo.Response toDto(RfidCard rfidCard);

    TagSearch.Response toSearchDto(RfidCard rfidCard);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "code", source = "code")
    @Mapping(target = "description", source = "description")
    @Mapping(target = "initialBalance", source = "initialBalance")
    CorporateTagSeries.Series toTagSeriesDto(RfidCardSeries series);

    Collection<CorporateTagSeries.Series> toTagSeriesDtos(Collection<RfidCardSeries> series);

    @Mapping(target = "corporateId", source = "corp.id")
    @Mapping(target = "corporateName", source = "corp.name")
    @Mapping(target = "corporateSeries", source = "series")
    CorporateTagSeries.Corporate toTagSeriesDto(CorporateDetails corp, Collection<RfidCardSeries> series);

    default String toString(RfidCardType type) {
        return type.getValue();
    }

    default String toString(RfidCardStatus status) {
        return status.getValue();
    }

    @Mapping(target = "code", source = "code")
    @Mapping(target = "description", source = "description")
    @Mapping(target = "corporateId", source = "corporateId")
    @Mapping(target = "initialBalance", source = "initialBalance")
    @Mapping(target = "active", constant = "true")
    RfidCardSeries toCardSeries(CreateTagSeriesRequest request);

    @Mapping(target = "id", source = "series.id")
    @Mapping(target = "code", source = "series.code")
    @Mapping(target = "description", source = "series.description")
    @Mapping(target = "initialBalance", source = "series.initialBalance")
    @Mapping(target = "corporateId", source = "corporateDetails.id")
    @Mapping(target = "corporateName", source = "corporateDetails.name")
    CorporateTagSeries.CorporateSeriesSummary toCorporateSeriesSummary(RfidCardSeries series, CorporateDetails corporateDetails);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    RfidCardSeries toUpdatedCardSeries(UpdateTagSeriesRequest request, @MappingTarget RfidCardSeries rfidCardSeries);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "uid", source = "uid")
    @Mapping(target = "token", source = "token")
    @Mapping(target = "status", source = "cardStatus")
    CorporateTag.Summary toTagSummary(RfidCard card);

    default List<CorporateTag.Summary> toTagSummaries(List<RfidCard> cards) {
        return cards.stream().map(this::toTagSummary).collect(Collectors.toList());
    }

    @Mapping(target = "id", source = "id")
    @Mapping(target = "uid", source = "uid")
    @Mapping(target = "token", source = "token")
    @Mapping(target = "status", source = "cardStatus")
    @Mapping(target = "balance", source = "cardWallet.wallet.balance")
    CorporateTag.Summary toTagWithBalanceSummary(RfidCard card);

    default List<CorporateTag.Summary> toTagWithBalanceSummaries(List<RfidCard> cards) {
        return cards.stream().map(this::toTagWithBalanceSummary).collect(Collectors.toList());
    }

    @Mapping(target = "seriesId", source = "seriesId")
    @Mapping(target = "uid", source = "request.uid")
    @Mapping(target = "token", source = "request.token")
    @Mapping(target = "cardType", constant = "Corporate")
    @Mapping(target = "cardStatus", constant = "New")
    RfidCard toCard(Long seriesId, CreateTagRequest request);

    @Mapping(target = "id", source = "card.id")
    @Mapping(target = "uid", source = "card.uid")
    @Mapping(target = "token", source = "card.token")
    @Mapping(target = "status", source = "card.cardStatus")
    @Mapping(target = "balance", source = "balance")
    CorporateTag.Summary toTagSummary(RfidCard card, Double balance);

    default List<RfidCard> toCards(Long seriesId, Collection<CreateTagRequest> requests) {
        if (seriesId == null) return null;
        if (requests == null) return null;

        var result = new ArrayList<RfidCard>(requests.size());
        for (CreateTagRequest request : requests) result.add(toCard(seriesId, request));

        return result;
    }
}
