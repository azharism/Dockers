package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SlotUtilizationCount implements Serializable{

	private static final long serialVersionUID = -3160673869840362005L;

	@JsonProperty(value = "vm_id") private int vmId;
	@JsonProperty(value = "vm_name")private String vmName;
	@JsonProperty(value = "filled_count")private int filledSlotsCount;
	@JsonProperty(value = "total_slot_count")private int totalSlotsCount;
	@JsonProperty(value = "slot_utilization")private int percentage;

	
	@Override
	public String toString() {
		return "SlotUtilizationCount [vmId=" + vmId + ", vmName=" + vmName + ", filledSlotsCount=" + filledSlotsCount
				+ ", totalSlotsCount=" + totalSlotsCount + ", percentage=" + percentage + "]";
	}
}
