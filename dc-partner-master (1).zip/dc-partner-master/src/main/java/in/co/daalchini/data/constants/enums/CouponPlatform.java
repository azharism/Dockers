package in.co.daalchini.data.constants.enums;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Objects;
import java.util.stream.Stream;

@Getter
public enum CouponPlatform {
    Kiosk(1),
    Consumer(2),
    KioskAndConsumer(3);

    private final @JsonValue Integer value;

    CouponPlatform (int value) {this.value = value;}

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CouponPlatform of (Integer value) {
        return Stream.of(CouponPlatform.values())
                     .filter(x -> Objects.equals(x.value, value))
                     .findFirst()
                     .orElse(null);
    }
}
