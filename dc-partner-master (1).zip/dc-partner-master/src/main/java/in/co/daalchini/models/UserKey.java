package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity
@Table(name = "user_keys")
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UserKey  {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "name", nullable = false)
    private String name;

    @OneToOne
    @JoinColumn(name = "payment_gateway_id")
    PaymentGateway paymentGateway;

    @Column(name = "access_key", nullable = false)
    private String accessKey;

    @Column(name = "external_id")
    private String externalId;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "user_id", updatable = false, insertable = false)
    private UserDetails userDetails;

    @Column(name = "active", nullable = false)
    private boolean active;

    @JsonIgnore
    @Transient
    private String subOwnerId;

    @Override
    public String toString () {
        return new StringJoiner(", ", UserKey.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("userId=" + userId)
            .add("name='" + name + "'")
            .add("paymentGateway=" + paymentGateway)
            .add("accessKey='" + accessKey + "'")
            .add("externalId='" + externalId + "'")
            .add("expiresAt=" + expiresAt)
            .add("active=" + active)
            .toString();
    }
}
