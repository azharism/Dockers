package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.ZohoVendor;
import in.co.daalchini.models.ZohoItemLookup;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ZohoLookupMapper {

     @Mapping(target = "id", source = "item_id")
     @Mapping(target = "itemName", source = "name")
     @Mapping(target = "mvId", source = "customFields.cf_mfid")
     @Mapping(target = "sku", source = "customFields.cf_mfid")
     @Mapping(target = "warehouseName", source = "customFields.cf_wh_name_items")
     @Mapping(target = "cfItemType", source = "customFields.cf_item_type")
     @Mapping(target = "itemType", source = "itemType")
     ZohoItemLookup toEntity(ZohoVendor.ZohoItem item);

}
