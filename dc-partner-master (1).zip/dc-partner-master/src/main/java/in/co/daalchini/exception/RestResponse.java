package in.co.daalchini.exception;

import lombok.*;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RestResponse<T> {

    private Integer code;
    private Boolean success;
    private Long timestamp;
    private String status;
    private String message;
    private T data;

    public static <T> RestResponse<T> ofSuccess (T body, String message) {
        return new RestResponse<T>(0, true, Instant.now().toEpochMilli(), "Success", message, body);
    }

    public static <T> RestResponse<T> ofFailure (int code, String message) {
        return new RestResponse<T>(code, false, Instant.now().toEpochMilli(), "Failure", message, null);
    }
}
