package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;
import java.util.Collections;
import java.util.Set;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineUpdateRequest {

    @Size(max = 50)
    @NoLeadingAndTrailingSpace
    @JsonProperty("name")
    private String name;

    @JsonProperty("operational_status_id")
    private Integer operationalStatusId;

    @Positive
    @JsonProperty("hardware_type_id")
    private Integer hardwareTypeId;

    @Positive
    @JsonProperty("machine_type_id")
    private Integer machineTypeId;

    @JsonProperty("health_report_enabled")
    private Boolean healthReportEnabled;

    @JsonProperty("consumer_app_enabled")
    private Boolean consumerAppEnabled;

    @Max(100)
    @PositiveOrZero
    @JsonProperty("share_percentage")
    private Integer sharePercentage = 0;

    @Max(10)
    @Positive
    @JsonProperty("cart_limit")
    private Integer cartLimit;

    @Positive
    @JsonProperty("warehouse_id")
    private Long warehouseId;

    @Positive
    @JsonProperty("corporate_id")
    private Long corporateId;

    @NoLeadingAndTrailingSpace
    @JsonProperty("serial_number")
    private String serialNumber;

    @JsonProperty("address")
    private @Valid DtoMachineAddressUpdate address;

    @JsonProperty("added_cohort_ids")
    private Set<@Positive Long> addedCohortIds = Collections.emptySet();

    @JsonProperty("removed_cohort_ids")
    private Set<@Positive Long> removedCohortIds = Collections.emptySet();

    @JsonProperty("added_payment_config_ids")
    private Set<@Positive Long> addedPaymentConfigIds = Collections.emptySet();

    @JsonProperty("removed_payment_config_ids")
    private Set<@Positive Long> removedPaymentConfigIds = Collections.emptySet();

    @JsonProperty("added_slots")
    private Set<DtoMachineSlot> addedSlots = Collections.emptySet();

    @JsonProperty("removed_slot_ids")
    private Set<@Positive Long> removedSlotIds = Collections.emptySet();
}
