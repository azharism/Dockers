package in.co.daalchini.mapper;

import in.co.daalchini.data.untransportable.PaymentStatus;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PaymentStatusMapper {

    default String toValue (PaymentStatus status) {
        if (status == null) return null;
        return status.getValue();
    }
}
