package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.ComboCohortDto;
import in.co.daalchini.models.ComboCohortConfig;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface ComboCohortConfigMapper {

    @Mapping(target = "vmIds", source = "comboCohortDto.vmIds", qualifiedByName = "mapMachineIds")
    @Mapping(target = "isActive", constant = "true")
    @Mapping(target = "cohortId", source = "cohortId")
    ComboCohortConfig toEntity(ComboCohortDto comboCohortDto, Long comboId, Long cohortId);

    @Mapping(target = "vmIds", source = "comboCohortConfig.vmIds", qualifiedByName = "mapMachineIdsToDto")
    ComboCohortDto toDto(ComboCohortConfig comboCohortConfig);

    List<ComboCohortDto> toDto(List<ComboCohortConfig> comboCohortConfig);

    @Named("mapMachineIds")
    default String mapMachineIds(List<Long> machineIds){
        return machineIds != null
                ? machineIds.stream().map(String::valueOf).collect(Collectors.joining(","))
                : null;
    }

    @Named("mapMachineIdsToDto")
    default List<Long> mapMachineIdsToDto(String machineIds){
        return Arrays.stream(machineIds.split(",")).map(Long::valueOf).collect(Collectors.toList());
    }
}
