package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.ComboDetailDto;
import in.co.daalchini.models.ComboMvConfig;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ComboMvConfigMapper {

    ComboMvConfig toEntity(ComboDetailDto.MvConfig mvConfig, Long comboId);


}
