package in.co.daalchini.data.untransportable;

import in.co.daalchini.models.PartnerPermission;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serial;
import java.util.*;
import java.util.stream.Collectors;

@Data
public class AuthUserDetails implements UserDetails {

    @Serial
    private static final long serialVersionUID = -3864983151513702845L;

    private Long userId;
    private String role;
    private List<GrantedAuthority> grantedAuthorities;
    private Set<String> permissions;

    public AuthUserDetails() {
    }

    private AuthUserDetails(
            final Long userId, final String role, final List<GrantedAuthority> grantedAuthorities) {
        this.userId = userId;
        this.role = role;
        this.grantedAuthorities = grantedAuthorities;
        this.permissions = grantedAuthorities.stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toUnmodifiableSet());
    }

    public static AuthUserDetails of(
            final PartnerPermission partnerPermission
    ) {
        if (partnerPermission.getMobileNumber() != null
            && partnerPermission.getRoleId() != null
        ) {
            final var userId = partnerPermission.getUserId();
            final var roleName = partnerPermission.getRoleName();
            final var grantedAuthorities =
                    partnerPermission
                            .getPermissionSet()
                            .stream()
                            .map(AuthGrantedAuthority::of)
                            .collect(Collectors.toList());
            grantedAuthorities.add(AuthGrantedAuthority.of("ROLE_" + roleName));

            return new AuthUserDetails(userId, roleName, grantedAuthorities);
        } else return new AuthUserDetails();
    }

    public static AuthUserDetails of(JwTokenPayload payload) {
        return new AuthUserDetails(payload.getId(),
                payload.getRole(),
                payload.getGrantedAuthorities());
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.grantedAuthorities;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public boolean hasPermission(String permission) {
        return this.permissions.contains(permission);
    }

    public boolean isAdmin() {
        return this.role.equals("ADMIN");
    }

    public boolean isFranchiseMax() {
        return this.role.equals("franchise max");
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", AuthUserDetails.class.getSimpleName() + "[", "]")
                .add("userId=" + userId)
                .add("role='" + role + "'")
                .toString();
    }

    public boolean hasAnyRole(String... roles) {
        return Arrays.stream(roles).anyMatch(r -> r.equals(this.role));
    }
}
