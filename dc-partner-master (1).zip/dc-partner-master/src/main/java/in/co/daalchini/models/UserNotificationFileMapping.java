package in.co.daalchini.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "notification_user_file_mapping")
@NamedQueries({@NamedQuery(
        name = "UserNotificationFileMapping.findOne",
        query = "SELECT k FROM UserNotificationFileMapping k where k.id=:id and k.status = true"
), @NamedQuery(
        name = "UserNotificationFileMapping.findAll",
        query = "SELECT k FROM UserNotificationFileMapping k where k.status = true"
), @NamedQuery(
        name = "UserNotificationFileMapping.findByUserId",
        query = "SELECT k FROM UserNotificationFileMapping k where k.userId = :id and k.status = true"
), @NamedQuery(
        name = "UserNotificationFileMapping.findByUserIdCampaignId",
        query = "SELECT k FROM UserNotificationFileMapping k where k.userId = :id and k.campaignId = :campaignId"
), @NamedQuery(
        name = "UserNotificationFileMapping.findByFileNameAndCampaignId",
        query = "SELECT k FROM UserNotificationFileMapping k where k.fileName = :fileName and k.campaignId = :campaignId"
),@NamedQuery(
        name = "UserNotificationFileMapping.updatebystatus",
        query = "UPDATE UserNotificationFileMapping u Set u.status =:status where u.id = :id"
),@NamedQuery(
        name = "UserNotificationFileMapping.updatebyNotificationResponse",
        query = "UPDATE UserNotificationFileMapping Set notificationResponse =:notificationResponse , notificationStatus =:notificationStatus where id = :id"
)})
public class UserNotificationFileMapping implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "campaign_id")
    private String campaignId;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "user_id")
    private int userId;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @Column(name = "notification_response")
    private String notificationResponse;

    @Column(name = "notification_status")
    private String notificationStatus;

    @Override
    public String toString() {
        return "UserNotificationFileMappingEntity{" +
                "id=" + id +
                ", campaignId='" + campaignId + '\'' +
                ", fileName='" + fileName + '\'' +
                ", campaignId='" + campaignId + '\'' +
                ", status=" + status +
                ", userId=" + userId +
                ", mobileNumber='" + mobileNumber + '\'' +
                ", notificationResponse='" + notificationResponse + '\'' +
                ", notificationStatus='" + notificationStatus + '\'' +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(String campaignId) {
        this.campaignId = campaignId;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getNotificationResponse() {
        return notificationResponse;
    }

    public void setNotificationResponse(String notificationResponse) {
        this.notificationResponse = notificationResponse;
    }

    public String getNotificationStatus() {
        return notificationStatus;
    }

    public void setNotificationStatus(String notificationStatus) {
        this.notificationStatus = notificationStatus;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
