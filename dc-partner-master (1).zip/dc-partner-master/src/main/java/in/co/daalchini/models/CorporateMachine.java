package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "corporate_vm_mappings")
@EntityListeners(AuditingEntityListener.class)
public class CorporateMachine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @With
    @Column(name = "corporate_id")
    private Long corporateId;

    @Column(name = "vending_machine_id", nullable = false)
    private Long machineId;

    @JsonIgnore
    @CreationTimestamp
    @Column(name = "created_timestamp")
    private Instant createdAt;

    @JsonIgnore
    @UpdateTimestamp
    @Column(name = "updated_timestamp")
    private Instant updatedAt;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "corporate_id", insertable = false, updatable = false)
    private CorporateDetails corporateDetails;

    public static CorporateMachine of(Long machineId, Long corporateId) {
        var mapping = new CorporateMachine();
        mapping.setMachineId(machineId);
        mapping.setCorporateId(corporateId);

        return mapping;
    }

    @Override
    public String toString() {
        return JsonUtil.stringifyObject(this);
    }
}
