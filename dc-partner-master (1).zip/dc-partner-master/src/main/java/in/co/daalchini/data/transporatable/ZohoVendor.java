package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
public class ZohoVendor {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Request {

        @JsonProperty("name")
        private String name;

        @JsonProperty("rate")
        private String rate;

        @JsonProperty("account_id")
        private String account_id;

        @JsonProperty("tax_id")
        private String tax_id;

        @JsonProperty("tags")
        private List<Tags> tags;

        @JsonProperty("sku")
        private String sku;

        @JsonProperty("custom_fields")
        private List<CustomField> customFields;

        @JsonProperty("purchase_rate")
        private String purchaseRate;

        @JsonProperty("purchase_account_id")
        private String purchaseAccountId;

        @JsonProperty("item_type")
        private String itemType;

        @JsonProperty("is_taxable")
        private String isTaxable;

        @JsonProperty("product_type")
        private String productType;

        @JsonProperty("hsn_or_sac")
        private String hsnOrSac;

        @JsonProperty("item_tax_preferences")
        private List<ItemTaxPreferences> itemTaxPreferences;

        @JsonProperty("unit")
        private String unit;

        @JsonProperty("taxability_type")
        private String taxabilityType;

    }
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ItemTaxPreferences {

        @JsonProperty("tax_id")
        private String taxId;

        @JsonProperty("tax_specification")
        private String taxSpecification;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Tags {
        private String weight;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CustomField {
        private String value;

        @JsonProperty("customfield_id")
        private String customfieldId;

        public static CustomField of(String zohoCustomFieldId, String value) {
            return CustomField.builder().customfieldId(zohoCustomFieldId).value(value).build();
        }
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Response {
        private Integer code;
        private String message;
        private ZohoItem item;
    }
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Fields {
        @JsonAlias({"cf_wh_name", "cf_wh_name_items" ,"cf_warehouse_name"})
        private String cf_wh_name_items;
        @JsonAlias({"cf_mfid", "cf_mfid_items"})
        private String cf_mfid;
        @JsonAlias({"cf_case_size", "cf_case_size_items"})
        private String cf_case_size;
        private String cf_hsn_sac;
        private String cf_item_type;
        private String cf_brand_id;
    }
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ZohoItem {
        private String item_id;
        private String name;
        @JsonProperty("item_tax_preferences")
        private List<ItemTaxPreferences> itemTaxPreferences;
        @JsonProperty("custom_field_hash")
        private Fields customFields;
        @JsonProperty("item_type")
        private String itemType;


    }
    @Data
    public static final class ResponseToken {
        private String access_token;
        private String scope;
        private String api_domain;
        private String token_type;
        private Integer expires_in;
        private String error;
    }

}


