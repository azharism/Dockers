package in.co.daalchini.data.transporatable.message;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.untransportable.CompletionReason;
import in.co.daalchini.data.untransportable.PaymentGatewayType;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public final class OrderCompletableEvent {

    private PaymentGatewayType paymentGateway;
    private CompletionReason completionReason;
    private String orderId;
    private Double refundAmount;

    public String json () {
        return JsonUtil.toJson(this);
    }
}
