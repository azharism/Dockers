package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoHardwareIssue {

    @JsonProperty("is_off")
    private Boolean isOff;

    @JsonProperty("issue_id")
    private Long issueId;

    @JsonProperty("off_reason_id")
    private Long offReasonId;

    @JsonProperty("off_reason_description")
    private String offReasonDescription;

    public static DtoHardwareIssue ofOn() {
        return DtoHardwareIssue.builder().isOff(false).build();
    }
}
