package in.co.daalchini.messaging;

import in.co.daalchini.data.constants.GeneralConstants.BrokerConfig;
import in.co.daalchini.data.feature.MachineItemDto;
import in.co.daalchini.data.transporatable.message.OrderCompletableEvent;
import in.co.daalchini.data.transporatable.message.PartnerDueEvent;
import in.co.daalchini.data.transporatable.message.ZohoInventorySyncEvent;
import in.co.daalchini.data.transporatable.message.ZohoVendorEvent;
import in.co.daalchini.service.*;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;

import static org.springframework.kafka.support.KafkaHeaders.RECEIVED_TOPIC;

@Log4j2
@Service
public class QueueListener {

    private final PartnerWalletPaymentService partnerWalletPaymentService;
    private final DriverService partnerDueService;
    private final QueuePublisher queuePublisher;
    private final ZohoVendorService zohoVendorService;
    private final ZohoInventorySyncService zohoInventorySyncService;
    private final MachineItemService machineItemService;

    public QueueListener(
            PartnerWalletPaymentService partnerWalletPaymentService,
            DriverService partnerDueService,
            QueuePublisher queuePublisher,
            ZohoVendorService zohoVendorService,
            ZohoInventorySyncService zohoInventorySyncService,
            MachineItemService machineItemService
    ) {
        this.partnerWalletPaymentService = partnerWalletPaymentService;
        this.partnerDueService = partnerDueService;
        this.queuePublisher = queuePublisher;
        this.zohoVendorService = zohoVendorService;
        this.zohoInventorySyncService = zohoInventorySyncService;
        this.machineItemService = machineItemService;
    }

    @JmsListener(
            containerFactory = "jmsQueueListenerContainerFactory",
            destination = BrokerConfig.QUEUE_COMPLETABLE_ORDERS,
            selector = "payment_gateway = 'WALLET_PARTNER'")
    public void queueCompletableOrders(ActiveMQTextMessage message) {
        try {
            final String destination = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();
            log.info("New message on [{}], content = {}", destination, jsonStr);
            final OrderCompletableEvent completableEvent = JsonUtil.fromJson(jsonStr, OrderCompletableEvent.class);

            final String paymentGateway = message.getStringProperty(BrokerConfig.PARAM_PAYMENT_GATEWAY);
            final String completionReason = message.getStringProperty(BrokerConfig.PARAM_COMPLETION_REASON);
            log.debug("paymentGateway = {}, completionReason = {}", paymentGateway, completionReason);

            partnerWalletPaymentService.refundOrder(completableEvent);
        } catch (RuntimeException e) {
            log.error("Error while processing event = ", e);
        } catch (JMSException e) {
            log.error("Caught error = ", e);
        }
    }

    @JmsListener(
            containerFactory = "jmsQueueListenerContainerFactory",
            destination = BrokerConfig.QUEUE_PARTNER_DUE)
    public void receivePartnerDueEvent(ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();

            log.info("New message on [{}], content = {}", topicName, jsonStr);

            final PartnerDueEvent event = JsonUtil.fromJson(jsonStr, PartnerDueEvent.class);

            partnerDueService.processDriverDue(event);
        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @JmsListener(
            containerFactory = "jmsQueueListenerContainerFactory",
            destination = BrokerConfig.QUEUE_ZOHO_CREATE)
    public void zohoVendorCreateEvent(ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();

            log.info("New message on [{}], content = {}", topicName, jsonStr);
            final ZohoVendorEvent event = JsonUtil.fromJson(jsonStr, ZohoVendorEvent.class);
            zohoVendorService.processZohoCreateItem(event);
        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @JmsListener(
            containerFactory = "jmsQueueListenerContainerFactory",
            destination = BrokerConfig.QUEUE_ZOHO_UPDATE)
    public void zohoVendorUpdateEvent(ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();

            log.info("New message on [{}], content = {}", topicName, jsonStr);
            final ZohoVendorEvent event = JsonUtil.fromJson(jsonStr, ZohoVendorEvent.class);
            zohoVendorService.zohoUpdateItem(event);

        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @JmsListener(
            containerFactory = "jmsQueueListenerContainerFactory",
            destination = BrokerConfig.QUEUE_ZOHO_VARIANT_UPDATE)
    public void zohoVendorUpdateVariantEvent(ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();

            log.info("New message on [{}], content = {}", topicName, jsonStr);
            final ZohoVendorEvent event = JsonUtil.fromJson(jsonStr, ZohoVendorEvent.class);
            zohoVendorService.zohoVariant(event);

        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @JmsListener(
            containerFactory = "jmsQueueListenerContainerFactory",
            destination = BrokerConfig.QUEUE_DEREGISTER_BP_USER)
    public void adminUnlinkRequest(ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();

            log.info("New message on [{}], content = {}", topicName, jsonStr);

            final BpDeregisterChangeEvent event = JsonUtil.fromJson(jsonStr, BpDeregisterChangeEvent.class);

            queuePublisher.publishApproveBpUnlinkRequest(event);
        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @JmsListener(
            containerFactory = "jmsQueueListenerContainerFactory",
            destination = BrokerConfig.QUEUE_ZOHO_INVENTORY_SYNC)
    public void zohoInventorySyncEvent(ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();

            log.info("New message on [{}], content = {}", topicName, jsonStr);
            var event = JsonUtil.fromJson(jsonStr, ZohoInventorySyncEvent.class);
            zohoInventorySyncService.updateZohoSync(event);

        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @JmsListener(
            containerFactory = "jmsQueueListenerContainerFactory",
            destination = BrokerConfig.QUEUE_EXPIRE_SCHEDULED_ITEM)
    public void processExpireScheduledItem(ActiveMQTextMessage message) {
        try {
            final String topicName = message.getDestination().getPhysicalName();
            final String jsonStr = message.getText();

            log.info("New message on [{}], content = {}", topicName, jsonStr);

            final var event = JsonUtil.fromJson(jsonStr, MachineItemDto.MvExpireEvent.class);

            machineItemService.processExpireScheduledItem(event);
        } catch (JMSException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @KafkaListener(
            groupId = "group_partner",
            topics = BrokerConfig.QUEUE_ZOHO_CREATE)
    public void zohoVendorCreateEvent(
            @Header(RECEIVED_TOPIC) String topicName,
            @Payload String jsonStr
    ) {
        try {
            log.info("New message on [{}], content = {}", topicName, jsonStr);
            final ZohoVendorEvent event = JsonUtil.fromJson(jsonStr, ZohoVendorEvent.class);
            zohoVendorService.processZohoCreateItem(event);
        } catch (RuntimeException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @KafkaListener(
            groupId = "group_partner",
            topics = BrokerConfig.QUEUE_ZOHO_UPDATE)
    public void zohoVendorUpdateEvent(
            @Header(RECEIVED_TOPIC) String topicName,
            @Payload String jsonStr
    ) {
        try {
            log.info("New message on [{}], content = {}", topicName, jsonStr);
            final ZohoVendorEvent event = JsonUtil.fromJson(jsonStr, ZohoVendorEvent.class);
            zohoVendorService.zohoUpdateItem(event);

        } catch (RuntimeException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @KafkaListener(
            groupId = "group_partner",
            topics = BrokerConfig.QUEUE_ZOHO_VARIANT_UPDATE)
    public void zohoVendorUpdateVariantEvent(
            @Header(RECEIVED_TOPIC) String topicName,
            @Payload String jsonStr
    ) {
        try {
            log.info("New message on [{}], content = {}", topicName, jsonStr);
            final ZohoVendorEvent event = JsonUtil.fromJson(jsonStr, ZohoVendorEvent.class);
            zohoVendorService.zohoVariant(event);

        } catch (RuntimeException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @KafkaListener(
            groupId = "group_partner",
            topics = BrokerConfig.QUEUE_ZOHO_INVENTORY_SYNC)
    public void zohoInventorySyncEvent(
            @Header(RECEIVED_TOPIC) String topicName,
            @Payload String jsonStr
    ) {
        try {
            log.info("New message on [{}], content = {}", topicName, jsonStr);
            var event = JsonUtil.fromJson(jsonStr, ZohoInventorySyncEvent.class);
            zohoInventorySyncService.updateZohoSync(event);

        } catch (RuntimeException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }

    @KafkaListener(
            groupId = "group_partner",
            topics = BrokerConfig.QUEUE_EXPIRE_SCHEDULED_ITEM)
    public void processExpireScheduledItem(
            @Header(RECEIVED_TOPIC) String topicName,
            @Payload String jsonStr
    ) {
        try {
            log.info("New message on [{}], content = {}", topicName, jsonStr);
            var event = JsonUtil.fromJson(jsonStr, MachineItemDto.MvExpireEvent.class);

            machineItemService.processExpireScheduledItem(event);
        } catch (RuntimeException e) {
            log.error("Caught error = {}", e.getMessage());
        }
    }
}

