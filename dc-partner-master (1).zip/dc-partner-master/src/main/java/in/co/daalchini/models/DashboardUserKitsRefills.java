package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;
import java.util.List;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_user_kits_refills")
public class DashboardUserKitsRefills {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "dashboard_user_id")
    private Long dashboardUserId;

    @Column(name = "vending_machine_id")
    private Long vmId;

    @Column(name = "dashboard_user_kit_id")
    private Long dashboardUserKitId;

    @Column(name = "status")
    private String status;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "dashboardUserKitsRefills")
    private List<DashboardUserKitRefillDetails> dashboardUserKitRefillDetailsList;

    @OneToOne
    @JoinColumn(name = "dashboard_user_kit_id", insertable = false, updatable = false)
    private DashboardUserKit kit;

}
