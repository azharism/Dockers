package in.co.daalchini.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import in.co.daalchini.DTO.SubTypeDTO;
import in.co.daalchini.DTO.TicketTypeDto;
import in.co.daalchini.models.SubTypeEntity;
import in.co.daalchini.models.TicketTypeActivityEntity;

@Mapper(componentModel="spring")
public interface SubTypeMapper {
	public SubTypeMapper INSTANCE = Mappers.getMapper(SubTypeMapper.class);
	List<SubTypeDTO> toSubTypeDTOs(List<SubTypeEntity> subTypeEntities);
}
