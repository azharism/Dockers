package in.co.daalchini.data.transporatable;


import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.Collection;
import java.util.StringJoiner;

@Data
@JsonIncludeProperties({"reason", "details"})
public class RechargeTagRequest {

    @NotBlank(message = "reason is required")
    @NoLeadingAndTrailingSpace
    @Size(min = 3, max = 250, message = "reason must be between 3 and 250 characters")
    @JsonProperty("reason")
    private String reason;

    @NotNull(message = "details are required")
    @Size(min = 1, max = 50, message = "request size must be between 1 and 50")
    @JsonProperty("details")
    Collection<@Valid TagRechargeDetail> rechargeDetails;

    @Data
    @JsonIncludeProperties({"uid", "amount"})
    public static class TagRechargeDetail {

        @NotBlank
        @NoLeadingAndTrailingSpace
        @Pattern(regexp = "^[0-9]{10}$", message = "invalid uid")
        @JsonProperty("uid")
        private String uid;

        @NotNull
        @Positive
        @JsonProperty("amount")
        private Double amount;

        @Override
        public String toString() {
            return new StringJoiner(", ", TagRechargeDetail.class.getSimpleName() + "[", "]")
                    .add("uid='" + uid + "'")
                    .add("amount=" + amount)
                    .toString();
        }
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", RechargeTagRequest.class.getSimpleName() + "[", "]")
                .add("reason='" + reason + "'")
                .add("rechargeDetails=" + rechargeDetails)
                .toString();
    }
}
