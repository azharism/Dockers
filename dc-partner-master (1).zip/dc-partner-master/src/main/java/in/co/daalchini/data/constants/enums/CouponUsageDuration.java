package in.co.daalchini.data.constants.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum CouponUsageDuration {

    DAYS("days"),
    WEEKS("weeks"),
    MONTHS("months");

    private final @JsonValue String value;

    CouponUsageDuration(String value){this.value=value;}

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CouponUsageDuration of (String status) {
        return Arrays.stream(CouponUsageDuration.values())
                     .filter(x -> x.value.equalsIgnoreCase(status))
                     .findFirst()
                     .orElse(null);
    }

    @Override
    public String toString () {
        return value;
    }

}
