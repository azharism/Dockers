package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.AddUsers;
import in.co.daalchini.models.UserCorporateMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.ArrayList;
import java.util.Collection;

@Mapper(componentModel = "spring")
public interface UserInfoMapper {


    @Mapping(target = "index", source = "index")
    @Mapping(target = "employeeEmail", source = "employeeEmail")
    @Mapping(target = "employeeId", source = "employeeId")
    AddUsers.UserInfoResponse toResponseDto(AddUsers.UserInfo info);

    @Mapping(target = "index", source = "info.index")
    @Mapping(target = "employeeEmail", source = "info.employeeEmail")
    @Mapping(target = "employeeId", source = "info.employeeId")
    @Mapping(target = "reason", source = "reason")
    AddUsers.UserInfoResponse toResponseDto(AddUsers.UserInfo info, String reason);

    @Mapping(target = "corporateId", source = "corporateId")
    @Mapping(target = "usersCorporateId", source = "info.employeeId")
    @Mapping(target = "emailId", source = "info.employeeEmail")
    @Mapping(target = "userName", source = "info.employeeName")
    @Mapping(target = "business", source = "info.businessName")
    @Mapping(target = "lastFileName", constant = "")
    @Mapping(target = "active", constant = "true")
    UserCorporateMapping toUcm(Long corporateId, AddUsers.UserInfo info);

    default Collection<UserCorporateMapping> toUcmCollection(Long corporateId, Collection<AddUsers.UserInfo> info) {
        Collection<UserCorporateMapping> mappings = new ArrayList<>();
        for (AddUsers.UserInfo userInfo : info) {
            mappings.add(toUcm(corporateId, userInfo));
        }

        return mappings;
    }
}
