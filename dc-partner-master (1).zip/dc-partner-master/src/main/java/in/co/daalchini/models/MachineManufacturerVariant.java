package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vending_machine_manufacturer_variant_mappings")
@EntityListeners(AuditingEntityListener.class)
public class MachineManufacturerVariant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "active_quantity")
    private Integer activeQuantity;

    @Column(name = "hold_quantity")
    private Integer holdQuantity;

    @Column(name = "slot_identifier")
    private Integer slotIdentifier;

    @Column(name = "slot_capacity")
    private Long slotCapacity;

    @Column(name = "manufacturer_variant_id")
    private Long manufacturerVariantId;

    @Column(name = "vending_machine_id")
    private Long vendingMachineId;

    @ManyToOne
    @JoinColumn(name = "vending_machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "manufacturer_variant_id", insertable = false, updatable = false)
    private ManufacturerVariant manufacturerVariant;

    @JsonIgnoreProperties({"vendingMachineManufacturerVariantMapping"})
    @OneToOne(mappedBy = "machineManufacturerVariant")
    private MachineManufacturerVariantSkuGroup machineManufacturerVariantSkuGroup;

    @JsonIgnore
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString () {
        return new StringJoiner(", ", MachineManufacturerVariant.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("activeQuantity=" + activeQuantity)
            .add("holdQuantity=" + holdQuantity)
            .add("slotIdentifier='" + slotIdentifier + "'")
            .toString();
    }
}
