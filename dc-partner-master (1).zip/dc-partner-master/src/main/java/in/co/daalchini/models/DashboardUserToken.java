package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.data.untransportable.TokenType;
import in.co.daalchini.repository.converter.TokenTypeConverter;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_user_tokens")
public class DashboardUserToken {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Basic
    @Column(name = "access_token")
    private String accessToken;

    @Convert(converter = TokenTypeConverter.class)
    @Column(name = "type")
    private TokenType type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pg_id")
    private PaymentGateway paymentGateway;

    @Column(name = "active")
    private Boolean active;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @JsonIgnoreProperties({"dashboardUserToken"})
    @ManyToOne
    @JoinColumn(name = "user_id")
    private DashboardUser dashboardUser;

    public static DashboardUserToken of (
        final DashboardUser user,
        final TokenType tokenType,
        final String accessToken)
    {
        final DashboardUserToken token = new DashboardUserToken();
        LocalDateTime currentDateTime = DateTimeHelper.now();
        token.setDashboardUser(user);
        token.setType(tokenType);
        token.setAccessToken(accessToken);
        token.setCreatedAt(currentDateTime);
        token.setUpdatedAt(currentDateTime);
        token.setActive(true);

        return token;
    }

    public static DashboardUserToken of (
        DashboardUser dashboardUser,
        TokenType tokenType,
        String accessToken,
        PaymentGateway paymentGateway)
    {
        final DashboardUserToken token = new DashboardUserToken();
        LocalDateTime currentDateTime = DateTimeHelper.now();
        token.setDashboardUser(dashboardUser);
        token.setType(tokenType);
        token.setAccessToken(accessToken);
        token.setPaymentGateway(paymentGateway);
        token.setActive(true);
        token.setCreatedAt(currentDateTime);
        token.setUpdatedAt(currentDateTime);

        return token;
    }

    public DashboardUserToken putToken (String accessToken) {
        this.setAccessToken(accessToken);
        this.setUpdatedAt(DateTimeHelper.now());
        return this;
    }

    @Override
    public String toString () {
        final String userId = dashboardUser != null ? String.valueOf(dashboardUser.getId()) : "";
        return new StringJoiner(", ", DashboardUserToken.class.getSimpleName() + "[", "]")
            .add("id=" + this.id)
            .add("accessToken='" + accessToken + "'")
            .add("type=" + type)
            .add("dashboardUser=" + userId)
            .toString();
    }
}

