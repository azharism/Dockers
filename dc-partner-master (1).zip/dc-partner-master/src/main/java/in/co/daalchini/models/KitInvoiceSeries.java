package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.StringJoiner;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@DynamicUpdate
@Table(name = "kit_invoice_series")
@EntityListeners(AuditingEntityListener.class)
public class KitInvoiceSeries {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "warehouse_id")
    private Long warehouseId;

    @Column(name = "prefix")
    private String prefix;

    @Column(name = "invoice_count")
    private Integer invoiceCount;

    @JsonIgnore
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public String generateNextInvoiceSerialNumber () {
        var tf = DateTimeFormatter.ofPattern("yy");
        var nowIst = DateTimeHelper.nowIst();
        return String.format("%s/%s-%s/%04d",
                             prefix,
                             tf.format(nowIst.minusMonths(3)),
                             tf.format(nowIst.plusMonths(9)),
                             ++invoiceCount);
    }

    @Override
    public String toString () {
        return new StringJoiner(", ", KitInvoiceSeries.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("warehouseId=" + warehouseId)
            .add("prefix='" + prefix + "'")
            .add("invoiceCount=" + invoiceCount)
            .toString();
    }
}
