package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.StringJoiner;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "partner_order_pickup")
public class PartnerOrderPickup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "time_begin")
    private LocalTime timeBegin;

    @Column(name = "time_end")
    private LocalTime timeEnd;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @JsonIgnore
    @Column(name = "date_time_end", insertable = false, updatable = false)
    private LocalDateTime dateTimeEnd;

    public PartnerOrderPickup (Long id) {
        this.id = id;
    }

    public static PartnerOrderPickup of (Long id) {
        return new PartnerOrderPickup(id);
    }

    @PrePersist
    void createTimestamp () {
        final LocalDateTime currentTimestamp = DateTimeHelper.now();
        this.createdAt = currentTimestamp;
        this.updatedAt = currentTimestamp;
    }

    @PreUpdate
    void updateTimestamp () {
        this.updatedAt = DateTimeHelper.now();
    }

    @Override
    public String toString () {
        return new StringJoiner(", ", PartnerOrderPickup.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("date=" + date)
            .add("timeBegin=" + timeBegin)
            .add("timeEnd=" + timeEnd)
            .add("createdAt=" + createdAt)
            .add("updatedAt=" + updatedAt)
            .toString();
    }
}
