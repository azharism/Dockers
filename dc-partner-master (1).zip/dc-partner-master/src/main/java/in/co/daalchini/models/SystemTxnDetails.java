package in.co.daalchini.models;

import in.co.daalchini.data.untransportable.PaymentGatewayType;
import in.co.daalchini.data.untransportable.SystemTxnType;
import in.co.daalchini.data.untransportable.TxnStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "system_txn_details")
public class SystemTxnDetails {

    @Basic(optional = false)
    @Column(name = "id", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payee_id")
    private Long payeeId;

    @Column(name = "payer_id")
    private Long payerId;

    @Column(name = "refund_id")
    private Long refundId;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "txn_amount")
    private Double txnAmount;

    @Column(name = "txn_status")
    private TxnStatus txnStatus;

    @Column(name = "txn_message")
    private String txnMessage;

    @Column(name = "txn_type")
    private SystemTxnType txnType;

    @Column(name = "payment_txn_id")
    private String paymentTxnId;

    @Column(name = "parent_txn_id")
    private Long parentTxnId;

    @Column(name = "payment_gateway_id")
    private PaymentGatewayType pgType;

    @Column(name = "payment_config_id")
    private Long paymentConfigId;

    @Column(name = "message")
    private String message;

    @Override
    public String toString () {
        return new StringJoiner(", ", SystemTxnDetails.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("payeeId=" + payeeId)
            .add("payerId=" + payerId)
            .add("refundId=" + refundId)
            .add("orderId='" + orderId + "'")
            .add("txnAmount=" + txnAmount)
            .add("txnStatus=" + txnStatus)
            .add("txnMessage='" + txnMessage + "'")
            .add("txnType=" + txnType)
            .add("paymentTxnId='" + paymentTxnId + "'")
            .add("parentTxnId=" + parentTxnId)
            .add("pgType=" + pgType)
            .add("paymentConfigId=" + paymentConfigId)
            .add("message='" + message + "'")
            .toString();
    }
}
