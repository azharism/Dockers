package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

@Getter
public enum TagStatus {

    New("new"),
    Issued("issued"),
    Active("active"),
    Inactive("inactive");

    private final @JsonValue String value;

    TagStatus (String value) {
        this.value = value;
    }

    @JsonCreator
    public static TagStatus of (String value) {
        return Stream.of(TagStatus.values())
                     .filter(x -> x.value.equalsIgnoreCase(value))
                     .findFirst()
                     .orElse(null);
    }
}
