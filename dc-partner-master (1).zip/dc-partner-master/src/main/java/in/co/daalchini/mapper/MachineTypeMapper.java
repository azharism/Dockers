package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoMachineType;
import in.co.daalchini.models.MachineType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface MachineTypeMapper {

    @Mapping(target = "name", source = "type")
    DtoMachineType toDto (MachineType type);

    List<DtoMachineType> toDto (List<MachineType> types);
}
