package in.co.daalchini.data.transporatable;

import lombok.*;


public final class Ping {

    @Builder
    @Getter
    @ToString
    @EqualsAndHashCode
    @RequiredArgsConstructor
    public static final class Response {
        private final Long timestamp;

        public static Response of (Long timestamp) {
            return new Response(timestamp);
        }
    }
}
