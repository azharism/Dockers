package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.models.OrderLineItem;
import in.co.daalchini.service.helper.JsonUtil;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.TreeMap;


public final class OrderComplete {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Request {

        @JsonProperty("orderId")
        private String orderId;

        @JsonProperty("pin")
        private String pin;

        @JsonProperty("vendingMachineId")
        private Long vendingMachineId;

        @JsonProperty("mobileNo")
        private String mobileNo;

        @JsonProperty("orderLineItems")
        private List<LineItem> orderLineItems;

        public Map<String, String> dataMap() {
            Map<String, String> dataMap = new TreeMap<>();
            dataMap.put("orderId", orderId);
            dataMap.put("pin", pin);
            dataMap.put("vendingMachineId", String.valueOf(vendingMachineId));
            dataMap.put("mobileNo", mobileNo);
            dataMap.put("body", JsonUtil.toJson(this));

            return dataMap;
        }

        @Override
        public String toString() {
            return new StringJoiner(", ", Request.class.getSimpleName() + "[", "]")
                    .add("orderId='" + orderId + "'")
                    .add("pin='" + pin + "'")
                    .add("vendingMachineId=" + vendingMachineId)
                    .add("mobileNo='" + PiiHelper.maskPhone(mobileNo) + "'")
                    .add("orderLineItems=" + orderLineItems)
                    .toString();
        }
    }

    @Data
    public static final class Response {
        private String orderId;
    }

    @Data
    public static final class LineItem {

        @JsonProperty("id")
        private Long id;

        @JsonProperty("skuGroupId")
        private Long skuGroupId;

        @JsonProperty("manufacturerVariantId")
        private Long manufacturerVariantId;

        @JsonProperty("slotIdentifier")
        private Long slotIdentifier;

        @JsonProperty("name")
        private String name;

        @JsonProperty("amount")
        private Double amount;

        @JsonProperty("quantity")
        private Long quantity;

        @JsonProperty("successCount")
        private Integer successCount;

        @JsonProperty("failureCount")
        private Integer failureCount;

        public LineItem(
                Long id,
                Long skuGroupId,
                Long manufacturerVariantId,
                Long slotIdentifier,
                String name,
                Double amount,
                Long quantity
        ) {
            this.id = id;
            this.skuGroupId = skuGroupId;
            this.manufacturerVariantId = manufacturerVariantId;
            this.slotIdentifier = slotIdentifier;
            this.name = name;
            this.amount = amount;
            this.quantity = quantity;
        }


        public static LineItem of(OrderLineItem item) {
            return new LineItem(
                    item.getId(),
                    item.getSkuGroupId(),
                    item.getManufacturerVariantId(),
                    item.getSlotIdentifier(),
                    item.getName(),
                    item.getOfferPrice(),
                    item.getItemQuantity());
        }
    }

}
