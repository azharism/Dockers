package in.co.daalchini.controller;

import in.co.daalchini.Interfaces.EntityAttributeInterface;
import in.co.daalchini.Interfaces.EntityAttributeManufacturerInterface;
import in.co.daalchini.Interfaces.EntityAttributeWarehouseInterface;
import in.co.daalchini.data.constants.RouteConstants.AttendanceContext;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.exception.BusinessException;
import in.co.daalchini.exception.ItemNotFoundException;
import in.co.daalchini.exception.RestResponse;
import in.co.daalchini.mapper.DashboardUserLastCheckInDetailsModelMapper;
import in.co.daalchini.mapper.LocationDetailsModelMapper;
import in.co.daalchini.mapper.WarehouseMapper;
import in.co.daalchini.models.*;
import in.co.daalchini.repository.*;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@RestController
@RequestMapping(AttendanceContext.BASE)
public class WareHouseController {

    private final WarehouseRepository warehouseRepository;
    private final ManufacturerRepository manufacturerRepository;
    private final VendingMachineRepository vendingMachineRepository;
    private final EntityAttributesRepository entityAttributeRepository;
    private final LocationDetailsRepository locationDetailRepository;
    private final LocationCaptureActivityRepository locationCaptureActivityRepository;
    private final DashboardUserLastCheckInRepository dashboardLastUserCheckInRepository;
    private final LocationDetailPagingRepository LocationDetailPagingRepository;
    private final WarehouseMapper warehouseMapper;
    private final PartnerTimesheetRepository partnerTimesheetRepository;
    private final DashboardUserWarehouseMappingRepository dashboardUserWarehouseMappingRepository;
    private final DashboardUserLastCheckInDetailsModelMapper lastCheckInDetailsModelMapper;
    private final LocationDetailsModelMapper locationDetailsModelMapper;


    public WareHouseController(
            WarehouseRepository warehouseRepository,
            ManufacturerRepository manufacturerRepository,
            VendingMachineRepository vendingMachineRepository,
            EntityAttributesRepository entityAttributeRepository,
            LocationDetailsRepository locationDetailRepository,
            LocationCaptureActivityRepository locationCaptureActivityRepository,
            DashboardUserLastCheckInRepository dashboardLastUserCheckInRepository,
            LocationDetailPagingRepository LocationDetailPagingRepository,
            WarehouseMapper warehouseMapper,
            PartnerTimesheetRepository partnerTimesheetRepository,
            DashboardUserWarehouseMappingRepository dashboardUserWarehouseMappingRepository,
            DashboardUserLastCheckInDetailsModelMapper lastCheckInDetailsModelMapper,
            LocationDetailsModelMapper locationDetailsModelMapper
    ) {
        this.warehouseRepository = warehouseRepository;
        this.manufacturerRepository = manufacturerRepository;
        this.vendingMachineRepository = vendingMachineRepository;
        this.entityAttributeRepository = entityAttributeRepository;
        this.locationDetailRepository = locationDetailRepository;
        this.locationCaptureActivityRepository = locationCaptureActivityRepository;
        this.dashboardLastUserCheckInRepository = dashboardLastUserCheckInRepository;
        this.LocationDetailPagingRepository = LocationDetailPagingRepository;
        this.warehouseMapper = warehouseMapper;
        this.partnerTimesheetRepository = partnerTimesheetRepository;
        this.dashboardUserWarehouseMappingRepository = dashboardUserWarehouseMappingRepository;
        this.lastCheckInDetailsModelMapper = lastCheckInDetailsModelMapper;
        this.locationDetailsModelMapper = locationDetailsModelMapper;
    }


    @GetMapping("/warehouse/{radius}/{lat}/{lng}")
    public List<DtoAttendanceWarehouseEntity> getAllWarehousesByCoordinates(
            @PathVariable("radius") int radius,
            @PathVariable("lat") Double lat,
            @PathVariable("lng") Double lng) {
        if (lat == null || lng == null || radius <= 0) throw new ItemNotFoundException("Invalid details");

        try {
            List<Warehouse> warehouseList = warehouseRepository.findByCoordinatesAndRadius(lat, lng, radius * 1_000);
            if (warehouseList.isEmpty()) throw new ItemNotFoundException("No warehouse found near to you ");

            List<EntityAttributeWarehouseInterface> entityAttributesList =
                    entityAttributeRepository.findByWarehouseIdIn(warehouseList);

            if (entityAttributesList.isEmpty()) throw new ItemNotFoundException("No warehouse found near to you ");

            return warehouseMapper.toDtoWarehouses(entityAttributesList);
        } catch (Exception e) {
            log.error("getAllWarehousesByCoordinates error = ", e);
            throw e;
        }
    }


    @GetMapping("/manufactures/{radius}/{lat}/{lng}")
    public List<DtoAttendanceManufacturerEntity> getAllManufacturesByCoordinates(
            @PathVariable("radius") int radius,
            @PathVariable("lat") Double lat,
            @PathVariable("lng") Double lng) {
        if (lat == null || lng == null || radius <= 0) throw new ItemNotFoundException("Invalid details");

        try {
            List<Manufactures> manufacturerList =
                    manufacturerRepository.findByCoordinatesAndRadius(lat, lng, radius * 1_000);

            List<EntityAttributeManufacturerInterface> entityAttributesList =
                    entityAttributeRepository.findByManufacturerIdIn(manufacturerList);
            if (entityAttributesList.isEmpty()) throw new ItemNotFoundException("No manufacturer found near to you ");

            return warehouseMapper.toDtoManufacturers(entityAttributesList);
        } catch (Exception e) {
            log.error("getAllManufacturesByCoordinates error = ", e);
            throw e;
        }
    }


    @GetMapping("/vendingmachine/{radius}/{lat}/{lng}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<DtoAttendanceMachineEntity>> getAllVendingMachinesByCoordinates(
            @PathVariable("radius") int radius,
            @PathVariable("lat") Double lat,
            @PathVariable("lng") Double lng) {
        if (lat == null || lng == null || radius <= 0) throw new ItemNotFoundException("Invalid details");

        try {
            List<VendingMachine> vendingMachineList =
                    vendingMachineRepository.findByCoordinatesAndRadius(lat, lng, radius * 1_000);

            List<EntityAttributeInterface> entityAttributesList =
                    entityAttributeRepository.findByVendingMachineIdIn(vendingMachineList);

            if (entityAttributesList.isEmpty())
                throw new ItemNotFoundException("No vending machine found near to you ");

            return ResponseEntity.accepted().body(warehouseMapper.toDtoMachines(entityAttributesList));
        } catch (Exception e) {
            log.error("getAllVendingMachinesByCoordinates error = ", e);
            throw e;
        }
    }

    @GetMapping("/user/last-checkin/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<RestResponseCheckIn<DtoLastCheckInEntity>> getUserLastCheckinStatus(
            @PathVariable("id") Long dashboardId) {
        try {
            var checkInDetailsModel = dashboardLastUserCheckInRepository.findByDashboardUserId(dashboardId);
            if (checkInDetailsModel == null) throw new ItemNotFoundException("User not found");

            var data = checkInDetailsModel.getFlag() == 1;
            var payload = lastCheckInDetailsModelMapper.toDto(checkInDetailsModel);
            var responseBody = RestResponseCheckIn.ofSuccess(HttpStatus.OK, data, payload);

            return ResponseEntity.ok(responseBody);
        } catch (Exception e) {
            log.error("[getUserLastCheckinStatus] error : ", e);
            throw e;
        }
    }

    @GetMapping("/user/activities/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<DtoLocationDetail>> getUserActivities(
            @PathVariable("id") Long dashboardId) {
        try {
            var lastCheckInDetail =
                    dashboardLastUserCheckInRepository.findByDashboardUserIdWithLocationDetail(dashboardId);

            log.debug("[getUserActivities] lastCheckInDetail = {}", lastCheckInDetail);

            if (lastCheckInDetail == null)
                throw new ItemNotFoundException("User not found");

            if (lastCheckInDetail.getFlag() != 1)
                throw new ItemNotFoundException("User is not checked in anywhere");

            var locationDetailsModelList =
                    locationDetailRepository.findByDashboard_user_idAndCreatedAt(
                            dashboardId, lastCheckInDetail.getLocationDetail().getCreatedAt());
            log.debug("[getUserActivities] locationDetailsModelList = {}", locationDetailsModelList);

            var response = locationDetailsModelMapper.toLocationDetails(locationDetailsModelList);
            log.debug("[getUserActivities] response = {}", response);

            return ResponseEntity.accepted().body(response);
        } catch (Exception e) {
            log.error("[getUserActivities] error:", e);
            throw e;
        }
    }


    @GetMapping("/user/activities-all/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<LocationDetailsModel>> getUserActivitiesAll(@PathVariable("id") int dashboardId)
            throws Exception {
        try {
            //DashboardUserLastCheckInDetailsModel dashboardUserLastCheckInDetailsModel= dashboardLastUserCheckInRepository.findByDashboardUserId(dashboardId);
            List<LocationDetailsModel> locationDetailsModelList = new ArrayList<>();
            List<EntityAttributeInterface> entityAttributesList = new ArrayList();

            //if(dashboardUserLastCheckInDetailsModel.getFlag() ==1) {

            //int locatioDetailsPrimaryID = dashboardUserLastCheckInDetailsModel.getLocation_details_id();
            //Date created_at = locationDetailRepository.findById(locatioDetailsPrimaryID).get().getCreatedAt();


            //Date updated_at = dashboardUserLastCheckInDetailsModel.getUpdatedAt();
            //log.debug("updated_at#############"+created_at);
            locationDetailsModelList = locationDetailRepository.findByDashboard_user_id(dashboardId);

            for (int i = 0; i < locationDetailsModelList.size(); i++) {
                log.debug(
                        "locationDetailsModelList.get(i).getEntitiesAttributesId()()#############" + locationDetailsModelList
                                .get(i)
                                .getEntitiesAttributesId());
                Integer id = locationDetailsModelList.get(i).getEntitiesAttributesId();
                log.debug(
                        "locationDetailsModelList.get(i).getEntitiesAttributesId()()#############" + id);
                log.debug(
                        "locationDetailsModelList.get(i).getEntitiesAttributesId()()#############" + entityAttributeRepository
                                .findById(id));

                Optional<EntityAttributesModel> optinalEntity = entityAttributeRepository.findById(
                        id);
                EntityAttributesModel entityAttributesModel = optinalEntity.get();
                locationDetailsModelList.get(i).setEntityAttributesModel(entityAttributesModel);

            }


            log.debug("locationDetailsModelList###########" + locationDetailsModelList.size());


            return ResponseEntity.accepted().body(locationDetailsModelList);
        } catch (Exception e) {
            log.error("error : " + e.getMessage());
            throw e;
        }
    }


    @GetMapping("/user/activities-all/{id}/page={page}/limit={limit}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<LocationDetailsModel>> getUserActivitiesTest(
            @PathVariable("id") Long dashboardId,
            @PathVariable("page") int index,
            @PathVariable("limit") int limit)
            throws Exception {
        try {

            List<LocationDetailsModel> locationDetailsModelList = new ArrayList<>();
            List<EntityAttributeInterface> entityAttributesList = new ArrayList();
            Pageable pageable = PageRequest.of(index, limit);
            Page<LocationDetailsModel> page = LocationDetailPagingRepository.findByDashboard_user_id(
                    dashboardId,
                    pageable);
            locationDetailsModelList = page.getContent();

            for (int i = 0; i < locationDetailsModelList.size(); i++) {

                Integer id = locationDetailsModelList.get(i).getEntitiesAttributesId();
                Optional<EntityAttributesModel> optinalEntity = entityAttributeRepository.findById(
                        id);
                EntityAttributesModel entityAttributesModel = optinalEntity.get();
                locationDetailsModelList.get(i).setEntityAttributesModel(entityAttributesModel);

            }

            return ResponseEntity.accepted().body(locationDetailsModelList);
        } catch (Exception e) {
            log.error("error : " + e.getMessage());
            throw e;
        }
    }


    @PostMapping("/location-details")
    public ResponseEntity<RestResponse> createStudent(@RequestBody LocationDetailsModel location)
            throws Exception {
        try {
            log.debug("request location = {}", location);
            Integer LocationType = location.getLocationType();
            var locationCaptureData = locationCaptureActivityRepository
                    .findByLocationType(LocationType);

            location.setLocationCaptureActivityId(locationCaptureData.getId());
            var dfLat = location.getDfLat();
            var dfLng = location.getDfLng();
            var entityLat = location.getEntityLat();
            var entityLng = location.getEntityLng();
            var distance = distance(dfLat, dfLng, entityLat, entityLng);

            Integer entitiesAttributesId = location.getEntitiesAttributesId();
            if (distance < location.getConditionValue()) {
                location.setFlag(1);
            } else {
                location.setFlag(0);
                if (locationCaptureData.getIs_location_bound()) {
                    throw new ItemNotFoundException(
                            "you are not allowed because you are not in range to desired location");
                }
            }
            var savedLocation = locationDetailRepository.save(location);

            if (LocationType.equals(1) || LocationType.equals(2)) {
                int flag = LocationType.equals(1) ? 1 : 0;
                updatePartnerTimesheet(flag, location.getDashboardUserId(), entitiesAttributesId);

                DashboardUserLastCheckInDetailsModel dashboardUserLastCheckInDetailsModel = dashboardLastUserCheckInRepository
                        .findByDashboardUserId(location.getDashboardUserId());
                if (dashboardUserLastCheckInDetailsModel == null) {
                    dashboardUserLastCheckInDetailsModel = new DashboardUserLastCheckInDetailsModel();
                    dashboardUserLastCheckInDetailsModel.setDashboard_user_id(location.getDashboardUserId());
                }
                dashboardUserLastCheckInDetailsModel.setFlag(flag);
                dashboardUserLastCheckInDetailsModel.setLocation_details_id(savedLocation.getId());
                dashboardLastUserCheckInRepository.save(dashboardUserLastCheckInDetailsModel);
            }

            return ResponseEntity.accepted().body(RestResponse.ofSuccess(null, HttpStatus.ACCEPTED.getReasonPhrase()));
        } catch (Exception e) {
            log.error("error : " + e.getMessage());
            throw e;
        }
    }


    @GetMapping("/warehousekit/{radius}/{userId}/{lat}/{lng}")
    public ResponseEntity<RestResponse> getAllWarehousesKitByLatLng(
            @PathVariable("radius") Integer radius,
            @PathVariable("userId") Long userId,
            @PathVariable("lat") Double lat,
            @PathVariable("lng") Double lng) {
        try {
            RestResponse restResponse = new RestResponse();
            List<Warehouse> warehouseList =
                    warehouseRepository.findByCoordinatesAndRadius(lat, lng, radius * 1_000);
            log.debug("Found warehouses = {}", warehouseList);
            if (warehouseList.isEmpty()) {
                log.debug("No nearby warehouse address found");
            } else {
                List<EntityAttributeWarehouseInterface> entityAttributesList =
                        entityAttributeRepository.findByWarehouseIdIn(warehouseList);

                if (entityAttributesList.isEmpty())
                    throw new ItemNotFoundException("No warehouse found near to you ");

                LocationDetailsModel location = new LocationDetailsModel();

                int locationType = 3; // will get this from user
                LocationCaptureActivityModel locationCaptureData =
                        locationCaptureActivityRepository.findByLocationType(locationType);

                final WarehouseAddress warehouseAddressId =
                        entityAttributesList.get(0).getWarehouseId().getWarehouseAddress();
                double entityLat = warehouseAddressId.getLat();
                double entityLng = warehouseAddressId.getLng();
                double distance = distance(lat, lng, entityLat, entityLng);

                int locationCaptureId = locationCaptureData.getId();
                int allowedDistance = 1;

                location.setLocationType(locationType);
                location.setConditionValue(allowedDistance);
                location.setDashboardUserId(userId);
                location.setDfLat(lat);
                location.setDfLng(lng);
                location.setEntitiesAttributesId(entityAttributesList.get(0).getId());
                location.setEntityLat(entityLat);
                location.setEntityLng(entityLng);
                location.setLocationCaptureActivityId(locationCaptureId);

                if (distance < allowedDistance) {
                    location.setFlag(1);
                } else {
                    location.setFlag(0);
                    if (locationCaptureData.getIs_location_bound()) {
                        throw new ItemNotFoundException(
                                "you are not allowed because you are not in range to desired location");
                    }
                }
                LocationDetailsModel savedLocation = locationDetailRepository.save(location);
                log.debug("savedLocation =  {}", savedLocation);
            }
            return ResponseEntity.accepted().body(restResponse);
        } catch (RuntimeException e) {
            log.warn("error : ", e);
            throw e;
        }
    }


    @PostMapping("/location-details-vm/{id}")
    public ResponseEntity<RestResponse> locationDetailsVm(
            @RequestBody LocationDetailsModel location, @PathVariable("id") Long vmId) {
        try {
            log.debug("Location = {}", location);

            Integer LocationType = location.getLocationType();
            LocationCaptureActivityModel locationCaptureData = new LocationCaptureActivityModel();
            locationCaptureData = locationCaptureActivityRepository.findByLocationType(LocationType);
            Optional<VendingMachine> optinalEntity = vendingMachineRepository.findById(vmId);
            VendingMachine vendingMachine = optinalEntity.get();
            List<VendingMachine> vendingMachineList = new ArrayList();
            vendingMachineList.add(vendingMachine);
            List<EntityAttributeInterface> entityAttributesList = new ArrayList();
            entityAttributesList = entityAttributeRepository.findByVendingMachineIdIn(
                    vendingMachineList);
            RestResponse restResponse = new RestResponse();

            location.setLocationCaptureActivityId(locationCaptureData.getId());
            double dfLat = location.getDfLat();
            double dfLng = location.getDfLng();
            if (vendingMachine.getAddress().getLat() == null
                    || vendingMachine.getAddress().getLng() == null) {
                throw new ItemNotFoundException("data missing");
            }
            double entityLat = vendingMachine.getAddress().getLat();
            double entityLng = vendingMachine.getAddress().getLng();
            double distance = distance(dfLat, dfLng, entityLat, entityLng);

            int locationCaptureId = locationCaptureData.getId();

            location.setLocationType(LocationType);
            location.setDfLat(dfLat);
            location.setDfLng(dfLng);
            location.setEntitiesAttributesId(entityAttributesList.get(0).getId());
            location.setEntityLat(entityLat);
            location.setEntityLng(entityLng);
            location.setLocationCaptureActivityId(locationCaptureId);

            if (distance < location.getConditionValue()) {
                location.setFlag(1);
            } else {
                location.setFlag(0);
                if (locationCaptureData.getIs_location_bound()) {
                    throw new ItemNotFoundException(
                            "you are not allowed because you are not in range to desired location");
                }
            }
            LocationDetailsModel savedLocation = locationDetailRepository.save(location);
            log.debug("savedLocation = {}", savedLocation);

            var timesheetCheckIn =
                    partnerTimesheetRepository
                            .findByDashboardUserIdAndCheckedInButNotCheck(location.getDashboardUserId());
            timesheetCheckIn.ifPresent(partnerTimesheet -> {
                partnerTimesheet.setLastSeenAt(DateTimeHelper.now());
                partnerTimesheetRepository.save(partnerTimesheet);
            });

            return ResponseEntity.accepted().body(RestResponse.ofSuccess(savedLocation, "Success Message"));

        } catch (Exception e) {
            log.warn("Caught error", e);
            throw e;
        }


    }


    private static double distance(
            double lat1, double lon1, double lat2, double lon2) {
        if ((lat1 == lat2) && (lon1 == lon2)) {
            return 0;
        } else {
            double theta = lon1 - lon2;
            double dist = Math.sin(Math.toRadians(lat1)) * Math.sin(Math.toRadians(lat2)) + Math.cos(
                    Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.cos(Math.toRadians(
                    theta));
            dist = Math.acos(dist);
            dist = Math.toDegrees(dist);
            dist = dist * 60 * 1.1515;
            dist = dist * 1.609344;
            return (dist);
        }
    }

    public void updatePartnerTimesheet(Integer flag, Long dashboardUserId, Integer entitiesAttributesId) {
        Long warehouseId = null;
        final var entityAttributesModel = entityAttributeRepository
                .findById(entitiesAttributesId);
        if (entityAttributesModel.isPresent() && entityAttributesModel.get().getWarehouseId() != null) {
            warehouseId = entityAttributesModel.get().getWarehouseId().getId();
            if (!dashboardUserWarehouseMappingRepository.isUserMappedWithWarehouse(warehouseId,
                    dashboardUserId)) {
                throw new BusinessException("User not mapped with this warehouse");
            }
        }
        switch (flag) {
            case 1: {
                var partnerTimesheetNew =
                        PartnerTimesheet.builder()
                                .dashboardUserId(dashboardUserId)
                                .warehouseId(warehouseId)
                                .checkIn(DateTimeHelper.now())
                                .lastSeenAt(DateTimeHelper.now())
                                .build();
                var timesheetCheckIn =
                        partnerTimesheetRepository
                                .findByDashboardUserIdAndCheckedInButNotCheck(dashboardUserId)
                                .orElse(partnerTimesheetNew);
                if (timesheetCheckIn.getId() != null) timesheetCheckIn.setLastSeenAt(DateTimeHelper.now());
                partnerTimesheetRepository.save(timesheetCheckIn);
                break;
            }
            case 0: {
                var optionalPartnerTimesheet = partnerTimesheetRepository.findByDashboardUserId(dashboardUserId);
                if (optionalPartnerTimesheet.isPresent()) {
                    PartnerTimesheet partnerTimesheet = optionalPartnerTimesheet.get();
                    log.debug("found timesheet to check out :{}", partnerTimesheet);
                    partnerTimesheet.setCheckOut(LocalDateTime.now());
                    partnerTimesheet.setWarehouseId(warehouseId);
                    log.info("saving partner timesheet :{}", partnerTimesheet);
                    partnerTimesheetRepository.save(partnerTimesheet);
                }
            }
        }
    }

}

