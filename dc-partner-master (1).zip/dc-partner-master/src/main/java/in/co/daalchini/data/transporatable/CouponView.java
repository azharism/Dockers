package in.co.daalchini.data.transporatable;

import lombok.Data;

import java.util.List;

public class CouponView {

    @Data
    public static final class Response {
        List<CouponInfo> activatedCoupons;
        List<CouponInfo> deactivatedCoupons;
    }

    @Data
    public static final class CouponInfo {
        private Long couponId;
        private String couponName;
    }
}
