package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@NoArgsConstructor
@Entity
@Table(name = "entities_attributes")
@EntityListeners(AuditingEntityListener.class)
@Builder
@AllArgsConstructor
public class EntityAttributesModel implements Serializable {

    private static final long serialVersionUID = -5519626748147769532L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "entity_id", insertable = false, updatable = false)
    private EntityModel entityId;

    @Column(name = "entity_id")
    private Integer entity;

    @JsonIgnoreProperties({"dashboardUsers", "orders", "warehouses", "vendingMachineAddress"})
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachineId;

    @Column(name = "vending_machine_id")
    private Long vmId;


    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manufacturer_id")
    private Manufactures manufacturerId;

    @JsonIgnoreProperties({"fuelRate"})
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "warehouse_id")
    private Warehouse warehouseId;

    @Column(name = "distribution_force_id")
    private Integer distributionForceId;

    @JsonIgnore
    @Column(nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date created_at;

    @JsonIgnore
    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date updated_at;


    public EntityModel getEntityId () {
        return entityId;
    }

    public void setEntityId (EntityModel entityId) {
        this.entityId = entityId;
    }

    public VendingMachine getVendingMachineId () {
        return vendingMachineId;
    }

    public void setVendingMachineId (VendingMachine vendingMachineId) {
        this.vendingMachineId = vendingMachineId;
    }

    public Manufactures getManufacturerId () {
        return manufacturerId;
    }

    public void setManufacturerId (Manufactures manufacturerId) {
        this.manufacturerId = manufacturerId;
    }

    public Warehouse getWarehouseId () {
        return warehouseId;
    }

    public void setWarehouseId (Warehouse warehouseId) {
        this.warehouseId = warehouseId;
    }

    public Integer getDistributionForceId () {
        return distributionForceId;
    }

    public void setDistributionForceId (Integer distributionForceId) {
        this.distributionForceId = distributionForceId;
    }


    public Integer getId () {
        return id;
    }

    public void setId (Integer id) {
        this.id = id;
    }

    public EntityModel getEntity_id () {
        return entityId;
    }

    public void setEntity_id (EntityModel entity_id) {
        this.entityId = entity_id;
    }


    @JsonIgnoreProperties({"dashboardUsers", "orders"})
    public VendingMachine getVending_machine_id () {
        return vendingMachineId;
    }

    public void setVending_machine_id (VendingMachine vending_machine_id) {
        this.vendingMachineId = vending_machine_id;
    }

    public Manufactures getManufacturer_id () {
        return manufacturerId;
    }

    public void setManufacturer_id (Manufactures manufacturer_id) {
        this.manufacturerId = manufacturer_id;
    }

    public Warehouse getWarehouse_id () {
        return warehouseId;
    }

    public void setWarehouse_id (Warehouse warehouse_id) {
        this.warehouseId = warehouse_id;
    }

    public Integer getDistribution_force_id () {
        return distributionForceId;
    }

    public void setDistribution_force_id (Integer distribution_force_id) {
        this.distributionForceId = distribution_force_id;
    }

    public Date getCreated_at () {
        return created_at;
    }

    public void setCreated_at (Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at () {
        return updated_at;
    }

    public void setUpdated_at (Date updated_at) {
        this.updated_at = updated_at;
    }

}

