package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoOperationalStatus;
import in.co.daalchini.models.MachineOperationalStatus;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface MachineOperationalTypeMapper {

    DtoOperationalStatus toDto (MachineOperationalStatus type);

    List<DtoOperationalStatus> toDto (List<MachineOperationalStatus> types);
}
