package in.co.daalchini.data.untransportable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum CompletionReason {

    Cancelled("CANCELLED"),
    Abandoned("ABANDONED"),
    PartiallyFulfilled("PARTIALLY_FULFILLED"),
    Fulfilled("FULFILLED"),
    Unfulfilled("UNFULFILLED"),
    REFUND_MANUAL("REFUND_MANUAL");


    private final @JsonValue String reason;

    CompletionReason (final String state) {
        this.reason = state;
    }

    @JsonCreator
    public static CompletionReason of (String reason) {
        return Arrays.stream(CompletionReason.values())
                     .filter(x -> x.reason.equalsIgnoreCase(reason))
                     .findFirst()
                     .orElseThrow(IllegalArgumentException::new);
    }
}
