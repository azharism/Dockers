package in.co.daalchini.DTO;


public class TicketTypeDto {
	private Integer id;
	private Integer types;
	private String projectId;
	
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getTypes() {
		return types;
	}
	public void setTypes(Integer types) {
		this.types = types;
	}
	@Override
	public String toString() {
		return "TicketTypeDto [id=" + id + ", types=" + types + "]";
	}
	

}
