package in.co.daalchini.models;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserWalletRepository extends JpaRepository<UserWallet, Long> {

    @Query("select w from UserWallet w where w.ownerId = :ownerId and w.ownerType = 'user' and w.subOwnerId = 'loyalty' and w.active = true")
    Optional<UserWallet> findDpWallet (@Param("ownerId") Long ownerId);
}
