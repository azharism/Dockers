package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

public class DriverCheckIn {

    @Builder
    @Data
    public static final class Response{
        private final Long dashboardUserId;
        private final String mobileNo;
        private final Long vendingMachineId;
        private final String vendingMachineName;
        private final LocalDateTime checkedInAt;
        private final Boolean isCheckedIn;
    }

}
