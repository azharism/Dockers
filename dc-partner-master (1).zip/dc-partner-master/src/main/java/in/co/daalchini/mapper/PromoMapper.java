package in.co.daalchini.mapper;

import in.co.daalchini.data.constants.enums.VmImagePlatform;
import in.co.daalchini.data.constants.enums.VmImageType;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.models.*;
import org.mapstruct.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface PromoMapper {

    @Mapping(target = "activatesAt", source = "activatesOn", qualifiedByName = "getActivatesAt")
    @Mapping(target = "expiresAt", source = "expiresOn", qualifiedByName = "getExpiresAt")
    @Mapping(target = "imageType", source = "type", qualifiedByName = "getImageType")
    @Mapping(target = "platform", source = "platform", qualifiedByName = "getImagePlatform")
    PromoImage toImageEntity(DtoPromoImageCreateRequest dto);

    @Mapping(target = "activatesAt", source = "activatesOn", qualifiedByName = "getActivatesAt")
    @Mapping(target = "expiresAt", source = "expiresOn", qualifiedByName = "getExpiresAt")
    @Mapping(target = "imageType", source = "type", qualifiedByName = "getImageType")
    @Mapping(target = "platform", source = "platform", qualifiedByName = "getImagePlatform")
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    PromoImage updateImageEntity(DtoPromoImageUpdateRequest dto, @MappingTarget PromoImage entity);

    @Mapping(target = "active",expression = "java(entity.isActive())")
    @Mapping(target = "type", source = "imageType", qualifiedByName = "getImageTypeDto")
    @Mapping(target = "platform", source = "platform", qualifiedByName = "getImagePlatformDto")
    DtoPromoImage toDtoImage(PromoImage entity);

    Collection<DtoPromoImage> toDtoImages(Collection<PromoImage> entities);

    DtoPromoCohort toDtoCohort(MachineCohort entity);

    Collection<DtoPromoCohort> toDtoCohorts(Collection<MachineCohort> entities);

    DtoPromoCohortConfig toDtoConfig(PromoCohortConfig config);

    @Mapping(target = "defaultPromoDurationSec", source = "defaultPromoDurationSec", defaultValue = "25")
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    PromoCohortConfig updateConfigEntity(DtoPromoCohortConfigPutRequest request, @MappingTarget PromoCohortConfig promoCohortConfig);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    VmCohortPromo updateCohortPromoEntity(DtoPromoCohortImagePutRequest request, @MappingTarget VmCohortPromo cohortPromo);

    @Mapping(target = "description", source = "promoImage.description")
    @Mapping(target = "imagePath", source = "promoImage.imagePath")
    @Mapping(target = "targetUrl", source = "promoImage.targetUrl")
    DtoPromoCohortImage toDtoCohortPromoImage(VmCohortPromo promo);

    Collection<DtoPromoCohortImage> toDtoCohortPromoImages(Collection<VmCohortPromo> promos);


    @Mapping(target = "active", constant = "true")
    @Mapping(target = "cohortId", source = "cohortId")
    @Mapping(target = "name", source = "request.name")
    @Mapping(target = "machineIdList", source = "request.machineIdList", qualifiedByName = "combineCollectionToCSV")
    @Mapping(target = "promoIdList", source = "request.promoIdList", qualifiedByName = "combineCollectionToCSV")
    PromoCohortOverride toCohortOverrideEntity(Long cohortId, DtoPromoOverrideCreateRequest request);

    @Mapping(target = "machineIdList", source = "request.machineIdList", qualifiedByName = "combineCollectionToCSV")
    @Mapping(target = "promoIdList", source = "request.promoIdList", qualifiedByName = "combineCollectionToCSV")
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    PromoCohortOverride updateCohortOverrideEntity(DtoPromoOverrideUpdateRequest request, @MappingTarget PromoCohortOverride override);

    @Mapping(target = "machineIdList", source = "machineIdList", qualifiedByName = "extractCollectionFromCSV")
    @Mapping(target = "promoIdList", source = "promoIdList", qualifiedByName = "extractCollectionFromCSV")
    DtoPromoCohortOverride toDtoCohortOverride(PromoCohortOverride override);

    Collection<DtoPromoCohortOverride> toDtoCohortOverrides(Collection<PromoCohortOverride> overrides);

    @Named("getActivatesAt")
    static LocalDateTime getActivatesAt(LocalDate date) {
        if (date == null) return null;

        return date.atTime(0, 0, 0);
    }

    @Named("getExpiresAt")
    static LocalDateTime getExpiresAt(LocalDate date) {
        if (date == null) return null;

        return date.atTime(23, 59, 59);
    }

    @Named("getImageType")
    static VmImageType getImageType(String type) {
        return VmImageType.of(type);
    }

    @Named("getImagePlatform")
    static VmImagePlatform getImagePlatform(String platform) {
        return VmImagePlatform.of(platform);
    }

    @Named("getImageTypeDto")
    static String getImageType(VmImageType type) {
        return type.getValue();
    }

    @Named("getImagePlatformDto")
    static String getImagePlatform(VmImagePlatform platform) {
        return platform.getValue();
    }

    @Named("extractCollectionFromCSV")
    static Collection<Long> extractCollectionFromCSV(String csIds) {
        if (csIds == null || csIds.isEmpty()) return Collections.emptySet();

        return Arrays.stream(csIds.split(",")).map(Long::valueOf).collect(Collectors.toCollection(TreeSet::new));
    }

    @Named("combineCollectionToCSV")
    static String combineCollectionToCSV(Collection<Long> ids) {
        if (ids == null || ids.isEmpty()) return null;

        return ids.stream().map(String::valueOf).collect(Collectors.joining(","));
    }
}
