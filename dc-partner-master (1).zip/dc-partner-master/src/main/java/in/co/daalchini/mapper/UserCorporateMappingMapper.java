package in.co.daalchini.mapper;

import in.co.daalchini.data.constants.enums.BpUnlinkStatus;
import in.co.daalchini.data.transporatable.BpUsers;
import in.co.daalchini.models.UserCorporateMapping;
import in.co.daalchini.service.helper.DateTimeHelper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;

@Mapper(componentModel = "spring")
public interface UserCorporateMappingMapper {

    @Mapping(target = "ucmId", source = "id")
    @Mapping(target = "status", source = "active")
    @Mapping(target = "emailId", expression = "java(mapping.getEmailIdUnmasked())")
    @Mapping(target = "isUnlinkRequest", source = "unlinkRequest.status")
    @Mapping(target = "Expired", source = "unlinkRequest.expiredAt")
    @Mapping(target = "businessName", source = "business")
    BpUsers.BpUserInfo toDto(UserCorporateMapping mapping);

    Collection<BpUsers.BpUserInfo> toDtoCollection(Collection<UserCorporateMapping> mappings);

    default boolean isNewRequest(BpUnlinkStatus status) {
        if (status == null) return false;
        if (status.equals(BpUnlinkStatus.APPROVED)) return false;

        return status.equals(BpUnlinkStatus.NEW);
    }

}
