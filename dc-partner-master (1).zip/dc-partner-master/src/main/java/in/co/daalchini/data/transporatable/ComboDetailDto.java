package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ComboDetailDto {
    @JsonProperty("name")
    private String name;
    @JsonProperty("description")
    private String description;
    @JsonProperty("total_price")
    private Double totalPrice;
    @JsonProperty("actual_price")
    private Double actualPrice;
    @JsonProperty("activates_at")
    private LocalDateTime activatesAt;
    @JsonProperty("expires_at")
    private LocalDateTime expiresAt;
    @JsonProperty("consumer_app_enabled")
    private Boolean consumerAppEnabled;
    @JsonProperty("kiosk_app_enabled")
    private Boolean kioskAppEnabled;
    @JsonProperty("image_url")
    private String imageUrl;
    @JsonProperty("mv_config")
    private List<MvConfig> mvConfig;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("combo_cohorts")
    private List<ComboCohortDto> comboCohorts;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static final class MvConfig{
        @JsonProperty("mv_id")
        private Long mvId;
        @JsonProperty("quantity")
        private Integer quantity;
        @JsonProperty("price")
        private Double price;

        public static MvConfig of(Long mvId,Integer quantity, Double price){
            return MvConfig.builder().mvId(mvId).quantity(quantity).price(price).build();
        }
    }
}
