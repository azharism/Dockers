package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.VMHealthStatusContext;
import in.co.daalchini.data.constants.DCConstants;
import in.co.daalchini.data.transporatable.VMResponse;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.models.response.DCResponse;
import in.co.daalchini.models.response.VMHealthStatusResponse;
import in.co.daalchini.service.VMHealthStatusService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Log4j2
public class VMHealthStatusController {

    private VMHealthStatusService vmHealthStatusService;

    @Autowired
    public VMHealthStatusController(VMHealthStatusService vmHealthStatusService) {
        this.vmHealthStatusService = vmHealthStatusService;
    }

    @RequestMapping(value = VMHealthStatusContext.BASE, method = RequestMethod.GET)
    public DCResponse<VMHealthStatusResponse> getVMHealthStatus() {

        DCResponse<VMHealthStatusResponse> response = new DCResponse<>();
        response.setStatus(DCConstants.API_SUCCESS);
        response.setStatusMessage(DCConstants.API_SUCCESS_MESSAGE);
        response.setStatusCode(DCConstants.API_SUCCESS_CODE);
        VMHealthStatusResponse data = null;

        try {
            data = this.vmHealthStatusService.getVMHealthStatus();
            response.setData(data);
        } catch (NullPointerException e) {
            response.setStatus(DCConstants.API_FAILURE);
            response.setStatusMessage(e.getMessage());
            response.setStatusCode(DCConstants.API_FAILURE_CODE_NULL_REQUEST);
            throw e;
        } catch (IllegalArgumentException e) {
            response.setStatus(DCConstants.API_FAILURE);
            response.setStatusMessage(e.getMessage());
            response.setStatusCode(DCConstants.API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST);
            throw e;
        } catch (Exception e) {
            response.setStatus(DCConstants.API_FAILURE);
            response.setStatusMessage(e.getClass().getSimpleName());
            response.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
            throw e;
        }
        log.info("Response {}",response);
        return response;
    }


	@GetMapping(VMHealthStatusContext.HEALTH_STATUS)
	public VMResponse.HealthResponse getVMHealthStatusReport(
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for fetching vm health status report {}",userDetails);
        try {
           var  response = vmHealthStatusService.getVMHealthStatusReport(userDetails.getUserId(),userDetails.isAdmin());
            log.info("Response :{}", response);
            return response;
        } catch (RuntimeException e) {
            log.warn("Error in fetching health report");
            throw e;
        }
    }
    @GetMapping(VMHealthStatusContext.PING_FAILURE)
    public VMResponse.PingFailureResponse getVMPingFailureReport(
            @AuthenticationPrincipal AuthUserDetails userDetails) {
        log.info("Request received for fetching vm Ping Failure report {}",userDetails);
        try {

             var response = vmHealthStatusService.getVMPingFailureReport(userDetails.getUserId(),userDetails.isAdmin());
            log.info("Response :{}", response);
            return response;
        } catch (RuntimeException e) {
            log.warn("Error in fetching ping failure report");
            throw e;
        }
    }

}
