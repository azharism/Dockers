package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.SkuGroupStockContext;
import in.co.daalchini.data.constants.RouteConstants.SkuGroupStockFetchAllContext;
import in.co.daalchini.data.constants.DCConstants;
import in.co.daalchini.models.InvoiceDetailsReqResHelper;
import in.co.daalchini.models.StockInReqResHelper;
import in.co.daalchini.models.request.DCRequest;
import in.co.daalchini.models.request.SkuGroupStockInRequest;
import in.co.daalchini.models.response.DCResponse;
import in.co.daalchini.service.InvoiceDetailsService;
import in.co.daalchini.service.SkuGroupStockInService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class SkuGroupStockInDetailsController {

	private static Logger log = LoggerFactory.getLogger(SkuGroupStockInDetailsController.class);

	private SkuGroupStockInService service;
	private InvoiceDetailsService invoiceService;

	@Autowired
	public SkuGroupStockInDetailsController(SkuGroupStockInService service, InvoiceDetailsService invoiceService) {
		this.service = service;
		this.invoiceService = invoiceService;
	}

	@RequestMapping(value = SkuGroupStockContext.BASE, method = RequestMethod.POST)
	public DCResponse<Boolean> saveStockInDetails(@RequestBody DCRequest<SkuGroupStockInRequest> request) {

		DCResponse<Boolean> response = new DCResponse<>();
		Boolean result = false;
		try {
			if (request == null || request.getRequest() == null) {
				response.setStatusCode(DCConstants.API_FAILURE_CODE_NULL_REQUEST);
				throw new NullPointerException("Null Request");
			}
			
			if(request.getRequest().getInvoiceDetails() == null || request.getRequest().getStockInList() == null || request.getRequest().getStockInList().size()<1) {
				response.setStatusCode(DCConstants.API_FAILURE_CODE_WRONG_ARG_VALUE_REQUEST);
				throw new NullPointerException("Null Request Params");
			}
			
			validateRequestStockIn(request.getRequest().getStockInList());
			validateRequestInvoice(request.getRequest().getInvoiceDetails());
			
			Long invoiceId = this.invoiceService.persist(request.getRequest().getInvoiceDetails());
			result = this.service.saveStockIn(request.getRequest().getStockInList(), invoiceId);// convert to entity
			
			response.setData(result);
			response.setStatus(DCConstants.API_SUCCESS);
			response.setStatusCode(DCConstants.API_SUCCESS_CODE);
			if(result)
				response.setStatusMessage("RECORD SUCCESSFULLY SAVED");
			else 
				response.setStatusMessage("NO RECORD SAVED");
		} catch (NullPointerException e) {

			response.setData(result);
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusMessage(e.getMessage());
			log.error("[saveStockInDetails] : " + e.getMessage());
			e.printStackTrace();

		} catch (Exception e) {

			response.setData(result);
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
			response.setStatusMessage(e.getMessage());
			log.error("[saveStockInDetails] : " + e.getMessage());
			e.printStackTrace();
		}

		return response;
	}

	@RequestMapping(value =SkuGroupStockFetchAllContext.BASE , method = RequestMethod.GET)
	public DCResponse<List<StockInReqResHelper>> fetchAllStockInDetails() {

		log.info("[fetchAllStockInDetails]");

		DCResponse<List<StockInReqResHelper>> response = new DCResponse<>();
		List<StockInReqResHelper> result = null;

		try {
			result = this.service.getAll();// convert to entity			
			response.setData(result);
			response.setStatus(DCConstants.API_SUCCESS);
			response.setStatusCode(DCConstants.API_SUCCESS_CODE);
			response.setStatusMessage("RECORD fetched ? " + ((result == null) ? false : true));
		} catch (Exception e) {
			log.error("[fetchAllStockInDetails]" + e.getMessage());
			response.setStatus(DCConstants.API_FAILURE);
			response.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
			response.setStatusMessage(
					"RECORD fetched ? " + ((result == null) ? false : true) + " : Check logs for error message.");
			e.printStackTrace();
		}
		return response;
	}

	private void validateRequestStockIn(List<StockInReqResHelper> stockInList) throws NullPointerException{
		for(StockInReqResHelper stockIn : stockInList) {
			if(stockIn.getCheckedIn() == null || stockIn.getCheckedIn() < 1) throw new NullPointerException(" STOCKIN DETAILS : CHECKED IN QUANTITY less than 1");
			if(stockIn.getManufacturerVariant() == null) throw new NullPointerException(" STOCKIN DETAILS : EMPTY MANUFACTURER CODE");
		}
	}

	private void validateRequestInvoice(InvoiceDetailsReqResHelper invoice) throws NullPointerException{
		if(invoice.getWarehouse() == null) throw new NullPointerException(" [validateRequestInvoice] : EMPTY WAREHOUSE");
		if(invoice.getInvoiceNo() == null) throw new NullPointerException(" [validateRequestInvoice] : EMPTY INVOICE NO");
		if(invoice.getRecievedDate() == null) throw new NullPointerException(" [validateRequestInvoice] : EMPTY RECIEVED-DATE");
		if(invoice.getInvoiceDate() == null) throw new NullPointerException(" [validateRequestInvoice] : EMPTY INVOICE-DATE");
//		if(invoice.getComments() == null) throw new NullPointerException("INVOICE DETAILS : NULL COMMENTS");
	}

}
