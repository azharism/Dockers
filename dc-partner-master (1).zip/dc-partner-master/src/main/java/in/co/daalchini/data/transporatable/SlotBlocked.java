package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public final class SlotBlocked {
    @Data
    public static final class Request {
        private static final ObjectMapper mapper;

        static {
            mapper = new ObjectMapper();
        }
        private final Long vmId;
        private final Long slotId;
        private final String productName;
        private final String imageId;

        @Builder
        @JsonCreator
        public Request (
                @JsonProperty("vmId") final Long vmId,
                @JsonProperty("slotId") final Long slotId,
                @JsonProperty("productName") final String productName,
                @JsonProperty("imageId") final String imageId)
        {
            this.vmId = vmId;
            this.slotId = slotId;
            this.productName = productName;
            this.imageId= imageId;
        }

        public Map<String, String> dataMap () throws JsonProcessingException {
            Map<String, String> dataMap = new TreeMap<>();
            dataMap.put("vmId", String.valueOf(vmId));
            dataMap.put("slotId", String.valueOf(slotId));
            dataMap.put("productName", productName);
            dataMap.put("imageId", imageId);
            dataMap.put("body", mapper.writeValueAsString(this));

            return dataMap;
        }
    }
}
