package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Date;

public class RefillReqResHelper implements Serializable{

	private static final long serialVersionUID = -3294304311296060192L;

	private Long id;
	
	@JsonProperty(value = "vending_machine_id") private Long vendingMachine;

	@JsonProperty(value = "user_id") private Long user;

	private Date createdAt;

	private Date updatedAt;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getVendingMachine() {
		return vendingMachine;
	}

	public void setVendingMachine(Long vendingMachine) {
		this.vendingMachine = vendingMachine;
	}

	public Long getUser() {
		return user;
	}

	public void setUser(Long user) {
		this.user = user;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public RefillReqResHelper(Long id, Long vendingMachine, Long user, Date createdAt, Date updatedAt) {
		super();
		this.id = id;
		this.vendingMachine = vendingMachine;
		this.user = user;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}
	
	public RefillReqResHelper(Refill refill) {
		this.id = refill.getId();
		
		if(refill.getUser()!=null && refill.getUser().getId()!=null)
			this.user = (refill.getUser().getId());

		if(refill.getVendingMachine()!=null && refill.getVendingMachine().getId()!=null)
			this.vendingMachine = (refill.getVendingMachine().getId());

	}

}
