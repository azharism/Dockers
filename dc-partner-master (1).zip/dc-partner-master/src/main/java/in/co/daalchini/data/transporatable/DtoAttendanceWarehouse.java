package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.StringJoiner;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoAttendanceWarehouse {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("name")
    private String name;

    @JsonProperty("city")
    private String city;

    @JsonProperty("vending_machine_cohort_id")
    private Integer vendingMachineCohortId;

    @JsonProperty("warehourse_address_id")
    private DtoAttendanceWarehouseAddress warehouseAddress;

    @Override
    public String toString() {
        return new StringJoiner(", ", DtoAttendanceWarehouse.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("name='" + name + "'")
                .add("city='" + city + "'")
                .add("vendingMachineCohortId=" + vendingMachineCohortId)
                .add("warehouseAddressId=" + (warehouseAddress == null ? null : warehouseAddress.getId()))
                .toString();
    }
}
