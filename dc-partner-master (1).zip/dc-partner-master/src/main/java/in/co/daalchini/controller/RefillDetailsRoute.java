package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants;
import in.co.daalchini.data.transporatable.LastRefillDetails;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.RefillDetailsService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Log4j2
public class RefillDetailsRoute {
    private final RefillDetailsService refillDetailsService;

    @Autowired
    public RefillDetailsRoute(RefillDetailsService refillDetailsService){
        this.refillDetailsService = refillDetailsService;
    }

    @GetMapping(RouteConstants.RefillContext.LAST_REFILL_DETAILS)
    public LastRefillDetails.Response getLastRefillDetails(
            @AuthenticationPrincipal AuthUserDetails userDetails)
    {
        log.info("Request received for fetching last refill details for :{}", userDetails);
        try{
            Long dashboardUserId = userDetails.getUserId();
            LastRefillDetails.Response response = refillDetailsService.fetchLastRefillDetails(dashboardUserId);
            log.info("Response :{}", response);
            return response;
        }catch (Exception e){
            log.error("Error in fetching refill details");
            throw e;
        }

    }
}
