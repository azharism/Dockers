package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.models.*;
import in.co.daalchini.service.helper.DateTimeHelper;
import org.mapstruct.*;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static in.co.daalchini.data.constants.enums.RechargeType.*;
import static java.time.temporal.TemporalAdjusters.*;

@Mapper(componentModel = "spring")
public interface CorporateMapper {

    DtoCorporate toDto(CorporateDetails details);

    List<DtoCorporate> toDto(Collection<CorporateDetails> locationTypes);

    @Mapping(target = "active", source = "active")
    DtoCorporateSummarized.DtoCorporateDomain toDomainDto(CorporateDomain domain);


    @Mapping(target = "id", source = "details.id")
    @Mapping(target = "name", source = "details.name")
    @Mapping(target = "active", source = "details.active")
    @Mapping(target = "expiryDateMonth", source = "details.expiryDateMonth")
    @Mapping(target = "domains", source = "domains")
    DtoCorporateSummarized toDtoCorporateSummarized(CorporateDetails details, Collection<CorporateDomain> domains);

    @Mapping(target = "id", source = "details.id")
    @Mapping(target = "name", source = "details.name")
    @Mapping(target = "active", source = "details.active")
    @Mapping(target = "expiryDateMonth", source = "details.expiryDateMonth")
    @Mapping(target = "walletDetails", source = "walletDetails")
    @Mapping(target = "walletRfidDetails", source = "walletRfidDetails")
    DtoCorporateComprehensive toDtoCorporateComprehensive(CorporateDetails details, DtoCorporateComprehensive.DtoWalletDetails walletDetails, DtoCorporateComprehensive.DtoWalletRfidDetails walletRfidDetails);

    @Mapping(target = "active", constant = "true")
    CorporateDetails toEntityCorporate(DtoCorporateCreateRequest createRequest);

    @Mapping(target = "active", constant = "true")
    @Mapping(target = "corporateId", source = "corporateId")
    @Mapping(target = "initialBalance", source = "domain.initialBalance", defaultValue = "0.0")
    @Mapping(target = "domain", source = "domain.domain")
    @Mapping(target = "description", source = "domain.description")
    CorporateDomain toEntityCorporateDomain(Long corporateId, DtoCorporateCreateRequest.EmailDomain domain);

    default List<CorporateDomain> toEntityCorporateDomains(Long corporateId, List<DtoCorporateCreateRequest.EmailDomain> corpDomains) {
        return corpDomains
                .stream()
                .map(corpDomain -> toEntityCorporateDomain(corporateId, corpDomain))
                .collect(Collectors.toList());
    }

    DtoCorporateLimitType toDtoLimitType(CorporateLimitType limitType);

    Collection<DtoCorporateLimitType> toDtoLimitTypes(List<CorporateLimitType> limitTypes);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "type", source = "type")
    @Mapping(target = "subType", source = "subType")
    @Mapping(target = "duration", source = "duration")
    @Mapping(target = "durationUnit", source = "durationUnit")
    DtoCorporateLimitSummarized.LimitType toDtoCorporateLimitType(CorporateLimitType limitType);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "pgId", source = "pgId")
    @Mapping(target = "value", source = "value")
    @Mapping(target = "active", source = "active")
    @Mapping(target = "limitType", source = "limitType")
    DtoCorporateLimitSummarized toDtoCorporateLimitSummary(CorporateLimit limit);

    Collection<DtoCorporateLimitSummarized> toDtoCorporateLimitSummaries(List<CorporateLimit> limitTypes);

    @Mapping(target = "corporateId", source = "corporateId")
    @Mapping(target = "pgId", source = "pgId")
    @Mapping(target = "value", source = "request.value")
    @Mapping(target = "limitTypeId", source = "request.limitTypeId")
    @Mapping(target = "cardSeriesId", source = "request.cardSeriesId")
    CorporateLimit toEntityCorporateLimit(Long corporateId, Integer pgId, DtoCorporateLimitRequest request);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    CorporateLimit updateEntity(@MappingTarget CorporateLimit corporateLimit, DtoCorporateLimitRequest request);

    @Mapping(target = "id", source = "plan.id")
    @Mapping(target = "name", source = "plan.name")
    @Mapping(target = "amount", source = "plan.rule.amount")
    @Mapping(target = "active", source = "plan.active")
    @Mapping(target = "resetBalance", source = "resetBalance")
    @Mapping(target = "rechargeDetails", source = "plan")
    DtoCorporatePlanSummarized.PlanMonthly toDtoCorporatePlanMonthly(Boolean resetBalance, RechargePlan plan);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "name", source = "name")
    @Mapping(target = "amount", source = "rule.amount")
    @Mapping(target = "active", source = "active")
    @Mapping(target = "lowBalance", source = "filter.maxBalance")
    @Mapping(target = "rechargeDetails", source = "plan")
    DtoCorporatePlanSummarized.PlanAddOn toDtoCorporatePlanAddOn(RechargePlan plan);

    @Mapping(target = "expenditure", source = "rule.rechargeExpenditure")
    @Mapping(target = "lastExecutionDate", source = "schedule.lastExecutionDate")
    @Mapping(target = "nextExecutionDate", source = "schedule.nextExecutionDate")
    DtoCorporatePlanSummarized.RechargeDetails toDtoCorporatePlanRechargeDetails(RechargePlan plan);

    default DtoCorporatePlanSummarized toDtoCorporatePlanSummary(RechargePlan monthly, RechargePlan addOn) {
        var result = DtoCorporatePlanSummarized.builder();

        if (null != monthly) {
            var resetBalance = Objects.equals(Monthly, monthly.getRule().getRechargeType());
            if (monthly.isActive()) result.planMonthly(toDtoCorporatePlanMonthly(resetBalance, monthly));
        }

        if (null != addOn) {
            if (addOn.isActive()) result.planAddOn(toDtoCorporatePlanAddOn(addOn));
        }

        return result.build();
    }

    default RechargePlan toEntityMonthlyPlan(
            Long corporateId,
            Integer pgId,
            DtoCorporatePlanSetRequest.PlanMonthly request
    ) {
        return toRechargePlanEntity(
                corporateId, pgId, request.getName(), request.getAmount(), request.getResetBalance(), null);
    }

    default RechargePlan toEntityAddOnPlan(
            Long corporateId,
            Integer pgId,
            DtoCorporatePlanSetRequest.PlanAddOn request
    ) {
        return toRechargePlanEntity(
                corporateId, pgId, request.getName(), request.getAmount(), null, request.getLowBalance());
    }

    default RechargePlan toEntityMonthlyPlan(
            DtoCorporatePlanSetRequest.PlanMonthly request,
            RechargePlan plan
    ) {
        return toRechargePlanEntity(
                request.getName(), request.getAmount(), request.getResetBalance(), null, plan);
    }

    default RechargePlan toEntityAddOnPlan(
            DtoCorporatePlanSetRequest.PlanAddOn request,
            RechargePlan plan
    ) {
        return toRechargePlanEntity(
                request.getName(), request.getAmount(), null, request.getLowBalance(), plan);
    }

    default RechargePlan toRechargePlanEntity(
            String name,
            Double amount,
            Boolean isResetBalance,
            Double lowBalance,
            RechargePlan plan
    ) {
        return updatePlanDetails(name, amount, isResetBalance, lowBalance, plan);
    }

    default RechargePlan toRechargePlanEntity(
            Long corporateId,
            Integer pgId,
            String name,
            Double amount,
            Boolean isResetBalance,
            Double lowBalance
    ) {

        var plan = initializePlan(corporateId, pgId, name, amount);

        return updatePlanDetails(name, amount, isResetBalance, lowBalance, plan);
    }

    private static RechargePlan initializePlan(
            Long corporateId,
            Integer pgId,
            String name,
            Double amount
    ) {
        // filter
        var filter = new RechargeFilter();
        filter.setPgId(pgId);
        filter.setMinBalance(0.0);
        filter.setScanUsersActive(false);
        filter.setActive(true);

        // rule
        var rule = new RechargeRule();
        rule.setRechargeBudget(99_00_000.0); // max value
        rule.setRechargeExpenditure(0.0);
        rule.setPrefillCorporate(true);
        rule.setCarryForward(false);
        rule.setAmount(amount);
        rule.setActive(true);

        // schedule
        var schedule = new RechargeSchedule();
        var currentDate = DateTimeHelper.today();
        schedule.setStartDate(currentDate);
        schedule.setActive(true);

        // plan - merging all data
        var plan = new RechargePlan();
        plan.setCorporateId(corporateId);
        plan.setName(name);
        plan.setDescription(name);
        plan.setFilter(filter);
        plan.setRule(rule);
        plan.setSchedule(schedule);
        plan.setActive(true);

        return plan;
    }

    private static RechargePlan updatePlanDetails(
            String name,
            Double amount,
            Boolean isResetBalance,
            Double lowBalance,
            RechargePlan plan
    ) {
        var rule = plan.getRule();
        var filter = plan.getFilter();
        var schedule = plan.getSchedule();
        var currentDate = DateTimeHelper.today();

        plan.setName(name);
        rule.setAmount(amount);
        if (null != lowBalance) {
            rule.setRechargeType(AddOn);
            filter.setMaxBalance(lowBalance);
            schedule.setDayInterval(1);
            schedule.setEndDate(currentDate.plusMonths(1).with(lastDayOfMonth())); // end of next month
            schedule.setNextExecutionDate(currentDate.plusDays(1)); // tomorrow
        } else {
            rule.setRechargeType(isResetBalance ? Monthly : Full);
            filter.setMaxBalance(amount);
            schedule.setDayMonth(1);
            schedule.setEndDate(currentDate.with(lastDayOfYear())); // end of current year
            schedule.setNextExecutionDate(currentDate.with(firstDayOfNextMonth())); // beginning of next month
        }

        plan.setActive(true);
        filter.setActive(true);
        rule.setActive(true);
        schedule.setActive(true);

        return plan;
    }

    DtoCorporateComprehensive.DtoCorporateDomain toDtoCorporateDomain(CorporateDomain domain);

    Collection<DtoCorporateComprehensive.DtoCorporateDomain> toDtoCorporateDomains(Collection<CorporateDomain> domains);


    default DtoCorporateComprehensive.DtoWalletDetails toDtoWalletDetails(
            Collection<CorporateDomain> domains,
            Collection<DtoCorporateLimitSummarized> limits,
            DtoCorporatePlanSummarized plan
    ) {
        var result = DtoCorporateComprehensive.DtoWalletDetails.builder();

        if (null != domains && !domains.isEmpty()) {
            result.domains(toDtoCorporateDomains(domains));
        }
        if (null != limits && !limits.isEmpty()) {
            result.usageLimits(limits);
        }
        if (null != plan) {
            result.rechargePlan(plan);
        }

        return result.build();
    }

    default DtoCorporateComprehensive.DtoWalletRfidDetails toDtoWalletRfidDetails(
            Collection<DtoCorporateLimitSummarized> limits,
            DtoCorporatePlanSummarized plan
    ) {
        var result = DtoCorporateComprehensive.DtoWalletRfidDetails.builder();

        if (null != limits && !limits.isEmpty()) {
            result.usageLimits(limits);
        }
        if (null != plan) {
            result.rechargePlan(plan);
        }

        return result.build();
    }
}
