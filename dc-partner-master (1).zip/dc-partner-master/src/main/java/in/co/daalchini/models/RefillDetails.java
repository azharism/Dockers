package in.co.daalchini.models;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "refill_details")
@NamedQuery(name = "RefillDetails.findAll", query = "SELECT i FROM RefillDetails i")
public class RefillDetails implements Serializable{

	private static final long serialVersionUID = 4044992200758292016L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	private Long id;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "manufacturer_variant_id")
	private ManufacturerVariant manufacturerVariant;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "refill_id")
	private Refill refill;

	@Column(name = "slot_identifier")
	private String slot;
	
//	@JoinColumn(name = "prefilled_quantity")
//	private short prefilledQuantity;

	@Column(name = "impacted_quantity")
	private short impactedQuantity;
	
	@Column(name = "final_quantity")
	private short finalQuantity;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "refill_type_id")
	private RefillType refillType;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
	@CreationTimestamp
	private Date createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at")
	@UpdateTimestamp
	private Date updatedAt;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ManufacturerVariant getManufacturerVariant() {
		return manufacturerVariant;
	}

	public void setManufacturerVariant(ManufacturerVariant manufacturerVariant) {
		this.manufacturerVariant = manufacturerVariant;
	}

	public Refill getRefill() {
		return refill;
	}

	public void setRefill(Refill refill) {
		this.refill = refill;
	}

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}

//	public short getPrefilledQuantity() {
//		return prefilledQuantity;
//	}
//
//	public void setPrefilledQuantity(short prefilledQuantity) {
//		this.prefilledQuantity = prefilledQuantity;
//	}

	public short getImpactedQuantity() {
		return impactedQuantity;
	}

	public void setImpactedQuantity(short impactedQuantity) {
		this.impactedQuantity = impactedQuantity;
	}

	public short getFinalQuantity() {
		return finalQuantity;
	}

	public void setFinalQuantity(short finalQuantity) {
		this.finalQuantity = finalQuantity;
	}

	public RefillType getRefillType() {
		return refillType;
	}

	public void setRefillType(RefillType refillType) {
		this.refillType = refillType;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public RefillDetails() {
	}

	public RefillDetails(Long id, ManufacturerVariant manufacturerVariant, Refill refill, String slot,
                         short prefilledQuantity, short impactedQuantity, short finalQuantity, RefillType refillType, Date createdAt,
                         Date updatedAt) {
		super();
		this.id = id;
		this.manufacturerVariant = manufacturerVariant;
		this.refill = refill;
		this.slot = slot;
//		this.prefilledQuantity = prefilledQuantity;
		this.impactedQuantity = impactedQuantity;
		this.finalQuantity = finalQuantity;
		this.refillType = refillType;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}
}
