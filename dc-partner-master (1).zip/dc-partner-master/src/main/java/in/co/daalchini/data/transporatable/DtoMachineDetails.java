package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.Collections;
import java.util.List;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoMachineDetails {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("name")
    private String name;

    @JsonProperty("operational_status")
    private String operationalStatus;

    @JsonProperty("hardware_type")
    private String hardwareType;

    @JsonProperty("machine_type")
    private String machineType;

    @JsonProperty("health_report_enabled")
    private boolean healthReportEnabled;

    @JsonProperty("consumer_app_enabled")
    private boolean consumerAppEnabled;

    @JsonProperty("share_percentage")
    private Integer sharePercentage;

    @JsonProperty("cart_limit")
    private Integer cartLimit;

    @JsonProperty("app_version")
    private String appVersion;

    @JsonProperty("warehouse")
    private DtoWarehouse warehouse;

    @JsonProperty("corporate")
    private DtoCorporate corporate;

    @Builder.Default
    @JsonProperty("cohorts")
    @JsonIncludeProperties({"id", "name"})
    private List<DtoCohort> cohorts = Collections.emptyList();

    @Builder.Default
    @JsonProperty("payment_configs")
    @JsonIncludeProperties({"id", "name"})
    private List<DtoPaymentConfig> paymentConfigs = Collections.emptyList();

    @JsonProperty("address")
    private DtoMachineAddress address;

    @JsonProperty("keys")
    private DtoMachineKeys keys;

    @Builder.Default
    @JsonProperty("slots")
    private List<DtoMachineSlot> slots = Collections.emptyList();
}
