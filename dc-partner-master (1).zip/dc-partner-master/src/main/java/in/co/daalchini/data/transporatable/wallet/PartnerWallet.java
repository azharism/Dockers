package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

import static in.co.daalchini.data.constants.DCConstants.WALLET_SUB_OWNER_PARTNER;

@Data
@Builder
public class PartnerWallet {
    private Long ownerId;
    private @Default String subOwnerId = WALLET_SUB_OWNER_PARTNER;
    private @Default String type = WalletType.Overdraft.value();
    private @Default String subType = WalletSubType.Normal.value();
}
