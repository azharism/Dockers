package in.co.daalchini.Interfaces;


import in.co.daalchini.models.response.SendNotificationResponse;
import in.co.daalchini.service.helper.UserNotificationFileStructure;
import in.co.daalchini.models.UserNotificationFileMapping;
import in.co.daalchini.models.response.DCResponse;

import java.util.List;
import java.util.concurrent.ExecutionException;

public interface IUserNotificationFileMappingService {
    public DCResponse<List<UserNotificationFileMapping>> saveUsersInDump(List<UserNotificationFileStructure> userNotificationFileStructureList);
    public DCResponse<SendNotificationResponse> sendNotification(String fileName, String campaignId, String text, String heading, String imageUrl);

}

