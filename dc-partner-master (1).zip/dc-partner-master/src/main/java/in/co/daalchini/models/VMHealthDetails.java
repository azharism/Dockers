package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class VMHealthDetails implements Serializable {

    private static final long serialVersionUID = -485050517963223352L;

    @JsonProperty(value = "vm_id") private Integer vmId;
    @JsonProperty(value = "vm_name")private String vmName;
    @JsonProperty(value = "time_since_last_update")private String timeSinceLastUpdate;
    @JsonProperty(value = "speed")private String speed;
	}
