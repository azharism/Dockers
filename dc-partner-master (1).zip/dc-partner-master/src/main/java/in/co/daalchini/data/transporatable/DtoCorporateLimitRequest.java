package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Data
@Builder
@JsonIncludeProperties({"value", "limit_type_id", "card_series_id"})
public class DtoCorporateLimitRequest {

    @NotNull
    @Min(1)
    @JsonProperty("value")
    private Integer value;

    @NotNull
    @Min(1)
    @JsonProperty("limit_type_id")
    private Long limitTypeId;

    @Min(1)
    @JsonProperty("card_series_id")
    private Long cardSeriesId;
}

