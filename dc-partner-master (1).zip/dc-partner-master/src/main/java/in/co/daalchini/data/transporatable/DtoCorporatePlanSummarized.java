package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
@JsonIncludeProperties({"monthly", "add_on"})
public class DtoCorporatePlanSummarized {

    @JsonProperty("monthly")
    private PlanMonthly planMonthly;

    @JsonProperty("add_on")
    private PlanAddOn planAddOn;

    @Data
    @Builder
    @JsonIncludeProperties({"id", "name", "amount", "reset_balance", "is_active", "recharge_details"})
    public static class PlanMonthly {
        @JsonProperty("id")
        private Long id;

        @JsonProperty("name")
        private String name;

        @JsonProperty("amount")
        private Double amount;

        @JsonProperty("reset_balance")
        public Boolean resetBalance;

        @JsonProperty("is_active")
        public Boolean active;

        @JsonProperty("recharge_details")
        private RechargeDetails rechargeDetails;
    }

    @Data
    @Builder
    @JsonIncludeProperties({"id", "name", "amount", "low_balance", "is_active", "recharge_details"})
    public static class PlanAddOn {
        @JsonProperty("id")
        private Long id;

        @JsonProperty("name")
        private String name;

        @JsonProperty("amount")
        private Double amount;

        @JsonProperty("low_balance")
        public Double lowBalance;

        @JsonProperty("is_active")
        public Boolean active;

        @JsonProperty("recharge_details")
        private RechargeDetails rechargeDetails;
    }

    @Data
    @Builder
    @JsonIncludeProperties({"last_execution_date", "next_execution_date", "expenditure"})
    public static class RechargeDetails {

        @JsonProperty("last_execution_date")
        private LocalDate lastExecutionDate;

        @JsonProperty("next_execution_date")
        private LocalDate nextExecutionDate;

        @JsonProperty("expenditure")
        private Double expenditure;
    }
}
