package in.co.daalchini.data.transporatable.message;

import in.co.daalchini.service.helper.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class InventoryReleaseEvent implements Jsonable {
    private String orderId;
    @Override
    public String json() {
        return JsonUtil.toJson(this);
    }
}
