package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants;
import in.co.daalchini.data.transporatable.BrandCategory;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.BrandServices;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Log4j2
public class BrandController {

    private final BrandServices brandServices;

    @Autowired
    public BrandController(BrandServices brandTypeServices) {
        this.brandServices = brandTypeServices;
    }



    @PreAuthorize("hasAuthority('view_brands')or hasAuthority('view_base')or hasAuthority('view_variants')")
    @GetMapping(RouteConstants.BrandContext.WARHOUSE_BRAND)
    public List<BrandCategory.Response> getWarehouseBrandList(@PathVariable(value = "warehouseId") Long warehouseId,
                                                              @AuthenticationPrincipal AuthUserDetails userDetails){

        log.info("Request received for adding users :{}", userDetails);
       List<BrandCategory.Response> response =null;
        try {
            response =  brandServices.fetchWarehouseBrandCategory(userDetails.getUserId(),warehouseId);

        } catch (Exception e) {

            log.error("Error in Adding Brand Details :{}", e.getMessage());
            throw e;
        }

        return response;
    }
}
