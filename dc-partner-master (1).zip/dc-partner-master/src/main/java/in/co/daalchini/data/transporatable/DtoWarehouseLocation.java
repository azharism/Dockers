package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DtoWarehouseLocation {

    @JsonProperty("title")
    private String title;

    @JsonProperty("gstin")
    private String gstin;

    @JsonProperty("address")
    private String address;
}
