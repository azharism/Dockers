package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "partner_timesheet")
public class PartnerTimesheet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "dashboard_user_id")
    private Long dashboardUserId;

    @Column(name = "warehouse_id")
    private Long warehouseId;

    @Column(name = "check_in")
    private LocalDateTime checkIn;

    @Column(name = "check_out")
    private LocalDateTime checkOut;

    @Column(name = "last_seen_at")
    private LocalDateTime lastSeenAt;

    @Column(name = "checkin_approved_at")
    private LocalDateTime checkInApprovedAt;

    @Column(name = "checkout_approved_at")
    private LocalDateTime checkOutApprovedAt;

    @OneToOne
    @JoinColumn(name = "dashboard_user_id", insertable = false, updatable = false)
    private DashboardUser dashboardUser;

    public DashboardUserDetails getDashboardUserDetails () {
        return dashboardUser != null ? dashboardUser.getDashboardUserDetails() : null;
    }
}
