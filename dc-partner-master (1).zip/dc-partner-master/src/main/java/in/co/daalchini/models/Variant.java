package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "variants")
@NamedQuery(name = "Variant.findAll", query = "SELECT v FROM Variant v")
public class Variant implements Serializable {

    private static final long serialVersionUID = 5730798765387066897L;

    @Id
    private Long id;

    @Column(name = "description")
    private String description;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "is_special")
    private Boolean isSpecial;

    @Column(name = "is_veg")
    private Boolean isVeg;

    @Column(name = "microwave_heating_required")
    private Boolean microwaveHeatingRequired;

    @Column(name = "name")
    private String name;

    @Column(name = "quantity_value")
    private String quantityValue;

    @Column(name = "serving")
    private Integer serving;

    @Column(name = "shelf_life")
    private String shelfLife;

    @Column(name = "title")
    private String title;

    @Column(name = "with_packaging_weight")
    private String withPackagingWeight;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tax_type_id")
    private TaxType taxType;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "hsn_code", referencedColumnName = "value")
    private HsnCodes hsnCode;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id")
    private Product product;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "quantity_type_id")
    private QuantityType quantityType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "form_type_id")
    private FormType formType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "meal_type_id")
    private MealType mealType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cuisine_type_id")
    private CuisineType cuisineType;

    @JsonIgnoreProperties({"variant"})
    @OneToMany(mappedBy = "variant")
    private List<VariantImage> variantImages;

    @Column(name = "crate_size")
    private Integer crateSize;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
