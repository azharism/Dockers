package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIncludeProperties({"id", "platform", "type", "description", "image_path", "target_url", "is_active"})
public class DtoPromoImage {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("platform")
    private String platform;

    @JsonProperty("type")
    private String type;

    @JsonProperty("description")
    private String description;

    @JsonProperty("image_path")
    private String imagePath;

    @JsonProperty("target_url")
    private String targetUrl;

    @JsonProperty("is_active")
    private boolean active;

}
