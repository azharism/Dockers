package in.co.daalchini.data.transporatable.message;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.untransportable.OrderSource;
import in.co.daalchini.data.untransportable.OrderState;
import in.co.daalchini.data.untransportable.PaymentGatewayType;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
public final class OrderStateChange {
    private final String orderId;
    private final OrderState orderState;
    private final OrderSource orderSource;
    private final PaymentGatewayType paymentGateway;

    @Builder
    @JsonCreator
    public OrderStateChange (
        @JsonProperty("orderId") final String orderId,
        @JsonProperty("orderState") final OrderState orderState,
        @JsonProperty("orderSource") final OrderSource orderSource,
        @JsonProperty("paymentGateway") final PaymentGatewayType paymentGateway)
    {
        this.orderId = orderId;
        this.orderState = orderState;
        this.orderSource = orderSource;
        this.paymentGateway = paymentGateway;
    }
}
