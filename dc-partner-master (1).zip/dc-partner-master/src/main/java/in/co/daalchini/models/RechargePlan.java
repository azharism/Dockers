package in.co.daalchini.models;


import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "recharge_plan")
@EntityListeners(AuditingEntityListener.class)
public class RechargePlan {

    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "corporate_id")
    private Long corporateId;

    @Column(name = "filter_id")
    private Long filterId;

    @Column(name = "rule_id")
    private Long ruleId;

    @Column(name = "schedule_id")
    private Long scheduleId;

    @Column(name = "active")
    private boolean active;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @LastModifiedBy
    @Column(name = "updated_by")
    private Long updatedBy;

    @Version
    @Column(name = "version")
    private Long version;

    @ManyToOne(fetch = FetchType.LAZY)
    @ReadOnlyProperty
    @JoinColumn(name = "corporate_id", updatable = false, insertable = false)
    private CorporateDetails corporate;

    @ManyToOne(fetch = FetchType.LAZY)
    @ReadOnlyProperty
    @JoinColumn(name = "filter_id", updatable = false, insertable = false)
    private RechargeFilter filter;

    @ManyToOne(fetch = FetchType.LAZY)
    @ReadOnlyProperty
    @JoinColumn(name = "rule_id", updatable = false, insertable = false)
    private RechargeRule rule;

    @ManyToOne(fetch = FetchType.LAZY)
    @ReadOnlyProperty
    @JoinColumn(name = "schedule_id", updatable = false, insertable = false)
    private RechargeSchedule schedule;

    @Override
    public String toString() {
        return new StringJoiner(", ", RechargePlan.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("name='" + name + "'")
                .add("description='" + description + "'")
                .add("corporateId=" + corporateId)
                .add("filterId=" + filterId)
                .add("ruleId=" + ruleId)
                .add("scheduleId=" + scheduleId)
                .add("active=" + active)
                .toString();
    }
}
