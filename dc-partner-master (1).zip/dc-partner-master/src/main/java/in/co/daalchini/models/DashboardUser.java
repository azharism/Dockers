package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

import javax.persistence.*;
import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_users")
public class DashboardUser {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Basic
    @Column(name = "mobile")
    private String mobile;

    @Basic
    @Column(name = "email")
    private String email;

    @Column(name = "cur_wh_id")
    private Long currentWarehouseId;

    @JsonIgnoreProperties({"dashboardUsers"})
    @ManyToOne
    @JoinColumn(name = "role_id")
    private DashboardRole dashboardRole;

    @JsonIgnoreProperties({"dashboardUsers"})
    @ManyToMany
    @JoinTable(name = "corporate_managers",
            joinColumns = {@JoinColumn(name = "dashboard_user_id")},
            inverseJoinColumns = {@JoinColumn(name = "corporate_id")})
    private List<CorporateDetails> corporateDetails;

    @JsonIgnoreProperties({"dashboardUser"})
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "dashboardUser")
    private List<DashboardUserToken> dashboardUserTokens;

    @JsonIgnoreProperties({"dashboardUsers"})
    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "dashboardUsers")
    private Set<VendingMachine> vendingMachines;

    @JsonIgnoreProperties({"dashboardUsers"})
    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "dashboardUsers")
    private Set<Warehouse> warehouses;

    @JsonIgnoreProperties({"dashboardUsers"})
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "dashboardUser")
    private List<VmFailedSlotHistory> vmFailedSlotHistoryList;

    @LazyToOne(LazyToOneOption.NO_PROXY)
    @JsonIgnoreProperties({"dashboardUsers"})
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "dashboardUser")
    private DashboardUserDetails dashboardUserDetails;

    @JsonIgnoreProperties({"dashboardUsers"})
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "dashboardUser")
    private PartnerPermission partnerPermissions;

    @LazyToOne(LazyToOneOption.NO_PROXY)
    @JsonIgnoreProperties({"dashboardUsers"})
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "dashboardUser")
    private DashboardUserData dashboardUserData;

    @JsonIgnore
    @Column(name = "created_at")
    private Instant createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private Instant updatedAt;

    public static DashboardUser of(Long userId) {
        DashboardUser user = new DashboardUser();
        user.setId(userId);

        return user;
    }

    public String getMobile() {
        return PiiHelper.maskPhone(mobile);
    }

    public String getEmail() {
        return PiiHelper.maskEmail(email);
    }

    @Override
    public String toString() {
        final String roleId = String.valueOf(dashboardRole.getId());
        final int tokens = dashboardUserTokens == null ? 0 : dashboardUserTokens.size();
        return new StringJoiner(", ", DashboardUser.class.getSimpleName() + "[", "]")
                .add("id=" + this.id)
                .add("mobile='" + getMobile() + "'")
                .add("email='" + getEmail() + "'")
                .add("dashboardRole=" + roleId)
                .add("dashboardUserTokens=" + tokens)
                .toString();
    }
}
