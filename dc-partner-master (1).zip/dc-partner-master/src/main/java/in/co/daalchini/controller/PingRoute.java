package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.GeneralContext;
import in.co.daalchini.data.transporatable.Ping.Response;
import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

@Log4j2
@RestController
public class PingRoute {

    @GetMapping({GeneralContext.PING,GeneralContext.ROOT})
    public Response ping () {
        final long currentInstantMillis = Instant.now().toEpochMilli();
        final Response response = Response.of(currentInstantMillis);

        log.info("ping, response = {}", response);
        return response;
    }
}
