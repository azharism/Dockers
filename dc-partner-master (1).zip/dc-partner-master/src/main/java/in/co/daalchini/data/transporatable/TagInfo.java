package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import lombok.ToString.Exclude;


public final class TagInfo {

    @Builder
    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Request {
        private String cardStatus;
        private Double balance;
    }

    @Builder
    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Response {

        @Exclude
        @JsonIgnore
        private Long id;

        private String uid;
        private String cardType;
        private String cardStatus;
        private Boolean active;

        @With
        private Double balance;
    }
}
