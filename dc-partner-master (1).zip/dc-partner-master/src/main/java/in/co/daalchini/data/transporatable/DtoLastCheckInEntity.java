package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.StringJoiner;

@Data
@Builder
public class DtoLastCheckInEntity {

    @JsonProperty("flag")
    private Integer flag;

    @JsonProperty("entity_lat")
    private Double entityLat;

    @JsonProperty("entity_lng")
    private Double entityLng;

    @JsonProperty("entity_type")
    private String entityType;

    @JsonProperty("vending_machine_name")
    private String vendingMachineName;

    @JsonProperty("vending_machine_street")
    private String vendingMachineStreet;

    @JsonProperty("warehouse_name")
    private String warehouseName;

    @JsonProperty("warehouse_street")
    private String warehouseStreet;

    @JsonProperty("vendor_name")
    private String vendorName;


    @Override
    public String toString() {
        return new StringJoiner(", ", DtoLastCheckInEntity.class.getSimpleName() + "[", "]")
                .add("flag=" + flag)
                .add("entityType='" + entityType + "'")
                .add("vendingMachineName='" + vendingMachineName + "'")
                .add("warehouseName='" + warehouseName + "'")
                .add("vendorName='" + vendorName + "'")
                .toString();
    }
}
