package in.co.daalchini.data.untransportable;


import io.jsonwebtoken.Claims;
import lombok.Builder;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;

import java.util.*;

@Data
@Builder
public final class JwTokenPayload {

    private Long id;
    private String jti;
    private String role;
    private Collection<String> permissions;


    public List<GrantedAuthority> getGrantedAuthorities() {
        if (permissions == null || permissions.isEmpty()) return Collections.emptyList();
        if (role != null) permissions.add("ROLE_" + role.toUpperCase());

        return permissions.stream().map(AuthGrantedAuthority::of).toList();
    }

    public static JwTokenPayload of(Claims claims) {
        var tokenId = claims.getId();
        var role = claims.get("role", String.class).toUpperCase();
        var userId = claims.getSubject() != null ? Long.valueOf(claims.getSubject()) : claims.get("id", Long.class);
        var permissionSet = new TreeSet<String>();
        if (claims.containsKey("permissions")) {
            for (var permission : claims.get("permissions", Collection.class)) {
                if (permission instanceof String permissionStr) permissionSet.add(permissionStr);
            }
        }

        return JwTokenPayload.builder()
                .id(userId)
                .jti(tokenId)
                .role(role)
                .permissions(permissionSet)
                .build();
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", JwTokenPayload.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("jti='" + jti + "'")
                .add("role='" + role + "'")
                .add("permissions=" + permissions)
                .toString();
    }
}
