package in.co.daalchini.models;


import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the cuisine_types database table.
 * 
 */
@Entity
@Table(name="cuisine_types")
@NamedQuery(name="CuisineType.findAll", query="SELECT c FROM CuisineType c")
public class CuisineType implements Serializable {

	private static final long serialVersionUID = 2210856367094079917L;

	@Id
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_at")
	private Date createdAt;

	private String description;

	private String type;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_at")
	private Date updatedAt;

	public CuisineType() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

}