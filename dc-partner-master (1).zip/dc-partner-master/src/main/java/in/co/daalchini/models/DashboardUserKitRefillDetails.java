package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "dashboard_user_kit_refill_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardUserKitRefillDetails {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "slot_identifier")
    private Long slotId;

    @Column(name = "item_quantity")
    private Integer itemQuantity;

    @Column(name = "operation_type")
    private String operationType;

    @ManyToOne
    @JoinColumn(name = "dashboard_user_refill_kit_id")
    private DashboardUserKitsRefills dashboardUserKitsRefills;

    @OneToOne
    @JoinColumn(name = "manufacturer_variant_id")
    private ManufacturerVariant manufacturerVariant;

}
