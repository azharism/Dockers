package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vm_cohort_promo_overrides")
@EntityListeners(AuditingEntityListener.class)
public class PromoCohortOverride {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "cohort_id")
    private Long cohortId;

    @Column(name = "name")
    private String name;

    @Column(name = "machine_id_list")
    private String machineIdList;

    @Column(name = "promo_id_list")
    private String promoIdList;

    @Column(name = "active")
    private boolean active;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
