package in.co.daalchini.models;


import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "recharge_schedule")
@EntityListeners(AuditingEntityListener.class)
public class RechargeSchedule {

    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "plan_id")
    private RechargePlan plan;

    @Column(name = "day_month")
    private Integer dayMonth;

    @Column(name = "day_week")
    private Integer dayWeek;

    @Column(name = "day_interval")
    private Integer dayInterval;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "last_execution_date")
    private LocalDate lastExecutionDate;

    @Column(name = "next_execution_date")
    private LocalDate nextExecutionDate;

    @Column(name = "active")
    private boolean active;

    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public String toString() {
        return new StringJoiner(", ", RechargeSchedule.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("dayMonth=" + dayMonth)
                .add("dayWeek=" + dayWeek)
                .add("dayInterval=" + dayInterval)
                .add("startDate=" + startDate)
                .add("endDate=" + endDate)
                .add("lastExecutionDate=" + lastExecutionDate)
                .add("nextExecutionDate=" + nextExecutionDate)
                .add("active=" + active)
                .toString();
    }
}
