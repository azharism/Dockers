package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DtoMMIDeviceUpdateResponse {

    @JsonProperty("user_id")
    private Long userId;

    @JsonProperty("mmi_device_id")
    private String mmiDeviceId;
}
