package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants;
import in.co.daalchini.data.constants.enums.RefillSuggestionSortBy;
import in.co.daalchini.data.transporatable.RefillSuggestionDetails;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.RefillSuggestionService;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Log4j2
public class RefillSuggestionController {

    private final RefillSuggestionService refillSuggestionService;

    public RefillSuggestionController(RefillSuggestionService refillSuggestionService) {
        this.refillSuggestionService = refillSuggestionService;
    }

    @GetMapping(RouteConstants.RefillContext.REFILL_SUGGESTION)
    @PreAuthorize("hasAuthority('slot_utilization')")
    public List<RefillSuggestionDetails> getRefillSuggestion(
            @AuthenticationPrincipal AuthUserDetails userDetails,
            @RequestParam("warehouseId") Long warehouseId,
            @RequestParam(value = "priority", required = false, defaultValue = "ALL") String priority,
            @RequestParam(value = "sortBy", required = false) String sortBy) {
        log.info("Request received for fetching suggestion for :{}", userDetails);
        try {
            var refillSuggestionSortBy = RefillSuggestionSortBy.of(sortBy);
            var response = refillSuggestionService.fetchRefillSuggestionDetails(userDetails, warehouseId, priority.toUpperCase(), refillSuggestionSortBy);
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("Error in fetching refill  suggestion details");
            throw e;
        }

    }


}
