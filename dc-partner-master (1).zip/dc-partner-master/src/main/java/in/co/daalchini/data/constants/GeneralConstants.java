package in.co.daalchini.data.constants;

import java.time.ZoneId;
import java.util.UUID;

public class GeneralConstants {

    public static final ZoneId TIME_ZONE_ID_INDIA = ZoneId.of("Asia/Kolkata");
    public static final ZoneId TIME_ZONE_ID_UTC = ZoneId.of("UTC");

    public static final long DEFAULT_CORPORATE_ID = 2;

    public static final class AuthConstants {
        public static final String TOKEN_PREFIX = "Bearer ";
    }

    public static final class BrokerConfig {
        // Param constants
        public static final String PARAM_MACHINE_ID = "machine_id";
        public static final String PARAM_PAYMENT_GATEWAY = "payment_gateway";
        public static final String PARAM_COMPLETION_REASON = "completion_reason";

        private static final UUID uuid = UUID.randomUUID();
        public static final String TOPIC_PRE_PLACED = "ORDERS_PRE_PLACED";
        public static final String TOPIC_ORDER_UPDATED_STATUS = "order.update.status";
        public static final String TOPIC_SLOT_BLOCK = "PROCESS_SLOT_BLOCKED";
        public static final String TOPIC_INVENTORY_RELEASE = "ORDER_INVENTORY_RELEASE";
        private static final String TEMPLATE_SERVICE_CLIENT_ID = "service.$serviceName-$uuid";
        // Queues
        public static final String QUEUE_SEND_NOTIFICATION = "PROCESS_SEND_NOTIFICATION";
        public static final String QUEUE_PARTNER_DUE = "PROCESS_PARTNER_DUE";
        public static final String QUEUE_ZOHO_CREATE = "QUEUE_ZOHO_CREATE";
        public static final String QUEUE_ZOHO_UPDATE = "QUEUE_ZOHO_UPDATE";
        public static final String QUEUE_ZOHO_VARIANT_UPDATE = "QUEUE_ZOHO_VARIANT_UPDATE";
        public static final String QUEUE_ZOHO_INVENTORY_SYNC = "QUEUE_ZOHO_INVENTORY_SYNC";
        public static final String QUEUE_BANK_REFUND = "QUEUE_BANK_REFUND";
        public static final String QUEUE_COMPLETABLE_ORDERS = "PROCESS_COMPLETABLE_ORDERS";
        public static final String QUEUE_DEACTIVATE_BP_USER = "PROCESS_BP_DEACTIVATION";
        public static final String QUEUE_DEREGISTER_BP_USER = "PROCESS_BP_UNLINK_ADMIN";
        public static final String QUEUE_EXPIRE_SCHEDULED_ITEM = "PROCESS_EXPIRE_SCHEDULED_ITEM";

        public static final String QUEUE_INVENTORY_HOLD_QUANTITY_CHANGE = "PROCESS_HOLD_QUANTITY_CHANGE";
        public static final String QUEUE_INVENTORY_ACTIVE_QUANTITY_CHANGE = "PROCESS_ACTIVE_QUANTITY_CHANGE";

        public static String getServiceClientId(String serviceName) {
            return TEMPLATE_SERVICE_CLIENT_ID
                    .replace("$serviceName", serviceName)
                    .replace("$uuid", uuid.toString());
        }
    }

    public static final class MobilityConfig {
        // Todo: move to properties
        public static final String ROLE_PERMISSION_NOTIFICATION = "notification_enabled";
        public static final String ROLE_DRIVER = "Mobility Partner";
    }

    public static final class PushNotificationConfig {
        public static final String SOUND = "default";
        public static final String COLOR = "#FFFF00";
    }

    public static final int LOCK_TIMEOUT_SECONDS = 5;
}
