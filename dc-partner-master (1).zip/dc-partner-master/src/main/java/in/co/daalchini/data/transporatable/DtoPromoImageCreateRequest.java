package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@JsonIncludeProperties({"platform", "type", "description", "image_path", "target_url", "activates_on", "expires_on"})
public class DtoPromoImageCreateRequest {

    @NotNull
    @JsonProperty("platform")
    private String platform;

    @NotNull
    @JsonProperty("type")
    private String type;

    @NotNull
    @JsonProperty("description")
    private String description;

    @NotNull
    @JsonProperty("image_path")
    private String imagePath;

    @JsonProperty("target_url")
    private String targetUrl;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @JsonProperty("activates_on")
    private LocalDate activatesOn;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @JsonProperty("expires_on")
    private LocalDate expiresOn;

}
