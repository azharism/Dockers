package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoHourlyMachineWiseSale;
import in.co.daalchini.models.HourlyMachineWiseSale;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface HourlyMachineWiseSaleMapper {
    @Mapping(target = "name", source = "vendingMachines.name")
    DtoHourlyMachineWiseSale toDto (HourlyMachineWiseSale machineWiseSale);
    @Mapping(target = "name", source = "vendingMachines.name")
    List<DtoHourlyMachineWiseSale> toDto (List<HourlyMachineWiseSale> machineWiseSales);
}
