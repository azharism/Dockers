package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;

public class CreateDraft {

    @Data
    @Builder
    public static final class Request {

        private Integer step;
        private Long draftId;
        private String couponName;
        private String couponDescription;
        @Size(max=45, message = "couponImage length max 45 only allowed ")
        private String couponImage;
        private String couponStartDate;
        private String couponExpiry;
        private String deeplink;
        private OrderReliability orderReliability;
        private Integer couponType;
        private CashBackDetails cashbackDetails;
        private DiscountDetails discountDetails;
        private FreeGiftDetails freeGiftDetails;
        private VmReliability vmReliability;
        private MvReliability mvReliability;
        private SlotIdReliability slotIdReliability;
        private MealTypeReliability mealTypeReliability;
        private PgReliability pgReliability;
        private UsageDurationReliability usageDurationReliability;
        private Long couponLimit;
        private Long couponDeviceUsage;
        private String tnc;
        private CouponTimeSlot couponTimeSlot;

    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class OrderReliability{
        private Boolean isOrder;
        private Double maxAmount;
        private Double minAmount;
        private Double cashbackAmount;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class VmReliability{
        private Boolean isVm;
        private List<Long> vmIds;
    }

    @Data
    public static final class CashBackDetails {
        private Integer flatTypeId;
        private Double flatAmount;
        private Double maxCashback;
    }
    @Data
    public static final class DiscountDetails {
        private Integer flatTypeId;
        private Double flatAmount;
        private Double maxDiscount;
    }

    @Data
    public static final class FreeGiftDetails{
        private List<MvIdWithPriority> mvIdWithPriorities;
    }

    @Data
    public static final class MvIdWithPriority{
        private Long mvId;
        private Integer priority;
    }

    @Data
    public static final class MvReliability{
        private Boolean isMv;
        private List<Long> mvIds;
    }

    @Data
    public static final class SlotIdReliability{
        private Boolean isSlotId;
        private List<Long> slotIds;
    }

    @Data
    public static final class MealTypeReliability{
        private Boolean isMealType;
        private List<Long> mealTypeIds;
    }

    @Data
    public static final class PgReliability{
        private Boolean isPg;
        private List<Long> pgIds;
    }

    @Data
    public static final class UsageDurationReliability{
        private Boolean isDurationLimit;
        private Integer couponFrequency;
        private Integer couponDuration;
    }

    @Data
    public static final class CouponTimeSlot{

        private Boolean isTimeSlot;

        @JsonProperty("00-01")
        private Boolean from00To01;

        @JsonProperty("01-02")
        private Boolean from01To02;

        @JsonProperty("02-03")
        private Boolean from02To03;

        @JsonProperty("03-04")
        private Boolean from03To04;

        @JsonProperty("04-05")
        private Boolean from04To05;

        @JsonProperty("05-06")
        private Boolean from05To06;

        @JsonProperty("06-07")
        private Boolean from06To07;

        @JsonProperty("07-08")
        private Boolean from07To08;

        @JsonProperty("08-09")
        private Boolean from08To09;

        @JsonProperty("09-10")
        private Boolean from09To10;

        @JsonProperty("10-11")
        private Boolean from10To11;

        @JsonProperty("11-12")
        private Boolean from11To12;

        @JsonProperty("12-13")
        private Boolean from12To13;

        @JsonProperty("13-14")
        private Boolean from13To14;

        @JsonProperty("14-15")
        private Boolean from14To15;

        @JsonProperty("15-16")
        private Boolean from15To16;

        @JsonProperty("16-17")
        private Boolean from16To17;

        @JsonProperty("17-18")
        private Boolean from17To18;

        @JsonProperty("18-19")
        private Boolean from18To19;

        @JsonProperty("19-20")
        private Boolean from19To20;

        @JsonProperty("20-21")
        private Boolean from20To21;

        @JsonProperty("21-22")
        private Boolean from21To22;

        @JsonProperty("22-23")
        private Boolean from22To23;

        @JsonProperty("23-00")
        private Boolean from23To00;
    }


    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response{
        public String couponName;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String couponDescription;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String couponImage;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String couponStartDate;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String couponExpiry;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String deeplink;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private OrderReliability orderReliability;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private Integer couponType;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private CashBackDetails rechargeCashBackDetails;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private CashBackDetails cashBackDetails;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private DiscountDetails discountDetails;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private FreeGiftDetails freeGiftDetails;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private VmReliability vmReliability;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private MvReliability mvReliability;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private SlotIdReliability slotIdReliability;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private MealTypeReliability mealTypeReliability;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private PgReliability pgReliability;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private UsageDurationReliability usageDurationReliability;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private Long couponLimit;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private Long couponDeviceUsage;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String tnc;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private CouponTimeSlot couponTimeSlot;

        private Integer nextStep;
        public String nextStepName;
        public Long draftId;
    }
}
