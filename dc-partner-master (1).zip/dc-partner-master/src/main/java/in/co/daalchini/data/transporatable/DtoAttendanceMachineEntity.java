package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.StringJoiner;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoAttendanceMachineEntity {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("entityId")
    private DtoAttendanceEntity entityId;

    @JsonProperty("vendingMachineId")
    private DtoAttendanceMachine vendingMachineId;


    @Override
    public String toString() {
        return new StringJoiner(", ", DtoAttendanceMachineEntity.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("entityId=" + (null == entityId ? null : entityId.getId()))
                .add("vendingMachineId=" + (null == vendingMachineId ? null : vendingMachineId.getId()))
                .toString();
    }
}
