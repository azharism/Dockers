package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants;
import in.co.daalchini.data.transporatable.Hsn;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.HsnService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Log4j2
public class HsnRoute {

    private final HsnService hsnService;

    @Autowired
    public HsnRoute(HsnService hsnService){
        this.hsnService = hsnService;
    }

    @GetMapping(RouteConstants.HsnContext.HSN_CODES)
    public List<Hsn.CodesResponse> fetchHsnCodes(@AuthenticationPrincipal AuthUserDetails userDetails,
                                                 @RequestParam(name = "sub_heading_id", required = false) Long subHeadingId,
                                                 @RequestParam(name = "search_query", required = false) String searchQuery){
        log.info("[fetchHsnCodes] : userId :{}, subHeadingId :{}, searchQuery :{}", userDetails.getUserId(), subHeadingId, searchQuery);
        List<Hsn.CodesResponse> response;
        try {
            response = hsnService.getHsnCodes(subHeadingId, searchQuery);
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error in fetching hsn codes :{}", e.getMessage());
            throw e;
        }
        return response;
    }

    @GetMapping(RouteConstants.HsnContext.HSN_CHAPTER)
    public List<Hsn.ChapterResponse> fetchHsnChapters(@AuthenticationPrincipal AuthUserDetails userDetails){
        log.info("[fetchHsnChapters] : userId :{}", userDetails.getUserId());
        List<Hsn.ChapterResponse> response;
        try {
            response = hsnService.getAllChapters();
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error in fetching hsn codes :{}", e.getMessage());
            throw e;
        }
        return response;
    }

    @GetMapping(RouteConstants.HsnContext.HSN_HEADINGS)
    public List<Hsn.HeadingsResponse> fetchHsnHeadings(@AuthenticationPrincipal AuthUserDetails userDetails,
                                                 @RequestParam(name = "chapter_id", required = false) Long chapterId){
        log.info("[fetchHsnHeadings] : userId :{}, chapterId :{}", userDetails.getUserId(), chapterId);
        List<Hsn.HeadingsResponse> response;
        try {
            response = hsnService.getHeadings(chapterId);
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error in fetching hsn codes :{}", e.getMessage());
            throw e;
        }
        return response;
    }

    @GetMapping(RouteConstants.HsnContext.HSN_SUB_HEADINGS)
    public List<Hsn.SubHeadingsResponse> fetchHsnSubHeadings(@AuthenticationPrincipal AuthUserDetails userDetails,
                                                 @RequestParam(name = "heading_id", required = false) Long headingId){
        log.info("[fetchHsnSubHeadings] : userId :{}, headingId :{}", userDetails.getUserId(), headingId);
        List<Hsn.SubHeadingsResponse> response;
        try {
            response = hsnService.getSubHeadings(headingId);
            log.info("Response :{}", response);
        } catch (Exception e) {
            log.error("Error in fetching hsn codes :{}", e.getMessage());
            throw e;
        }
        return response;
    }

}
