package in.co.daalchini.exception;

public class BusinessException extends RuntimeException {
    private static final long serialVersionUID = 5227468995814082187L;

    public BusinessException (String message) {
        super(message);
    }

    public BusinessException (String message, Throwable cause) {
        super(message, cause);
    }

    public static BusinessException of (String message) {
        return new BusinessException(message);
    }

    public static BusinessException of (String message, Exception e) {
        return new BusinessException(message, e);
    }
}
