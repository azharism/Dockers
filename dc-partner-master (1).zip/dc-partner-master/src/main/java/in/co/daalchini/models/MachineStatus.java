package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.StringJoiner;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vending_machine_status")
public class MachineStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "vending_machine_id")
    private Long vendingMachineId;

    @Column(name = "current_order_id")
    private String currentOrderId;

    @Column(name = "status")
    private String status;

    @Column(name = "app_version")
    private String appVersion;

    @Column(name = "client_remote_address")
    private String clientRemoteAddress;

    @Column(name = "updated_at")
    private Instant updatedAt;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vending_machine_id", insertable = false, updatable = false)
    private VendingMachine vendingMachine;

    @Override
    public String toString () {
        return new StringJoiner(", ", MachineStatus.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("vendingMachineId=" + vendingMachineId)
            .add("currentOrderId='" + currentOrderId + "'")
            .add("status='" + status + "'")
            .add("appVersion='" + appVersion + "'")
            .add("clientRemoteAddress='" + clientRemoteAddress + "'")
            .add("updatedAt=" + updatedAt)
            .toString();
    }
}
