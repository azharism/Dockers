package in.co.daalchini.data.transporatable;

import lombok.*;

public class SlotReported {
    @Builder
    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Request {
        private Long slotId;
        private Long vmId;
    }

    @Builder
    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Response {
        private Boolean isSlotReported;
        private String reason;
    }
}
