package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Collection;

@Data
@JsonIncludeProperties({"id", "name", "machine_id_list", "promo_id_list", "active"})
public class DtoPromoCohortOverride {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("name")
    private String name;

    @JsonProperty("machine_id_list")
    private Collection<Long> machineIdList;

    @JsonProperty("promo_id_list")
    private Collection<Long> promoIdList;

    @JsonProperty("active")
    private boolean active;
}
