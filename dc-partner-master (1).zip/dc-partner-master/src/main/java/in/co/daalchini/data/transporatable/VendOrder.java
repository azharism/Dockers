package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.*;

import java.util.StringJoiner;

public class VendOrder {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static final class Request {

        @JsonProperty("PIN")
        private String PIN;

        @JsonProperty("vending_machine_id")
        private Long vending_machine_id;

        @JsonProperty("mobile")
        private String mobile;

        public static Request of(DeliveryComplete.Request request, String mobile) {
            return Request.builder()
                    .PIN(request.getPin())
                    .vending_machine_id(request.getVendingMachineId())
                    .mobile(mobile).build();
        }

        public static Request of(OrderComplete.Request request, String mobile) {
            return Request.builder()
                    .PIN(request.getPin())
                    .vending_machine_id(request.getVendingMachineId())
                    .mobile(mobile).build();
        }

        @Override
        public String toString() {
            return new StringJoiner(", ", Request.class.getSimpleName() + "[", "]")
                    .add("PIN='" + PIN + "'")
                    .add("vending_machine_id=" + vending_machine_id)
                    .add("mobile='" + PiiHelper.maskPhone(mobile) + "'")
                    .toString();
        }
    }

    @Builder
    @Getter
    @ToString
    @EqualsAndHashCode
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private final String id;
        private final String status;

        @JsonCreator
        public Response(
                @JsonProperty("id") final String id,
                @JsonProperty("status") final String status) {
            this.id = id;
            this.status = status;
        }
    }

}
