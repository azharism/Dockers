package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.TreeSet;

@Data
@JsonIncludeProperties({"name", "machine_id_list", "promo_id_list"})
public class DtoPromoOverrideCreateRequest {

    @NotNull
    @Size(min = 3, max = 100)
    @NoLeadingAndTrailingSpace
    @JsonProperty("name")
    private String name;

    @NotNull
    @Size(min = 1)
    @JsonProperty("machine_id_list")
    private TreeSet<Long> machineIdList;

    @NotNull
    @Size(min = 1)
    @JsonProperty("promo_id_list")
    private TreeSet<Long> promoIdList;
}
