package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateWarehouseLocationRequest {
    @NotBlank
    @Size(max = 100)
    @NoLeadingAndTrailingSpace
    @JsonProperty("title")
    private String title;

    @NotBlank
    @Size(max = 45)
    @NoLeadingAndTrailingSpace
    @JsonProperty("gstin")
    private String gstin;

    @NotBlank
    @Size(max = 500)
    @NoLeadingAndTrailingSpace
    @JsonProperty("address")
    private String address;
}
