package in.co.daalchini.models;


import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@ToString
@Table(name = "sku_groups")
@EntityListeners(AuditingEntityListener.class)
public class SkuGroup implements Serializable {

	@Serial
	private static final long serialVersionUID = -4326005301208826760L;

	@Id
	private Long id;

	@With
	@Column(name = "warehouse_id")
	private Long warehouseId;

	@With
	@Column(name = "zoho_item_type_id")
	private Long zohoItemTypeId;

	private String batch;

	@Column(name = "checked_in")
	private Double checkedIn;

	@Column(name = "created_at")
	@CreationTimestamp
	private LocalDateTime createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expiry_date")
	private Date expiryDate;

	@Column(name = "manufacturer_variant_id")
	private Long manufacturerVariantId;

	private Double filled;

	@Column(name = "in_transit")
	private Integer inTransit;

	@Column(name = "manufacture_date")
	@CreationTimestamp
	private Date manufactureDate;

	@Column(name = "sku_number")
	private Integer skuNumber;

	private Integer sold;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at")
	@UpdateTimestamp
	private Date updatedAt;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "zoho_item_type_id",insertable = false, updatable = false)
	private ZohoItemTypes zohoItemTypes;

	// bi-directional many-to-one association to Warehouse
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "warehouse_id",insertable = false, updatable = false)
	private Warehouse warehouse;

	// bi-directional many-to-one association to ManufacturerVariant
	@ManyToOne
	@JoinColumn(name = "manufacturer_variant_id",insertable = false, updatable = false)
	private ManufacturerVariant manufacturerVariant;

	// bi-directional many-to-one association to
	// VendingMachineManufacturerVariantSkuGroupMapping
	/*
	 * @OneToMany(mappedBy="skuGroup") private
	 * List<VendingMachineManufacturerVariantSkuGroupMapping>
	 * vendingMachineManufacturerVariantSkuGroupMappings;
	 */

}
