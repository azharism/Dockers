package in.co.daalchini.data.transporatable;

import lombok.*;

import java.util.List;

@Builder
@Data
@AllArgsConstructor
@ToString
public class VMResponse {

    @Data
    @Builder
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PingFailure {
        private Long vmId;
        private String vmName;
        private String city;
        private String timeSinceLastUpdate;
        private String status;
    }
    @Data
    @Builder
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Health {
        private Long vmId;
        private String vmName;
        private String city;
        private String timeSinceLastUpdate;
    }
    @Data
    @Builder
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HealthResponse {
        private List<String> city;
        private List<Health> health;
    }
    @Data
    @Builder
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PingFailureResponse {
        private List<String> city;
        private List<PingFailure> pingFailure;
    }

}
