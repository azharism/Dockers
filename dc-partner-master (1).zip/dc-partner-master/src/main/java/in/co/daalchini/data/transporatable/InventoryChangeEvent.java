package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.data.constants.enums.ChangeType;
import in.co.daalchini.data.transporatable.message.Jsonable;
import in.co.daalchini.service.helper.JsonUtil;
import lombok.Builder;
import lombok.Data;

@Data
public class InventoryChangeEvent implements Jsonable {
    private Long vmId;
    private Long slotId;
    private Long vmMvSkuId;
    private Integer finalQuantity;
    private Integer delta;
    private String updatedBy;
    private String reason;
    private ChangeType changeType;
    private String source;

    @JsonCreator
    @Builder
    public InventoryChangeEvent(
            @JsonProperty("vmId") Long vmId,
            @JsonProperty("slotId") Long slotId,
            @JsonProperty("vmMvSkuId") Long vmMvSkuId,
            @JsonProperty("finalQuantity") Integer finalQuantity,
            @JsonProperty("delta") Integer delta,
            @JsonProperty("updatedBy") String updatedBy,
            @JsonProperty("reason") String reason,
            @JsonProperty("changeType") String changeType,
            @JsonProperty("source") String source

    ) {
        this.vmId = vmId;
        this.slotId = slotId;
        this.vmMvSkuId = vmMvSkuId;
        this.finalQuantity = finalQuantity;
        this.delta = delta;
        this.updatedBy = updatedBy;
        this.reason = reason;
        this.changeType = ChangeType.of(changeType);
        this.source = source;
    }

    @Override
    public String json() {
         return JsonUtil.toJson(this);
    }
}

