package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;


public final class OutletSearch {

    @Data
    @Builder
    public static final class Response {
        public Long id;
        public String name;
        public String address;
        public Double latitude;
        public Double longitude;
    }
}
