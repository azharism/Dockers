package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.service.helper.PiiHelper;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.StringJoiner;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DtoAttendanceManufacturer {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("name")
    private String name;

    @JsonProperty("phone_number")
    private String phoneNumber;

    @JsonProperty("email")
    private String email;

    @JsonProperty("manufacturersAddress")
    private List<DtoAttendanceWarehouseAddress> manufacturersAddresses;

    @Override
    public String toString() {
        return new StringJoiner(", ", DtoAttendanceManufacturer.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("name='" + name + "'")
                .add("phoneNumber='" + PiiHelper.maskPhone(phoneNumber) + "'")
                .add("email='" + PiiHelper.maskEmail(email) + "'")
                .add("manufacturersAddresses length=" + (null == manufacturersAddresses ? null : manufacturersAddresses.size()))
                .toString();
    }
}
