package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.Hsn;
import in.co.daalchini.models.HsnChapters;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface HsnChapterMapper {

    Hsn.ChapterResponse toDto(HsnChapters hsnChapters);

    List<Hsn.ChapterResponse> toDto(List<HsnChapters> hsnChapters);
}
