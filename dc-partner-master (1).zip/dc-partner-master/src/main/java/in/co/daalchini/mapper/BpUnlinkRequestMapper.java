package in.co.daalchini.mapper;

import in.co.daalchini.data.transporatable.DtoBpUnlinkResponse;
import in.co.daalchini.messaging.BpDeregisterChangeEvent;
import in.co.daalchini.models.BpUnlinkRequest;
import in.co.daalchini.models.UserCorporateMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BpUnlinkRequestMapper {

    @Mapping(target = "id", source = "id")
    @Mapping(target = "status", source = "status")
    @Mapping(target = "userCorporateMappingId", source = "userCorporateMappingId")
    DtoBpUnlinkResponse toDto (BpUnlinkRequest unlinkRequest);

    @Mapping(target = "ucmId", source = "id")
    @Mapping(target = "employeeId", source = "usersCorporateId")
    BpDeregisterChangeEvent toChangeEvent (UserCorporateMapping ucm);
}
