package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import in.co.daalchini.config.NoLeadingAndTrailingSpace;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIncludeProperties({"username", "password", "latitude", "longitude"})
public final class DtoUserLoginRequest {

    @NotNull
    @Size(max = 50)
    @NoLeadingAndTrailingSpace
    @JsonProperty("username")
    private String username;

    @NotNull
    @Size(max = 50)
    @NoLeadingAndTrailingSpace
    @JsonProperty("password")
    private String password;

    @NotNull
    @DecimalMin("-90.0")
    @DecimalMax("90.0")
    @Digits(integer = 2, fraction = 8)
    @JsonProperty("latitude")
    private Double latitude;

    @NotNull
    @DecimalMin("-180")
    @DecimalMax("180")
    @Digits(integer = 3, fraction = 8)
    @JsonProperty("longitude")
    private Double longitude;

}
