package in.co.daalchini.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name = "refill_suggestion_urgency_score")
public class RefillSuggestionUrgencyScore implements Comparable<RefillSuggestionUrgencyScore> {
    @Id
    @Column(name = "id", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "machine_id")
    private Long machineId;

    @Column(name = "last_refilled_date")
    private LocalDate lastRefilledDate;

    @Column(name = "current_stock")
    private Long currentStock;

    @Column(name = "full_stock_cap")
    private Integer fullStockCap;

    @Column(name = "occupancy_ratio")
    private Float occupancyRatio;

    @Column(name = "non_empty_ratio")
    private Float nonEmptyRatio;

    @Column(name = "avg_sales")
    private Float weeklyAverageSales;

    @Column(name = "sales_minus_7")
    private Float salesMinus7;

    @Column(name = "urgency_score")
    private Float urgencyScore;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", insertable = false, updatable = false)
    @ToString.Exclude
    private VendingMachine vendingMachine;

    @Override
    public int compareTo (RefillSuggestionUrgencyScore r) {
        return this.urgencyScore.compareTo(r.urgencyScore);
    }
}