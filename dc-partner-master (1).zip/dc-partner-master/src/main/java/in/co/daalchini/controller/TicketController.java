package in.co.daalchini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.co.daalchini.DTO.SubSubTypeDTO;
import in.co.daalchini.DTO.SubTypeDTO;
import in.co.daalchini.DTO.TicketTypeDto;
import in.co.daalchini.data.constants.RouteConstants.TicketContext;
import in.co.daalchini.exception.ItemNotFoundException;
import in.co.daalchini.mapper.SubSubTypeMapper;
import in.co.daalchini.mapper.SubTypeMapper;
import in.co.daalchini.mapper.TicketTypeMapper;
import in.co.daalchini.service.TicketTypeService;
import lombok.extern.log4j.Log4j2;

import java.util.List;

@Log4j2
@RestController
public class TicketController {

    @Autowired
    TicketTypeService ticketTypeService;

    public TicketTypeMapper ticketTypeMapper = TicketTypeMapper.INSTANCE;

    public SubTypeMapper subTypeMapper = SubTypeMapper.INSTANCE;

    public SubSubTypeMapper subSubTypeMapper = SubSubTypeMapper.INSTANCE;

    @GetMapping(TicketContext.TYPE)
    public ResponseEntity<List<TicketTypeDto>> findByDashBoardUserAllowed (@RequestParam(required = false) Boolean id,
                                                                           @RequestParam Integer userType,
                                                                           @RequestParam(required = false)
                                                                               Integer ticketType,
                                                                           @RequestParam(required = true)
                                                                               Integer roleId) throws Exception
    {
        try {
            if (id == null)
                id = true;

            if (roleId != null) {
                if (userType == 1) {
                    return ResponseEntity.ok(ticketTypeMapper.toTicketTypeDTOs(ticketTypeService
                                                                                   .findByRoleIDAnddashboardAllowedtypesAndTicketType(
                                                                                       roleId,
                                                                                       id,
                                                                                       ticketType)));
                } else if (userType == 2) {
                    return ResponseEntity.ok(ticketTypeMapper.toTicketTypeDTOs(
                        ticketTypeService.findByRoleIDAnduserAllowedtypesAndTicketType(roleId, id, ticketType)));
                } else if (userType == 3) {
                    return ResponseEntity.ok(ticketTypeMapper.toTicketTypeDTOs(
                        ticketTypeService.findByRoleIDAndsystemAllowedtypesAndTicketType(roleId, id, ticketType)));
                }
                throw new ItemNotFoundException("No Type found as per your request");
            }
            throw new ItemNotFoundException("Role Id is mandatory");
        } catch (Exception e) {
            log.error("error : {}", e.getMessage());
            throw e;
        }
    }

    @GetMapping(TicketContext.SUB_TYPE)
    public ResponseEntity<List<SubTypeDTO>> findByType (@RequestParam Integer type) throws Exception {
        try {
            return ResponseEntity.ok(subTypeMapper.toSubTypeDTOs(ticketTypeService.findByTypeOfTicketId(type)));
        } catch (Exception e) {
            log.error("error : {}", e.getMessage());
            throw e;
        }
    }

    @GetMapping(TicketContext.SUB_SUB_TYPE)
    public ResponseEntity<List<SubSubTypeDTO>> findBySubType (@RequestParam Integer type) throws Exception {
        try {
            return ResponseEntity.ok(subSubTypeMapper.toSubSubTypeDTOs(ticketTypeService.findByTypeOfSubTypeId(type)));
        } catch (Exception e) {
            log.error("error : {}", e.getMessage());
            throw e;
        }
    }

}
