package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

public final class DeleteWallet {

    @Data
    @Builder
    public static final class Request {
        private Long ownerId;
        private String subOwnerId;
        @Default
        private WalletType type = WalletType.Prepaid;
        @Default
        private WalletSubType subType = WalletSubType.Normal;

        public static Request ofInternalCorporate(Long corporateId) {
            return DeleteWallet.Request.builder()
                    .ownerId(corporateId)
                    .subOwnerId(null)
                    .type(WalletType.Overdraft)
                    .subType(WalletSubType.Internal)
                    .build();
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private Boolean active;
        private Long walletId;
    }
}
