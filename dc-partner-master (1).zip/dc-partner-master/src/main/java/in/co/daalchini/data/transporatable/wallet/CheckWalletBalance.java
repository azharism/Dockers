package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

public final class CheckWalletBalance {

    @Data
    @Builder
    public static final class Request {
        private Long ownerId;
        private String subOwnerId;
        @Default private WalletType type = WalletType.Prepaid;
        @Default private WalletSubType subType = WalletSubType.Normal;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private Double balance;
    }
}

