package in.co.daalchini.data.transporatable;

import in.co.daalchini.data.untransportable.OrderState;
import in.co.daalchini.models.PartnerAddress;
import in.co.daalchini.models.PartnerOrderDelivery;
import in.co.daalchini.models.PartnerOrderPickup;
import lombok.Builder;
import lombok.Data;


import java.time.LocalDateTime;
import java.util.List;
import in.co.daalchini.data.transporatable.OrderHistory.LineItem;
import in.co.daalchini.data.transporatable.ScheduledPickupDelivery.*;

public class FetchOrderDetails {
    @Data
    @Builder
    public static final class Response {

        private Long vendingMachineId;
        private String vendingMachineAddress;
        private Long paymentId;
        private String orderId;
        private OrderState status;
        private String displayStatus;
        private Double amount;
        private Double mrp;
        private String dcCode;
        private LocalDateTime createdAt;
        private List<LineItem> lineItems;
        private PickupDetails pickupDetails;
        private DeliveryDetails deliveryDetails;

    }

}
