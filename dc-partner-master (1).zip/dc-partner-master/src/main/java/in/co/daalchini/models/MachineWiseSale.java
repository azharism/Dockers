package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "machine_wise_sales")
public class MachineWiseSale {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "machine_id")
    private Long machineId;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "success_quantity")
    private Integer successQuantity;

    @Column(name = "sale")
    private Double sale;
}
