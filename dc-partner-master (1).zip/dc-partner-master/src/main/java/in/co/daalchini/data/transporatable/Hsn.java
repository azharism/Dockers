package in.co.daalchini.data.transporatable;

import lombok.Builder;
import lombok.Data;

public class Hsn {

    @Data
    @Builder
    public static final class CodesResponse {
        private Long id;
        private String value;
        private String description;
    }

    @Data
    @Builder
    public static final class ChapterResponse {
        private Long id;
        private String value;
        private String description;
    }

    @Data
    @Builder
    public static final class HeadingsResponse {
        private Long id;
        private String value;
        private String description;
    }

    @Data
    @Builder
    public static final class SubHeadingsResponse {
        private Long id;
        private String value;
        private String description;
    }

}
