package in.co.daalchini.controller;


import in.co.daalchini.Interfaces.IUserNotificationFileMappingService;
import in.co.daalchini.data.constants.DCConstants;
import in.co.daalchini.exception.BusinessException;
import in.co.daalchini.models.response.SendNotificationResponse;
import in.co.daalchini.service.helper.UserNotificationFileStructure;
import in.co.daalchini.models.UserNotificationFileMapping;
import in.co.daalchini.models.response.DCResponse;
import in.co.daalchini.util.CsvUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import in.co.daalchini.data.constants.RouteConstants.SendNotification;

import java.util.List;

@RestController
@Log4j2
public class NotificationController {

     private IUserNotificationFileMappingService notificationService;
     @Autowired
     public NotificationController(IUserNotificationFileMappingService notificationService){
         this.notificationService=notificationService;
     }

    @RequestMapping(value = SendNotification.NOTIFICATION_USER_CSV_UPLOAD, method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public @ResponseBody
    DCResponse<List<UserNotificationFileMapping>> corpUserFileDump(@RequestParam("file") MultipartFile file, @RequestParam("type") String type, @RequestParam("campaign_id") String campaignId) {

        log.info("NotificationController corpUserFileDump, type = {}, campaign_id = {}", type, campaignId);
        DCResponse<List<UserNotificationFileMapping>> res=null;
        List<UserNotificationFileStructure> corporateModelsList = null;

        try {
            if(file==null || file.isEmpty() || file.getSize()<1)
                throw new BusinessException("Empty File Uploaded");

            if(type==null || type.length()<1)
                throw new BusinessException("Empty Corporate-Id recieved");

            if(campaignId==null || campaignId.length()<1)
                throw new BusinessException("Empty Corporate-Id recieved");

            log.info("[NotificationController] : [corpUserFileDump] : Reading File...");
            corporateModelsList = CsvUtils.readUserNotificationFileMappings(file, type,campaignId);
            res = this.notificationService.saveUsersInDump(corporateModelsList);
            log.info("[NotificationController] : [corpUserFileDump] : Persisting File Completed...");

        } catch (BusinessException e) {
            res = new DCResponse<>();
            res.setStatus(DCConstants.API_FAILURE);
            res.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
            res.setStatusMessage(e.getMessage());
        }
        log.info("NotificationController corpUserFileDump, response = {}", res);
        return res;
    }


    @RequestMapping(value = SendNotification.SEND_NOTIFICATION, method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public @ResponseBody DCResponse<SendNotificationResponse> sendNotification(@RequestParam("file_name") String fileName,
                                                                               @RequestParam("campaign_id") String campaignId, @RequestParam("text") String text, @RequestParam("heading") String heading,
                                                                               @RequestParam("image_url") String imageUrl) {


        log.info("NotificationController sendNotification, fileName = {}, campaignId = {}, heading = {}, text = {}, imageUrl = {}", fileName, campaignId, heading, text, imageUrl);
        DCResponse<SendNotificationResponse> res=null;

        try {
            if((fileName==null || fileName.length()<1) && (campaignId==null || campaignId.length()<1) && (heading==null || heading.length()<1) && (text==null || text.length()<1) && (imageUrl==null || imageUrl.length()<1))
                throw new BusinessException("Empty File Name recieved");

            try {
                res = this.notificationService.sendNotification(fileName, campaignId, text, heading, imageUrl);

            }catch (Exception e) {
                res = new DCResponse<>();
                res.setStatus(DCConstants.API_FAILURE);
                res.setStatusMessage(e.getMessage());
            }


        }
        catch (BusinessException e) {
            res = new DCResponse<>();
            res.setStatus(DCConstants.API_FAILURE);
            res.setStatusCode(DCConstants.API_FAILURE_CODE_OTHER);
            res.setStatusMessage(e.getMessage());
        }

        log.info("NotificationController sendNotification, response = {}", res);
        return res;
    }
}
