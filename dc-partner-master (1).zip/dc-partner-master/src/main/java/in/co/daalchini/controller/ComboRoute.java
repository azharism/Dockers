package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.service.ComboService;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collection;
import java.util.List;

@RestController
@Log4j2
public class ComboRoute {
    private final ComboService comboService;

    public ComboRoute(ComboService comboService) {
        this.comboService = comboService;
    }

    @PostMapping(RouteConstants.ComboContext.COMBO_CREATE)
    public RestResponseV2<ComboDetailDto> createCombo(@RequestBody @Valid ComboDetailDto comboDetailDto){
        log.info("[createCombo] request : {}", comboDetailDto);
        var response = comboService.createCombo(comboDetailDto);
        log.info("[createCombo] response : {}", response);
        return RestResponseV2.ofSuccess(response);
    }

    @PatchMapping(RouteConstants.ComboContext.COMBO_UPDATE)
    public RestResponseV2<ComboDetailDto> updateCombo(@RequestBody @Valid ComboDetailDto comboDetailDto,
                                                      @PathVariable(name = "comboId") Long comboId){
        log.info("[updateCombo] request : {}", comboDetailDto);
        var response = comboService.updateComboDetails(comboId, comboDetailDto);
        log.info("[updateCombo] response : {}", response);
        return RestResponseV2.ofSuccess(response);
    }

    @GetMapping(RouteConstants.ComboContext.COMBO_FETCH)
    public RestResponseV2<ComboDetailDto> fetchCombo(@PathVariable(name = "comboId") Long comboId){
        log.info("[fetchCombo] comboId : {}", comboId);
        var response = comboService.fetchComboDetails(comboId);
        log.info("[fetchCombo] response : {}", response);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @GetMapping(RouteConstants.ComboContext.COMBO_TYPE_COHORT)
    public RestResponseV2<Collection<DtoComboCohort>> getComboCohorts() {
        var response = comboService.getComboCohorts();
        return RestResponseV2.ofSuccess(response);
    }

    @PutMapping(RouteConstants.ComboContext.COMBO_COHORT)
    public RestResponseV2<String> comboCohortConfig(@RequestBody ComboCohortDto comboCohortDto,
                                                    @PathVariable(name = "comboId") Long comboId,
                                                    @PathVariable(name = "cohortId") Long cohortId){
        log.info("[comboCohortConfig] request : {}", comboCohortDto);
        comboService.configCohortCombo(comboId,cohortId, comboCohortDto);

        return RestResponseV2.ofSuccess("Accepted");
    }

    @DeleteMapping(RouteConstants.ComboContext.COMBO_COHORT)
    public RestResponseV2<String> deleteComboCohortConfig(
            @PathVariable(name = "cohortId") Long cohortId,
            @PathVariable(name = "comboId") Long comboId){
        log.info("[deleteComboCohortConfig],comboId : {} cohortId :{}", comboId, cohortId);
        comboService.deactivateComboCohortConfig(comboId,cohortId);

        return RestResponseV2.ofSuccess("Accepted");
    }

    @GetMapping(RouteConstants.ComboContext.COMBO_COHORT_ALL)
    public RestResponseV2<List<ComboDto>> getCombosInCohort(
            @PathVariable(name = "cohortId") Long cohortId){
        log.info("[getCombosInCohort] cohortId : {}", cohortId);
        var response = comboService.fetchAllCombosInCohort(cohortId);
        log.info("[getCombosInCohort] response : {}", response);

        return RestResponseV2.ofSuccess(response);
    }
}
