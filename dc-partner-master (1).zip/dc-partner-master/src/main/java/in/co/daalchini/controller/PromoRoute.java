package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.PromoContext;
import in.co.daalchini.data.constants.enums.PromoImageType;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.wrapper.RestResponseV2;
import in.co.daalchini.service.PromoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collection;

@Slf4j
@RestController
public class PromoRoute {

    private final PromoService promoService;

    public PromoRoute(
            PromoService promoService
    ) {
        this.promoService = promoService;
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(PromoContext.PROMO_IMAGE)
    public RestResponseV2<DtoPromoImage> createPromoImage(
            @RequestBody @Valid DtoPromoImageCreateRequest request
    ) {
        var response = promoService.createPromoImage(request);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @GetMapping(PromoContext.PROMO_IMAGE)
    public RestResponseV2<Collection<DtoPromoImage>> getPromoImages(
            @RequestParam(name = "type", required = false) PromoImageType type,
            @RequestParam(name = "include_inactive", required = false, defaultValue = "false") Boolean includeInactive
    ) {
        var response = promoService.getPromoImages(type, includeInactive);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @PatchMapping(PromoContext.PROMO_IMAGE_WITH_ID)
    public RestResponseV2<DtoPromoImage> updatePromoImage(
            @PathVariable Long imageId,
            @RequestBody @Valid DtoPromoImageUpdateRequest request
    ) {
        var response = promoService.updatePromoImage(imageId, request);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping(PromoContext.PROMO_IMAGE_WITH_ID)
    public void deletePromoImage(@PathVariable Long imageId) {
        promoService.deletePromoImage(imageId);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @GetMapping(PromoContext.PROMO_COHORT)
    public RestResponseV2<Collection<DtoPromoCohort>> getPromoCohorts() {
        var response = promoService.getPromoCohorts();
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @GetMapping(PromoContext.PROMO_COHORT_WITH_ID_CONFIG)
    public RestResponseV2<DtoPromoCohortConfig> getCohortPromoConfig(
            @PathVariable Long cohortId
    ) {
        var response = promoService.getCohortPromoConfig(cohortId);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @PutMapping(PromoContext.PROMO_COHORT_WITH_ID_CONFIG)
    public RestResponseV2<DtoPromoCohortConfig> setCohortPromoConfig(
            @PathVariable Long cohortId,
            @RequestBody @Valid DtoPromoCohortConfigPutRequest request
    ) {
        var response = promoService.setCohortPromoConfig(cohortId, request);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @GetMapping(PromoContext.PROMO_COHORT_WITH_ID_IMAGE)
    public RestResponseV2<Collection<DtoPromoCohortImage>> getCohortPromoImages(
            @PathVariable Long cohortId,
            @RequestParam(name = "type") PromoImageType type
    ) {
        var response = promoService.getCohortPromoImages(cohortId, type);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @PutMapping(PromoContext.PROMO_COHORT_WITH_ID_IMAGE)
    public RestResponseV2<Collection<DtoPromoCohortImage>> setCohortPromoImages(
            @PathVariable Long cohortId,
            @RequestParam(name = "type") PromoImageType type,
            @RequestBody Collection<@Valid DtoPromoCohortImagePutRequest> requests
    ) {
        var response = promoService.setCohortPromoImages(cohortId, type, requests);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @GetMapping(PromoContext.PROMO_COHORT_WITH_ID_OVERRIDE)
    public RestResponseV2<Collection<DtoPromoCohortOverride>> getCohortPromoOverrides(
            @PathVariable Long cohortId,
            @RequestParam(name = "include_inactive", required = false, defaultValue = "false") Boolean includeInactive
    ) {
        var response = promoService.getCohortPromoOverrides(cohortId, includeInactive);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(PromoContext.PROMO_COHORT_WITH_ID_OVERRIDE)
    public RestResponseV2<DtoPromoCohortOverride> createCohortPromoOverride(
            @PathVariable Long cohortId,
            @RequestBody @Valid DtoPromoOverrideCreateRequest request
    ) {
        var response = promoService.createCohortPromoOverride(cohortId, request);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @PatchMapping(PromoContext.PROMO_COHORT_WITH_ID_OVERRIDE_ID)
    public RestResponseV2<DtoPromoCohortOverride> updateCohortPromoOverride(
            @PathVariable Long cohortId,
            @PathVariable Long overrideId,
            @RequestBody @Valid DtoPromoOverrideUpdateRequest request
    ) {
        var response = promoService.updateCohortPromoOverride(overrideId, cohortId, request);
        return RestResponseV2.ofSuccess(response);
    }

    @PreAuthorize("hasAuthority('banner_create')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping(PromoContext.PROMO_COHORT_WITH_ID_OVERRIDE_ID)
    public void deactivateCohortPromoOverride(
            @PathVariable Long cohortId,
            @PathVariable Long overrideId
    ) {
        promoService.deactivateCohortPromoOverride(overrideId, cohortId);
    }
}
