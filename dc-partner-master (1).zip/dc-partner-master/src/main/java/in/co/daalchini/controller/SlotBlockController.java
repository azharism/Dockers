package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants;
import in.co.daalchini.data.transporatable.SlotBlockDto;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.service.SlotBlockedService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Log4j2
public class SlotBlockController {


    private final SlotBlockedService slotBlockedService;

    @Autowired
    public SlotBlockController(SlotBlockedService slotBlockedService) {
        this.slotBlockedService = slotBlockedService;
    }

    @GetMapping(RouteConstants.SlotBlockContext.SLOT_BLOCK)
    public SlotBlockDto.Response slotBlockReasons(
            @AuthenticationPrincipal AuthUserDetails userDetails)
    {
        try {
            var  response = slotBlockedService.fetchBlockedSlotsWithReason();
            log.info("Response :{}",response);
            return response;
        } catch (Exception e) {
            log.error("Caught error :{}", e.getMessage());
            throw e;
        }
    }
}
