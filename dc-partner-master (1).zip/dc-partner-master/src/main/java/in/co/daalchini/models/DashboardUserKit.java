package in.co.daalchini.models;

import lombok.*;

import javax.persistence.*;
import java.util.List;
import java.util.StringJoiner;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dashboard_user_kits")
public class DashboardUserKit {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(mappedBy = "kit")
    private DashboardUserKitsRefills kitsRefills;

    @OneToMany(mappedBy = "kit")
    private List<DashboardUserKitDetail> kitDetails;

    @Override
    public String toString () {
        return new StringJoiner(", ", DashboardUserKit.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .toString();
    }
}
