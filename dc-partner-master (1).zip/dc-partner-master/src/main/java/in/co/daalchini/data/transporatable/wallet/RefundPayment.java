package in.co.daalchini.data.transporatable.wallet;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

public final class RefundPayment {

    @Data
    @Builder
    public static final class Request {
        private Long ownerId;
        private String subOwnerId;
        @Default private WalletType type = WalletType.Overdraft;
        @Default private WalletSubType subType = WalletSubType.Normal;
        private String orderId;
        private Long transactionId;
        private Double amount;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Response {
        private String orderId;
        private Double balance;
        private Long transactionId;
    }
}

