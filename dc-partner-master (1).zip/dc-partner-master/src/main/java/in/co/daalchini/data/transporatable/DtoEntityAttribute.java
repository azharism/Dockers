package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.StringJoiner;

@Data
@Builder
public class DtoEntityAttribute {

    @JsonProperty("vendingMachineId")
    private DtoAttendanceMachine vendingMachineId;

    @JsonProperty("manufacturerId")
    private DtoAttendanceManufacturer manufacturerId;

    @JsonProperty("warehouseId")
    private DtoAttendanceWarehouse warehouseId;


    @Override
    public String toString() {
        return new StringJoiner(", ", DtoEntityAttribute.class.getSimpleName() + "[", "]")
                .add("vendingMachineId=" + (null == vendingMachineId ? null : vendingMachineId.getId()))
                .add("manufacturerId=" + (null == manufacturerId ? null : manufacturerId.getId()))
                .add("warehouseId=" + (null == warehouseId ? null : warehouseId.getId()))
                .toString();
    }
}
