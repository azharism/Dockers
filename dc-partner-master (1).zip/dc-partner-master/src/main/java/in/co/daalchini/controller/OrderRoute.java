package in.co.daalchini.controller;

import in.co.daalchini.data.constants.RouteConstants.OrderContext;
import in.co.daalchini.data.transporatable.*;
import in.co.daalchini.data.transporatable.DeliveryComplete.Response;
import in.co.daalchini.data.transporatable.SchedulePickup.Request;
import in.co.daalchini.data.untransportable.AuthUserDetails;
import in.co.daalchini.data.untransportable.FulfillmentMode;
import in.co.daalchini.data.untransportable.OrderSource;
import in.co.daalchini.data.untransportable.OrderState;
import in.co.daalchini.exception.ItemNotFoundException;
import in.co.daalchini.models.MachineManufacturerVariantSkuGroup;
import in.co.daalchini.models.Order;
import in.co.daalchini.models.OrderLineItem;
import in.co.daalchini.models.PartnerItemTransaction;
import in.co.daalchini.repository.OrderRepository;
import in.co.daalchini.service.external.PaymentApiService;
import in.co.daalchini.service.http.OrderService;
import in.co.daalchini.service.http.PaymentService;
import io.vavr.Tuple;
import io.vavr.Tuple4;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Log4j2
@RestController
public class OrderRoute {

    private final PaymentApiService paymentApiService;
    private final OrderService orderService;
    private final OrderRepository orderRepository;
    private final PaymentService paymentService;

    @Autowired
    public OrderRoute (
        PaymentApiService paymentApiService,
        OrderService orderService,
        OrderRepository orderRepository,
        PaymentService paymentService)
    {
        this.paymentApiService = paymentApiService;
        this.orderService = orderService;
        this.orderRepository = orderRepository;
        this.paymentService = paymentService;
    }


    /**
     * @param request Combination of vend and fulfilment API
     * @return dummy response on request submission
     * @deprecated Unguarded API - for manual user
     */
    @Deprecated
    @PostMapping(OrderContext.DELIVERY_COMPLETE)
    public DeliveryComplete.Response deliveryOrderComplete (
        @RequestBody DeliveryComplete.Request request)
    {
        log.info("deliveryOrderComplete - begin, request = {}", request);
        final String orderId = request.getOrderId();

        final Optional<Order> orderIdOptional = orderRepository.findById(orderId);
        if (orderIdOptional.isPresent()) {
            final Order order = orderIdOptional.get();

            paymentApiService.vendOrder(VendOrder.Request.of(request, order.getPhone()));
            orderService.fulfilOrder(
                FulfilOrder.Request.of(request),
                Tuple.of(orderId, request.getVendingMachineId()));

            final Response response = Response.builder().orderId(orderId).build();

            log.info("deliveryOrderComplete - end, response = {}", response);
            return response;
        } else {
            log.warn("No order found for orderId = {}", orderId);
            throw new ItemNotFoundException("Order not found");
        }
    }

    @PostMapping(OrderContext.ORDER_COMPLETE)
    public DeliveryComplete.Response orderComplete (
        @RequestBody OrderComplete.Request request)
    {
        log.info("orderComplete - begin, request = {}", request);
        final String orderId = request.getOrderId();

        final Optional<Order> orderIdOptional = orderRepository.findById(orderId);
        if (orderIdOptional.isPresent()) {
            try {
                final Order order = orderIdOptional.get();
                final Response response = Response.builder().orderId(orderId).build();
                final OrderState status = order.getStatus();
                if (status.equals(OrderState.COMPLETED)) {
                    log.info("orderComplete, already completed, sending success, order = {}", order);
                    return response;
                }
                paymentApiService.vendOrder(VendOrder.Request.of(request, order.getPhone()));
                orderService.fulfilOrder(
                    FulfilOrder.Request.of(request),
                    Tuple.of(orderId, request.getVendingMachineId()));

                log.info("orderComplete - end, response = {}", response);
                return response;
            } catch (Exception e) {
                log.warn("Unable to complete order", e);
                throw new RuntimeException("Unable to complete order", e);
            }
        } else {
            log.warn("No order found for orderId = {}", orderId);
            throw new ItemNotFoundException("Order not found");
        }
    }

    @PreAuthorize("hasAuthority('bulk_purchase')")
    @PostMapping(OrderContext.ORDER_PAYMENT)
    public OrderPayment.Response orderPayment (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @PathVariable String orderId,
        @RequestBody OrderPayment.Request request)
    {
        log.info("[orderPayment], userDetails = {},  orderId = {}, request = {}", userDetails, orderId, request);
        OrderPayment.Response response = paymentService.initiatePayment(userDetails.getUserId(), orderId, request);

        log.info("[orderPayment], responses = {}", response);
        return response;
    }

    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority('order_approve')")
    @PostMapping(OrderContext.ORDER_FULFIL)
    public NullResponse fulfilPartnerOrder (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @RequestHeader(value = "X-fulfilment-mode", required = false) String fulfillmentMode,
        @PathVariable String orderId,
        @RequestBody OrderFulfil.Request request)
    {
        log.info("[fulfilPartnerOrder], userDetails = {}, fulfillmentMode = {}, orderId = {}, request = {}",
                 fulfillmentMode, userDetails, orderId, request);
        try {
            Tuple4<Order, List<MachineManufacturerVariantSkuGroup>, List<PartnerItemTransaction>, List<OrderLineItem>> tuple4 =
                orderService.preparePartnerFulfil(orderId, request);

            orderService.fulfilPartnerOrder(
                FulfillmentMode.of(fulfillmentMode),
                request,
                tuple4._1(),
                tuple4._2(),
                tuple4._3(),
                tuple4._4());
        } catch (Exception e) {
            log.error("[fulfilPartnerOrder], error = ", e);
            throw e;
        }

        NullResponse response = NullResponse.of("Request submitted");
        log.info("[fulfilPartnerOrder], response = {}", response);

        return response;
    }

    @PreAuthorize("hasAuthority('order_approve')")
    @GetMapping(OrderContext.ORDER_FETCH_SCHEDULED)
    public List<ScheduledPickupDelivery.Response> orderFetchScheduledPickupDelivery (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @RequestParam(value = "limit", required = false) Integer limit,
        @RequestParam(value = "pageNumber", required = false) Integer pageNumber)
    {
        log.info("[orderFetchScheduledPickup], userDetails = {}, limit = {}, pageNumber = {}",
                 userDetails, limit, pageNumber);
        List<ScheduledPickupDelivery.Response> responses =
            orderService.fetchScheduledPickups(userDetails.getUserId(), limit, pageNumber);

        log.info("[orderFetchScheduledPickup], response = {}", responses);
        return responses;
    }

    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority('bulk_purchase')")
    @PostMapping(OrderContext.ORDER_SCHEDULE_PICKUP)
    public NullResponse orderSchedulePickup (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @PathVariable String orderId,
        @RequestBody Request request)
    {
        log.info("[orderSchedulePickup], userDetails = {}, orderId = {}, request = {}", userDetails, orderId, request);
        try {
            orderService.schedulePickup(userDetails.getUserId(), orderId, request);
        } catch (Exception e) {
            log.error("[orderSchedulePickup], error = ", e);
        }

        NullResponse response = NullResponse.of("Request submitted");
        log.info("[orderSchedulePickup], response = {}", response);

        return response;
    }

    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority('bulk_purchase')")
    @PostMapping(OrderContext.ORDER_SCHEDULE_DELIVERY)
    public NullResponse orderScheduleDelivery (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @PathVariable String orderId,
        @RequestBody ScheduleDelivery.Request request)
    {
        log.info("[orderScheduleDelivery], user = {}, orderId = {}, request = {}", userDetails, orderId, request);
        try {
            orderService.scheduleDelivery(userDetails.getUserId(), orderId, request);
        } catch (Exception e) {
            log.error("[orderScheduleDelivery], error = ", e);
            throw e;
        }

        NullResponse response = NullResponse.of("Request submitted");
        log.info("[orderScheduleDelivery], response = {}", response);

        return response;
    }

    @PreAuthorize("hasAuthority('bulk_purchase')")
    @GetMapping(OrderContext.ORDER_HISTORY)
    public List<OrderHistory.Response> orderHistory (
        @AuthenticationPrincipal AuthUserDetails userDetails,
        @RequestParam(value = "limit", required = false) Integer limit,
        @RequestParam(value = "pageNumber", required = false) Integer pageNumber)
    {
        log.info("[orderHistory], userDetails = {}, limit = {}, pageNumber = {}", userDetails, limit, pageNumber);
        List<OrderHistory.Response> response =
            orderService.getOrderHistory(userDetails.getUserId(), limit, pageNumber, OrderSource.PartnerApp);

        log.info("[orderHistory], responses = {}", response);
        return response;
    }


    @PreAuthorize("hasAuthority('bulk_purchase')")
    @GetMapping(OrderContext.FETCH_ORDER_DETAIL)
    public FetchOrderDetails.Response orderDetail (@AuthenticationPrincipal AuthUserDetails userDetails,
                                                   @PathVariable String orderId)
    {
        log.info("[orderDetail], userDetails = {}", userDetails);
        try {
            FetchOrderDetails.Response response = orderService.fetchOrderDetails(orderId, userDetails.getUserId());
            log.info("Response :{}", response);
            return response;
        } catch (Exception e) {
            log.error("Error in fetching order details");
            throw e;
        }

    }
}
