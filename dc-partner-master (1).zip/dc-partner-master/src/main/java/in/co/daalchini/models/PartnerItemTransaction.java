package in.co.daalchini.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import in.co.daalchini.data.untransportable.ItemTransactionType;
import in.co.daalchini.data.untransportable.UnitOfMeasurement;
import in.co.daalchini.service.helper.DateTimeHelper;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.StringJoiner;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "partner_item_transactions")
public class PartnerItemTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "partner_id")
    private Long partnerId;

    @Column(name = "manufacturer_variant_id")
    private Long manufacturerVariantId;

    @Column(name = "sku_group_id")
    private Long skuGroupId;

    @Column(name = "uom")
    private UnitOfMeasurement uom;

    @Column(name = "quantity")
    private Long quantity;

    @Column(name = "case_size")
    private Long caseSize;

    @Column(name = "unit_count", insertable = false, updatable = false)
    private Long unitCount;

    @Column(name = "unit_count_final")
    private Long unitCountFinal;

    @Column(name = "transaction_type")
    private ItemTransactionType transactionType;

    @Column(name = "reason")
    private String reason;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    void createTimestamp () {
        this.createdAt = DateTimeHelper.now();
    }

    public Long getUnitCount () {
        Long unitCount = 0L;

        switch (uom) {
            case Unit: {
                unitCount = quantity;
                break;
            }
            case Case: {
                unitCount = quantity * caseSize;
                break;
            }
        }
        return unitCount;
    }

    @Override
    public String toString () {
        return new StringJoiner(", ", PartnerItemTransaction.class.getSimpleName() + "[", "]")
            .add("id=" + id)
            .add("partnerId=" + partnerId)
            .add("manufacturerVariantId=" + manufacturerVariantId)
            .add("skuGroupId=" + skuGroupId)
            .add("uom=" + uom)
            .add("quantity=" + quantity)
            .add("caseSize=" + caseSize)
            .add("unitCount=" + unitCount)
            .add("unitCountFinal=" + unitCountFinal)
            .add("transactionType=" + transactionType)
            .add("reason='" + reason + "'")
            .add("createdAt=" + createdAt)
            .toString();
    }
}
