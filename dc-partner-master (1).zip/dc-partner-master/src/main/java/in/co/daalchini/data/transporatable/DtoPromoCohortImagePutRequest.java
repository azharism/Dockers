package in.co.daalchini.data.transporatable;

import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@JsonIncludeProperties({"promo_image_id", "priority", "duration_sec", "is_mandatory"})
public class DtoPromoCohortImagePutRequest {

    @NotNull
    @JsonProperty("promo_image_id")
    private Long promoImageId;

    @NotNull
    @JsonProperty("priority")
    private Integer priority;

    @NotNull
    @JsonProperty("is_mandatory")
    private boolean mandatory;

    @JsonProperty("duration_sec")
    private Integer durationSec;
}
